import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../models.dart';
import '../store.dart';
import '../theme.dart';

/// 一本书的详情页：只放两个入口（小说资料 / 章节内容）
class BookHomePage extends StatelessWidget {
  const BookHomePage({super.key, required this.bookId});

  final String bookId;

  @override
  Widget build(BuildContext context) {
    final st = AppState.I;
    return AnimatedBuilder(
      animation: st,
      builder: (context, _) {
        final book = st.books.firstWhere(
          (b) => b.id == bookId,
          orElse: () => Novel(),
        );
        return Scaffold(
          appBar: AppBar(
            title: Text(book.title.trim().isEmpty ? '未命名' : book.title),
            actions: [
              PopupMenuButton<String>(
                icon: const Icon(Icons.more_vert, size: 20),
                color: C.cardHi,
                onSelected: (v) => _onMenu(context, st, book, v),
                itemBuilder: (_) => const [
                  PopupMenuItem(value: 'rename', child: Text('修改书名', style: TextStyle(fontSize: 13))),
                  PopupMenuItem(value: 'copy', child: Text('复制全书', style: TextStyle(fontSize: 13))),
                  PopupMenuItem(value: 'delete', child: Text('删除这本书', style: TextStyle(fontSize: 13))),
                ],
              ),
            ],
          ),
          body: ListView(
            padding: const EdgeInsets.fromLTRB(14, 10, 14, 30),
            children: [
              _entry(
                context,
                icon: Icons.chat_bubble_outline,
                title: '继续对话',
                sub: '和 AI 接着聊这本书',
                onTap: () {
                  AppState.I.goTab(0);
                  Navigator.of(context).pop();
                },
              ),
              const SizedBox(height: 10),
              _entry(
                context,
                icon: Icons.folder_open_outlined,
                title: '小说资料',
                sub: '共 ${book.settingWords} 字',
                onTap: () => Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => BookDocsPage(bookId: bookId)),
                ),
              ),
              const SizedBox(height: 10),
              _entry(
                context,
                icon: Icons.menu_book_outlined,
                title: '章节内容',
                sub: book.chapters.isEmpty
                    ? '还没有章节'
                    : '${book.chapters.length} 章 · 正文 ${book.chapterWords} 字',
                onTap: () => Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => BookChaptersPage(bookId: bookId)),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _entry(
    BuildContext context, {
    required IconData icon,
    required String title,
    required String sub,
    required VoidCallback onTap,
  }) {
    return Material(
      color: C.card,
      borderRadius: BorderRadius.circular(14),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(14),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(14, 15, 10, 15),
          child: Row(
            children: [
              Container(
                width: 38,
                height: 38,
                decoration: BoxDecoration(
                  color: const Color(0x337B5CFF),
                  borderRadius: BorderRadius.circular(11),
                ),
                child: Icon(icon, size: 19, color: C.purpleSoft),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title,
                        style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w500)),
                    const SizedBox(height: 3),
                    Text(sub, style: const TextStyle(fontSize: 11.5, color: C.dim)),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right, size: 18, color: C.faint),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _onMenu(BuildContext context, AppState st, Novel book, String v) async {
    final messenger = ScaffoldMessenger.of(context);
    final nav = Navigator.of(context);
    if (v == 'rename') {
      final ctrl = TextEditingController(text: book.title);
      final ok = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          backgroundColor: C.card,
          title: const Text('修改书名', style: TextStyle(fontSize: 15)),
          content: TextField(
            controller: ctrl,
            autofocus: true,
            style: const TextStyle(fontSize: 13.5),
            decoration: const InputDecoration(hintText: '书名'),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('取消')),
            ElevatedButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('保存')),
          ],
        ),
      );
      if (ok == true) {
        await st.renameBook(book.id, ctrl.text.trim());
        messenger.showSnackBar(const SnackBar(content: Text('书名已更新')));
      }
    } else if (v == 'copy') {
      final text = st.exportBookText(book.id);
      await Clipboard.setData(ClipboardData(text: text));
      messenger.showSnackBar(
        SnackBar(content: Text('全书已复制（${text.replaceAll(RegExp(r"\s"), "").length} 字）')),
      );
    } else if (v == 'delete') {
      final ok = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          backgroundColor: C.card,
          title: const Text('删除这本书？'),
          content: Text('「${book.title}」和它的章节会移到回收站，${AppState.trashKeepDays} 天内还能恢复。',
              style: const TextStyle(fontSize: 12.5, height: 1.6)),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('取消')),
            ElevatedButton(
              onPressed: () => Navigator.pop(ctx, true),
              style: ButtonStyle(
                backgroundColor: MaterialStateProperty.all<Color>(const Color(0xFFD9534F)),
                foregroundColor: MaterialStateProperty.all<Color>(Colors.white),
              ),
              child: const Text('删除'),
            ),
          ],
        ),
      );
      if (ok == true) {
        await st.deleteBook(book.id);
        nav.pop();
      }
    }
  }
}

/// 资料文件列表：世界观.md / 人物库.md / 章节摘要.md
class BookDocsPage extends StatelessWidget {
  const BookDocsPage({super.key, required this.bookId});

  final String bookId;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: AppState.I,
      builder: (context, _) {
        final book = AppState.I.books.firstWhere(
          (b) => b.id == bookId,
          orElse: () => Novel(),
        );
        final docs = <List<String>>[
          ['world', '世界观.md', book.world],
          ['characters', '人物库.md', book.characters],
          ['summary', '章节摘要.md', book.summary],
        ];
        return Scaffold(
          appBar: AppBar(
            title: const Text('小说资料'),
            actions: [
              Padding(
                padding: const EdgeInsets.only(right: 14),
                child: Center(
                  child: Text('共 ${book.settingWords} 字',
                      style: const TextStyle(fontSize: 11.5, color: C.dim)),
                ),
              ),
            ],
          ),
          body: ListView(
            padding: const EdgeInsets.fromLTRB(14, 8, 14, 30),
            children: [
              for (final d in docs)
                _fileRow(
                  context,
                  kind: d[0],
                  name: d[1],
                  text: d[2],
                ),
            ],
          ),
        );
      },
    );
  }

  Widget _fileRow(
    BuildContext context, {
    required String kind,
    required String name,
    required String text,
  }) {
    final words = text.replaceAll(RegExp(r'\s'), '').length;
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: C.card,
        borderRadius: BorderRadius.circular(13),
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(13),
        onTap: () => Navigator.of(context).push(
          MaterialPageRoute(
            builder: (_) => BookDocPage(bookId: bookId, kind: kind, name: name),
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(14, 13, 10, 13),
          child: Row(
            children: [
              Container(
                width: 34,
                height: 34,
                decoration: BoxDecoration(
                  color: const Color(0xFF252538),
                  borderRadius: BorderRadius.circular(9),
                ),
                child: const Icon(Icons.description_outlined, size: 17, color: C.purpleSoft),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(name, style: const TextStyle(fontSize: 14)),
                    const SizedBox(height: 2),
                    Text('$words 字', style: const TextStyle(fontSize: 11, color: C.dim)),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right, size: 18, color: C.faint),
            ],
          ),
        ),
      ),
    );
  }
}

/// 单个资料文件的查看 / 编辑
class BookDocPage extends StatefulWidget {
  const BookDocPage({
    super.key,
    required this.bookId,
    required this.kind,
    required this.name,
  });

  final String bookId;
  final String kind; // world | characters | summary
  final String name;

  @override
  State<BookDocPage> createState() => _BookDocPageState();
}

class _BookDocPageState extends State<BookDocPage> {
  late final TextEditingController _ctrl;
  bool _edit = false;

  Novel get _book => AppState.I.books.firstWhere(
        (b) => b.id == widget.bookId,
        orElse: () => Novel(),
      );

  String get _text {
    switch (widget.kind) {
      case 'world':
        return _book.world;
      case 'characters':
        return _book.characters;
      default:
        return _book.summary;
    }
  }

  @override
  void initState() {
    super.initState();
    _ctrl = TextEditingController(text: _text);
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    await AppState.I.updateDoc(widget.kind, _ctrl.text);
    if (!mounted) return;
    setState(() => _edit = false);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('已保存 ${widget.name}')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final text = _text;
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.name),
        actions: [
          TextButton(
            onPressed: () {
              if (_edit) {
                _save();
              } else {
                setState(() {
                  _ctrl.text = text;
                  _edit = true;
                });
              }
            },
            child: Text(
              _edit ? '保存' : '编辑',
              style: const TextStyle(fontSize: 13, color: C.purpleSoft),
            ),
          ),
        ],
      ),
      body: _edit
          ? Padding(
              padding: const EdgeInsets.fromLTRB(14, 10, 14, 14),
              child: TextField(
                controller: _ctrl,
                maxLines: null,
                expands: true,
                textAlignVertical: TextAlignVertical.top,
                style: TextStyle(
                    fontSize: AppState.I.settings.editorFontSize,
                    height: 1.7,
                    color: const Color(0xFFE3E3EE)),
                decoration: const InputDecoration(
                  hintText: '直接改，改完点右上角保存',
                  hintStyle: TextStyle(fontSize: 12, color: C.faint),
                  border: OutlineInputBorder(borderSide: BorderSide.none),
                  filled: true,
                  fillColor: Color(0xFF14141E),
                ),
              ),
            )
          : text.trim().isEmpty
              ? const Center(
                  child: Padding(
                    padding: EdgeInsets.all(28),
                    child: Text(
                      '这个文件还是空的。\n回到「对话」页写一章并点「保存这一章」，再选「同步资料」就会自动生成。',
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 12.5, height: 1.8, color: C.dim),
                    ),
                  ),
                )
              : SingleChildScrollView(
                  padding: const EdgeInsets.fromLTRB(16, 14, 16, 40),
                  child: SelectableText(
                    text,
                    style: const TextStyle(fontSize: 14, height: 1.85, color: Color(0xFFE3E3EE)),
                  ),
                ),
    );
  }
}

/// 章节列表
class BookChaptersPage extends StatelessWidget {
  const BookChaptersPage({super.key, required this.bookId});

  final String bookId;

  static String _preview(String s) {
    final one = s.replaceAll(RegExp(r'\s+'), ' ').trim();
    return one.length <= 28 ? one : '${one.substring(0, 28)}…';
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: AppState.I,
      builder: (context, _) {
        final book = AppState.I.books.firstWhere(
          (b) => b.id == bookId,
          orElse: () => Novel(),
        );
        final chapters = book.chapters;
        return Scaffold(
          appBar: AppBar(
            title: const Text('章节内容'),
            actions: [
              Padding(
                padding: const EdgeInsets.only(right: 14),
                child: Center(
                  child: Text('${chapters.length} 章 · ${book.chapterWords} 字',
                      style: const TextStyle(fontSize: 11.5, color: C.dim)),
                ),
              ),
            ],
          ),
          body: chapters.isEmpty
              ? const Center(
                  child: Padding(
                    padding: EdgeInsets.all(28),
                    child: Text(
                      '还没有保存过章节。\n回到「对话」页，写完一章点「保存这一章」，就会出现在这里。',
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 12.5, height: 1.7, color: C.dim),
                    ),
                  ),
                )
              : ListView.separated(
                  padding: const EdgeInsets.symmetric(vertical: 6),
                  itemCount: chapters.length,
                  separatorBuilder: (_, __) =>
                      const Divider(height: 1, indent: 16, endIndent: 16),
                  itemBuilder: (context, i) {
                    final c = chapters[i];
                    return ListTile(
                      leading: CircleAvatar(
                        radius: 14,
                        backgroundColor: const Color(0x337B5CFF),
                        child: Text('${i + 1}',
                            style: const TextStyle(fontSize: 11, color: C.purpleSoft)),
                      ),
                      title: Text(c.title, style: const TextStyle(fontSize: 13.5)),
                      subtitle: Text(
                        _preview(c.content),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontSize: 11, color: C.dim),
                      ),
                      trailing: Text(
                        '${c.content.replaceAll(RegExp(r'\s'), '').length} 字',
                        style: const TextStyle(fontSize: 10.5, color: C.faint),
                      ),
                      onTap: () => Navigator.of(context).push(
                        MaterialPageRoute(builder: (_) => ChapterDetailPage(chapter: c)),
                      ),
                    );
                  },
                ),
        );
      },
    );
  }
}

/// 章节正文
class ChapterDetailPage extends StatelessWidget {
  const ChapterDetailPage({super.key, required this.chapter});

  final Chapter chapter;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(chapter.title)),
      body: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(18, 16, 18, 40),
        child: SelectableText(
          chapter.content,
          style: const TextStyle(fontSize: 15, height: 1.9, color: Color(0xFFE3E3EE)),
        ),
      ),
    );
  }
}
