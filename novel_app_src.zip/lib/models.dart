import 'dart:convert';

/// 一个章节
class Chapter {
  String title;
  String content;

  Chapter({required this.title, required this.content});

  Map<String, dynamic> toJson() => {'title': title, 'content': content};

  factory Chapter.fromJson(Map<String, dynamic> j) =>
      Chapter(title: j['title'] as String? ?? '未命名', content: j['content'] as String? ?? '');
}

/// 一个可点的选项
class Choice {
  final String label;
  final String hint;

  const Choice(this.label, this.hint);

  factory Choice.fromJson(Map<String, dynamic> j) => Choice(
        (j['label'] ?? j['text'] ?? j['title'] ?? '继续').toString(),
        (j['hint'] ?? j['description'] ?? '').toString(),
      );

  /// 兼容两种写法：{"label": "...", "hint": "..."} 或者直接写一行字
  factory Choice.fromAny(dynamic v) {
    if (v is Map<String, dynamic>) return Choice.fromJson(v);
    if (v is String) return Choice(v, '');
    return const Choice('', '');
  }

  Map<String, dynamic> toJson() => {'label': label, 'hint': hint};
}

/// 一条聊天气泡
class ChatBubble {
  final String role; // 'user' | 'assistant'
  String text;
  List<Choice> options;
  int tokens; // 本轮消耗（含上下文）
  int ms; // 耗时
  String raw; // 模型原始返回，折叠里给用户看
  String reasoning; // 思考过程（推理模型才有）
  List<ToolStep> tools; // 这一轮读了什么、写了什么
  List<String> alts; // 抽卡留下的其他候选（可随时换回来）
  List<WebSource> sources; // 这一轮联网搜索引用的来源
  List<String> attachments; // 这条消息附了哪些文件（只存名字，界面显示用）
  String attachmentText; // 附件正文，发给模型时拼上，界面不显示

  ChatBubble({
    required this.role,
    required this.text,
    List<Choice>? options,
    this.tokens = 0,
    this.ms = 0,
    this.raw = '',
    this.reasoning = '',
    List<ToolStep>? tools,
    List<String>? alts,
    List<WebSource>? sources,
    List<String>? attachments,
    this.attachmentText = '',
  })  : options = options ?? <Choice>[],
        tools = tools ?? <ToolStep>[],
        alts = alts ?? <String>[],
        sources = sources ?? <WebSource>[],
        attachments = attachments ?? <String>[];

  Map<String, dynamic> toJson() => {
        'role': role,
        'text': text,
        'options': options.map((o) => o.toJson()).toList(),
        'tokens': tokens,
        'ms': ms,
        'raw': raw,
        'reasoning': reasoning,
        'tools': tools.map((t) => t.toJson()).toList(),
        'alts': alts,
        'sources': sources.map((x) => x.toJson()).toList(),
        'attachments': attachments,
        'attachmentText': attachmentText,
      };

  factory ChatBubble.fromJson(Map<String, dynamic> j) => ChatBubble(
        role: j['role'] as String? ?? 'assistant',
        text: j['text'] as String? ?? '',
        options: (j['options'] as List<dynamic>? ?? [])
            .map(Choice.fromAny)
            .where((c) => c.label.trim().isNotEmpty)
            .toList(),
        tokens: j['tokens'] as int? ?? 0,
        ms: j['ms'] as int? ?? 0,
        raw: j['raw'] as String? ?? '',
        reasoning: j['reasoning'] as String? ?? '',
        tools: (j['tools'] as List<dynamic>? ?? [])
            .map((e) => ToolStep.fromJson(e as Map<String, dynamic>))
            .toList(),
        alts: (j['alts'] as List<dynamic>? ?? []).map((e) => e.toString()).toList(),
        sources: (j['sources'] as List<dynamic>? ?? [])
            .map((e) => WebSource.fromJson(e as Map<String, dynamic>))
            .toList(),
        attachments:
            (j['attachments'] as List<dynamic>? ?? []).map((e) => e.toString()).toList(),
        attachmentText: j['attachmentText'] as String? ?? '',
      );
}

/// 一次生成记录（脑洞 / 简介），用于「历史」
class GenRecord {
  String id;
  String kind; // idea | blurb
  String title; // 例如「男频 · 都市」
  String input; // 生成时的要求
  String output; // 生成结果
  int createdAt;

  GenRecord({
    String? id,
    this.kind = 'idea',
    this.title = '',
    this.input = '',
    this.output = '',
    int? createdAt,
  })  : id = id ?? DateTime.now().microsecondsSinceEpoch.toString(),
        createdAt = createdAt ?? DateTime.now().millisecondsSinceEpoch;

  Map<String, dynamic> toJson() => {
        'id': id,
        'kind': kind,
        'title': title,
        'input': input,
        'output': output,
        'createdAt': createdAt,
      };

  factory GenRecord.fromJson(Map<String, dynamic> j) => GenRecord(
        id: j['id'] as String? ?? '',
        kind: j['kind'] as String? ?? 'idea',
        title: j['title'] as String? ?? '',
        input: j['input'] as String? ?? '',
        output: j['output'] as String? ?? '',
        createdAt: j['createdAt'] as int?,
      );
}

/// 待发送的附件（已解析成纯文本）
class ChatFile {
  final String name;
  final String text;
  const ChatFile(this.name, this.text);

  /// 去掉空白后的字数，界面上显示用
  int get chars => text.replaceAll(RegExp(r'\s'), '').length;
}

/// 一条联网搜索结果
class WebSource {
  final String title;
  final String url;
  final String snippet;
  final String site; // 站点名或域名，界面显示用

  const WebSource({
    required this.title,
    required this.url,
    this.snippet = '',
    this.site = '',
  });

  Map<String, dynamic> toJson() => {
        'title': title,
        'url': url,
        'snippet': snippet,
        'site': site,
      };

  factory WebSource.fromJson(Map<String, dynamic> j) => WebSource(
        title: j['title'] as String? ?? '',
        url: j['url'] as String? ?? '',
        snippet: j['snippet'] as String? ?? '',
        site: j['site'] as String? ?? '',
      );
}

/// 一条备忘录
class Note {
  String id;
  String text;
  String category; // 默认 / 灵感 / 大纲
  int createdAt;

  Note({
    String? id,
    this.text = '',
    this.category = '默认',
    int? createdAt,
  })  : id = id ?? DateTime.now().microsecondsSinceEpoch.toString(),
        createdAt = createdAt ?? DateTime.now().millisecondsSinceEpoch;

  Map<String, dynamic> toJson() => {
        'id': id,
        'text': text,
        'category': category,
        'createdAt': createdAt,
      };

  factory Note.fromJson(Map<String, dynamic> j) => Note(
        id: j['id'] as String? ?? '',
        text: j['text'] as String? ?? '',
        category: j['category'] as String? ?? '默认',
        createdAt: j['createdAt'] as int?,
      );
}

/// 一轮对话里实际发生的「工具动作」，用于在界面上显示成卡片
class ToolStep {
  final String action; // 加载技能 / 读取 / 写入
  final String name; // 人物库.md
  final String detail; // 内容预览，点开才看

  const ToolStep(this.action, this.name, [this.detail = '']);

  Map<String, dynamic> toJson() => {'a': action, 'n': name, 'd': detail};

  factory ToolStep.fromJson(Map<String, dynamic> j) => ToolStep(
        j['a'] as String? ?? '',
        j['n'] as String? ?? '',
        j['d'] as String? ?? '',
      );
}

/// 一问一答向导的一步
class WizardStep {
  final String title;
  final String question;
  final List<String> options;

  const WizardStep(this.title, this.question, this.options);
}

/// 新建小说向导：题材 → 风格 → 主角
const List<WizardStep> kNewBookWizard = [
  WizardStep('题材', '这本新书想写哪个题材方向？', ['都市异能', '东方玄幻', '悬疑惊悚', '科幻末日']),
  WizardStep('风格节奏', '叙事风格与节奏偏好？', ['爽文快节奏', '慢热细腻', '轻松幽默', '暗黑压抑']),
  WizardStep('主角', '主角设定倾向？', ['男性主角', '女性主角', '双主角', '让 AI 来定']),
];

/// 一本书：书名 + 三份维护文档 + 章节 + 这本书自己的聊天记录
class Novel {
  String id;
  String title;
  String characters; // 人物库
  String world; // 世界观
  String summary; // 章节摘要
  List<Chapter> chapters;
  List<ChatBubble> chats;
  List<Note> notes;
  List<GenRecord> gens; // 脑洞 / 简介的生成历史
  int updatedAt; // 毫秒时间戳
  int deletedAt; // 0 = 正常；>0 = 在回收站里（毫秒时间戳）

  Novel({
    String? id,
    this.title = '',
    this.characters = '',
    this.world = '',
    this.summary = '',
    List<Chapter>? chapters,
    List<ChatBubble>? chats,
    List<Note>? notes,
    List<GenRecord>? gens,
    int? updatedAt,
    this.deletedAt = 0,
  })  : id = id ?? DateTime.now().microsecondsSinceEpoch.toString(),
        chapters = chapters ?? <Chapter>[],
        chats = chats ?? <ChatBubble>[],
        notes = notes ?? <Note>[],
        gens = gens ?? <GenRecord>[],
        updatedAt = updatedAt ?? DateTime.now().millisecondsSinceEpoch;

  bool get deleted => deletedAt > 0;

  bool get isEmpty =>
      title.trim().isEmpty &&
      characters.trim().isEmpty &&
      world.trim().isEmpty &&
      chapters.isEmpty;

  /// 新书还没开始：没有章节，三份资料也都是空的（书名填了也算）
  bool get needsSetup =>
      chapters.isEmpty &&
      characters.trim().isEmpty &&
      world.trim().isEmpty &&
      summary.trim().isEmpty;

  /// 只算章节正文
  int get chapterWords =>
      chapters.fold<int>(0, (sum, c) => sum + c.content.replaceAll(RegExp(r'\s'), '').length);

  /// 人物库 + 世界观 + 章节摘要
  int get settingWords =>
      (characters + world + summary).replaceAll(RegExp(r'\s'), '').length;

  /// 全书字数（正文 + 设定）
  int get wordCount => chapterWords + settingWords;

  void touch() => updatedAt = DateTime.now().millisecondsSinceEpoch;

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'characters': characters,
        'world': world,
        'summary': summary,
        'chapters': chapters.map((c) => c.toJson()).toList(),
        'chats': chats.map((c) => c.toJson()).toList(),
        'notes': notes.map((n) => n.toJson()).toList(),
        'gens': gens.map((g) => g.toJson()).toList(),
        'updatedAt': updatedAt,
        if (deletedAt > 0) 'deletedAt': deletedAt,
      };

  factory Novel.fromJson(Map<String, dynamic> j) => Novel(
        id: j['id'] as String?,
        title: j['title'] as String? ?? '',
        characters: j['characters'] as String? ?? '',
        world: j['world'] as String? ?? '',
        summary: j['summary'] as String? ?? '',
        chapters: (j['chapters'] as List<dynamic>? ?? [])
            .map((e) => Chapter.fromJson(e as Map<String, dynamic>))
            .toList(),
        chats: (j['chats'] as List<dynamic>? ?? [])
            .map((e) => ChatBubble.fromJson(e as Map<String, dynamic>))
            .toList(),
        notes: (j['notes'] as List<dynamic>? ?? [])
            .map((e) => Note.fromJson(e as Map<String, dynamic>))
            .toList(),
        gens: (j['gens'] as List<dynamic>? ?? [])
            .map((e) => GenRecord.fromJson(e as Map<String, dynamic>))
            .toList(),
        updatedAt: j['updatedAt'] as int?,
        deletedAt: j['deletedAt'] as int? ?? 0,
      );

  /// 最近 n 章的正文，拼成给模型看的上下文
  String recentChapters(int n) {
    if (chapters.isEmpty) return '（暂无已保存章节）';
    final start = chapters.length - n < 0 ? 0 : chapters.length - n;
    final buf = StringBuffer();
    for (var i = start; i < chapters.length; i++) {
      buf.writeln('### ${chapters[i].title}');
      buf.writeln(_clip(chapters[i].content, 1200));
      buf.writeln();
    }
    return buf.toString();
  }

  static String _clip(String s, int max) =>
      s.length <= max ? s : '${s.substring(0, max)}……（后略）';
}

/// 模型清单里的一项
class ModelOption {
  final String name; // 显示名
  final String provider; // 供应商（用来取对应的 Key）
  final String baseUrl;
  final String model;
  final bool free;

  const ModelOption(this.name, this.provider, this.baseUrl, this.model, {this.free = false});
}

/// 内置模型清单。只放确认能连通的，其余让用户「自定义」加。
const List<ModelOption> kModels = [
  ModelOption('GLM-4-Flash', '智谱', 'https://open.bigmodel.cn/api/paas/v4', 'glm-4-flash', free: true),
  ModelOption('Qwen2.5-7B', '硅基流动', 'https://api.siliconflow.cn/v1', 'Qwen/Qwen2.5-7B-Instruct', free: true),
  ModelOption('DeepSeek-V3', 'DeepSeek', 'https://api.deepseek.com/v1', 'deepseek-chat'),
  ModelOption('DeepSeek-R1', 'DeepSeek', 'https://api.deepseek.com/v1', 'deepseek-reasoner'),
  ModelOption('Qwen-Plus', '通义千问', 'https://dashscope.aliyuncs.com/compatible-mode/v1', 'qwen-plus'),
  ModelOption('GLM-4-Plus', '智谱', 'https://open.bigmodel.cn/api/paas/v4', 'glm-4-plus'),
  ModelOption('GPT-4o mini', 'OpenAI', 'https://api.openai.com/v1', 'gpt-4o-mini'),
];

/// 支持的供应商（设置页填 Key 用）
const List<String> kProviders = ['智谱', '硅基流动', 'DeepSeek', '通义千问', 'OpenAI'];

/// 模型一次回复解析后的结果
class AiReply {
  final String message;
  final List<Choice> options;
  final String chapterTitle;
  final String chapterContent;
  final Map<String, String> docs;
  final String bookTitle; // 模型给的建议书名（用户选定后才写进书）

  AiReply({
    required this.message,
    this.options = const [],
    this.chapterTitle = '',
    this.chapterContent = '',
    this.docs = const {},
    this.bookTitle = '',
  });

  bool get hasBookTitle => bookTitle.trim().isNotEmpty;

  bool get hasChapter => chapterContent.trim().isNotEmpty;
  bool get hasDocs => docs.values.any((v) => v.trim().isNotEmpty);

  /// 把模型原始输出解析成结构化结果。
  /// 三层兜底：分隔符协议 → JSON → 纯文本启发式（列表转选项、长文转章节）。
  static AiReply parse(String raw) {
    final text = raw.trim();
    if (text.isEmpty) return AiReply(message: '');

    final delimited = _parseDelimited(text);
    if (delimited != null) return delimited;

    final json = _parseJson(text);
    if (json != null) return json;

    return _fallback(text);
  }

  // ---------- 第一层：分隔符协议 ----------

  static final RegExp _marker =
      RegExp(r'[\[【]\s*(选项|章节|人物库|世界观|章节摘要|书名)\s*[\]】]');

  static AiReply? _parseDelimited(String text) {
    final matches = _marker.allMatches(text).toList();
    if (matches.isEmpty) return null;

    final message = text.substring(0, matches.first.start).trim();
    final options = <Choice>[];
    final docs = <String, String>{};
    String chapterTitle = '';
    String chapterContent = '';
    var bookTitle = '';

    for (var i = 0; i < matches.length; i++) {
      final kind = matches[i].group(1);
      final bodyStart = matches[i].end;
      final bodyEnd = i + 1 < matches.length ? matches[i + 1].start : text.length;
      final body = text.substring(bodyStart, bodyEnd).trim();
      if (kind == '选项') {
        options.addAll(_listOptions(body));
      } else if (kind == '书名') {
        final first = body.split('\n').first.trim();
        bookTitle = first
            .replaceAll(RegExp(r'^#+\s*'), '')
            .replaceAll(RegExp(r'^[《「]+|[》」]+$'), '')
            .replaceAll(RegExp(r'^书名[:：]\s*'), '')
            .trim();
      } else if (kind != '章节') {
        // 人物库 / 世界观 / 章节摘要
        final key = kind == '人物库'
            ? 'characters'
            : kind == '世界观'
                ? 'world'
                : 'summary';
        if (body.isNotEmpty) docs[key] = body;
      } else {
        final lines = body.split('\n');
        var idx = 0;
        while (idx < lines.length && lines[idx].trim().isEmpty) {
          idx++;
        }
        if (idx < lines.length) {
          chapterTitle = lines[idx].trim().replaceAll(RegExp(r'^#+\s*'), '');
          chapterContent = lines.skip(idx + 1).join('\n').trim();
        }
      }
    }

    if (chapterContent.isEmpty &&
        options.isEmpty &&
        message.isEmpty &&
        docs.isEmpty &&
        bookTitle.isEmpty) {
      return null;
    }
    return AiReply(
      message: message,
      options: options,
      chapterTitle: chapterTitle,
      chapterContent: chapterContent,
      docs: docs,
      bookTitle: bookTitle,
    );
  }

  // ---------- 第二层：JSON（兼容老格式 / 其他模型） ----------

  static AiReply? _parseJson(String text) {
    final start = text.indexOf('{');
    final end = text.lastIndexOf('}');
    if (start < 0 || end <= start) return null;
    try {
      final map = jsonDecode(text.substring(start, end + 1)) as Map<String, dynamic>;
      final rawOpts =
          (map['options'] ?? map['choices'] ?? map['suggestions']) as List<dynamic>? ?? [];
      final opts = rawOpts
          .map(Choice.fromAny)
          .where((c) => c.label.trim().isNotEmpty)
          .toList();
      final chap = map['chapter'];
      var cTitle = '';
      var cContent = '';
      if (chap is Map<String, dynamic>) {
        cTitle = (chap['title'] ?? '').toString();
        cContent = (chap['content'] ?? '').toString();
      }
      final docsRaw = map['docs'];
      final docs = <String, String>{};
      if (docsRaw is Map<String, dynamic>) {
        for (final k in ['characters', 'world', 'summary']) {
          final v = docsRaw[k];
          if (v != null) docs[k] = v.toString();
        }
      }
      final bookTitle =
          (map['bookTitle'] ?? map['title'] ?? '').toString().trim();
      final msg = (map['message'] ?? map['reply'] ?? '').toString();
      if (msg.isEmpty && cContent.isEmpty && opts.isEmpty) return null;
      return AiReply(
        message: msg.isEmpty ? '（模型只返回了章节内容）' : msg,
        options: opts,
        chapterTitle: cTitle,
        chapterContent: cContent,
        docs: docs,
        bookTitle: bookTitle,
      );
    } catch (_) {
      return null;
    }
  }

  // ---------- 第三层：纯文本启发式 ----------

  static AiReply _fallback(String text) {
    // Markdown 里直接写「## 人物库 / ## 世界观 / ## 章节摘要」：当成资料处理
    final docs = _guessDocs(text);
    if (docs.isNotEmpty) {
      final first = RegExp(
        r'^\s*#{1,6}\s*(人物库|世界观|章节摘要)(?:\.md)?\s*$',
        multiLine: true,
      ).firstMatch(text);
      final before = first == null ? '' : text.substring(0, first.start).trim();
      return AiReply(
        message: before,
        options: _listOptions(before),
        docs: docs,
      );
    }

    final longText = text.replaceAll(RegExp(r'\s'), '').length > 600;
    // 长回复也看一眼最后几行，技能常在解释末尾列几个选项
    final lines = text.split('\n');
    final tail = longText && lines.length > 12
        ? lines.sublist(lines.length - 12).join('\n')
        : text;
    final opts = _listOptions(tail);
    var title = '';
    var content = '';
    if (longText) {
      final guessed = _guessChapter(text);
      if (guessed != null) {
        title = guessed[0];
        content = guessed[1];
      }
    }
    // 有选项时把选项行从正文里剔掉，别让用户看到两遍
    var shown = text;
    if (opts.isNotEmpty) {
      final kept = text
          .split('\n')
          .where((l) => _bullet.firstMatch(l.trim()) == null)
          .join('\n')
          .trim();
      if (kept.isNotEmpty) shown = kept;
    }

    return AiReply(
      message: shown,
      options: opts,
      chapterTitle: title,
      chapterContent: content,
    );
  }

  /// 从「- 选项 | 说明」「1. 选项」「• 选项」这类行里抽选项
  static final RegExp _bullet = RegExp(r'^\s*(?:[-*•·]|\d{1,2}[.、)）])\s*(.+)$');

  static List<Choice> _listOptions(String body) {
    final out = <Choice>[];
    for (final line in body.split('\n')) {
      final m = _bullet.firstMatch(line.trim());
      if (m == null) continue;
      var item = m.group(1)!.trim();
      // 去掉「1. xxx」这类残留编号
      item = item.replaceFirst(RegExp(r'^\d{1,2}[.、)）]\s*'), '');
      if (item.isEmpty) continue;
      var label = item;
      var hint = '';
      final sep = item.indexOf('|');
      if (sep > 0) {
        label = item.substring(0, sep).trim();
        hint = item.substring(sep + 1).trim();
      } else {
        final colon = item.indexOf('：');
        if (colon > 0 && colon <= 14) {
          label = item.substring(0, colon).trim();
          hint = item.substring(colon + 1).trim();
        }
      }
      if (label.length > 16) continue; // 太长的是正文，不是选项
      out.add(Choice(label, hint));
      if (out.length >= 5) break;
    }
    return out.length >= 2 ? out : <Choice>[];
  }

  /// 从「## 人物库」这类 Markdown 标题里认出三份资料（至少两份才算）
  static final RegExp _docHeading =
      RegExp(r'^\s*#{1,6}\s*(人物库|世界观|章节摘要)(?:\.md)?\s*$');
  static Map<String, String> _guessDocs(String text) {
    const keys = {'人物库': 'characters', '世界观': 'world', '章节摘要': 'summary'};
    final found = <String, String>{};
    final buf = StringBuffer();
    String? key;

    void flush() {
      if (key == null) return;
      final body = buf.toString().trim();
      if (body.length >= 12) found[key!] = body;
      buf.clear();
      key = null;
    }

    for (final line in text.split('\n')) {
      final m = _docHeading.firstMatch(line);
      if (m != null) {
        flush();
        key = keys[m.group(1)!];
        continue;
      }
      if (key != null) buf.writeln(line);
    }
    flush();
    return found.length >= 2 ? found : <String, String>{};
  }

  /// 从长文本里认出「第X章 标题 + 正文」
  static List<String>? _guessChapter(String text) {
    final lines = text.split('\n');
    final re = RegExp(r'^\s*#*\s*第\s*[0-9一二三四五六七八九十百零两]+\s*章(?:\s|[:：、.．\-—]|$)');
    for (var i = 0; i < lines.length; i++) {
      final line = lines[i].trim();
      if (line.length > 40) continue;
      if (!re.hasMatch(line)) continue;
      final body = lines.skip(i + 1).join('\n').trim();
      if (body.replaceAll(RegExp(r'\s'), '').length < 300) continue;
      return [line.replaceAll(RegExp(r'^#+\s*'), ''), body];
    }
    return null;
  }
}

/// 一个技能（内置或用户导入）
class SkillDoc {
  final String id;
  String name;
  String content;
  final bool builtin;
  final String path; // 导入时的文件路径，内置为空

  SkillDoc({
    required this.id,
    required this.name,
    required this.content,
    this.builtin = false,
    this.path = '',
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'content': content,
        'builtin': builtin,
        'path': path,
      };

  factory SkillDoc.fromJson(Map<String, dynamic> j) => SkillDoc(
        id: j['id'] as String? ?? '',
        name: j['name'] as String? ?? '未命名技能',
        content: j['content'] as String? ?? '',
        builtin: j['builtin'] as bool? ?? false,
        path: j['path'] as String? ?? '',
      );
}

String _fixSkillId(String? raw) {
  final v = (raw ?? '').trim();
  if (v.isEmpty || v == 'builtin') return 'builtin:novel-writer';
  return v;
}

/// 自定义接入的一套配置
class CustomConfig {
  String name;
  String baseUrl;
  String apiKey;
  String model;
  String format; // 'openai' | 'anthropic'
  List<String> models;

  CustomConfig({
    this.name = '',
    this.baseUrl = '',
    this.apiKey = '',
    this.model = '',
    this.format = 'openai',
    List<String>? models,
  }) : models = models ?? <String>[];

  Map<String, dynamic> toJson() => {
        'name': name,
        'baseUrl': baseUrl,
        'apiKey': apiKey,
        'model': model,
        'format': format,
        'models': models,
      };

  factory CustomConfig.fromJson(Map<String, dynamic> j) => CustomConfig(
        name: j['name'] as String? ?? '',
        baseUrl: j['baseUrl'] as String? ?? '',
        apiKey: j['apiKey'] as String? ?? '',
        model: j['model'] as String? ?? '',
        format: j['format'] as String? ?? 'openai',
        models: (j['models'] as List<dynamic>? ?? []).map((e) => e.toString()).toList(),
      );
}

/// 设置：走 OpenAI 兼容接口，任何家都能用
class Settings {
  String baseUrl;
  String apiKey; // 当前生效的那把
  String model;
  String provider; // 当前供应商
  Map<String, String> keys; // 每个供应商各存一把
  double temperature; // 0~1.4，越高越发散
  bool followSystemTheme;
  String format; // 'openai' | 'anthropic'
  List<CustomConfig> customConfigs;
  int totalTokens; // 累计 token（本地统计）
  int requestCount; // 累计请求次数
  String thinkingLevel; // default | off | low | medium | high | deep
  bool agentEnabled; // 工具调用（Agent 模式）
  String sourceBase; // 小说站域名，如 https://www.xxx.com
  bool scanEnabled; // 扫榜开关
  String marketFeedUrl; // Skill 广场订阅源（JSON）
  bool autoCompact; // 上下文自动压缩
  int contextWindowK; // 上下文窗口（K tokens）
  int maxOutputK; // 最大输出（K tokens），仅 Anthropic 生效
  int outputReserveK; // 给输出预留（K tokens）
  String customPrompt; // 自定义系统提示词，空=用默认
  double chatFontSize; // 聊天字号
  double editorFontSize; // 编辑器字号
  bool soundEnabled; // 完成后提示音
  String themeMode; // system | dark
  String webdavUrl;
  String webdavUser;
  String webdavPass;
  String webdavPath;
  bool searchEnabled; // 联网搜索
  String searchProvider; // bing | bocha
  String searchKey; // 博查 Key，bing 不需要
  int searchCount; // 每次取几条结果
  String storageMode; // app | saf
  String safUri;
  String safName;
  List<SkillDoc> importedSkills; // 用户导入的技能
  String activeSkillId; // 当前主技能
  String styleSkillId; // 附加的风格技能（空=不用）
  List<String> disabledSkills; // 被关掉的技能 id
  List<String> allowedDirs; // 已「始终允许」的目录

  Settings({
    // 默认走智谱免费模型，新用户不花钱就能把流程跑通
    this.baseUrl = 'https://open.bigmodel.cn/api/paas/v4',
    this.apiKey = '',
    this.model = 'glm-4-flash',
    this.provider = '智谱',
    Map<String, String>? keys,
    this.temperature = 0.9,
    this.followSystemTheme = true,
    this.format = 'openai',
    List<CustomConfig>? customConfigs,
    this.totalTokens = 0,
    this.requestCount = 0,
    this.thinkingLevel = 'default',
    this.agentEnabled = true,
    this.sourceBase = '',
    this.scanEnabled = false,
    this.marketFeedUrl = '',
    this.autoCompact = true,
    this.contextWindowK = 200,
    this.maxOutputK = 32,
    this.outputReserveK = 16,
    this.customPrompt = '',
    this.chatFontSize = 14,
    this.editorFontSize = 14,
    this.soundEnabled = true,
    this.themeMode = 'system',
    this.webdavUrl = '',
    this.webdavUser = '',
    this.webdavPass = '',
    this.webdavPath = '/OpenWrite/',
    this.searchEnabled = false,
    this.searchProvider = 'bing',
    this.searchKey = '',
    this.searchCount = 5,
    this.storageMode = 'app',
    this.safUri = '',
    this.safName = '',
    List<SkillDoc>? importedSkills,
    this.activeSkillId = 'builtin:novel-writer',
    this.styleSkillId = '',
    List<String>? disabledSkills,
    List<String>? allowedDirs,
  })  : importedSkills = importedSkills ?? <SkillDoc>[],
        allowedDirs = allowedDirs ?? <String>[],
        disabledSkills = disabledSkills ?? <String>[],
        keys = keys ?? <String, String>{},
        customConfigs = customConfigs ?? <CustomConfig>[];

  bool get isReady =>
      apiKey.trim().isNotEmpty && baseUrl.trim().isNotEmpty && model.trim().isNotEmpty;

  Map<String, dynamic> toJson() => {
        'baseUrl': baseUrl,
        'apiKey': apiKey,
        'model': model,
        'provider': provider,
        'keys': keys,
        'temperature': temperature,
        'followSystemTheme': followSystemTheme,
        'format': format,
        'customConfigs': customConfigs.map((c) => c.toJson()).toList(),
        'totalTokens': totalTokens,
        'requestCount': requestCount,
        'thinkingLevel': thinkingLevel,
        'agentEnabled': agentEnabled,
        'sourceBase': sourceBase,
        'scanEnabled': scanEnabled,
        'marketFeedUrl': marketFeedUrl,
        'autoCompact': autoCompact,
        'contextWindowK': contextWindowK,
        'maxOutputK': maxOutputK,
        'outputReserveK': outputReserveK,
        'customPrompt': customPrompt,
        'chatFontSize': chatFontSize,
        'editorFontSize': editorFontSize,
        'soundEnabled': soundEnabled,
        'themeMode': themeMode,
        'webdavUrl': webdavUrl,
        'webdavUser': webdavUser,
        'webdavPass': webdavPass,
        'webdavPath': webdavPath,
        'searchEnabled': searchEnabled,
        'searchProvider': searchProvider,
        'searchKey': searchKey,
        'searchCount': searchCount,
        'storageMode': storageMode,
        'safUri': safUri,
        'safName': safName,
        'importedSkills': importedSkills.map((e) => e.toJson()).toList(),
        'activeSkillId': activeSkillId,
        'styleSkillId': styleSkillId,
        'disabledSkills': disabledSkills,
        'allowedDirs': allowedDirs,
      };

  factory Settings.fromJson(Map<String, dynamic> j) => Settings(
        baseUrl: j['baseUrl'] as String? ?? 'https://open.bigmodel.cn/api/paas/v4',
        apiKey: j['apiKey'] as String? ?? '',
        model: j['model'] as String? ?? 'glm-4-flash',
        provider: j['provider'] as String? ?? '智谱',
        keys: (j['keys'] as Map?)?.map((k, v) => MapEntry(k.toString(), v.toString())) ?? {},
        temperature: (j['temperature'] as num?)?.toDouble() ?? 0.9,
        followSystemTheme: j['followSystemTheme'] as bool? ?? true,
        format: j['format'] as String? ?? 'openai',
        customConfigs: (j['customConfigs'] as List<dynamic>? ?? [])
            .map((e) => CustomConfig.fromJson(e as Map<String, dynamic>))
            .toList(),
        totalTokens: j['totalTokens'] as int? ?? 0,
        requestCount: j['requestCount'] as int? ?? 0,
        thinkingLevel: j['thinkingLevel'] as String? ?? 'default',
        agentEnabled: j['agentEnabled'] as bool? ?? true,
        sourceBase: j['sourceBase'] as String? ?? '',
        scanEnabled: j['scanEnabled'] as bool? ?? false,
        marketFeedUrl: j['marketFeedUrl'] as String? ?? '',
        autoCompact: j['autoCompact'] as bool? ?? true,
        contextWindowK: j['contextWindowK'] as int? ?? 200,
        maxOutputK: j['maxOutputK'] as int? ?? 32,
        outputReserveK: j['outputReserveK'] as int? ?? 16,
        customPrompt: j['customPrompt'] as String? ?? '',
        chatFontSize: (j['chatFontSize'] as num?)?.toDouble() ?? 14,
        editorFontSize: (j['editorFontSize'] as num?)?.toDouble() ?? 14,
        soundEnabled: j['soundEnabled'] as bool? ?? true,
        themeMode: j['themeMode'] as String? ?? 'system',
        webdavUrl: j['webdavUrl'] as String? ?? '',
        webdavUser: j['webdavUser'] as String? ?? '',
        webdavPass: j['webdavPass'] as String? ?? '',
        webdavPath: j['webdavPath'] as String? ?? '/OpenWrite/',
        searchEnabled: j['searchEnabled'] as bool? ?? false,
        searchProvider: j['searchProvider'] as String? ?? 'bing',
        searchKey: j['searchKey'] as String? ?? '',
        searchCount: j['searchCount'] as int? ?? 5,
        storageMode: j['storageMode'] as String? ?? 'app',
        safUri: j['safUri'] as String? ?? '',
        safName: j['safName'] as String? ?? '',
        importedSkills: (j['importedSkills'] as List<dynamic>? ?? [])
            .map((e) => SkillDoc.fromJson(e as Map<String, dynamic>))
            .toList(),
        activeSkillId: _fixSkillId(j['activeSkillId'] as String?),
        styleSkillId: j['styleSkillId'] as String? ?? '',
        disabledSkills: (j['disabledSkills'] as List<dynamic>? ?? [])
            .map((e) => e.toString())
            .toList(),
        allowedDirs: (j['allowedDirs'] as List<dynamic>? ?? []).map((e) => e.toString()).toList(),
      );
}
