import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:novel_app/models.dart';
import 'package:novel_app/store.dart';
import 'package:novel_app/web_search.dart';

const String _base = 'http://127.0.0.1:8777';

Future<Novel> _book() async {
  SharedPreferences.setMockInitialValues(<String, Object>{});
  await AppState.I.init();
  final b = Novel(title: '灰烬纪元')
    ..characters = '叶烬，24 岁，殡仪馆火化工。';
  AppState.I.books = [b];
  AppState.I.currentId = b.id;
  AppState.I.settings
    ..baseUrl = '$_base/v1'
    ..apiKey = 'k'
    ..model = 'm'
    ..format = 'openai'
    ..agentEnabled = false
    ..searchEnabled = true
    ..searchProvider = 'bing'
    ..searchKey = ''
    ..searchCount = 5
    ..requestCount = 0
    ..totalTokens = 0;
  return b;
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  setUpAll(() {
    HttpOverrides.global = null;
    bingBase = '$_base/bing';
    bochaBase = '$_base/bocha';
  });

  test('普通模式：先搜再回答，气泡挂上来源', () async {
    await _book();
    await AppState.I.send('联网查一下都市小说榜');

    final last = AppState.I.novel.chats.last;
    expect(last.text.contains('已看到搜索结果'), isTrue);
    expect(last.sources.length, 5);
    expect(last.sources.first.url, startsWith('https://'));
    expect(last.tools.any((t) => t.action == '联网搜索'), isTrue);
    expect(last.tools.first.name, '必应');
    expect(AppState.I.errorText, isNull);
  });

  test('Agent 模式：模型自己调 web_search，步骤与来源都对', () async {
    await _book();
    AppState.I.settings.agentEnabled = true;

    await AppState.I.send('联网找一下最近的都市小说榜');

    final last = AppState.I.novel.chats.last;
    expect(last.tools.first.name, '联网搜索');
    expect(last.tools.first.detail.contains('都市小说榜'), isTrue);
    expect(last.sources.length, 5);
    expect(AppState.I.settings.requestCount, 2);
  });

  test('关掉开关：不搜索、不挂来源', () async {
    await _book();
    AppState.I.settings.searchEnabled = false;

    await AppState.I.send('联网查一下都市小说榜');

    final last = AppState.I.novel.chats.last;
    expect(last.sources, isEmpty);
    expect(last.tools.any((t) => t.action == '联网搜索'), isFalse);
  });

  test('博查没填 Key：明确报错，这一轮仍然回答', () async {
    await _book();
    AppState.I.settings
      ..searchProvider = 'bocha'
      ..searchKey = '';

    await AppState.I.send('联网查一下都市小说榜');

    final last = AppState.I.novel.chats.last;
    expect(AppState.I.errorText, contains('联网搜索失败'));
    expect(last.sources, isEmpty);
    expect(last.tools.first.detail, contains('失败'));
    expect(last.text.trim(), isNotEmpty);
  });
}
