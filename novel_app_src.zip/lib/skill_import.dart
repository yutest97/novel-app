import 'dart:convert';
import 'dart:typed_data';

import 'package:archive/archive.dart';
import 'package:file_picker/file_picker.dart';

import 'doc_text.dart';

/// 用户选中的文件
class PickedSkill {
  final String name;
  final String path;
  final String content;

  PickedSkill(this.name, this.path, this.content);
}

/// 选文件失败时抛这个，界面可以把 message 直接给用户看
class SkillPickException implements Exception {
  final String message;
  SkillPickException(this.message);
  @override
  String toString() => message;
}

const List<String> _allTextExts = ['txt', 'md', 'markdown', 'docx'];

/// 技能包里的单个文件最多带多少字，防止一个包把对话撑爆
const int kSkillPackMaxChars = 120000;

/// 让用户从手机里选一个技能文件（.md / .txt / .zip 技能包）
Future<PickedSkill?> pickSkillFile() =>
    _pick(allowed: const ['md', 'markdown', 'txt', 'zip']);

/// 选一个小说文本文件（txt / md / docx），返回抽好的纯文本
Future<PickedSkill?> pickTextFile() => _pick(allowed: _allTextExts);

Future<PickedSkill?> _pick({required List<String> allowed}) async {
  FilePickerResult? res;
  try {
    // 用 FileType.any：部分国产 ROM 下 custom + MIME 过滤会匹配不到任何 Activity，
    // 表现就是「点了没反应」。先让它弹出系统选择器，选完我们自己校验后缀。
    res = await FilePicker.platform.pickFiles(
      type: FileType.any,
      allowMultiple: false,
      withData: true,
    );
  } catch (e) {
    throw SkillPickException('打不开系统文件选择器：$e\n可以先在文件管理器里确认有这个文件。');
  }

  if (res == null || res.files.isEmpty) return null; // 用户取消

  final f = res.files.first;
  final lower = f.name.toLowerCase();
  if (!allowed.any((e) => lower.endsWith('.$e'))) {
    throw SkillPickException('只支持 ${allowed.join("、")} 格式，你选的是「${f.name}」');
  }

  final bytes = f.bytes;
  if (bytes == null) {
    throw SkillPickException('读不到文件内容。如果是网盘/微信里的文件，先下载到本机再选。');
  }

  if (lower.endsWith('.zip')) {
    return readSkillZip(f.name, f.path ?? '', bytes);
  }

  return PickedSkill(f.name, f.path ?? '', extractText(f.name, bytes));
}

/// 解一个 .zip 技能包：找 SKILL.md，连同 references 里的 md/txt 一起拼成一份内容。
/// 结构和内置技能一致（每个文件前加一行「===== 路径 原文开始 =====」）。
PickedSkill readSkillZip(String fileName, String filePath, List<int> bytes) {
  if (bytes.length > 20 * 1024 * 1024) {
    throw SkillPickException('这个包超过 20MB，技能包一般没这么大。可以先解压，只把 SKILL.md 传进来。');
  }
  Archive archive;
  try {
    archive = ZipDecoder().decodeBytes(bytes);
  } catch (e) {
    throw SkillPickException('这个 zip 打不开，可能下载不完整或加了密码：$e');
  }

  final files = <_ZipEntry>[];
  for (final f in archive.files) {
    if (!f.isFile) continue;
    final name = f.name.replaceAll('\\', '/');
    if (name.contains('__MACOSX/')) continue;
    final base = name.split('/').last;
    if (base.isEmpty || base.startsWith('.')) continue;
    final lower = name.toLowerCase();
    final isText = lower.endsWith('.md') || lower.endsWith('.markdown') || lower.endsWith('.txt');
    if (!isText) continue;
    final content = utf8.decode(f.content as List<int>, allowMalformed: true).trim();
    if (content.isEmpty) continue;
    files.add(_ZipEntry(name, content));
  }

  if (files.isEmpty) {
    throw SkillPickException('压缩包里没找到 Markdown 文件。技能包至少要有一个 SKILL.md。');
  }

  // SKILL.md 排最前面，其余按路径排，读的时候有主次
  files.sort((a, b) {
    final am = a.isSkillMd ? 0 : 1;
    final bm = b.isSkillMd ? 0 : 1;
    if (am != bm) return am.compareTo(bm);
    if (a.path.length != b.path.length) return a.path.length.compareTo(b.path.length);
    return a.path.compareTo(b.path);
  });

  final main = files.firstWhere(
    (e) => e.isSkillMd,
    orElse: () => files.first,
  );
  final folder = main.path.contains('/')
      ? main.path.substring(0, main.path.lastIndexOf('/')).split('/').last
      : '';
  final zipBase = fileName.replaceAll(RegExp(r'\.zip$', caseSensitive: false), '').trim();
  final name = _cleanName(main.isSkillMd && folder.isNotEmpty ? folder : zipBase);

  final buf = StringBuffer();
  var used = 0;
  var cut = false;
  for (final e in files) {
    final block = StringBuffer()
      ..writeln('===== ${e.path} 原文开始 =====')
      ..writeln(e.content)
      ..writeln('===== ${e.path} 原文结束 =====')
      ..writeln();
    if (used + block.length > kSkillPackMaxChars) {
      cut = true;
      break;
    }
    used += block.length;
    buf.write(block);
  }
  if (cut) {
    buf.writeln('（技能包太大，后面的附件没有导入。可以删掉用不上的 references 再打包。）');
  }

  return PickedSkill(
    name.isEmpty ? '导入的技能' : name,
    filePath,
    buf.toString().trim(),
  );
}

/// 名字收拾干净：下划线换空格、去掉多余空白，太长截断
String _cleanName(String raw) {
  var s = raw.trim().replaceAll(RegExp(r'[_\s]+'), ' ');
  if (s.length > 40) s = s.substring(0, 40).trim();
  return s;
}

class _ZipEntry {
  final String path;
  final String content;
  _ZipEntry(this.path, this.content);

  bool get isSkillMd {
    final base = path.split('/').last.toLowerCase();
    return base == 'skill.md';
  }
}

/// 让用户选个位置把文本存成文件（系统文件选择器 / SAF）。
/// 返回保存路径；用户取消返回 null；打不开面板抛 SkillPickException。
Future<String?> saveTextFile(
  String name,
  String content, {
  String title = '保存文件',
  List<String> exts = const ['txt'],
}) async {
  try {
    return await FilePicker.platform.saveFile(
      dialogTitle: title,
      fileName: name,
      type: FileType.custom,
      allowedExtensions: exts,
      bytes: Uint8List.fromList(utf8.encode(content)),
    );
  } catch (e) {
    throw SkillPickException('打不开保存面板：$e');
  }
}

/// 让用户选个位置把备份存成文件（系统文件选择器 / SAF）。
/// 返回保存路径；用户取消返回 null；打不开面板抛 SkillPickException。
Future<String?> saveBackupFile(String name, String content) =>
    saveTextFile(name, content, title: '保存备份', exts: const ['json']);

/// 选一个备份文件，读回内容
Future<PickedSkill?> pickBackupFile() => _pick(allowed: const ['json']);
