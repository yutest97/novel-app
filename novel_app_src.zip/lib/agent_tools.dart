import 'web_search.dart';

/// 注册给模型的工具声明（OpenAI 兼容格式）
const List<Map<String, dynamic>> kAgentToolSpecs = <Map<String, dynamic>>[
  {
    'type': 'function',
    'function': {
      'name': 'read_doc',
      'description': '读取本书的一份资料。name 只能是：世界观、人物库、章节摘要。',
      'parameters': {
        'type': 'object',
        'properties': {
          'name': {
            'type': 'string',
            'enum': ['世界观', '人物库', '章节摘要'],
            'description': '要读哪一份',
          },
        },
        'required': ['name'],
      },
    },
  },
  {
    'type': 'function',
    'function': {
      'name': 'list_chapters',
      'description': '列出已保存的章节：序号、标题、字数。写新章前先看这个。',
      'parameters': {'type': 'object', 'properties': {}},
    },
  },
  {
    'type': 'function',
    'function': {
      'name': 'read_chapter',
      'description': '读某一章正文。用 index（从 1 开始）或 title 关键词指定。',
      'parameters': {
        'type': 'object',
        'properties': {
          'index': {'type': 'integer', 'description': '章节序号，从 1 开始'},
          'title': {'type': 'string', 'description': '章节标题关键词，index 没给时用'},
        },
      },
    },
  },
  {
    'type': 'function',
    'function': {
      'name': 'search_book',
      'description': '在小说书源网站搜索书名，返回前几条书名和链接。用于找参考书、查热门书。',
      'parameters': {
        'type': 'object',
        'properties': {
          'title': {'type': 'string', 'description': '书名或关键词'},
        },
        'required': ['title'],
      },
    },
  },
  {
    'type': 'function',
    'function': {
      'name': 'read_notes',
      'description': '读用户的备忘录（写作灵感、待办、设定草稿）。',
      'parameters': {'type': 'object', 'properties': {}},
    },
  },
];

/// 按当前开关决定给模型哪些工具
List<Map<String, dynamic>> agentToolSpecs({bool webSearch = false}) =>
    <Map<String, dynamic>>[
      ...kAgentToolSpecs,
      if (webSearch) kWebSearchToolSpec,
    ];
