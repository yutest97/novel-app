import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'dart:convert';
import 'dart:io';

import 'package:archive/archive.dart';
import 'package:novel_app/app_version.dart';
import 'package:novel_app/doc_text.dart';
import 'package:novel_app/main.dart';
import 'package:novel_app/models.dart';
import 'package:novel_app/skill.dart';
import 'package:novel_app/store.dart';

void main() {
  test('刚打开时没有可重试的动作', () async {
    SharedPreferences.setMockInitialValues(<String, Object>{});
    await AppState.I.init();
    expect(AppState.I.canRetry, isFalse);
  });

  test('刚打开时书架是空的（不该有占位空书）', () async {
    SharedPreferences.setMockInitialValues(<String, Object>{});
    await AppState.I.init();
    expect(AppState.I.books.length, 1); // 内部占位
    expect(AppState.I.visibleBooks, isEmpty); // 但不显示
  });

  testWidgets('打开 App 能看到三个页签和开场引导', (tester) async {
    SharedPreferences.setMockInitialValues(<String, Object>{});
    await AppState.I.init();
    await tester.pumpWidget(const NovelApp());
    await tester.pumpAndSettle();

    expect(find.text('对话'), findsWidgets);
    expect(find.text('小说'), findsWidgets);
    expect(find.text('设置'), findsWidgets);
    expect(find.text('新书启航'), findsOneWidget);
    expect(find.text('你的 AI 小说写作助手'), findsOneWidget);
  });

  parserTests();

  // 回归：底部栏点击必须能切页（曾经点不动的 bug）
  testWidgets('底部栏能切到小说和设置页', (tester) async {
    SharedPreferences.setMockInitialValues(<String, Object>{});
    await AppState.I.init();
    await tester.pumpWidget(const NovelApp());
    await tester.pumpAndSettle();

    await tester.tap(find.text('小说').first);
    await tester.pumpAndSettle();
    expect(find.text('我的小说'), findsOneWidget);

    await tester.tap(find.text('设置').first);
    await tester.pumpAndSettle();
    expect(find.text('管理 AI、外观、同步和应用数据'), findsOneWidget);

    await tester.tap(find.text('对话').first);
    await tester.pumpAndSettle();
    expect(find.text('新对话'), findsWidgets);
  });

  test('txt 文本原样读出', () {
    expect(extractText('a.txt', utf8.encode('第一章 雨夜\n雨下得很大。')), contains('雨下得很大'));
  });

  test('docx 能抽出正文', () {
    const xml = '<w:document><w:body>'
        '<w:p><w:r><w:t>第一段文字</w:t></w:r></w:p>'
        '<w:p><w:r><w:t>第二段文字</w:t></w:r></w:p>'
        '</w:body></w:document>';
    final bytes = utf8.encode(xml);
    final archive = Archive()..addFile(ArchiveFile('word/document.xml', bytes.length, bytes));
    final zip = ZipEncoder().encode(archive)!;
    final text = extractText('样本.docx', zip);
    expect(text.contains('第一段文字'), isTrue);
    expect(text.contains('第二段文字'), isTrue);
  });

  test('版本号常量与 pubspec 一致', () {
    final pubspec = File('pubspec.yaml').readAsStringSync();
    final m = RegExp(r'^version:\s*([0-9.]+)', multiLine: true).firstMatch(pubspec);
    expect(m, isNotNull, reason: 'pubspec.yaml 里找不到 version');
    expect(m!.group(1), kAppVersion, reason: '改了 pubspec 版本就要同步 lib/app_version.dart');
  });

  test('技能包能被读到', () async {
    final text = await SkillPack.load();
    expect(text.contains('小说写作助手'), isTrue);
    expect(text.contains('人物库'), isTrue);
  });

  test('第二个内置技能（技能创作）也打进去了', () async {
    final text = await SkillPack.load('builtin:skill-creator');
    expect(text.contains('技能创建助手'), isTrue);
    expect(text.contains('SKILL.md'), isTrue);
  });
}

// 下面是针对「模型不按格式返回」的回归测试

void parserTests() {
  test('模型只回大白话时，不崩、选项为空', () {
    final r = AiReply.parse('当然有，我直接给你几个现成的主角模板。');
    expect(r.message.contains('主角模板'), isTrue);
    expect(r.options, isEmpty);
    expect(r.hasChapter, isFalse);
  });

  test('选项写成字符串数组也能解析', () {
    final r = AiReply.parse('{"message":"选一个","options":["程序员","外卖员"]}');
    expect(r.options.length, 2);
    expect(r.options.first.label, '程序员');
  });

  test('分隔符协议：选项', () {
    final r = AiReply.parse('[选项]\n- 现实主义 | 展现真实都市生活\n- 轻松幽默 | 轻松愉快');
    expect(r.options.length, 2);
    expect(r.options.first.label, '现实主义');
    expect(r.options.first.hint, '展现真实都市生活');
  });

  test('分隔符协议：章节', () {
    final body = '雨下得很大。' * 120;
    final r = AiReply.parse('[章节]\n第1章 雨夜\n$body');
    expect(r.chapterTitle, '第1章 雨夜');
    expect(r.hasChapter, isTrue);
    expect(r.options, isEmpty);
  });

  test('模型只回大白话 + 数字列表：自动变成选项', () {
    const raw = '好的，已选择都市异能题材。接下来，请选择小说的风格：\n\n'
        '1. 现实主义\n2. 轻松幽默\n3. 悬疑推理\n4. 浪漫爱情\n\n请选择您喜欢的风格。';
    final r = AiReply.parse(raw);
    expect(r.options.length, 4);
    expect(r.options.first.label, '现实主义');
    // 正文里不应再出现选项行
    expect(r.message.contains('1. 现实主义'), isFalse);
  });

  test('分隔符协议：三份资料', () {
    final r = AiReply.parse('[人物库]\n# 人物库\n## 主角\n陈烬\n\n'
        '[世界观]\n# 世界观\n废弃都市\n\n'
        '[章节摘要]\n第1章 雨夜\n陈烬捡到系统');
    expect(r.hasDocs, isTrue);
    expect(r.docs['characters'], contains('陈烬'));
    expect(r.docs['world'], contains('废弃都市'));
    expect(r.docs['summary'], contains('第1章'));
  });

  test('模型只回长文：自动认出章节', () {
    final body = '雨下得很大，陈烬把车停在桥洞下。' * 40;
    final raw = '第一章正文创作完成，以下是本章内容。\n\n第1章 雨夜\n$body';
    final r = AiReply.parse(raw);
    expect(r.hasChapter, isTrue);
    expect(r.chapterTitle, '第1章 雨夜');
  });

  test('字段名叫 choices、外面裹着代码块也能解析', () {
    final r = AiReply.parse('```json\n{"message":"选","choices":[{"label":"A","hint":"a"}]}\n```');
    expect(r.options.single.label, 'A');
    expect(r.options.single.hint, 'a');
  });
}
