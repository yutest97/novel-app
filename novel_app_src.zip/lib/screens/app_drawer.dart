import 'package:flutter/material.dart';

import '../app_version.dart';
import '../models.dart';
import '../store.dart';
import '../theme.dart';
import 'simple_pages.dart';

/// 侧边栏：会话（每本书一条）+ 底部套餐入口
class AppDrawer extends StatelessWidget {
  const AppDrawer({super.key});

  @override
  Widget build(BuildContext context) {
    final st = AppState.I;
    return AnimatedBuilder(
      animation: st,
      builder: (context, _) {
        final groups = _group(st.visibleBooks);
        return Drawer(
          width: 300,
          backgroundColor: const Color(0xFF0E0E16),
          child: SafeArea(
            child: Column(
              children: [
                _header(),
                _row(
                  icon: Icons.add,
                  label: '新对话',
                  onTap: () async {
                    Navigator.pop(context);
                    await st.createBook();
                    st.goTab(0);
                  },
                ),
                _row(
                  icon: Icons.delete_sweep_outlined,
                  label: '批量删除对话',
                  color: const Color(0xFFE06C63),
                  onTap: () {
                    Navigator.pop(context);
                    _openBatchDelete(context);
                  },
                ),
                const SizedBox(height: 6),
                Expanded(
                  child: groups.isEmpty
                      ? const Center(
                          child: Text('还没有对话', style: TextStyle(fontSize: 12, color: C.faint)),
                        )
                      : ListView(
                          padding: const EdgeInsets.only(bottom: 8),
                          children: [
                            for (final g in groups) ...[
                              Padding(
                                padding: const EdgeInsets.fromLTRB(18, 10, 18, 4),
                                child: Text(g.label,
                                    style: const TextStyle(fontSize: 11, color: C.faint)),
                              ),
                              for (final b in g.books) _bookRow(context, b),
                            ],
                          ],
                        ),
                ),
                _footer(context),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _header() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 10),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFF9B7BFF), Color(0xFF5B3FE0)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(11),
            ),
            child: const Icon(Icons.auto_awesome, color: Colors.white, size: 20),
          ),
          const SizedBox(width: 10),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: const [
              Text('AI 写小说', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
              SizedBox(height: 2),
              Text('v$kAppVersion', style: TextStyle(fontSize: 10.5, color: C.faint)),
            ],
          ),
        ],
      ),
    );
  }

  Widget _row({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
    Color? color,
  }) {
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
        child: Row(
          children: [
            Icon(icon, size: 17, color: color ?? C.purpleSoft),
            const SizedBox(width: 12),
            Text(label, style: TextStyle(fontSize: 13.5, color: color ?? C.text)),
          ],
        ),
      ),
    );
  }

  Widget _bookRow(BuildContext context, Novel b) {
    final st = AppState.I;
    final active = b.id == st.currentId;
    return InkWell(
      onTap: () async {
        Navigator.pop(context);
        await st.switchBook(b.id);
        st.goTab(0);
      },
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 1),
        padding: const EdgeInsets.fromLTRB(10, 9, 4, 9),
        decoration: BoxDecoration(
          color: active ? const Color(0xFF1D1830) : Colors.transparent,
          borderRadius: BorderRadius.circular(8),
        ),
        child: Row(
          children: [
            Icon(Icons.chat_bubble_outline, size: 14, color: active ? C.purpleSoft : C.faint),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                b.title.trim().isEmpty ? '未命名对话' : b.title,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(fontSize: 12.5, color: active ? C.purpleSoft : C.text),
              ),
            ),
            Text(_ago(b.updatedAt), style: const TextStyle(fontSize: 10, color: C.faint)),
            IconButton(
              onPressed: () async {
                final nav = Navigator.of(context);
                await st.deleteBook(b.id);
                nav.pop();
              },
              icon: const Icon(Icons.delete_outline, size: 15, color: C.faint),
              splashRadius: 14,
              constraints: const BoxConstraints(minWidth: 28, minHeight: 28),
              padding: EdgeInsets.zero,
            ),
          ],
        ),
      ),
    );
  }

  Widget _footer(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 10),
      decoration: const BoxDecoration(
        border: Border(top: BorderSide(color: C.border, width: 0.6)),
      ),
      child: Row(
        children: [
          Expanded(
            child: InkWell(
              onTap: () => _openPlanSheet(context),
              borderRadius: BorderRadius.circular(9),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 9),
                decoration: BoxDecoration(
                  color: C.card,
                  borderRadius: BorderRadius.circular(9),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 18,
                      height: 18,
                      decoration: BoxDecoration(
                        color: const Color(0x337B5CFF),
                        borderRadius: BorderRadius.circular(9),
                      ),
                      child: const Icon(Icons.person, size: 11, color: C.purpleSoft),
                    ),
                    const SizedBox(width: 8),
                    const Text('免费版', style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w500)),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(width: 8),
          IconButton(
            onPressed: () {
              Navigator.pop(context);
              AppState.I.goTab(2);
            },
            icon: const Icon(Icons.settings_outlined, size: 18, color: C.dim),
            splashRadius: 18,
          ),
        ],
      ),
    );
  }

  /// 点「免费版」弹出的菜单
  void _openPlanSheet(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (sheetCtx) => Container(
        decoration: const BoxDecoration(
          color: C.surface,
          borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
        ),
        child: SafeArea(
          top: false,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 38,
                height: 4,
                margin: const EdgeInsets.symmetric(vertical: 10),
                decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(2)),
              ),
              _sheetItem(context, Icons.palette_outlined, '界面主题', const ThemePage()),
              _sheetItem(context, Icons.receipt_long_outlined, '我的套餐', const ComingPage(
                title: '我的套餐',
                desc: '当前是免费版：所有现有功能都不收费，也没有需要激活的套餐。\n以后如果加云端同步、批量生成，会在设置页提前说明。',
              )),
              _sheetItem(context, Icons.extension_outlined, 'Skill 管理', const SkillPage()),
              _sheetItem(context, Icons.help_outline, '使用教程', const GuidePage()),
              _sheetItem(context, Icons.refresh, '检查更新', null, onTap: () {
                Navigator.pop(sheetCtx);
                showDialog<void>(
                  context: context,
                  builder: (ctx) => AlertDialog(
                    backgroundColor: C.card,
                    title: const Text('检查更新'),
                    content: const Text(
                      '当前版本 v$kAppVersion（最新）。\n\n这个 App 没有自动更新服务器：有新版本时，我重新打包，你从 GitHub 下载新 APK 覆盖安装即可，书稿会保留。',
                      style: TextStyle(fontSize: 12.5, height: 1.7),
                    ),
                    actions: [
                      TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('知道了')),
                    ],
                  ),
                );
              }),
              _sheetItem(context, Icons.settings_outlined, '全部设置', null, onTap: () {
                Navigator.pop(sheetCtx);
                Navigator.pop(context); // 关掉侧边栏
                AppState.I.goTab(2);
              }),
              const SizedBox(height: 10),
            ],
          ),
        ),
      ),
    );
  }

  Widget _sheetItem(BuildContext context, IconData icon, String label, Widget? page,
      {VoidCallback? onTap}) {
    return ListTile(
      leading: Icon(icon, size: 19, color: C.purpleSoft),
      title: Text(label, style: const TextStyle(fontSize: 14)),
      onTap: onTap ??
          () {
            Navigator.pop(context);
            Navigator.of(context).push(MaterialPageRoute(builder: (_) => page!));
          },
    );
  }

  /// 按「今天 / 昨天 / 更早」分组
  List<_Group> _group(List<Novel> books) {
    final sorted = List<Novel>.from(books)
      ..sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
    final today = <Novel>[];
    final yesterday = <Novel>[];
    final older = <Novel>[];
    final now = DateTime.now();
    for (final b in sorted) {
      final d = DateTime.fromMillisecondsSinceEpoch(b.updatedAt);
      final days = DateTime(now.year, now.month, now.day)
          .difference(DateTime(d.year, d.month, d.day))
          .inDays;
      if (days <= 0) {
        today.add(b);
      } else if (days == 1) {
        yesterday.add(b);
      } else {
        older.add(b);
      }
    }
    final out = <_Group>[];
    if (today.isNotEmpty) out.add(_Group('今天', today));
    if (yesterday.isNotEmpty) out.add(_Group('昨天', yesterday));
    if (older.isNotEmpty) out.add(_Group('更早', older));
    return out;
  }

  void _openBatchDelete(BuildContext context) {
    final st = AppState.I;
    final selected = <String>{};
    showDialog<void>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDlg) => AlertDialog(
          backgroundColor: C.card,
          title: const Text('批量删除对话'),
          content: SizedBox(
            width: double.maxFinite,
            height: 320,
            child: st.visibleBooks.isEmpty
                ? const Center(child: Text('没有可删除的对话', style: TextStyle(fontSize: 12, color: C.dim)))
                : ListView(
                    children: [
                      for (final b in st.visibleBooks)
                        CheckboxListTile(
                          value: selected.contains(b.id),
                          dense: true,
                          contentPadding: EdgeInsets.zero,
                          activeColor: C.purple,
                          title: Text(
                            b.title.trim().isEmpty ? '未命名对话' : b.title,
                            style: const TextStyle(fontSize: 13),
                          ),
                          subtitle: Text('${b.chapters.length} 章 · ${_ago(b.updatedAt)}',
                              style: const TextStyle(fontSize: 10.5, color: C.dim)),
                          onChanged: (v) => setDlg(() {
                            if (v == true) {
                              selected.add(b.id);
                            } else {
                              selected.remove(b.id);
                            }
                          }),
                        ),
                    ],
                  ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('取消')),
            ElevatedButton(
              onPressed: () async {
                final ids = selected.toList();
                Navigator.pop(ctx);
                for (final id in ids) {
                  await st.deleteBook(id);
                }
              },
              style: ButtonStyle(
                backgroundColor: MaterialStateProperty.all<Color>(const Color(0xFFD9534F)),
              ),
              child: Text('删除 ${selected.length} 条', style: const TextStyle(fontSize: 13)),
            ),
          ],
        ),
      ),
    );
  }

  static String _ago(int ms) {
    final diff = DateTime.now().difference(DateTime.fromMillisecondsSinceEpoch(ms));
    if (diff.inMinutes < 1) return '刚刚';
    if (diff.inMinutes < 60) return '${diff.inMinutes} 分钟前';
    if (diff.inHours < 24) return '${diff.inHours} 小时前';
    return '${diff.inDays} 天前';
  }
}


class _Group {
  final String label;
  final List<Novel> books;
  _Group(this.label, this.books);
}
