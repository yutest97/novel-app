import 'package:flutter/material.dart';

import '../book_sources.dart';
import '../novel_source.dart';
import '../skill_import.dart';
import 'source_dialog.dart';
import '../store.dart';
import '../theme.dart';

/// 按「第X章」切分整本 txt
List<List<String>> splitChapters(String text) {
  final re = RegExp(r'^第\s*[0-9０-９一二三四五六七八九十百千零两]+\s*章.*$',
      multiLine: true);
  final matches = re.allMatches(text).toList();
  if (matches.isEmpty) return const [];
  final out = <List<String>>[];
  for (var i = 0; i < matches.length; i++) {
    final start = matches[i].start;
    final end = i + 1 < matches.length ? matches[i + 1].start : text.length;
    final title = matches[i].group(0)!.trim();
    final body = text.substring(start + matches[i].group(0)!.length, end).trim();
    out.add([title, body]);
  }
  return out;
}

/// 小说拆解：搜书源 / 上传 txt → 选章 → AI 分析
class DeconstructSheet extends StatefulWidget {
  const DeconstructSheet({super.key});

  @override
  State<DeconstructSheet> createState() => _DeconstructSheetState();
}

class _DeconstructSheetState extends State<DeconstructSheet> {
  // search：首页；books：搜索结果；chapters：目录
  String _stage = 'search';

  final TextEditingController _title = TextEditingController();

  List<SourceBook> _books = const [];
  String _bookTitle = '';
  List<SourceChapter> _webChapters = const [];
  final Set<int> _webPicked = <int>{};

  // 本地 txt
  List<List<String>> _chapters = const [];
  final Set<int> _picked = <int>{};
  String _fileName = '';

  bool _busy = false;
  String _progress = '';

  @override
  void dispose() {
    _title.dispose();
    super.dispose();
  }

  Future<void> _searchWeb() async {
    final messenger = ScaffoldMessenger.of(context);
    final title = _title.text.trim();
    if (title.isEmpty) {
      messenger.showSnackBar(const SnackBar(content: Text('先填书名')));
      return;
    }
    setState(() {
      _busy = true;
      _progress = '正在找可用书源…';
    });
    try {
      final base = await AppState.I.ensureSource(
        onProgress: (m) {
          if (mounted) setState(() => _progress = m);
        },
      );
      if (base.isEmpty) {
        if (mounted) {
          setState(() {
            _busy = false;
            _progress = '';
          });
        }
        await _askManualSource();
        return;
      }
      if (mounted) setState(() => _progress = '正在搜索…');
      final list = await searchBooks(base, title);
      if (!mounted) return;
      setState(() {
        _books = list;
        _stage = 'books';
      });
    } on NovelFetchException catch (e) {
      messenger.showSnackBar(
        SnackBar(content: Text(e.message), duration: const Duration(seconds: 6)),
      );
    } catch (e) {
      messenger.showSnackBar(SnackBar(content: Text('搜索失败：$e')));
    } finally {
      if (mounted) {
        setState(() {
          _busy = false;
          _progress = '';
        });
      }
    }
  }

  /// 全部内置源都失效时，问一次
  Future<void> _askManualSource() async {
    final messenger = ScaffoldMessenger.of(context);
    final manual = await askSourceManually(
      context,
      message: '内置书源这次都没连上（可能是网络或站点换了域名）。'
          '你可以填一个自己打得开的书站，只需要这一次。',
    );
    if (manual == null) return;
    await AppState.I.setSourceBase(manual);
    if (!mounted) return;
    messenger.showSnackBar(SnackBar(content: Text('已记住书源：$manual')));
    await _searchWeb();
  }

  /// 换一个内置书源重试
  Future<void> _switchSource() async {
    final messenger = ScaffoldMessenger.of(context);
    setState(() {
      _busy = true;
      _progress = '正在换源…';
    });
    try {
      final base = await AppState.I.ensureSource(
        forceReprobe: true,
        onProgress: (m) {
          if (mounted) setState(() => _progress = m);
        },
      );
      if (!mounted) return;
      if (base.isEmpty) {
        await _askManualSource();
      } else {
        messenger.showSnackBar(SnackBar(content: Text('已换到：${Uri.parse(base).host}')));
      }
    } finally {
      if (mounted) {
        setState(() {
          _busy = false;
          _progress = '';
        });
      }
    }
  }

  Future<void> _openBook(SourceBook book) async {
    final messenger = ScaffoldMessenger.of(context);
    setState(() {
      _busy = true;
      _progress = '正在打开目录…';
    });
    try {
      final list = await fetchChapters(book.url);
      if (!mounted) return;
      setState(() {
        _bookTitle = book.title;
        _webChapters = list;
        _webPicked
          ..clear()
          ..addAll(List.generate(list.length > 3 ? 3 : list.length, (i) => i));
        _stage = 'chapters';
      });
      messenger.showSnackBar(SnackBar(content: Text('共 ${list.length} 章，已选前 3 章')));
    } on NovelFetchException catch (e) {
      messenger.showSnackBar(
        SnackBar(content: Text(e.message), duration: const Duration(seconds: 6)),
      );
    } finally {
      if (mounted) {
        setState(() {
          _busy = false;
          _progress = '';
        });
      }
    }
  }

  Future<void> _analyzeWeb() async {
    if (_webPicked.isEmpty) return;
    final messenger = ScaffoldMessenger.of(context);
    final nav = Navigator.of(context);
    final st = AppState.I;

    final picked = _webPicked.toList()..sort();
    final chosen = picked.take(3).toList(); // 最多抓 3 章，再多太慢
    final contents = <String>[];

    setState(() => _busy = true);
    try {
      for (var i = 0; i < chosen.length; i++) {
        if (!mounted) return;
        setState(() => _progress = '抓正文 ${i + 1}/${chosen.length}…');
        contents.add(await fetchChapterContent(_webChapters[chosen[i]].url));
      }
    } on NovelFetchException catch (e) {
      messenger.showSnackBar(
        SnackBar(content: Text(e.message), duration: const Duration(seconds: 6)),
      );
      if (mounted) setState(() => _busy = false);
      return;
    } finally {
      if (mounted) {
        setState(() {
          _busy = false;
          _progress = '';
        });
      }
    }

    final text = joinChapters(
      chosen.map((i) => _webChapters[i]).toList(),
      contents,
    );
    nav.pop();
    await st.send(
      '【小说拆解】《$_bookTitle》，共选 ${chosen.length} 章。\n'
      '下面是原文节选，请分析：\n'
      '1) 主线剧情与核心冲突\n'
      '2) 每章一句话摘要\n'
      '3) 人物关系与伏笔\n'
      '4) 可复用的写法（节奏、钩子、爽点）\n'
      '最后用 [选项] 给我下一步：继续拆后面 / 生成同类大纲 / 做成风格技能。\n\n'
      '--- 原文开始 ---\n$text--- 原文结束 ---',
    );
  }

  Future<void> _upload() async {
    final messenger = ScaffoldMessenger.of(context);
    setState(() {
      _busy = true;
      _progress = '读取文件…';
    });
    try {
      final f = await pickTextFile();
      if (f == null) return;
      final list = splitChapters(f.content);
      if (!mounted) return;
      setState(() {
        _fileName = f.name;
        _chapters = list;
        _stage = 'chapters';
        _webChapters = const [];
        _webPicked.clear();
        _picked
          ..clear()
          ..addAll(List.generate(list.length > 3 ? 3 : list.length, (i) => i));
      });
      if (list.isEmpty) {
        messenger.showSnackBar(
          const SnackBar(content: Text('没认出章节。文本里需要有「第1章」这样的标题行。')),
        );
      }
    } on SkillPickException catch (e) {
      messenger.showSnackBar(
        SnackBar(content: Text(e.message), duration: const Duration(seconds: 6)),
      );
    } catch (e) {
      messenger.showSnackBar(
        SnackBar(content: Text('读取失败：$e'), duration: const Duration(seconds: 6)),
      );
    } finally {
      if (mounted) {
        setState(() {
          _busy = false;
          _progress = '';
        });
      }
    }
  }

  Future<void> _analyzeTxt() async {
    if (_picked.isEmpty) return;
    final nav = Navigator.of(context);
    final picked = _picked.toList()..sort();
    final buf = StringBuffer();
    var used = 0;
    for (final i in picked) {
      final chunk = '${_chapters[i][0]}\n${_chapters[i][1]}\n\n';
      if (used + chunk.length > 15000) break;
      buf.write(chunk);
      used += chunk.length;
    }
    nav.pop();
    await AppState.I.send(
      '【小说拆解】${_fileName.isEmpty ? "上传文本" : _fileName}，共选 ${picked.length} 章。\n'
      '下面是原文节选，请分析：\n'
      '1) 主线剧情与核心冲突\n'
      '2) 每章一句话摘要\n'
      '3) 人物关系与伏笔\n'
      '4) 可复用的写法（节奏、钩子、爽点）\n'
      '最后用 [选项] 给我下一步：继续拆后面 / 生成同类大纲 / 做成风格技能。\n\n'
      '--- 原文开始 ---\n$buf--- 原文结束 ---',
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: C.surface,
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: SafeArea(
        top: false,
        child: Padding(
          padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 38,
                height: 4,
                margin: const EdgeInsets.symmetric(vertical: 10),
                decoration: BoxDecoration(
                  color: Colors.white24,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(18, 2, 10, 6),
                child: Row(
                  children: [
                    Container(
                      width: 26,
                      height: 26,
                      decoration: BoxDecoration(
                        color: const Color(0x337B5CFF),
                        borderRadius: BorderRadius.circular(7),
                      ),
                      child: const Icon(Icons.auto_stories, size: 14, color: C.purpleSoft),
                    ),
                    const SizedBox(width: 9),
                    Expanded(
                      child: Text(
                        _stage == 'chapters' && _webChapters.isNotEmpty
                            ? _bookTitle
                            : '小说拆解',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                            fontSize: 14.5, fontWeight: FontWeight.w600),
                      ),
                    ),
                    if (_stage != 'search')
                      TextButton(
                        onPressed: () => setState(() {
                          _stage = (_stage == 'chapters' && _webChapters.isNotEmpty)
                              ? 'books'
                              : 'search';
                        }),
                        child: const Text('← 返回',
                            style: TextStyle(fontSize: 12, color: C.dim)),
                      ),
                    IconButton(
                      icon: const Icon(Icons.close, size: 19, color: C.dim),
                      onPressed: () => Navigator.of(context).pop(),
                    ),
                  ],
                ),
              ),
              if (_stage == 'search')
                ..._searchBody()
              else if (_stage == 'books')
                _booksBody()
              else
                _chaptersBody(),
              if (_busy)
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const SizedBox(
                        width: 12,
                        height: 12,
                        child: CircularProgressIndicator(
                            strokeWidth: 1.6, color: C.purpleSoft),
                      ),
                      const SizedBox(width: 8),
                      Text(_progress.isEmpty ? '处理中…' : _progress,
                          style: const TextStyle(fontSize: 11.5, color: C.dim)),
                    ],
                  ),
                ),
              Padding(
                padding: const EdgeInsets.fromLTRB(18, 8, 18, 12),
                child: Row(
                  children: [
                    Expanded(
                      child: TextButton(
                        onPressed: () => Navigator.of(context).pop(),
                        child: const Text('取消',
                            style: TextStyle(fontSize: 12.5, color: C.dim)),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      flex: 2,
                      child: SizedBox(
                        height: 44,
                        child: ElevatedButton(
                          onPressed: _primaryAction(),
                          style: ButtonStyle(
                            backgroundColor: MaterialStateProperty.all<Color>(
                              _primaryAction() == null ? C.cardHi : C.purple,
                            ),
                            foregroundColor: MaterialStateProperty.all<Color>(Colors.white),
                            shape: MaterialStateProperty.all(
                              RoundedRectangleBorder(borderRadius: BorderRadius.circular(11)),
                            ),
                          ),
                          child: Text(_primaryLabel(),
                              style: const TextStyle(fontSize: 13.5, color: Colors.white)),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  VoidCallback? _primaryAction() {
    if (_busy) return null;
    if (_stage == 'search') return _searchWeb;
    if (_stage == 'books') return null;
    if (_webChapters.isNotEmpty) {
      return _webPicked.isEmpty ? null : _analyzeWeb;
    }
    return _picked.isEmpty ? null : _analyzeTxt;
  }

  String _primaryLabel() {
    if (_stage == 'search') return '搜索';
    if (_stage == 'books') return '选一本';
    if (_webChapters.isNotEmpty) return '抓取并分析（最多 3 章）';
    return '分析选中章节';
  }

  List<Widget> _searchBody() {
    return [
      Padding(
        padding: const EdgeInsets.fromLTRB(18, 0, 18, 10),
        child: Align(
          alignment: Alignment.centerLeft,
          child: Text(
            '填书名搜书，书源自动找。也可以直接上传 TXT。',
            style: TextStyle(fontSize: 11, height: 1.6, color: C.dim.withOpacity(0.9)),
          ),
        ),
      ),
      Padding(
        padding: const EdgeInsets.fromLTRB(18, 0, 18, 0),
        child: Container(
          padding: const EdgeInsets.fromLTRB(11, 9, 6, 9),
          decoration: BoxDecoration(
            color: C.card,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: C.border, width: 0.6),
          ),
          child: Row(
            children: [
              const Icon(Icons.hub_outlined, size: 15, color: C.purpleSoft),
              const SizedBox(width: 8),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('书源：自动选择',
                        style: TextStyle(fontSize: 11.5, color: C.text)),
                    const SizedBox(height: 2),
                    Text(
                      AppState.I.settings.sourceBase.isEmpty
                          ? '内置 ${kBookSources.length} 个常见站点，能用哪个用哪个'
                          : '上次可用：${Uri.tryParse(AppState.I.settings.sourceBase)?.host ?? AppState.I.settings.sourceBase}',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 10, color: C.faint),
                    ),
                  ],
                ),
              ),
              TextButton(
                onPressed: _busy ? null : _switchSource,
                child: const Text('换源',
                    style: TextStyle(fontSize: 11.5, color: C.purpleSoft)),
              ),
            ],
          ),
        ),
      ),
      Padding(
        padding: const EdgeInsets.fromLTRB(18, 8, 18, 0),
        child: TextField(
          controller: _title,
          style: const TextStyle(fontSize: 13.5, color: C.text),
          decoration: InputDecoration(
            hintText: '书名',
            hintStyle: const TextStyle(fontSize: 13, color: C.faint),
            prefixIcon: const Icon(Icons.search, size: 18, color: C.dim),
            filled: true,
            fillColor: C.card,
            contentPadding: const EdgeInsets.symmetric(vertical: 12),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: const BorderSide(color: C.border, width: 0.7),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: const BorderSide(color: C.border, width: 0.7),
            ),
          ),
        ),
      ),
      Padding(
        padding: const EdgeInsets.fromLTRB(18, 10, 18, 0),
        child: SizedBox(
          height: 42,
          width: double.infinity,
          child: OutlinedButton.icon(
            onPressed: _busy ? null : _upload,
            icon: const Icon(Icons.upload_file, size: 17, color: C.text),
            label: const Text('上传 TXT（不联网，最稳）',
                style: TextStyle(fontSize: 13, color: C.text)),
            style: OutlinedButton.styleFrom(
              side: const BorderSide(color: C.border),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            ),
          ),
        ),
      ),
      Padding(
        padding: const EdgeInsets.symmetric(vertical: 24),
        child: Column(
          children: const [
            Icon(Icons.search, size: 38, color: C.faint),
            SizedBox(height: 10),
            Text('只抓公开网页，个人阅读分析用，不要传播',
                style: TextStyle(fontSize: 11, color: C.faint)),
          ],
        ),
      ),
    ];
  }

  Widget _booksBody() {
    if (_books.isEmpty) {
      return const Padding(
        padding: EdgeInsets.symmetric(vertical: 30),
        child: Text('没搜到结果', style: TextStyle(fontSize: 12, color: C.dim)),
      );
    }
    return Flexible(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(18, 0, 18, 6),
            child: Text('搜索结果（${_books.length}）',
                style: const TextStyle(fontSize: 12, color: C.dim)),
          ),
          Flexible(
            child: ListView.builder(
              shrinkWrap: true,
              padding: const EdgeInsets.fromLTRB(14, 0, 14, 6),
              itemCount: _books.length,
              itemBuilder: (context, i) {
                final b = _books[i];
                final host = Uri.tryParse(b.url)?.host ?? '';
                return Container(
                  margin: const EdgeInsets.only(bottom: 8),
                  decoration: BoxDecoration(
                    color: C.card,
                    borderRadius: BorderRadius.circular(11),
                  ),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(11),
                    onTap: _busy ? null : () => _openBook(b),
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(13, 11, 10, 11),
                      child: Row(
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(b.title,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(fontSize: 13.5)),
                                const SizedBox(height: 5),
                                Row(
                                  children: [
                                    Container(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 6, vertical: 1),
                                      decoration: BoxDecoration(
                                        color: const Color(0x337B5CFF),
                                        borderRadius: BorderRadius.circular(4),
                                      ),
                                      child: Text(host,
                                          style: const TextStyle(
                                              fontSize: 9.5, color: C.purpleSoft)),
                                    ),
                                    const SizedBox(width: 8),
                                    Text('匹配度 ${b.score}%',
                                        style: const TextStyle(
                                            fontSize: 9.5, color: C.faint)),
                                  ],
                                ),
                              ],
                            ),
                          ),
                          const Icon(Icons.chevron_right, size: 17, color: C.faint),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _chaptersBody() {
    final web = _webChapters.isNotEmpty;
    final list =
        web ? _webChapters.map((c) => <String>[c.title, '']).toList() : _chapters;
    final picked = web ? _webPicked : _picked;

    if (list.isEmpty) {
      return const Padding(
        padding: EdgeInsets.symmetric(vertical: 30),
        child: Text('没识别到章节', style: TextStyle(fontSize: 12, color: C.dim)),
      );
    }

    return Flexible(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(18, 0, 18, 4),
            child: Row(
              children: [
                Text('已选 ${picked.length} / ${list.length} 章',
                    style: const TextStyle(fontSize: 11.5, color: C.dim)),
                const Spacer(),
                TextButton(
                  onPressed: () => setState(() {
                    if (picked.length == list.length) {
                      picked.clear();
                    } else {
                      picked
                        ..clear()
                        ..addAll(List.generate(list.length, (i) => i));
                    }
                  }),
                  child: Text(
                    picked.length == list.length ? '全不选' : '全选',
                    style: const TextStyle(fontSize: 11.5, color: C.purpleSoft),
                  ),
                ),
              ],
            ),
          ),
          if (web)
            const Padding(
              padding: EdgeInsets.fromLTRB(18, 0, 18, 4),
              child: Text('一次最多抓 3 章，抓多了会很慢',
                  style: TextStyle(fontSize: 10.5, color: C.faint)),
            ),
          Flexible(
            child: ListView.builder(
              shrinkWrap: true,
              padding: const EdgeInsets.fromLTRB(14, 0, 14, 4),
              itemCount: list.length,
              itemBuilder: (context, i) {
                final on = picked.contains(i);
                return InkWell(
                  onTap: () => setState(() {
                    if (on) {
                      picked.remove(i);
                    } else {
                      picked.add(i);
                    }
                  }),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 7, horizontal: 4),
                    child: Row(
                      children: [
                        Icon(
                          on ? Icons.check_box : Icons.check_box_outline_blank,
                          size: 17,
                          color: on ? C.purpleSoft : C.faint,
                        ),
                        const SizedBox(width: 9),
                        Expanded(
                          child: Text(
                            list[i][0],
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(fontSize: 12.5, color: on ? C.text : C.dim),
                          ),
                        ),
                        if (list[i][1].isNotEmpty)
                          Text(
                            '${list[i][1].replaceAll(RegExp(r"\s"), "").length} 字',
                            style: const TextStyle(fontSize: 10, color: C.faint),
                          ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
