import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:novel_app/novel_source.dart';
import 'package:novel_app/store.dart';

const String _base = 'http://127.0.0.1:8777';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  setUpAll(() {
    HttpOverrides.global = null; // 允许真实 socket（本地假站点）
  });

  test('搜索：解析结果并按匹配度排序', () async {
    final books = await searchBooks(_base, '斗破苍穹');
    expect(books.length, 2);
    expect(books.first.title, '斗破苍穹');
    expect(books.first.score, 100);
    expect(books.any((b) => b.title.contains('师姐')), isTrue);
  });

  test('目录：解析出章节链接', () async {
    final list = await fetchChapters('$_base/book/1');
    expect(list.length, 3);
    expect(list.first.title.contains('第一章'), isTrue);
    expect(list.first.url, endsWith('/chapter/1'));
  });

  test('正文：utf8 页面', () async {
    final t = await fetchChapterContent('$_base/chapter/1');
    expect(t.contains('斗之力'), isTrue);
    expect(t.length, greaterThan(100));
  });

  test('正文：gbk 页面不乱码', () async {
    final t = await fetchChapterContent('$_base/chapter/2');
    expect(t.contains('斗气大陆'), isTrue);
  });

  test('正文：JS 渲染页给出明确错误', () async {
    expect(
      () => fetchChapterContent('$_base/chapter/3'),
      throwsA(isA<NovelFetchException>()),
    );
  });

  test('搜索：域名没写协议也能补全', () {
    expect(normalizeBase('www.example.com'), 'https://www.example.com');
    expect(normalizeBase('https://a.com/'), 'https://a.com');
  });

  test('榜单：按顺序解析书名与作者', () async {
    final list = await fetchRanking('$_base/rank/hotsales/');
    expect(list.length, 10);
    expect(list.first.title, '斗破苍穹');
    expect(list[3].title, '夜的命名术');
    expect(list.first.extra.contains('天蚕土豆'), isTrue);
  });

  test('简介：从容器里抓到正文', () async {
    final t = await fetchBookIntro('$_base/book/1');
    expect(t.contains('萧炎'), isTrue);
    expect(t.contains('莫欺少年穷'), isTrue);
    expect(t.length, greaterThan(50));
  });

  test('简介：JS 渲染页给出明确错误', () async {
    expect(
      () => fetchBookIntro('$_base/book/2'),
      throwsA(isA<NovelFetchException>()),
    );
  });

  test('探测书源：连不上返回 false，能打开返回 true', () async {
    expect(await isSourceAlive('http://127.0.0.1:9'), isFalse);
    expect(await isSourceAlive(_base), isTrue);
  });

  test('自动选源：跳过连不上的，记住能用的', () async {
    SharedPreferences.setMockInitialValues(<String, Object>{});
    await AppState.I.init();
    AppState.I.settings.sourceBase = '';

    final base = await AppState.I.ensureSource(
      candidates: ['http://127.0.0.1:9', _base],
    );
    expect(base, _base);
    expect(AppState.I.settings.sourceBase, _base);
  });

  test('换源：强制重探时会跳过上次保存的地址', () async {
    SharedPreferences.setMockInitialValues(<String, Object>{});
    await AppState.I.init();
    AppState.I.settings.sourceBase = 'http://127.0.0.1:9';

    // 不强制时，先试保存的那个，失败后仍然会落到可用站点
    final first = await AppState.I.ensureSource(candidates: [_base]);
    expect(first, _base);

    AppState.I.settings.sourceBase = 'http://127.0.0.1:9';
    final second = await AppState.I.ensureSource(
      candidates: ['http://127.0.0.1:9', _base],
      forceReprobe: true,
    );
    expect(second, _base);
  });
}
