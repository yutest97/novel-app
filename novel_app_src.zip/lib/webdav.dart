import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;

class WebDavException implements Exception {
  final String message;
  WebDavException(this.message);
  @override
  String toString() => message;
}

class WebDavConfig {
  final String url;
  final String user;
  final String pass;
  final String path;

  const WebDavConfig({
    required this.url,
    required this.user,
    required this.pass,
    required this.path,
  });

  bool get configured => url.trim().isNotEmpty;
}

String _join(String base, String path, [String? file]) {
  var b = base.trim().replaceAll(RegExp(r'/+$'), '');
  var p = path.trim();
  if (p.isEmpty) p = '/';
  if (!p.startsWith('/')) p = '/$p';
  if (!p.endsWith('/')) p = '$p/';
  return file == null ? '$b$p' : '$b$p${Uri.encodeComponent(file)}';
}

Map<String, String> _auth(WebDavConfig c) => {
      'Authorization':
          'Basic ${base64Encode(utf8.encode('${c.user}:${c.pass}'))}',
    };

/// 确保远程目录存在；不存在就建一层
Future<void> ensureWebDavDir(WebDavConfig cfg) async {
  final uri = Uri.parse(_join(cfg.url, cfg.path));

  http.StreamedResponse resp;
  try {
    final req = http.Request('PROPFIND', uri)
      ..headers.addAll({..._auth(cfg), 'Depth': '0'});
    resp = await req.send().timeout(const Duration(seconds: 20));
    await resp.stream.drain<void>();
  } on TimeoutException {
    throw WebDavException('连接超时。检查地址和网络。');
  } catch (e) {
    throw WebDavException('连不上 WebDAV：$e');
  }

  if (resp.statusCode == 207 || resp.statusCode == 200 || resp.statusCode == 301) {
    return;
  }
  if (resp.statusCode == 401 || resp.statusCode == 403) {
    throw WebDavException('用户名或密码不对（HTTP ${resp.statusCode}）。'
        '坚果云要用「应用密码」，不是登录密码。');
  }
  if (resp.statusCode == 404) {
    http.StreamedResponse mk;
    try {
      final req = http.Request('MKCOL', uri)..headers.addAll(_auth(cfg));
      mk = await req.send().timeout(const Duration(seconds: 20));
      await mk.stream.drain<void>();
    } on TimeoutException {
      throw WebDavException('建目录超时。');
    } catch (e) {
      throw WebDavException('建目录失败：$e');
    }
    if ([200, 201, 204, 405].contains(mk.statusCode)) return;
    throw WebDavException('目录不存在，自动创建也失败了（HTTP ${mk.statusCode}）。'
        '路径要写成 /OpenWrite/ 这种形式，父目录得先存在。');
  }
  throw WebDavException('目录不可用（HTTP ${resp.statusCode}）。');
}

Future<void> uploadWebDavBackup(WebDavConfig cfg, String content) async {
  await ensureWebDavDir(cfg);
  final uri = Uri.parse(_join(cfg.url, cfg.path, 'novel_app_backup.json'));
  http.StreamedResponse resp;
  try {
    final req = http.Request('PUT', uri)
      ..headers.addAll({
        ..._auth(cfg),
        'Content-Type': 'application/json; charset=utf-8',
      })
      ..bodyBytes = utf8.encode(content);
    resp = await req.send().timeout(const Duration(seconds: 60));
    await resp.stream.drain<void>();
  } on TimeoutException {
    throw WebDavException('上传超时，备份可能比较大。再试一次。');
  } catch (e) {
    throw WebDavException('上传失败：$e');
  }
  if (resp.statusCode < 200 || resp.statusCode >= 300) {
    throw WebDavException('上传失败（HTTP ${resp.statusCode}）。');
  }
}

Future<String> downloadWebDavBackup(WebDavConfig cfg) async {
  final uri = Uri.parse(_join(cfg.url, cfg.path, 'novel_app_backup.json'));
  http.Response resp;
  try {
    resp = await http
        .get(uri, headers: _auth(cfg))
        .timeout(const Duration(seconds: 60));
  } on TimeoutException {
    throw WebDavException('下载超时。');
  } catch (e) {
    throw WebDavException('下载失败：$e');
  }
  if (resp.statusCode == 404) {
    throw WebDavException('云端还没有备份，先点「备份到云端」。');
  }
  if (resp.statusCode == 401 || resp.statusCode == 403) {
    throw WebDavException('用户名或密码不对（HTTP ${resp.statusCode}）。');
  }
  if (resp.statusCode != 200) {
    throw WebDavException('下载失败（HTTP ${resp.statusCode}）。');
  }
  return utf8.decode(resp.bodyBytes, allowMalformed: true);
}
