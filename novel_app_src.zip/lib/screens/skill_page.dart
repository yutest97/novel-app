import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../builtin_skills.dart';
import '../skill.dart';
import '../skill_import.dart';
import '../store.dart';
import '../theme.dart';
import 'skill_market_page.dart';

/// Skill 管理：内置 + 导入的技能，可开关、可导出、可去广场
class SkillPage extends StatefulWidget {
  const SkillPage({super.key});

  @override
  State<SkillPage> createState() => _SkillPageState();
}

class _SkillPageState extends State<SkillPage> {
  final TextEditingController _search = TextEditingController();
  bool _onlyEnabled = false;
  bool _builtinOpen = true;
  bool _importedOpen = true;
  bool _busy = false;

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  Future<void> _importFlow() async {
    final messenger = ScaffoldMessenger.of(context);
    setState(() => _busy = true);
    try {
      final picked = await pickSkillFile();
      if (picked == null) {
        messenger.showSnackBar(
            const SnackBar(content: Text('没有选到文件（.md / .markdown / .txt / .zip）')));
        return;
      }
      if (!mounted) return;

      final path = picked.path;
      final dir = path.contains('/') ? path.substring(0, path.lastIndexOf('/')) : path;

      final allow = await showDialog<String>(
        context: context,
        builder: (ctx) => AlertDialog(
          backgroundColor: C.card,
          title: const Text('读取项目外文件待确认', style: TextStyle(fontSize: 15)),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                path.isEmpty ? picked.name : path,
                style: const TextStyle(
                    fontSize: 11.5, height: 1.5, color: C.dim, fontFamily: 'monospace'),
              ),
              const SizedBox(height: 10),
              Text('始终允许将授权：$dir',
                  style: const TextStyle(fontSize: 11, color: C.faint)),
              const SizedBox(height: 12),
              const Text(
                '这个文件会读进 App，作为当前技能注入到对话里。技能内容只存在本机。'
                '（选 zip 会把里面的 SKILL.md 和 references 一起读进来）',
                style: TextStyle(fontSize: 11.5, height: 1.6, color: C.dim),
              ),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, 'no'), child: const Text('拒绝')),
            TextButton(onPressed: () => Navigator.pop(ctx, 'once'), child: const Text('本次允许')),
            ElevatedButton(
              onPressed: () => Navigator.pop(ctx, 'always'),
              style: ButtonStyle(
                backgroundColor: MaterialStateProperty.all<Color>(C.purple),
                foregroundColor: MaterialStateProperty.all<Color>(Colors.white),
              ),
              child: const Text('始终允许此目录'),
            ),
          ],
        ),
      );
      if (allow == null || allow == 'no') {
        messenger.showSnackBar(const SnackBar(content: Text('已取消导入')));
        return;
      }

      final name = picked.name
          .replaceAll(RegExp(r'\.(md|markdown|txt|zip)$', caseSensitive: false), '');
      await AppState.I.importSkill(name, path, picked.content);
      if (allow == 'always') await AppState.I.rememberDir(dir);
      messenger.showSnackBar(SnackBar(content: Text('已导入「$name」，并设为当前技能')));
    } on SkillPickException catch (e) {
      messenger.showSnackBar(
        SnackBar(content: Text(e.message), duration: const Duration(seconds: 6)),
      );
    } catch (e) {
      messenger.showSnackBar(
        SnackBar(content: Text('选择文件失败：$e'), duration: const Duration(seconds: 6)),
      );
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _exportSheet() async {
    final st = AppState.I;
    final messenger = ScaffoldMessenger.of(context);
    final pick = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => Container(
        decoration: const BoxDecoration(
          color: C.surface,
          borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
        ),
        child: SafeArea(
          top: false,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 38,
                height: 4,
                margin: const EdgeInsets.symmetric(vertical: 10),
                decoration: BoxDecoration(
                  color: Colors.white24,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const Padding(
                padding: EdgeInsets.fromLTRB(18, 2, 18, 8),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Text('导出技能',
                      style: TextStyle(fontSize: 13.5, fontWeight: FontWeight.w600)),
                ),
              ),
              ListTile(
                leading: const Icon(Icons.article_outlined, size: 19, color: C.purpleSoft),
                title: const Text('当前技能原文', style: TextStyle(fontSize: 13)),
                subtitle: const Text('复制成 Markdown，可直接发给别人导入',
                    style: TextStyle(fontSize: 10.5, color: C.dim)),
                onTap: () => Navigator.pop(context, 'active'),
              ),
              ListTile(
                leading: const Icon(Icons.inventory_2_outlined, size: 19, color: C.purpleSoft),
                title: Text('全部技能（${st.totalSkillCount} 个）',
                    style: const TextStyle(fontSize: 13)),
                subtitle: const Text('打包成 JSON，含内置技能原文',
                    style: TextStyle(fontSize: 10.5, color: C.dim)),
                onTap: () => Navigator.pop(context, 'all'),
              ),
              const SizedBox(height: 10),
            ],
          ),
        ),
      ),
    );
    if (pick == null) return;

    try {
      final text = pick == 'active'
          ? await st.exportActiveSkillText()
          : await st.exportAllSkillsJson();
      await Clipboard.setData(ClipboardData(text: text));
      messenger.showSnackBar(
        SnackBar(
          content: Text(pick == 'active'
              ? '已复制当前技能原文（${text.length} 字）'
              : '已复制全部技能 JSON（${text.length} 字符）'),
        ),
      );
    } catch (e) {
      messenger.showSnackBar(SnackBar(content: Text('导出失败：$e')));
    }
  }

  Future<void> _toggle(String id, bool on) async {
    final messenger = ScaffoldMessenger.of(context);
    final ok = await AppState.I.setSkillEnabled(id, on);
    if (!ok && mounted) {
      messenger.showSnackBar(
        const SnackBar(content: Text('至少要留一个技能开启，否则 AI 没有工作流。')),
      );
    }
  }

  Future<void> _menu(String action, {required String id, required String name, required bool builtin}) async {
    final st = AppState.I;
    final messenger = ScaffoldMessenger.of(context);
    switch (action) {
      case 'open':
        if (builtin) {
          Navigator.of(context).push(MaterialPageRoute(
            builder: (_) => SkillDetailPage(skillId: id, title: name),
          ));
        } else {
          final s = st.settings.importedSkills.firstWhere((e) => e.id == id);
          Navigator.of(context).push(MaterialPageRoute(
            builder: (_) => SkillDetailPage(text: s.content, title: name),
          ));
        }
        break;
      case 'use':
        await st.setActiveSkill(id);
        messenger.showSnackBar(SnackBar(content: Text('已切换到「$name」')));
        break;
      case 'style':
        await st.setStyleSkill(id);
        messenger.showSnackBar(
          SnackBar(
            content: Text(st.settings.styleSkillId == id ? '已设为写作风格' : '已取消写作风格'),
          ),
        );
        break;
      case 'delete':
        await st.removeSkill(id);
        messenger.showSnackBar(SnackBar(content: Text('已删除「$name」')));
        break;
    }
  }

  bool _match(String name, String desc) {
    final q = _search.text.trim().toLowerCase();
    if (q.isNotEmpty &&
        !name.toLowerCase().contains(q) &&
        !desc.toLowerCase().contains(q)) {
      return false;
    }
    return true;
  }

  @override
  Widget build(BuildContext context) {
    final st = AppState.I;
    return AnimatedBuilder(
      animation: st,
      builder: (context, _) {
        final builtins = kBuiltinSkills
            .where((b) =>
                _match(b.name, b.desc) &&
                (!_onlyEnabled || st.isSkillEnabled(b.id)))
            .toList();
        final imported = st.settings.importedSkills
            .where((s) =>
                _match(s.name, s.path) &&
                (!_onlyEnabled || st.isSkillEnabled(s.id)))
            .toList();

        return Scaffold(
          appBar: AppBar(title: const Text('Skill 管理')),
          body: ListView(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 30),
            children: [
              _headerCard(st),
              const SizedBox(height: 12),
              _searchRow(st),
              const SizedBox(height: 12),
              _section(
                title: '内置',
                count: builtins.length,
                open: _builtinOpen,
                onToggle: () => setState(() => _builtinOpen = !_builtinOpen),
              ),
              if (_builtinOpen)
                for (final b in builtins)
                  _skillRow(
                    id: b.id,
                    name: b.name,
                    desc: b.desc,
                    builtin: true,
                    active: st.settings.activeSkillId == b.id,
                    enabled: st.isSkillEnabled(b.id),
                  ),
              const SizedBox(height: 10),
              _section(
                title: '已导入',
                count: imported.length,
                open: _importedOpen,
                onToggle: () => setState(() => _importedOpen = !_importedOpen),
              ),
              if (_importedOpen)
                if (imported.isEmpty)
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                        color: C.card, borderRadius: BorderRadius.circular(12)),
                    child: const Text(
                      '还没有导入过技能。点上面的「导入」选一个 .md 或 .zip 技能包，或者去「广场」挑现成的。',
                      style: TextStyle(fontSize: 11.5, height: 1.7, color: C.dim),
                    ),
                  )
                else
                  for (final s in imported)
                    _skillRow(
                      id: s.id,
                      name: s.name,
                      desc: s.path.isEmpty ? '已导入' : s.path,
                      builtin: false,
                      active: st.settings.activeSkillId == s.id,
                      enabled: st.isSkillEnabled(s.id),
                      isStyle: st.settings.styleSkillId == s.id,
                    ),
            ],
          ),
        );
      },
    );
  }

  Widget _headerCard(AppState st) {
    return Container(
      padding: const EdgeInsets.fromLTRB(14, 13, 14, 11),
      decoration: BoxDecoration(
        color: C.card,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: C.border, width: 0.7),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Skill 定义了 AI 的工作流程和行为规范。开启的 Skill 会注入到系统提示词中，'
            '指导 AI 怎么写。同一时间只有一个主技能生效。',
            style: TextStyle(fontSize: 11, height: 1.65, color: C.dim),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: _headerBtn(
                  icon: Icons.file_upload_outlined,
                  label: _busy ? '读取中…' : '导入',
                  onTap: _busy ? null : _importFlow,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _headerBtn(
                  icon: Icons.file_download_outlined,
                  label: '导出',
                  onTap: _exportSheet,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _headerBtn(
                  icon: Icons.storefront_outlined,
                  label: '广场',
                  filled: true,
                  onTap: () => Navigator.of(context).push(
                    MaterialPageRoute(builder: (_) => const SkillMarketPage()),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _headerBtn({
    required IconData icon,
    required String label,
    VoidCallback? onTap,
    bool filled = false,
  }) {
    return SizedBox(
      height: 38,
      child: filled
          ? ElevatedButton.icon(
              onPressed: onTap,
              icon: Icon(icon, size: 15, color: Colors.white),
              label: Text(label, style: const TextStyle(fontSize: 12.5, color: Colors.white)),
              style: ElevatedButton.styleFrom(
                backgroundColor: C.purple,
                elevation: 0,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(9)),
              ),
            )
          : OutlinedButton.icon(
              onPressed: onTap,
              icon: Icon(icon, size: 15, color: C.text),
              label: Text(label, style: const TextStyle(fontSize: 12.5, color: C.text)),
              style: OutlinedButton.styleFrom(
                side: const BorderSide(color: C.border),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(9)),
              ),
            ),
    );
  }

  Widget _searchRow(AppState st) {
    return Row(
      children: [
        Expanded(
          child: SizedBox(
            height: 38,
            child: TextField(
              controller: _search,
              onChanged: (_) => setState(() {}),
              style: const TextStyle(fontSize: 12.5, color: C.text),
              decoration: InputDecoration(
                hintText: '搜索 Skill',
                hintStyle: const TextStyle(fontSize: 12, color: C.faint),
                prefixIcon: const Icon(Icons.search, size: 17, color: C.dim),
                filled: true,
                fillColor: C.card,
                isDense: true,
                contentPadding: const EdgeInsets.symmetric(vertical: 8),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(9),
                  borderSide: const BorderSide(color: C.border, width: 0.7),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(9),
                  borderSide: const BorderSide(color: C.border, width: 0.7),
                ),
              ),
            ),
          ),
        ),
        const SizedBox(width: 8),
        InkWell(
          onTap: () => setState(() => _onlyEnabled = !_onlyEnabled),
          borderRadius: BorderRadius.circular(9),
          child: Container(
            height: 38,
            padding: const EdgeInsets.symmetric(horizontal: 12),
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: _onlyEnabled ? const Color(0x337B5CFF) : C.card,
              borderRadius: BorderRadius.circular(9),
              border: Border.all(
                color: _onlyEnabled ? C.purple : C.border,
                width: 0.7,
              ),
            ),
            child: Text(
              '已开启 ${st.enabledSkillCount}/${st.totalSkillCount}',
              style: TextStyle(
                fontSize: 11,
                color: _onlyEnabled ? C.purpleSoft : C.dim,
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _section({
    required String title,
    required int count,
    required bool open,
    required VoidCallback onToggle,
  }) {
    return InkWell(
      onTap: onToggle,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(2, 4, 2, 8),
        child: Row(
          children: [
            Icon(open ? Icons.expand_less : Icons.expand_more, size: 16, color: C.faint),
            const SizedBox(width: 4),
            Text('$title $count', style: const TextStyle(fontSize: 11.5, color: C.faint)),
          ],
        ),
      ),
    );
  }

  Widget _skillRow({
    required String id,
    required String name,
    required String desc,
    required bool builtin,
    required bool active,
    required bool enabled,
    bool isStyle = false,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.fromLTRB(12, 10, 6, 10),
      decoration: BoxDecoration(
        color: C.card,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: active ? C.purple : C.border,
          width: active ? 0.9 : 0.6,
        ),
      ),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => _menu('open', id: id, name: name, builtin: builtin),
            child: Container(
              width: 34,
              height: 34,
              decoration: BoxDecoration(
                color: const Color(0x337B5CFF),
                borderRadius: BorderRadius.circular(9),
              ),
              child: Icon(
                builtin ? Icons.auto_awesome : Icons.extension_outlined,
                size: 16,
                color: C.purpleSoft,
              ),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: GestureDetector(
              onTap: () => _menu('open', id: id, name: name, builtin: builtin),
              behavior: HitTestBehavior.opaque,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Flexible(
                        child: Text(
                          name,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w500,
                            color: enabled ? C.text : C.dim,
                          ),
                        ),
                      ),
                      if (builtin) ...[
                        const SizedBox(width: 6),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                          decoration: BoxDecoration(
                            color: const Color(0x337B5CFF),
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: const Text('内置',
                              style: TextStyle(fontSize: 8.5, color: C.purpleSoft)),
                        ),
                      ],
                      if (active) ...[
                        const SizedBox(width: 6),
                        const Text('使用中',
                            style: TextStyle(fontSize: 9, color: C.purpleSoft)),
                      ],
                      if (isStyle) ...[
                        const SizedBox(width: 6),
                        const Icon(Icons.style, size: 11, color: C.purpleSoft),
                      ],
                    ],
                  ),
                  const SizedBox(height: 2),
                  Text(
                    desc,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 10.5, color: C.dim),
                  ),
                ],
              ),
            ),
          ),
          Transform.scale(
            scale: 0.78,
            child: Switch(
              value: enabled,
              activeColor: Colors.white,
              activeTrackColor: C.purple,
              inactiveThumbColor: const Color(0xFFBFC2D4),
              inactiveTrackColor: C.cardHi,
              onChanged: (v) => _toggle(id, v),
            ),
          ),
          PopupMenuButton<String>(
            padding: EdgeInsets.zero,
            icon: const Icon(Icons.more_vert, size: 17, color: C.faint),
            color: C.card,
            onSelected: (v) => _menu(v, id: id, name: name, builtin: builtin),
            itemBuilder: (_) => [
              const PopupMenuItem(
                value: 'open',
                height: 38,
                child: Text('查看原文', style: TextStyle(fontSize: 12.5)),
              ),
              PopupMenuItem(
                value: 'use',
                height: 38,
                enabled: enabled && !active,
                child: Text(active ? '正在使用' : '设为当前技能',
                    style: const TextStyle(fontSize: 12.5)),
              ),
              if (!builtin)
                PopupMenuItem(
                  value: 'style',
                  height: 38,
                  enabled: enabled,
                  child: Text(isStyle ? '取消写作风格' : '设为写作风格',
                      style: const TextStyle(fontSize: 12.5)),
                ),
              if (!builtin)
                const PopupMenuItem(
                  value: 'delete',
                  height: 38,
                  child: Text('删除',
                      style: TextStyle(fontSize: 12.5, color: Color(0xFFD9534F))),
                ),
            ],
          ),
        ],
      ),
    );
  }
}

/// 技能原文
class SkillDetailPage extends StatefulWidget {
  const SkillDetailPage({
    super.key,
    this.text,
    this.skillId = 'builtin:novel-writer',
    this.title = '技能原文',
  });

  final String? text;
  final String skillId;
  final String title;

  @override
  State<SkillDetailPage> createState() => _SkillDetailPageState();
}

class _SkillDetailPageState extends State<SkillDetailPage> {
  String _text = '读取中…';

  @override
  void initState() {
    super.initState();
    final preset = widget.text;
    if (preset != null && preset.trim().isNotEmpty) {
      _text = preset;
      return;
    }
    SkillPack.load(widget.skillId).then((v) {
      if (mounted) setState(() => _text = v);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.title)),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: SelectableText(
          _text,
          style: const TextStyle(
              fontSize: 12, height: 1.7, color: Color(0xFFCFCFDE), fontFamily: 'monospace'),
        ),
      ),
    );
  }
}
