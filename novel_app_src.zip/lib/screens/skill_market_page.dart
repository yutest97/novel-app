import 'package:flutter/material.dart';

import '../skill_market.dart';
import '../store.dart';
import '../theme.dart';

/// Skill 广场：内置精选（离线）+ 订阅源 + 我的
class SkillMarketPage extends StatefulWidget {
  const SkillMarketPage({super.key});

  @override
  State<SkillMarketPage> createState() => _SkillMarketPageState();
}

class _SkillMarketPageState extends State<SkillMarketPage> {
  int _tab = 0; // 0 精选 1 订阅 2 我的
  String _cat = '全部';
  final TextEditingController _q = TextEditingController();
  late final TextEditingController _feedUrl;
  List<MarketSkill> _feed = const [];
  bool _loading = false;
  String _err = '';

  @override
  void initState() {
    super.initState();
    _feedUrl = TextEditingController(text: AppState.I.settings.marketFeedUrl);
  }

  @override
  void dispose() {
    _q.dispose();
    _feedUrl.dispose();
    super.dispose();
  }

  Future<void> _loadFeed() async {
    final messenger = ScaffoldMessenger.of(context);
    final url = _feedUrl.text.trim();
    if (url.isEmpty) {
      messenger.showSnackBar(const SnackBar(content: Text('先填订阅源地址')));
      return;
    }
    setState(() {
      _loading = true;
      _err = '';
    });
    try {
      final list = await fetchMarketFeed(url);
      await AppState.I.setMarketFeedUrl(url);
      if (!mounted) return;
      setState(() => _feed = list);
      messenger.showSnackBar(SnackBar(content: Text('拉到 ${list.length} 个技能')));
    } on SkillFeedException catch (e) {
      if (mounted) setState(() => _err = e.message);
    } catch (e) {
      if (mounted) setState(() => _err = '拉取失败：$e');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _add(MarketSkill s) async {
    final messenger = ScaffoldMessenger.of(context);
    final added = await AppState.I.addMarketSkill(
      id: s.id,
      name: s.name,
      content: s.content,
    );
    if (!mounted) return;
    setState(() {});
    messenger.showSnackBar(
      SnackBar(
        content: Text(added
            ? '已添加「${s.name}」，去 Skill 管理里可以设为主技能'
            : '「${s.name}」已经在你的技能里了'),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final st = AppState.I;
    return AnimatedBuilder(
      animation: st,
      builder: (context, _) => Scaffold(
        appBar: AppBar(title: const Text('Skill 广场')),
        body: Column(
          children: [
            _tabs(),
            const Divider(height: 1, color: C.border),
            Expanded(
              child: _tab == 0
                  ? _curated(st)
                  : _tab == 1
                      ? _subscribe(st)
                      : _mine(st),
            ),
          ],
        ),
      ),
    );
  }

  Widget _tabs() {
    const names = ['精选', '订阅', '我的'];
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 6, 16, 8),
      child: Row(
        children: [
          for (var i = 0; i < names.length; i++)
            Padding(
              padding: const EdgeInsets.only(right: 20),
              child: InkWell(
                onTap: () => setState(() => _tab = i),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      names[i],
                      style: TextStyle(
                        fontSize: 13.5,
                        fontWeight: _tab == i ? FontWeight.w600 : FontWeight.w400,
                        color: _tab == i ? C.text : C.dim,
                      ),
                    ),
                    const SizedBox(height: 5),
                    Container(
                      height: 2,
                      width: 18,
                      color: _tab == i ? C.purple : Colors.transparent,
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }

  // ---------- 精选 ----------

  Widget _curated(AppState st) {
    final q = _q.text.trim().toLowerCase();
    final list = kMarketSkills.where((s) {
      if (_cat != '全部' && s.category != _cat) return false;
      if (q.isEmpty) return true;
      return s.name.toLowerCase().contains(q) || s.desc.toLowerCase().contains(q);
    }).toList();

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 10, 16, 8),
          child: SizedBox(
            height: 38,
            child: TextField(
              controller: _q,
              onChanged: (_) => setState(() {}),
              style: const TextStyle(fontSize: 12.5, color: C.text),
              decoration: InputDecoration(
                hintText: '搜索 Skill…',
                hintStyle: const TextStyle(fontSize: 12, color: C.faint),
                prefixIcon: const Icon(Icons.search, size: 17, color: C.dim),
                filled: true,
                fillColor: C.card,
                isDense: true,
                contentPadding: const EdgeInsets.symmetric(vertical: 8),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(9),
                  borderSide: const BorderSide(color: C.border, width: 0.7),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(9),
                  borderSide: const BorderSide(color: C.border, width: 0.7),
                ),
              ),
            ),
          ),
        ),
        SizedBox(
          height: 34,
          child: ListView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            children: [
              for (final c in kMarketCategories)
                Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: _catChip(c, _cat == c, () => setState(() => _cat = c)),
                ),
            ],
          ),
        ),
        const SizedBox(height: 6),
        Expanded(
          child: list.isEmpty
              ? const Center(
                  child: Text('没有匹配的技能',
                      style: TextStyle(fontSize: 12, color: C.dim)),
                )
              : ListView.builder(
                  padding: const EdgeInsets.fromLTRB(16, 4, 16, 20),
                  itemCount: list.length + 1,
                  itemBuilder: (context, i) {
                    if (i == 0) {
                      return const Padding(
                        padding: EdgeInsets.only(bottom: 8),
                        child: Text(
                          '精选技能随 App 内置，不联网也能用；添加后在 Skill 管理里开启。',
                          style: TextStyle(fontSize: 10, height: 1.6, color: C.faint),
                        ),
                      );
                    }
                    final s = list[i - 1];
                    return _marketRow(
                      s,
                      added: st.hasMarketSkill(s.id),
                      onAdd: () => _add(s),
                    );
                  },
                ),
        ),
      ],
    );
  }

  // ---------- 订阅 ----------

  Widget _subscribe(AppState st) {
    final configured = _feed.isNotEmpty;
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
      children: [
        Container(
          padding: const EdgeInsets.all(13),
          decoration: BoxDecoration(
            color: C.card,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: C.border, width: 0.6),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('订阅源', style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w500)),
              const SizedBox(height: 5),
              const Text(
                '填一个 JSON 地址，别人把自己的技能打包放上去，这里就能加载。'
                '格式：数组，每条含 name / content，可选 desc、category、author。',
                style: TextStyle(fontSize: 10.5, height: 1.65, color: C.dim),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: _feedUrl,
                style: const TextStyle(fontSize: 12, color: C.text),
                decoration: InputDecoration(
                  hintText: 'https://example.com/skills.json',
                  hintStyle: const TextStyle(fontSize: 11.5, color: C.faint),
                  filled: true,
                  fillColor: C.surface,
                  isDense: true,
                  contentPadding:
                      const EdgeInsets.symmetric(vertical: 10, horizontal: 10),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: const BorderSide(color: C.border, width: 0.7),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: const BorderSide(color: C.border, width: 0.7),
                  ),
                ),
              ),
              const SizedBox(height: 10),
              SizedBox(
                height: 38,
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: _loading ? null : _loadFeed,
                  icon: _loading
                      ? const SizedBox(
                          width: 13,
                          height: 13,
                          child: CircularProgressIndicator(
                              strokeWidth: 1.6, color: Colors.white),
                        )
                      : const Icon(Icons.refresh, size: 15, color: Colors.white),
                  label: Text(_loading ? '加载中…' : (configured ? '刷新订阅' : '加载订阅'),
                      style: const TextStyle(fontSize: 12.5, color: Colors.white)),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: C.purple,
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(9)),
                  ),
                ),
              ),
              if (_err.isNotEmpty) ...[
                const SizedBox(height: 8),
                Text(_err,
                    style: const TextStyle(fontSize: 10.5, height: 1.5, color: Color(0xFFE0736E))),
              ],
            ],
          ),
        ),
        if (configured) ...[
          const SizedBox(height: 14),
          Text('订阅内容 ${_feed.length} 个',
              style: const TextStyle(fontSize: 11, color: C.faint)),
          const SizedBox(height: 6),
          for (final s in _feed)
            _marketRow(s, added: st.hasMarketSkill(s.id), onAdd: () => _add(s)),
        ],
      ],
    );
  }

  // ---------- 我的 ----------

  Widget _mine(AppState st) {
    final list = st.settings.importedSkills;
    if (list.isEmpty) {
      return const Center(
        child: Padding(
          padding: EdgeInsets.all(30),
          child: Text(
            '还没有自己的技能。\n去「精选」添加一个，或在 Skill 管理里导入 .md。',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 12, height: 1.8, color: C.dim),
          ),
        ),
      );
    }
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 20),
      itemCount: list.length,
      itemBuilder: (context, i) {
        final s = list[i];
        final on = st.isSkillEnabled(s.id);
        return Container(
          margin: const EdgeInsets.only(bottom: 8),
          padding: const EdgeInsets.fromLTRB(12, 10, 6, 10),
          decoration: BoxDecoration(
            color: C.card,
            borderRadius: BorderRadius.circular(11),
            border: Border.all(color: C.border, width: 0.6),
          ),
          child: Row(
            children: [
              const Icon(Icons.extension_outlined, size: 17, color: C.purpleSoft),
              const SizedBox(width: 9),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(s.name,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontSize: 12.5)),
                    const SizedBox(height: 2),
                    Text(
                      '${s.content.replaceAll(RegExp(r"\s"), "").length} 字 · ${on ? "已开启" : "已关闭"}',
                      style: const TextStyle(fontSize: 10, color: C.faint),
                    ),
                  ],
                ),
              ),
              TextButton(
                onPressed: () async {
                  final messenger = ScaffoldMessenger.of(context);
                  await st.removeSkill(s.id);
                  if (mounted) {
                    setState(() {});
                    messenger.showSnackBar(SnackBar(content: Text('已删除「${s.name}」')));
                  }
                },
                child: const Text('删除',
                    style: TextStyle(fontSize: 11, color: C.faint)),
              ),
            ],
          ),
        );
      },
    );
  }

  // ---------- 组件 ----------

  Widget _catChip(String label, bool on, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 6),
        decoration: BoxDecoration(
          color: on ? const Color(0x337B5CFF) : C.card,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: on ? C.purple : C.border, width: 0.6),
        ),
        child: Text(label,
            style: TextStyle(fontSize: 11, color: on ? C.purpleSoft : C.dim)),
      ),
    );
  }

  Widget _marketRow(MarketSkill s, {required bool added, required VoidCallback onAdd}) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.fromLTRB(12, 11, 10, 11),
      decoration: BoxDecoration(
        color: C.card,
        borderRadius: BorderRadius.circular(11),
        border: Border.all(color: C.border, width: 0.6),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 34,
            height: 34,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: const Color(0x337B5CFF),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Text(
              s.name.characters.first.toUpperCase(),
              style: const TextStyle(
                  fontSize: 15, fontWeight: FontWeight.w600, color: C.purpleSoft),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(s.name,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500)),
                const SizedBox(height: 3),
                Text(s.desc,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 10.5, height: 1.5, color: C.dim)),
                const SizedBox(height: 4),
                Text(
                  [
                    s.author,
                    s.category,
                    if (s.downloads > 0) '${s.downloads} 次下载',
                  ].join(' · '),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 9.5, color: C.faint),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          SizedBox(
            height: 30,
            child: added
                ? const Padding(
                    padding: EdgeInsets.symmetric(horizontal: 6),
                    child: Center(
                      child: Text('已添加',
                          style: TextStyle(fontSize: 10.5, color: C.faint)),
                    ),
                  )
                : OutlinedButton(
                    onPressed: onAdd,
                    style: OutlinedButton.styleFrom(
                      side: const BorderSide(color: C.purple, width: 0.7),
                      padding: const EdgeInsets.symmetric(horizontal: 13),
                      minimumSize: const Size(0, 30),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(7)),
                    ),
                    child: const Text('下载',
                        style: TextStyle(fontSize: 11, color: C.purpleSoft)),
                  ),
          ),
        ],
      ),
    );
  }
}
