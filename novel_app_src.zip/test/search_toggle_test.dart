import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:novel_app/main.dart';
import 'package:novel_app/models.dart';
import 'package:novel_app/store.dart';
import 'package:novel_app/theme.dart';

Future<void> _loadFonts() async {
  final cjk = File('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc').readAsBytesSync();
  for (final f in ['CJK', 'monospace', 'Roboto']) {
    await (FontLoader(f)..addFont(Future.value(ByteData.view(cjk.buffer)))).load();
  }
  final icon = File('/opt/f3/flutter/bin/cache/artifacts/material_fonts/MaterialIcons-Regular.otf').readAsBytesSync();
  await (FontLoader('MaterialIcons')..addFont(Future.value(ByteData.view(icon.buffer)))).load();
}

Widget _wrap(Widget home) {
  final t = buildDarkTheme();
  return MaterialApp(
    debugShowCheckedModeBanner: false,
    theme: t.copyWith(
      textTheme: t.textTheme.apply(fontFamily: 'CJK'),
      primaryTextTheme: t.primaryTextTheme.apply(fontFamily: 'CJK'),
      appBarTheme: t.appBarTheme.copyWith(
        titleTextStyle: (t.appBarTheme.titleTextStyle ?? const TextStyle())
            .copyWith(fontFamily: 'CJK', color: const Color(0xFFEDEDF5)),
      ),
    ),
    home: home,
  );
}

Future<void> _setup(WidgetTester tester, {String provider = 'bing', String key = ''}) async {
  tester.view.physicalSize = const Size(1080, 2280);
  tester.view.devicePixelRatio = 3.0;
  addTearDown(tester.view.resetPhysicalSize);
  addTearDown(tester.view.resetDevicePixelRatio);

  SharedPreferences.setMockInitialValues(<String, Object>{});
  await AppState.I.init();
  final b = Novel(title: '灰烬纪元');
  AppState.I.books = [b];
  AppState.I.currentId = b.id;
  AppState.I.settings
    ..searchEnabled = false
    ..searchProvider = provider
    ..searchKey = key;
  AppState.I.goTab(0);
  await tester.pumpWidget(_wrap(const HomeShell()));
  await tester.pumpAndSettle();
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  setUp(() async => _loadFonts());

  testWidgets('右边不再有开关', (tester) async {
    await _setup(tester);
    expect(find.byType(Switch), findsNothing);
  });

  testWidgets('点一下开启并高亮，再点一下关闭', (tester) async {
    await _setup(tester);

    expect(find.text('联网搜索'), findsOneWidget);
    expect(find.text('必应'), findsNothing); // 关着的时候不显示通道

    await tester.tap(find.text('联网搜索'));
    await tester.pumpAndSettle();
    expect(AppState.I.settings.searchEnabled, isTrue);
    expect(find.text('必应'), findsOneWidget); // 通道标签出现 = 高亮态

    await tester.tap(find.text('联网搜索'));
    await tester.pumpAndSettle();
    expect(AppState.I.settings.searchEnabled, isFalse);
    expect(find.text('必应'), findsNothing);
  });

  testWidgets('博查没填 Key 时，点一下先去配置，不会假装打开', (tester) async {
    await _setup(tester, provider: 'bocha');

    await tester.tap(find.text('联网搜索'));
    await tester.pumpAndSettle();

    expect(AppState.I.settings.searchEnabled, isFalse);
    expect(find.text('通道'), findsOneWidget); // 设置面板打开了
  });

  testWidgets('点通道标签进设置，不改开关状态', (tester) async {
    await _setup(tester, provider: 'bing', key: 'k');
    await tester.tap(find.text('联网搜索'));
    await tester.pumpAndSettle();
    expect(AppState.I.settings.searchEnabled, isTrue);

    await tester.tap(find.text('必应'));
    await tester.pumpAndSettle();
    expect(find.text('通道'), findsOneWidget);
    expect(AppState.I.settings.searchEnabled, isTrue);
  });
}
