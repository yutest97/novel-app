import 'package:flutter/material.dart';

import '../theme.dart';
import 'settings_ai_page.dart';
import 'simple_pages.dart';
import 'sync_page.dart';

/// 设置首页：分组卡片菜单
class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 30),
          children: [
            const Text('设置', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w700)),
            const SizedBox(height: 4),
            const Text('管理 AI、外观、同步和应用数据', style: TextStyle(fontSize: 11.5, color: C.dim)),
            const SizedBox(height: 18),
            _group(context, [
              _item(
                context,
                icon: Icons.dns_outlined,
                title: 'AI 提供商',
                subtitle: '模型、接口与密钥',
                page: const AiSettingsPage(),
              ),
              _item(
                context,
                icon: Icons.extension_outlined,
                title: 'Skill 管理',
                subtitle: '浏览、导入与管理写作技能',
                page: const SkillPage(),
              ),
              _item(
                context,
                icon: Icons.tune,
                title: '参数',
                subtitle: '温度、提示词、上下文与输出',
                page: const ParamsPage(),
              ),
              _item(
                context,
                icon: Icons.palette_outlined,
                title: '主题',
                subtitle: '外观、背景与显示',
                page: const ThemePage(),
              ),
            ]),
            const SizedBox(height: 18),
            const Padding(
              padding: EdgeInsets.only(left: 4, bottom: 8),
              child: Text('账户与数据', style: TextStyle(fontSize: 11.5, color: C.dim)),
            ),
            _group(context, [
              _item(
                context,
                icon: Icons.workspace_premium_outlined,
                title: 'VIP',
                subtitle: '高级功能与激活',
                page: const ComingPage(
                  title: 'VIP',
                  desc: '高级排版、多端同步、批量生成这些功能还在排期，现在全部现有功能都免费可用。',
                ),
              ),
              _item(
                context,
                icon: Icons.sync,
                title: '同步',
                subtitle: 'WebDAV 云备份与局域网传输',
                page: const SyncPage(),
              ),
              _item(
                context,
                icon: Icons.storage_outlined,
                title: '数据',
                subtitle: '重置软件配置与记录',
                page: const DataPage(),
              ),
              _item(
                context,
                icon: Icons.info_outline,
                title: '关于',
                subtitle: '版本、更新与反馈',
                page: const AboutPage(),
              ),
            ]),
          ],
        ),
      ),
    );
  }

  Widget _group(BuildContext context, List<Widget> children) {
    return Container(
      decoration: BoxDecoration(
        color: C.card,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: C.border, width: 0.6),
      ),
      child: Column(
        children: [
          for (var i = 0; i < children.length; i++) ...[
            if (i > 0) const Divider(height: 1, indent: 60, endIndent: 14),
            children[i],
          ],
        ],
      ),
    );
  }

  Widget _item(
    BuildContext context, {
    required IconData icon,
    required String title,
    required String subtitle,
    required Widget page,
  }) {
    return InkWell(
      onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => page)),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
        child: Row(
          children: [
            Container(
              width: 32,
              height: 32,
              decoration: BoxDecoration(
                color: const Color(0x337B5CFF),
                borderRadius: BorderRadius.circular(9),
              ),
              child: Icon(icon, size: 17, color: C.purpleSoft),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w500)),
                  const SizedBox(height: 2),
                  Text(subtitle, style: const TextStyle(fontSize: 11, color: C.dim)),
                ],
              ),
            ),
            const Icon(Icons.chevron_right, size: 18, color: C.faint),
          ],
        ),
      ),
    );
  }
}
