import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:novel_app/models.dart';
import 'package:novel_app/screens/settings_ai_page.dart';
import 'package:novel_app/store.dart';
import 'package:novel_app/theme.dart';

Future<void> _loadFonts() async {
  final cjk = File('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc').readAsBytesSync();
  for (final f in ['CJK', 'monospace', 'Roboto']) {
    await (FontLoader(f)..addFont(Future.value(ByteData.view(cjk.buffer)))).load();
  }
  final icon = File('/opt/f3/flutter/bin/cache/artifacts/material_fonts/MaterialIcons-Regular.otf').readAsBytesSync();
  await (FontLoader('MaterialIcons')..addFont(Future.value(ByteData.view(icon.buffer)))).load();
}

Widget _wrap(Widget home) {
  final t = buildDarkTheme();
  return MaterialApp(
    debugShowCheckedModeBanner: false,
    theme: t.copyWith(
      textTheme: t.textTheme.apply(fontFamily: 'CJK'),
      primaryTextTheme: t.primaryTextTheme.apply(fontFamily: 'CJK'),
      appBarTheme: t.appBarTheme.copyWith(
        titleTextStyle: (t.appBarTheme.titleTextStyle ?? const TextStyle())
            .copyWith(fontFamily: 'CJK', color: const Color(0xFFEDEDF5)),
      ),
    ),
    home: home,
  );
}

Future<void> _connected() async {
  SharedPreferences.setMockInitialValues(<String, Object>{});
  await AppState.I.init();
  final json = AppState.I.settings.toJson()
    ..['baseUrl'] = 'https://api.deepseek.com/v1'
    ..['apiKey'] = 'sk-1234567890abcdef'
    ..['model'] = 'deepseek-chat'
    ..['provider'] = 'DeepSeek'
    ..['requestCount'] = 12
    ..['totalTokens'] = 18600;
  await AppState.I.saveSettings(Settings.fromJson(json));
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  setUp(() async => _loadFonts());

  testWidgets('已连接时直接显示连接页', (tester) async {
    tester.view.physicalSize = const Size(1080, 2280);
    tester.view.devicePixelRatio = 3.0;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);

    await _connected();
    await tester.pumpWidget(_wrap(const AiSettingsPage()));
    await tester.pumpAndSettle();

    expect(find.text('已连接'), findsWidgets);
    expect(find.text('deepseek-chat'), findsWidgets);
    expect(find.text('修改配置'), findsOneWidget);
    expect(find.text('断开连接'), findsOneWidget);
    // 参考图没有的补充信息
    expect(find.text('当前参数'), findsOneWidget);
    expect(find.text('本机用量'), findsOneWidget);
    expect(find.text('12 次请求 · 18.6K tokens'), findsOneWidget);
    expect(find.text('换个模型'), findsOneWidget);
    expect(find.text('deepseek-reasoner'), findsOneWidget);
    // Key 打码，不出现明文
    expect(find.textContaining('sk-1234567890abcdef'), findsNothing);
    expect(find.textContaining('••••'), findsOneWidget);
  });

  testWidgets('点「换个模型」直接切过去', (tester) async {
    tester.view.physicalSize = const Size(1080, 2280);
    tester.view.devicePixelRatio = 3.0;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);

    await _connected();
    await tester.pumpWidget(_wrap(const AiSettingsPage()));
    await tester.pumpAndSettle();

    await tester.tap(find.text('deepseek-reasoner'));
    await tester.pumpAndSettle();

    expect(AppState.I.settings.model, 'deepseek-reasoner');
    expect(AppState.I.settings.apiKey, 'sk-1234567890abcdef');
  });

  testWidgets('「修改配置」回到表单，带取消', (tester) async {
    tester.view.physicalSize = const Size(1080, 2280);
    tester.view.devicePixelRatio = 3.0;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);

    await _connected();
    await tester.pumpWidget(_wrap(const AiSettingsPage()));
    await tester.pumpAndSettle();

    await tester.tap(find.text('修改配置'));
    await tester.pumpAndSettle();
    expect(find.text('保存并测试'), findsOneWidget);
    expect(find.text('取消'), findsOneWidget);

    await tester.tap(find.text('取消'));
    await tester.pumpAndSettle();
    expect(find.text('当前参数'), findsOneWidget);
  });

  testWidgets('断开连接清掉 Key，但保留地址和模型', (tester) async {
    tester.view.physicalSize = const Size(1080, 2280);
    tester.view.devicePixelRatio = 3.0;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);

    await _connected();
    await tester.pumpWidget(_wrap(const AiSettingsPage()));
    await tester.pumpAndSettle();

    await tester.tap(find.text('断开连接'));
    await tester.pumpAndSettle();
    expect(find.text('断开连接？'), findsOneWidget);

    await tester.tap(find.text('断开'));
    await tester.pumpAndSettle();

    expect(AppState.I.settings.apiKey, isEmpty);
    expect(AppState.I.settings.baseUrl, 'https://api.deepseek.com/v1');
    expect(AppState.I.settings.model, 'deepseek-chat');
    // 回到表单
    expect(find.text('保存并测试'), findsOneWidget);
  });

  testWidgets('未连接时还是表单', (tester) async {
    SharedPreferences.setMockInitialValues(<String, Object>{});
    await AppState.I.init();
    await tester.pumpWidget(_wrap(const AiSettingsPage()));
    await tester.pumpAndSettle();

    expect(find.text('保存并测试'), findsOneWidget);
    expect(find.text('当前参数'), findsNothing);
  });
}
