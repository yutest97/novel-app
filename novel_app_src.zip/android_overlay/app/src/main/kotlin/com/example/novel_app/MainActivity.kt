package com.example.novel_app

import android.app.Activity
import android.content.Intent
import android.media.AudioManager
import android.media.ToneGenerator
import android.net.Uri
import android.provider.DocumentsContract
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.FileNotFoundException

class MainActivity : FlutterActivity() {
    private val channelName = "novel_app/storage"
    private val soundChannel = "novel_app/sound"
    private val requestPick = 4213
    private var pending: MethodChannel.Result? = null
    private var tone: ToneGenerator? = null

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "pickDirectory" -> startPick(result)
                    "check" -> result.success(hasPermission(call.argument<String>("uri")))
                    "list" -> try {
                        result.success(listFiles(call.argument<String>("uri")))
                    } catch (e: Exception) {
                        result.error("list", e.message ?: "读取目录失败", null)
                    }
                    "read" -> try {
                        result.success(readFile(call.argument<String>("uri"), call.argument<String>("name")))
                    } catch (e: Exception) {
                        result.error("read", e.message ?: "读取失败", null)
                    }
                    "write" -> try {
                        writeFile(
                            call.argument<String>("uri"),
                            call.argument<String>("name"),
                            call.argument<ByteArray>("bytes")
                        )
                        result.success(null)
                    } catch (e: Exception) {
                        result.error("write", e.message ?: "写入失败", null)
                    }
                    "delete" -> try {
                        deleteFile(call.argument<String>("uri"), call.argument<String>("name"))
                        result.success(null)
                    } catch (e: Exception) {
                        result.error("delete", e.message ?: "删除失败", null)
                    }
                    else -> result.notImplemented()
                }
            }
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, soundChannel)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "beep" -> {
                        // 走通知音轨：不依赖系统「触摸提示音」，静音模式仍会被系统压掉
                        try {
                            if (tone == null) {
                                tone = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 85)
                            }
                            tone?.startTone(ToneGenerator.TONE_PROP_ACK, 180)
                            result.success(true)
                        } catch (e: Exception) {
                            result.success(false)
                        }
                    }
                    else -> result.notImplemented()
                }
            }
    }

    override fun onDestroy() {
        try {
            tone?.release()
        } catch (_: Exception) {
        }
        tone = null
        super.onDestroy()
    }

    private fun startPick(result: MethodChannel.Result) {
        if (pending != null) {
            result.error("busy", "已经有一个目录选择在进行了", null)
            return
        }
        pending = result
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
            addFlags(
                Intent.FLAG_GRANT_READ_URI_PERMISSION or
                    Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                    Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
            )
        }
        try {
            startActivityForResult(intent, requestPick)
        } catch (e: Exception) {
            pending = null
            result.error("pick", e.message ?: "打不开目录选择器", null)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != requestPick) return
        val result = pending ?: return
        pending = null
        val uri = data?.data
        if (resultCode != Activity.RESULT_OK || uri == null) {
            result.success(null)
            return
        }
        try {
            contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
        } catch (_: Exception) {
            // 有的文件管理器不给持久化授权，先继续，写入时会再报错
        }
        val name = queryName(uri) ?: "外部目录"
        result.success(mapOf("uri" to uri.toString(), "name" to name))
    }

    private fun treeDoc(uri: Uri): Uri =
        DocumentsContract.buildDocumentUriUsingTree(uri, DocumentsContract.getTreeDocumentId(uri))

    private fun queryName(uri: Uri): String? {
        return try {
            contentResolver.query(
                uri,
                arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME),
                null, null, null
            )?.use { c ->
                if (c.moveToFirst()) c.getString(0) else null
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun hasPermission(uriStr: String?): Boolean {
        if (uriStr.isNullOrEmpty()) return false
        val uri = Uri.parse(uriStr)
        return try {
            contentResolver.persistedUriPermissions.any {
                it.uri == uri && it.isReadPermission && it.isWritePermission
            }
        } catch (e: Exception) {
            false
        }
    }

    private fun listFiles(uriStr: String?): List<Map<String, Any?>> {
        val tree = Uri.parse(uriStr ?: throw IllegalArgumentException("目录为空"))
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(
            tree, DocumentsContract.getTreeDocumentId(tree)
        )
        val out = mutableListOf<Map<String, Any?>>()
        contentResolver.query(
            children,
            arrayOf(
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_SIZE,
                DocumentsContract.Document.COLUMN_LAST_MODIFIED,
                DocumentsContract.Document.COLUMN_MIME_TYPE
            ),
            null, null, null
        )?.use { c ->
            while (c.moveToNext()) {
                out.add(
                    mapOf(
                        "name" to c.getString(1),
                        "size" to c.getLong(2),
                        "modified" to c.getLong(3),
                        "mime" to c.getString(4)
                    )
                )
            }
        }
        return out
    }

    private fun findChild(tree: Uri, name: String): Uri? {
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(
            tree, DocumentsContract.getTreeDocumentId(tree)
        )
        contentResolver.query(
            children,
            arrayOf(
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME
            ),
            null, null, null
        )?.use { c ->
            while (c.moveToNext()) {
                if (c.getString(1) == name) {
                    return DocumentsContract.buildDocumentUriUsingTree(tree, c.getString(0))
                }
            }
        }
        return null
    }

    private fun writeFile(uriStr: String?, name: String?, bytes: ByteArray?) {
        val tree = Uri.parse(uriStr ?: throw IllegalArgumentException("目录为空"))
        val fileName = name ?: throw IllegalArgumentException("文件名为空")
        val data = bytes ?: ByteArray(0)
        val doc = findChild(tree, fileName)
            ?: DocumentsContract.createDocument(
                contentResolver, treeDoc(tree), "application/json", fileName
            )
            ?: throw IllegalStateException("创建文件失败")
        contentResolver.openOutputStream(doc, "wt")?.use { it.write(data) }
            ?: throw FileNotFoundException("写不进这个文件")
    }

    private fun readFile(uriStr: String?, name: String?): String {
        val tree = Uri.parse(uriStr ?: throw IllegalArgumentException("目录为空"))
        val doc = findChild(tree, name ?: throw IllegalArgumentException("文件名为空")) ?: return ""
        return contentResolver.openInputStream(doc)?.use {
            it.readBytes().toString(Charsets.UTF_8)
        } ?: ""
    }

    private fun deleteFile(uriStr: String?, name: String?) {
        val tree = Uri.parse(uriStr ?: throw IllegalArgumentException("目录为空"))
        val doc = findChild(tree, name ?: return) ?: return
        DocumentsContract.deleteDocument(contentResolver, doc)
    }
}
