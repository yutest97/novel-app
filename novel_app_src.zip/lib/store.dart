import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'llm.dart';
import 'models.dart';
import 'prompt.dart';

/// 当前这一轮要用户确认什么
enum Pending { none, saveChapter, syncDocs }

/// 全局状态：一本书、设置、聊天记录，全部落在手机本地
class AppState extends ChangeNotifier {
  static final AppState I = AppState._();
  AppState._();

  static const _kNovel = 'novel_v1';
  static const _kSettings = 'settings_v1';
  static const _kChat = 'chat_v1';

  SharedPreferences? _prefs;

  Novel novel = Novel();
  Settings settings = Settings();
  final List<ChatBubble> bubbles = <ChatBubble>[];

  bool ready = false;
  bool busy = false;
  String? errorText;
  String _lastUserText = '';

  Pending pending = Pending.none;
  String pendingTitle = '';
  String pendingContent = '';
  Map<String, String> pendingDocs = const {};

  // ---------- 启动 ----------

  Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();

    final n = _prefs!.getString(_kNovel);
    if (n != null && n.isNotEmpty) {
      try {
        novel = Novel.fromJson(jsonDecode(n) as Map<String, dynamic>);
      } catch (_) {/* 存档坏了就当新书 */}
    }

    final s = _prefs!.getString(_kSettings);
    if (s != null && s.isNotEmpty) {
      try {
        settings = Settings.fromJson(jsonDecode(s) as Map<String, dynamic>);
      } catch (_) {}
    }

    final c = _prefs!.getString(_kChat);
    if (c != null && c.isNotEmpty) {
      try {
        final list = jsonDecode(c) as List<dynamic>;
        bubbles
          ..clear()
          ..addAll(list.map((e) => ChatBubble.fromJson(e as Map<String, dynamic>)));
      } catch (_) {}
    }

    if (bubbles.isEmpty) {
      bubbles.add(ChatBubble(
        role: 'assistant',
        text: '我是写小说助手。\n\n接下来我会一步步问你：写什么题材、主角是谁、有什么金手指，然后一章一章写出来（每章 2000 字以上）。你只要点选项就行，想不到合适的就点「自定义」自己写一句。',
        options: [
          Choice('开始新建一本', '从题材开始，一步步定设定'),
          Choice('我已经想好了', '直接告诉我你的想法'),
        ],
      ));
    }

    ready = true;
    notifyListeners();
  }

  // ---------- 保存到本地 ----------

  Future<void> _persist() async {
    final p = _prefs;
    if (p == null) return;
    await p.setString(_kNovel, jsonEncode(novel.toJson()));
    await p.setString(_kSettings, jsonEncode(settings.toJson()));
    final recent = bubbles.length > 60 ? bubbles.sublist(bubbles.length - 60) : bubbles;
    await p.setString(_kChat, jsonEncode(recent.map((b) => b.toJson()).toList()));
  }

  // ---------- 发消息 ----------

  Future<void> send(String text) async {
    final t = text.trim();
    if (t.isEmpty || busy) return;
    _lastUserText = t;
    errorText = null;
    bubbles.add(ChatBubble(role: 'user', text: t));
    notifyListeners();
    await _call();
  }

  /// 用户点「重试」：历史里已有上一条用户消息，直接重发
  Future<void> retry() async {
    if (busy || _lastUserText.isEmpty) return;
    errorText = null;
    await _call();
  }

  Future<void> _call() async {
    if (!settings.isReady) {
      errorText = '还没填 API Key。请到「设置」页填好供应商、Key 和模型名，再回来继续。';
      notifyListeners();
      return;
    }

    busy = true;
    errorText = null;
    notifyListeners();

    try {
      final system = await buildSystemPrompt(novel);
      final msgs = <Map<String, String>>[
        {'role': 'system', 'content': system},
      ];

      // 只带最近 12 条，避免太长
      final recent = bubbles.length > 12 ? bubbles.sublist(bubbles.length - 12) : bubbles;
      for (final b in recent) {
        if (b.role == 'assistant' && b.text.trim().isEmpty) continue;
        msgs.add({'role': b.role, 'content': b.text});
      }
      final raw = await callModel(settings: settings, messages: msgs);
      final reply = AiReply.parse(raw);

      if (reply.message.trim().isNotEmpty) {
        bubbles.add(ChatBubble(
          role: 'assistant',
          text: reply.message,
          options: reply.options,
        ));
      }

      if (reply.hasChapter) {
        pendingTitle = reply.chapterTitle.trim().isEmpty
            ? '第${novel.chapters.length + 1}章'
            : reply.chapterTitle.trim();
        pendingContent = reply.chapterContent.trim();
        pending = Pending.saveChapter;
      } else {
        pending = Pending.none;
      }

      await _persist();
    } on LlmException catch (e) {
      errorText = e.message;
    } catch (e) {
      errorText = '出了点意外：$e';
    } finally {
      busy = false;
      notifyListeners();
    }
  }

  // ---------- 保存章节 ----------

  void confirmSaveChapter() {
    if (pending != Pending.saveChapter) return;
    novel.chapters.add(Chapter(title: pendingTitle, content: pendingContent));
    pending = Pending.none;
    pendingTitle = '';
    pendingContent = '';
    notifyListeners();
    _persist();
  }

  void cancelSaveChapter() {
    pending = Pending.none;
    pendingTitle = '';
    pendingContent = '';
    notifyListeners();
  }

  // ---------- 章节存完后，问是否同步资料 ----------

  Future<void> requestDocsUpdate() async {
    if (busy) return;
    busy = true;
    errorText = null;
    notifyListeners();
    try {
      final system = await buildSystemPrompt(novel);
      final msgs = <Map<String, String>>[
        {'role': 'system', 'content': system},
        {'role': 'user', 'content': buildSyncPrompt(novel)},
      ];
      final raw = await callModel(settings: settings, messages: msgs);
      final reply = AiReply.parse(raw);
      if (reply.hasDocs) {
        pendingDocs = reply.docs;
        pending = Pending.syncDocs;
      } else {
        errorText = '模型这次没给出资料更新，可以先跳过，下一章再同步。';
      }
      await _persist();
    } on LlmException catch (e) {
      errorText = e.message;
    } catch (e) {
      errorText = '出了点意外：$e';
    } finally {
      busy = false;
      notifyListeners();
    }
  }

  void confirmSyncDocs() {
    if (pending != Pending.syncDocs) return;
    if (pendingDocs.containsKey('characters')) novel.characters = pendingDocs['characters']!;
    if (pendingDocs.containsKey('world')) novel.world = pendingDocs['world']!;
    if (pendingDocs.containsKey('summary')) novel.summary = pendingDocs['summary']!;
    pendingDocs = const {};
    pending = Pending.none;
    notifyListeners();
    _persist();
  }

  void cancelSyncDocs() {
    pendingDocs = const {};
    pending = Pending.none;
    notifyListeners();
  }

  // ---------- 设置 ----------

  Future<void> saveSettings(Settings s) async {
    settings = s;
    await _persist();
    notifyListeners();
  }

  Future<void> renameNovel(String title) async {
    novel.title = title.trim();
    await _persist();
    notifyListeners();
  }

  /// 新建一本：清空书和聊天，不动设置
  Future<void> resetNovel() async {
    novel = Novel();
    bubbles
      ..clear()
      ..add(ChatBubble(
        role: 'assistant',
        text: '新书已清空（旧书内容不会保留）。\n\n先定题材：你想写哪一类？',
        options: [
          Choice('都市', '现代背景，贴近生活'),
          Choice('玄幻', '架空世界，修炼升级'),
          Choice('悬疑', '案件推理，节奏紧'),
          Choice('言情', '感情线为主'),
        ],
      ));
    pending = Pending.none;
    pendingDocs = const {};
    await _persist();
    notifyListeners();
  }
}
