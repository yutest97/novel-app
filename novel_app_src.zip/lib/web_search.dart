import 'dart:convert';

import 'package:http/http.dart' as http;
import 'package:html/parser.dart' as html_parser;

import 'models.dart';

/// 搜索失败：message 可以直接展示给用户
class WebSearchException implements Exception {
  final String message;
  WebSearchException(this.message);

  @override
  String toString() => message;
}

/// 两个通道的域名，测试时可以改成本地假服务
String bingBase = 'https://cn.bing.com';
String bochaBase = 'https://api.bochaai.com';

const String _ua =
    'Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 '
    '(KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36';

/// 给模型看的工具声明
const Map<String, dynamic> kWebSearchToolSpec = {
  'type': 'function',
  'function': {
    'name': 'web_search',
    'description': '联网搜索网页。需要最新资讯、榜单、书籍资料、作者背景等外部信息时用它。'
        '返回若干条标题、链接和摘要，回答时要引用这些结果，不要编造。',
    'parameters': {
      'type': 'object',
      'properties': {
        'query': {
          'type': 'string',
          'description': '搜索词。要具体，例如「2026 年 10 月 都市 小说 畅销榜」',
        },
      },
      'required': ['query'],
    },
  },
};

String _siteOf(String url) {
  final u = Uri.tryParse(url);
  if (u == null || u.host.isEmpty) return '';
  return u.host.replaceFirst(RegExp(r'^www\.'), '');
}

String _clean(String s) =>
    s.replaceAll(RegExp(r'\s+'), ' ').replaceAll('\u00a0', ' ').trim();

/// 统一入口：provider = bing | bocha
Future<List<WebSource>> searchWeb({
  required String provider,
  required String key,
  required String query,
  int count = 5,
}) async {
  final q = query.trim();
  if (q.isEmpty) throw WebSearchException('搜索词是空的。');
  final n = count.clamp(1, 10);
  if (provider == 'bocha') return _searchBocha(q, key, n);
  return _searchBing(q, n);
}

/// 必应网页搜索：不需要 Key，解析结果页
Future<List<WebSource>> _searchBing(String query, int count) async {
  final base = bingBase.replaceAll(RegExp(r'/+$'), '');
  final uri = Uri.parse('$base/search').replace(queryParameters: {
    'q': query,
    'count': '$count',
    'setlang': 'zh-Hans',
    'mkt': 'zh-CN',
  });

  http.Response resp;
  try {
    resp = await http.get(uri, headers: {
      'User-Agent': _ua,
      'Accept': 'text/html,application/xhtml+xml',
      'Accept-Language': 'zh-CN,zh;q=0.9',
    }).timeout(const Duration(seconds: 15));
  } catch (_) {
    throw WebSearchException('连不上必应。检查网络，或换用「博查」通道。');
  }

  if (resp.statusCode != 200) {
    throw WebSearchException('必应返回 HTTP ${resp.statusCode}，可能被限流，稍后再试。');
  }

  final doc = html_parser.parse(resp.body);
  final out = <WebSource>[];

  for (final li in doc.querySelectorAll('li.b_algo')) {
    final a = li.querySelector('h2 a') ?? li.querySelector('a');
    final href = a?.attributes['href'] ?? '';
    final title = _clean(a?.text ?? '');
    if (title.isEmpty || href.isEmpty) continue;
    if (!href.startsWith('http')) continue;
    if (href.contains('bing.com/ck/a')) continue; // 跳转壳，解析不出真实地址

    var snippet = '';
    for (final sel in ['.b_caption p', '.b_snippet', 'p']) {
      final el = li.querySelector(sel);
      if (el != null && _clean(el.text).length > snippet.length) {
        snippet = _clean(el.text);
      }
    }
    // 去掉标题重复
    snippet = snippet.replaceFirst(title, '').trim();

    out.add(WebSource(
      title: title,
      url: href,
      snippet: snippet.length > 220 ? '${snippet.substring(0, 220)}…' : snippet,
      site: _siteOf(href),
    ));
    if (out.length >= count) break;
  }

  if (out.isEmpty) {
    throw WebSearchException(
      '必应这页没解析出结果（可能被要求验证，或页面结构变了）。'
      '可以换用「博查」通道，把搜索词写具体一点再试。',
    );
  }
  return out;
}

/// 博查 Web Search API：国内直连，返回结构化结果
Future<List<WebSource>> _searchBocha(String query, String key, int count) async {
  final k = key.trim();
  if (k.isEmpty) {
    throw WebSearchException('博查需要 API Key。去 open.bochaai.com 注册后填到设置里。');
  }
  final base = bochaBase.replaceAll(RegExp(r'/+$'), '');

  http.Response resp;
  try {
    resp = await http
        .post(
          Uri.parse('$base/v1/web-search'),
          headers: {
            'Authorization': 'Bearer $k',
            'Content-Type': 'application/json',
            'Accept': 'application/json',
          },
          body: jsonEncode({
            'query': query,
            'count': count,
            'summary': true,
            'freshness': 'noLimit',
          }),
        )
        .timeout(const Duration(seconds: 20));
  } catch (_) {
    throw WebSearchException('连不上博查接口。检查网络，或换用「必应」通道。');
  }

  if (resp.statusCode == 401 || resp.statusCode == 403) {
    throw WebSearchException('博查 Key 不对或没权限（HTTP ${resp.statusCode}）。');
  }
  if (resp.statusCode != 200) {
    final body = resp.body.length > 120 ? resp.body.substring(0, 120) : resp.body;
    throw WebSearchException('博查报错（HTTP ${resp.statusCode}）：$body');
  }

  dynamic data;
  try {
    data = jsonDecode(resp.body);
  } catch (_) {
    throw WebSearchException('博查返回的不是 JSON，可能被网关拦了。');
  }
  if (data is! Map) throw WebSearchException('博查返回格式不对。');

  final payload = data['data'];
  final pages = payload is Map ? payload['webPages'] : null;
  final values = pages is Map ? pages['value'] : null;
  if (values is! List || values.isEmpty) {
    throw WebSearchException('博查没搜到「$query」的结果。换个说法再试。');
  }

  final out = <WebSource>[];
  for (final raw in values) {
    if (raw is! Map) continue;
    final url = (raw['url'] ?? '').toString();
    final title = _clean((raw['name'] ?? raw['title'] ?? '').toString());
    if (url.isEmpty || title.isEmpty) continue;
    final snip = _clean(
      (raw['summary'] ?? raw['snippet'] ?? raw['description'] ?? '').toString(),
    );
    out.add(WebSource(
      title: title,
      url: url,
      snippet: snip.length > 220 ? '${snip.substring(0, 220)}…' : snip,
      site: (raw['siteName'] ?? '').toString().isNotEmpty
          ? raw['siteName'].toString()
          : _siteOf(url),
    ));
    if (out.length >= count) break;
  }
  if (out.isEmpty) throw WebSearchException('博查返回了结果，但没有能用的条目。');
  return out;
}

/// 拼成给模型看的文本，带编号，方便它写 [1][2]
String formatSources(List<WebSource> list) {
  final buf = StringBuffer();
  for (var i = 0; i < list.length; i++) {
    final s = list[i];
    buf.writeln('[${i + 1}] ${s.title}');
    buf.writeln('链接：${s.url}');
    if (s.snippet.isNotEmpty) buf.writeln('摘要：${s.snippet}');
    buf.writeln();
  }
  return buf.toString().trimRight();
}

/// 给系统提示词用的规则
const String kSearchRules = '''
【联网搜索结果使用规则】
下面会给你一份搜索结果（带 [1][2] 编号）。要求：
1. 优先依据这些结果回答，引用具体信息时在句末标上来源编号，例如 [1]。
2. 结果里没有的内容就直说「搜索结果里没有」，不要用记忆补齐，也不要编链接和数字。
3. 如果搜索结果和问题无关，明确说「这次没搜到相关的」，然后给出你自己的判断，并说明这不是来自搜索结果。
4. 不要复述整段摘要，用自己的话概括。''';
