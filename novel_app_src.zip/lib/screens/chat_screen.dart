import 'package:flutter/material.dart';

import '../models.dart';
import '../store.dart';

/// 对话页：AI 抛选项 → 用户点选 → 下一步。核心交互都在这里。
class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final TextEditingController _input = TextEditingController();
  final ScrollController _scroll = ScrollController();
  int _bubbleCount = 0;

  @override
  void dispose() {
    _input.dispose();
    _scroll.dispose();
    super.dispose();
  }

  void _scrollToEnd() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) {
        _scroll.animateTo(
          _scroll.position.maxScrollExtent,
          duration: const Duration(milliseconds: 250),
          curve: Curves.easeOut,
        );
      }
    });
  }

  Future<void> _send(String text) async {
    _input.clear();
    await AppState.I.send(text);
    _scrollToEnd();
  }

  Future<void> _openCustomInput() async {
    final ctrl = TextEditingController();
    final result = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('自己写一句'),
        content: TextField(
          controller: ctrl,
          autofocus: true,
          maxLines: 4,
          minLines: 1,
          decoration: const InputDecoration(
            hintText: '比如：我要写一个外卖员捡到系统的小说',
            border: OutlineInputBorder(),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('取消')),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, ctrl.text),
            child: const Text('发送'),
          ),
        ],
      ),
    );
    if (result != null && result.trim().isNotEmpty) {
      await _send(result.trim());
    }
  }

  @override
  Widget build(BuildContext context) {
    final st = AppState.I;
    return AnimatedBuilder(
      animation: st,
      builder: (context, _) {
        if (st.bubbles.length != _bubbleCount) {
          _bubbleCount = st.bubbles.length;
          _scrollToEnd();
        }
        final showOptionsOfIndex =
            (!st.busy && st.pending == Pending.none) ? st.bubbles.length - 1 : -1;

        return Scaffold(
          appBar: AppBar(
            title: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  st.novel.title.trim().isEmpty ? 'AI 写小说' : st.novel.title,
                  style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600),
                ),
                Text(
                  '已存 ${st.novel.chapters.length} 章',
                  style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
                ),
              ],
            ),
            actions: [
              if (st.busy)
                const Padding(
                  padding: EdgeInsets.only(right: 16),
                  child: Center(
                    child: SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)),
                  ),
                ),
            ],
          ),
          body: Column(
            children: [
              Expanded(
                child: ListView.builder(
                  controller: _scroll,
                  padding: const EdgeInsets.fromLTRB(12, 12, 12, 8),
                  itemCount: st.bubbles.length,
                  itemBuilder: (context, i) {
                    final b = st.bubbles[i];
                    final isUser = b.role == 'user';
                    return Column(
                      crossAxisAlignment: isUser ? CrossAxisAlignment.end : CrossAxisAlignment.start,
                      children: [
                        _Bubble(text: b.text, isUser: isUser),
                        if (i == showOptionsOfIndex && b.options.isNotEmpty)
                          Padding(
                            padding: const EdgeInsets.only(top: 8, bottom: 4, right: 8),
                            child: Wrap(
                              spacing: 8,
                              runSpacing: 8,
                              children: [
                                for (final o in b.options) _choiceButton(o),
                                _customButton(),
                              ],
                            ),
                          ),
                        const SizedBox(height: 10),
                      ],
                    );
                  },
                ),
              ),
              if (st.errorText != null) _errorBar(st),
              if (!st.busy) _actionBar(st),
              _inputBar(st),
            ],
          ),
        );
      },
    );
  }

  Widget _choiceButton(Choice o) {
    return SizedBox(
      width: 158,
      child: OutlinedButton(
        onPressed: () => _send(o.label),
        style: OutlinedButton.styleFrom(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
          alignment: Alignment.centerLeft,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(o.label, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
            if (o.hint.trim().isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 2),
                child: Text(
                  o.hint,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(fontSize: 11, color: Colors.grey.shade600),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _customButton() {
    return SizedBox(
      width: 158,
      child: OutlinedButton.icon(
        onPressed: _openCustomInput,
        icon: const Icon(Icons.edit_outlined, size: 15),
        label: const Text('自定义', style: TextStyle(fontSize: 13)),
        style: OutlinedButton.styleFrom(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 14),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        ),
      ),
    );
  }

  Widget _errorBar(AppState st) {
    return Container(
      width: double.infinity,
      color: const Color(0xFFFFF3F2),
      padding: const EdgeInsets.fromLTRB(12, 8, 8, 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Icon(Icons.error_outline, size: 18, color: Color(0xFFD9534F)),
          const SizedBox(width: 6),
          Expanded(
            child: Text(st.errorText!, style: const TextStyle(fontSize: 12, color: Color(0xFF9B2C2C))),
          ),
          TextButton(onPressed: st.retry, child: const Text('重试')),
        ],
      ),
    );
  }

  Widget _actionBar(AppState st) {
    if (st.pending == Pending.saveChapter) {
      return _bar(
        label: '这一章「${st.pendingTitle}」写完了，存吗？',
        primaryText: '保存这一章',
        onPrimary: () async {
          st.confirmSaveChapter();
          await st.requestDocsUpdate(); // 存完顺带整理人物库/世界观
        },
        secondaryText: '我先想想',
        onSecondary: st.cancelSaveChapter,
      );
    }
    if (st.pending == Pending.syncDocs) {
      return _bar(
        label: '人物库、世界观、章节摘要要一起更新吗？',
        primaryText: '同步资料',
        onPrimary: st.confirmSyncDocs,
        secondaryText: '先不同步',
        onSecondary: st.cancelSyncDocs,
      );
    }
    return const SizedBox.shrink();
  }

  Widget _bar({
    required String label,
    required String primaryText,
    required VoidCallback onPrimary,
    required String secondaryText,
    required VoidCallback onSecondary,
  }) {
    return Container(
      width: double.infinity,
      color: const Color(0xFFEEF0FB),
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(fontSize: 12, color: Color(0xFF3D4785))),
          const SizedBox(height: 6),
          Row(
            children: [
              Expanded(
                child: ElevatedButton(
                  onPressed: onPrimary,
                  child: Text(primaryText),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: OutlinedButton(onPressed: onSecondary, child: Text(secondaryText)),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _inputBar(AppState st) {
    return SafeArea(
      top: false,
      child: Container(
        padding: const EdgeInsets.fromLTRB(10, 6, 10, 8),
        decoration: BoxDecoration(
          color: Colors.white,
          border: Border(top: BorderSide(color: Colors.grey.shade200)),
        ),
        child: Row(
          children: [
            Expanded(
              child: TextField(
                controller: _input,
                enabled: !st.busy,
                textInputAction: TextInputAction.send,
                onSubmitted: st.busy ? null : (v) => _send(v),
                decoration: InputDecoration(
                  hintText: st.novel.isEmpty ? '点上面的选项，或者自己说一句' : '补充一句你的想法',
                  isDense: true,
                  filled: true,
                  fillColor: const Color(0xFFF2F3F7),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20),
                    borderSide: BorderSide.none,
                  ),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                ),
              ),
            ),
            const SizedBox(width: 6),
            SizedBox(
              width: 42,
              height: 42,
              child: ElevatedButton(
                onPressed: st.busy ? null : () => _send(_input.text),
                style: ElevatedButton.styleFrom(
                  padding: EdgeInsets.zero,
                  shape: const CircleBorder(),
                ),
                child: const Icon(Icons.arrow_upward, size: 20),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Bubble extends StatelessWidget {
  const _Bubble({required this.text, required this.isUser});

  final String text;
  final bool isUser;

  @override
  Widget build(BuildContext context) {
    final maxWidth = MediaQuery.of(context).size.width * 0.82;
    return Align(
      alignment: isUser ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        constraints: BoxConstraints(maxWidth: maxWidth),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
        decoration: BoxDecoration(
          color: isUser ? const Color(0xFF5B6ABF) : Colors.white,
          borderRadius: BorderRadius.only(
            topLeft: const Radius.circular(14),
            topRight: const Radius.circular(14),
            bottomLeft: Radius.circular(isUser ? 14 : 4),
            bottomRight: Radius.circular(isUser ? 4 : 14),
          ),
          border: isUser ? null : Border.all(color: const Color(0xFFE7E8EF)),
        ),
        child: SelectableText(
          text,
          style: TextStyle(
            fontSize: 14,
            height: 1.65,
            color: isUser ? Colors.white : const Color(0xFF22242B),
          ),
        ),
      ),
    );
  }
}
