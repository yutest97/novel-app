import 'package:flutter/material.dart';

import '../llm.dart';
import '../models.dart';
import '../store.dart';

/// 一家供应商的预设
class _Provider {
  final String name;
  final String url;
  final String model;
  final String note;
  const _Provider(this.name, this.url, this.model, this.note);
}

const List<_Provider> _providers = [
  _Provider('DeepSeek', 'https://api.deepseek.com/v1', 'deepseek-chat', '便宜，中文写小说手感好'),
  _Provider('通义千问', 'https://dashscope.aliyuncs.com/compatible-mode/v1', 'qwen-plus', '阿里云，国内直连'),
  _Provider('智谱 GLM', 'https://open.bigmodel.cn/api/paas/v4', 'glm-4-flash', '有免费额度可以先试'),
  _Provider('OpenAI', 'https://api.openai.com/v1', 'gpt-4o-mini', '国内需自备网络'),
];

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late final TextEditingController _url;
  late final TextEditingController _key;
  late final TextEditingController _model;
  late final TextEditingController _title;

  int _selected = 0;
  bool _testing = false;

  @override
  void initState() {
    super.initState();
    final s = AppState.I.settings;
    _url = TextEditingController(text: s.baseUrl);
    _key = TextEditingController(text: s.apiKey);
    _model = TextEditingController(text: s.model);
    _title = TextEditingController(text: AppState.I.novel.title);
    final i = _providers.indexWhere((p) => p.url == s.baseUrl);
    _selected = i < 0 ? 0 : i;
  }

  @override
  void dispose() {
    _url.dispose();
    _key.dispose();
    _model.dispose();
    _title.dispose();
    super.dispose();
  }

  void _applyProvider(int i) {
    setState(() {
      _selected = i;
      _url.text = _providers[i].url;
      _model.text = _providers[i].model;
    });
  }

  Future<void> _save() async {
    final s = Settings(
      baseUrl: _url.text.trim(),
      apiKey: _key.text.trim(),
      model: _model.text.trim(),
    );
    await AppState.I.saveSettings(s);
    if (_title.text.trim().isNotEmpty) {
      await AppState.I.renameNovel(_title.text.trim());
    }
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('已保存，回对话页继续')),
    );
  }

  Future<void> _test() async {
    setState(() => _testing = true);
    try {
      final reply = await callModel(
        settings: Settings(baseUrl: _url.text.trim(), apiKey: _key.text.trim(), model: _model.text.trim()),
        messages: [
          {'role': 'user', 'content': '只回复两个字：正常'}
        ],
      );
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('连上了，模型回复：${reply.trim()}')),
      );
    } on LlmException catch (e) {
      if (!mounted) return;
      showDialog(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('连接失败'),
          content: Text(e.message),
          actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('知道了'))],
        ),
      );
    } finally {
      if (mounted) setState(() => _testing = false);
    }
  }

  Future<void> _reset() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('新建一本小说'),
        content: const Text('会把当前这本书的章节、人物库、世界观、章节摘要和聊天记录全部清空，且不能撤销。\n\n设置（Key、模型）不受影响。'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('算了')),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: ButtonStyle(
              backgroundColor: MaterialStateProperty.all<Color>(const Color(0xFFD9534F)),
              foregroundColor: MaterialStateProperty.all<Color>(Colors.white),
            ),
            child: const Text('确认清空'),
          ),
        ],
      ),
    );
    if (ok == true) {
      await AppState.I.resetNovel();
      if (!mounted) return;
      _title.clear();
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('已清空，回对话页从头开始')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('设置')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 40),
        children: [
          _section('本书书名'),
          TextField(
            controller: _title,
            decoration: const InputDecoration(
              hintText: '给这本书起个名字',
              border: OutlineInputBorder(),
              isDense: true,
            ),
          ),

          const SizedBox(height: 22),
          _section('AI 供应商'),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              for (var i = 0; i < _providers.length; i++)
                ChoiceChip(
                  label: Text(_providers[i].name),
                  selected: _selected == i,
                  onSelected: (_) => _applyProvider(i),
                ),
            ],
          ),
          Padding(
            padding: const EdgeInsets.only(top: 6, left: 2),
            child: Text(
              _providers[_selected].note,
              style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
            ),
          ),

          const SizedBox(height: 22),
          _section('接口地址'),
          TextField(
            controller: _url,
            keyboardType: TextInputType.url,
            autocorrect: false,
            decoration: const InputDecoration(
              hintText: 'https://api.deepseek.com/v1',
              border: OutlineInputBorder(),
              isDense: true,
              helperText: '只用填到 /v1 这一层，不要带 /chat/completions',
            ),
          ),

          const SizedBox(height: 16),
          _section('模型名'),
          TextField(
            controller: _model,
            autocorrect: false,
            decoration: const InputDecoration(
              hintText: 'deepseek-chat',
              border: OutlineInputBorder(),
              isDense: true,
            ),
          ),

          const SizedBox(height: 16),
          _section('API Key'),
          TextField(
            controller: _key,
            obscureText: true,
            autocorrect: false,
            decoration: const InputDecoration(
              hintText: '粘贴你的 Key，通常以 sk- 开头',
              border: OutlineInputBorder(),
              isDense: true,
            ),
          ),

          const SizedBox(height: 18),
          Row(
            children: [
              Expanded(
                child: ElevatedButton(onPressed: _save, child: const Text('保存设置')),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: OutlinedButton(
                  onPressed: _testing ? null : _test,
                  child: _testing
                      ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                      : const Text('测试连接'),
                ),
              ),
            ],
          ),

          const SizedBox(height: 26),
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: const Color(0xFFF2F3F7),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('关于费用和隐私', style: TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
                const SizedBox(height: 6),
                Text(
                  '· 写作时按字数计费，一章 2000 字大约几分钱，具体看供应商价格。\n'
                  '· 你的 Key 只存在这台手机本地，App 不经过任何中间服务器。\n'
                  '· 断网时只能看已保存的章节，不能生成。',
                  style: TextStyle(fontSize: 12, height: 1.7, color: Colors.grey.shade700),
                ),
              ],
            ),
          ),

          const SizedBox(height: 26),
          _section('换个题材重写'),
          OutlinedButton(
            onPressed: _reset,
            style: OutlinedButton.styleFrom(
              side: const BorderSide(color: Color(0xFFE8B4B2)),
            ),
            child: const Text('新建一本（清空当前内容）', style: TextStyle(color: Color(0xFFD9534F))),
          ),
        ],
      ),
    );
  }

  Widget _section(String title) => Padding(
        padding: const EdgeInsets.only(bottom: 8, top: 4),
        child: Text(title, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
      );
}
