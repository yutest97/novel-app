import 'package:flutter/material.dart';

import '../models.dart';
import '../store.dart';
import '../theme.dart';

/// 回收站：删掉的书先放这儿，30 天内能恢复
class TrashPage extends StatelessWidget {
  const TrashPage({super.key});

  @override
  Widget build(BuildContext context) {
    final st = AppState.I;
    return AnimatedBuilder(
      animation: st,
      builder: (context, _) {
        final list = st.trashedBooks;
        return Scaffold(
          appBar: AppBar(
            title: const Text('回收站'),
            actions: [
              if (list.isNotEmpty)
                TextButton(
                  onPressed: () => _empty(context, st),
                  child: const Text('清空', style: TextStyle(fontSize: 13, color: C.dim)),
                ),
              const SizedBox(width: 6),
            ],
          ),
          body: list.isEmpty
              ? const Center(
                  child: Text('回收站是空的', style: TextStyle(color: C.dim, fontSize: 13)),
                )
              : ListView(
                  padding: const EdgeInsets.fromLTRB(14, 8, 14, 24),
                  children: [
                    for (final b in list) _card(context, st, b),
                    const SizedBox(height: 10),
                    Text(
                      '删除的书保留 ${AppState.trashKeepDays} 天，到期自动清理。',
                      textAlign: TextAlign.center,
                      style: const TextStyle(fontSize: 11, color: C.faint),
                    ),
                  ],
                ),
        );
      },
    );
  }

  Widget _card(BuildContext context, AppState st, Novel book) {
    final title = book.title.trim().isEmpty ? '未命名作品' : book.title;
    final words = book.chapterWords;
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.fromLTRB(12, 12, 8, 12),
      decoration: BoxDecoration(
        color: C.card,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: C.border, width: 0.8),
      ),
      child: Row(
        children: [
          Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(
              color: const Color(0x1FFFFFFF),
              borderRadius: BorderRadius.circular(10),
            ),
            child: const Icon(Icons.delete_outline, size: 18, color: C.faint),
          ),
          const SizedBox(width: 11),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w500),
                ),
                const SizedBox(height: 3),
                Text(
                  '删除于 ${_ago(book.deletedAt)} · 正文 $words 字',
                  style: const TextStyle(fontSize: 11, color: C.dim),
                ),
              ],
            ),
          ),
          TextButton(
            onPressed: () async {
              await st.restoreBook(book.id);
              if (!context.mounted) return;
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('《$title》已恢复到书架')),
              );
            },
            style: TextButton.styleFrom(
              minimumSize: const Size(48, 32),
              padding: const EdgeInsets.symmetric(horizontal: 8),
              tapTargetSize: MaterialTapTargetSize.shrinkWrap,
            ),
            child: const Text('恢复', style: TextStyle(fontSize: 12.5, color: C.purpleSoft)),
          ),
          IconButton(
            tooltip: '彻底删除',
            onPressed: () => _purge(context, st, book),
            icon: const Icon(Icons.delete_forever, size: 18, color: C.faint),
            constraints: const BoxConstraints(minWidth: 34, minHeight: 34),
            padding: EdgeInsets.zero,
          ),
        ],
      ),
    );
  }

  Future<void> _purge(BuildContext context, AppState st, Novel book) async {
    final title = book.title.trim().isEmpty ? '未命名作品' : book.title;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: C.card,
        title: const Text('彻底删除？'),
        content: Text('《$title》会从回收站里删掉，之后谁也找不回来了。',
            style: const TextStyle(fontSize: 12.5, height: 1.6)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('算了')),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: ButtonStyle(
              backgroundColor: MaterialStateProperty.all<Color>(const Color(0xFFD9534F)),
            ),
            child: const Text('彻底删除'),
          ),
        ],
      ),
    );
    if (ok == true) await st.purgeBook(book.id);
  }

  Future<void> _empty(BuildContext context, AppState st) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: C.card,
        title: const Text('清空回收站？'),
        content: const Text('里面的书会全部彻底删除，不能恢复。',
            style: TextStyle(fontSize: 12.5, height: 1.6)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('算了')),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: ButtonStyle(
              backgroundColor: MaterialStateProperty.all<Color>(const Color(0xFFD9534F)),
            ),
            child: const Text('清空'),
          ),
        ],
      ),
    );
    if (ok != true) return;
    final n = await st.emptyTrash();
    if (!context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('已清空 $n 本书')));
  }

  static String _ago(int ms) {
    if (ms <= 0) return '刚刚';
    final diff = DateTime.now().difference(DateTime.fromMillisecondsSinceEpoch(ms));
    if (diff.inMinutes < 1) return '刚刚';
    if (diff.inMinutes < 60) return '${diff.inMinutes} 分钟前';
    if (diff.inHours < 24) return '${diff.inHours} 小时前';
    return '${diff.inDays} 天前';
  }
}
