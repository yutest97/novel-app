import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../model_sheet.dart';
import '../models.dart';
import '../markdown_light.dart';
import '../store.dart';
import '../builtin_skills.dart';
import '../main.dart';
import '../skill_import.dart';
import '../sound.dart';
import '../theme.dart';
import 'blurb_sheet.dart';
import 'deconstruct_sheet.dart';
import 'idea_sheet.dart';
import 'distill_sheet.dart';
import 'naming_sheet.dart';
import 'notes_page.dart';
import 'scan_sheet.dart';
import 'search_sheet.dart';
import 'draw_sheet.dart';
import 'simple_pages.dart';

/// 对话页：空状态 + 技能行 + 输入栏
class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final TextEditingController _input = TextEditingController();
  final FocusNode _focus = FocusNode();
  final ScrollController _scroll = ScrollController();
  int _bubbleCount = 0;
  final Set<int> _expanded = <int>{};
  final TextEditingController _wizardInput = TextEditingController();
  int _wizardSeenStep = -1;

  @override
  void initState() {
    super.initState();
    AppState.I.addListener(_onStateChanged);
  }

  @override
  void dispose() {
    AppState.I.removeListener(_onStateChanged);
    _input.dispose();
    _optionInput.dispose();
    _focus.dispose();
    _scroll.dispose();
    super.dispose();
  }

  bool _wasBusy = false;

  void _onStateChanged() {
    _autoScrollOnStream();
    final st = AppState.I;
    if (_wasBusy && !st.busy && st.settings.soundEnabled && st.errorText == null) {
      final last = st.bubbles.isEmpty ? null : st.bubbles.last;
      if (last != null && last.role == 'assistant' && last.text.trim().isNotEmpty) {
        playDoneSound();
      }
    }
    _wasBusy = st.busy;
  }

  DateTime _lastAutoScroll = DateTime.fromMillisecondsSinceEpoch(0);

  /// 流式输出时跟着往下滚（限频，别每一帧都滚）
  void _autoScrollOnStream() {
    final st = AppState.I;
    if (!st.busy) return;
    final now = DateTime.now();
    if (now.difference(_lastAutoScroll).inMilliseconds < 350) return;
    _lastAutoScroll = now;
    _scrollToEnd();
  }

  void _scrollToEnd() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) {
        _scroll.animateTo(
          _scroll.position.maxScrollExtent,
          duration: const Duration(milliseconds: 250),
          curve: Curves.easeOut,
        );
      }
    });
  }

  Future<void> _send(String raw) async {
    var text = raw.trim();
    if (text.isEmpty && AppState.I.pendingFiles.isEmpty) return;

    // 开头的 @技能名 表示切技能，真正的提问在后面
    final m = RegExp(r'^@(\S+)\s*').firstMatch(text);
    if (m != null) {
      final name = m.group(1)!;
      var matched = false;
      for (final b in kBuiltinSkills) {
        if (b.name == name) {
          await AppState.I.setActiveSkill(b.id);
          matched = true;
        }
      }
      if (!matched) {
        for (final sk in AppState.I.settings.importedSkills) {
          if (sk.name == name) await AppState.I.setActiveSkill(sk.id);
        }
      }
      text = text.substring(m.end).trim();
      if (text.isEmpty) {
        _input.clear();
        return; // 只切技能，不发言
      }
    }

    _input.clear();
    await AppState.I.send(text);
    _scrollToEnd();
  }

  Future<void> _openSkillSheet() async {
    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => Container(
        decoration: const BoxDecoration(
          color: C.surface,
          borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
        ),
        child: SafeArea(
          top: false,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 38,
                height: 4,
                margin: const EdgeInsets.symmetric(vertical: 10),
                decoration: BoxDecoration(
                  color: Colors.white24,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(18, 0, 18, 8),
                child: Row(
                  children: const [
                    Icon(Icons.auto_awesome, color: C.purpleSoft, size: 18),
                    SizedBox(width: 8),
                    Text('技能与快捷指令', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
                  ],
                ),
              ),
              for (final b in kBuiltinSkills)
                ListTile(
                  leading: const Icon(Icons.menu_book, color: C.purpleSoft),
                  title: Row(
                    children: [
                      Text(b.name, style: const TextStyle(fontSize: 14)),
                      const SizedBox(width: 6),
                      const Text('内置', style: TextStyle(fontSize: 9.5, color: C.faint)),
                    ],
                  ),
                  subtitle: Text(b.desc, style: const TextStyle(fontSize: 11, color: C.dim)),
                  trailing: AppState.I.settings.activeSkillId == b.id
                      ? const Icon(Icons.check, size: 15, color: C.purpleSoft)
                      : null,
                  onTap: () {
                    Navigator.pop(context);
                    AppState.I.setActiveSkill(b.id);
                    _insertAt('@${b.name} ');
                  },
                ),
              for (final sk in AppState.I.settings.importedSkills)
                ListTile(
                  leading: const Icon(Icons.extension, color: C.purpleSoft, size: 20),
                  title: Text(sk.name, style: const TextStyle(fontSize: 14)),
                  subtitle: Text(
                    sk.path.isEmpty ? '我导入的技能' : sk.path,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 10.5, color: C.dim),
                  ),
                  trailing: AppState.I.settings.activeSkillId == sk.id
                      ? const Icon(Icons.check, size: 15, color: C.purpleSoft)
                      : null,
                  onTap: () {
                    Navigator.pop(context);
                    AppState.I.setActiveSkill(sk.id);
                    _insertAt('@${sk.name} ');
                  },
                ),
              const Padding(
                padding: EdgeInsets.fromLTRB(18, 8, 18, 4),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Text('快捷指令', style: TextStyle(fontSize: 11, color: C.faint)),
                ),
              ),
              for (final q in _quickCommands)
                ListTile(
                  leading: const Icon(Icons.bolt, color: C.dim, size: 20),
                  title: Text(q.label, style: const TextStyle(fontSize: 14)),
                  subtitle: Text(q.hint, style: const TextStyle(fontSize: 11, color: C.dim)),
                  onTap: () {
                    Navigator.pop(context);
                    _insertAt(q.payload);
                  },
                ),
              const SizedBox(height: 8),
            ],
          ),
        ),
      ),
    );
  }

  void _insertAt(String text) {
    final cur = _input.text;
    _input.text = cur.isEmpty ? text : '$cur$text';
    _input.selection = TextSelection.fromPosition(TextPosition(offset: _input.text.length));
    _focus.requestFocus();
  }

  static const List<_Quick> _quickCommands = [
    _Quick('大纲', '生成章节大纲', '根据现有设定，生成 10 章的章节大纲，用选项让我确认或调整'),
    _Quick('续写', '接着写下一章', '继续写下一章'),
  ];

  /// 向导最后一步：把答案放进输入框，让用户自己决定发不发
  void _finishWizard() {
    final st = AppState.I;
    final text = st.wizardPromptText();
    st.wizardClose();
    _wizardInput.clear();
    _input.text = text;
    _input.selection = TextSelection.collapsed(offset: text.length);
    _focus.requestFocus();
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('设定整理好了，改完点发送')),
    );
  }

  /// 新书启航：直接开一本空书，交给技能从头带
  Future<void> _onNewBook() async {
    final st = AppState.I;
    if (!st.novel.isEmpty) {
      final ok = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          backgroundColor: C.card,
          title: const Text('开一本新书'),
          content: const Text('当前这本会留在「小说」页里，随时能切回去。\n现在开始一本新的吗？'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('算了')),
            ElevatedButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('开新的')),
          ],
        ),
      );
      if (ok != true) return;
    }
    await st.startNewBook();
  }

  @override
  Widget build(BuildContext context) {
    final st = AppState.I;
    return AnimatedBuilder(
      animation: st,
      builder: (context, _) {
        if (st.bubbles.length != _bubbleCount) {
          _bubbleCount = st.bubbles.length;
          _scrollToEnd();
        }
        final chatting = st.bubbles.isNotEmpty || st.wizardOpen;

        return Scaffold(
          appBar: AppBar(
            leading: IconButton(
              icon: const Icon(Icons.menu, size: 22),
              onPressed: () => homeScaffoldKey.currentState?.openDrawer(),
            ),
            titleSpacing: 0,
            title: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  st.novel.title.trim().isEmpty ? '新对话' : st.novel.title,
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                ),
                const SizedBox(height: 1),
                InkWell(
                  onTap: () => showModelSheet(context),
                  borderRadius: BorderRadius.circular(4),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(st.settings.model, style: const TextStyle(fontSize: 11, color: C.dim)),
                      const Icon(Icons.arrow_drop_down, size: 14, color: C.dim),
                    ],
                  ),
                ),
              ],
            ),
            actions: [
              if (st.busy)
                Padding(
                  padding: const EdgeInsets.only(right: 12),
                  child: Center(
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
                      decoration: BoxDecoration(
                        color: const Color(0xFF1E1B33),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: const Color(0xFF3B2F6B), width: 0.7),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: const [
                          SizedBox(
                            width: 9,
                            height: 9,
                            child: CircularProgressIndicator(strokeWidth: 1.4, color: C.purpleSoft),
                          ),
                          SizedBox(width: 6),
                          Text('思考中…', style: TextStyle(fontSize: 10.5, color: C.purpleSoft)),
                        ],
                      ),
                    ),
                  ),
                ),
            ],
          ),
          body: Column(
            children: [
              _skillRow(),
              Expanded(
                child: chatting
                    ? MediaQuery(
                        data: MediaQuery.of(context).copyWith(
                          textScaleFactor: (MediaQuery.of(context).textScaleFactor *
                                  st.settings.chatFontSize /
                                  14)
                              .clamp(0.7, 2.0),
                        ),
                        child: ListView.builder(
                          controller: _scroll,
                          padding: const EdgeInsets.fromLTRB(14, 10, 14, 10),
                          itemCount: st.bubbles.length + (st.wizardOpen ? 1 : 0),
                          itemBuilder: (context, i) {
                            if (i >= st.bubbles.length) return _wizardCard(st);
                            return _bubbleItem(context, i, st);
                          },
                        ),
                      )
                    : _emptyState(st),
              ),
              if (st.errorText != null) _errorBar(st),
              if (!st.busy) _actionBar(st),
              _composer(st),
            ],
          ),
        );
      },
    );
  }

  // ---------- 技能行 ----------

  /// 顶部这一排是「动作入口」，不是「选项」，所以不做选中态，
  /// 全部同一个样式：卡片底 + 细边框，按下去有 ripple。
  Widget _toolChip(String label, IconData icon, VoidCallback onTap) {
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: TextButton.icon(
        onPressed: onTap,
        icon: Icon(icon, size: 13, color: C.dim),
        label: Text(label, style: const TextStyle(fontSize: 12, color: C.dim)),
        style: TextButton.styleFrom(
          padding: const EdgeInsets.symmetric(horizontal: 10),
          minimumSize: const Size(0, 32),
          tapTargetSize: MaterialTapTargetSize.shrinkWrap,
          visualDensity: VisualDensity.compact,
          backgroundColor: C.card,
          foregroundColor: C.dim,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8),
            side: const BorderSide(color: C.border, width: 0.6),
          ),
        ),
      ),
    );
  }

  Future<void> _openNotes() async {
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => const NotesPage(), fullscreenDialog: true),
    );
  }

  Future<void> _openNaming() async {
    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => const NamingSheet(),
    );
  }

  Future<void> _openScan() async {
    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => const ScanSheet(),
    );
  }

  Future<void> _openIdea() async {
    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => const IdeaSheet(),
    );
  }

  Future<void> _openBlurb() async {
    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => const BlurbSheet(),
    );
  }

  Future<void> _openDeconstruct() async {
    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => const DeconstructSheet(),
    );
  }

  Widget _skillRow() {
    return Container(
      height: 48,
      decoration: const BoxDecoration(
        border: Border(bottom: BorderSide(color: C.border, width: 0.5)),
      ),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.fromLTRB(10, 8, 10, 8),
        child: Row(
          children: [
          _toolChip('备忘录', Icons.note_alt_outlined, _openNotes),
          _toolChip('起名', Icons.text_fields, _openNaming),
          _toolChip('扫榜', Icons.insights, _openScan),
          _toolChip('脑洞', Icons.lightbulb_outline, _openIdea),
          _toolChip('简介', Icons.description_outlined, _openBlurb),
          _toolChip('蒸馏', Icons.filter_alt_outlined,
              () => showDistillSheet(context)),
          _toolChip('拆解', Icons.auto_stories_outlined, _openDeconstruct),
          for (final q in _quickCommands)
            Padding(
              padding: const EdgeInsets.only(right: 8),
              child: TextButton.icon(
                onPressed: () => _send(q.payload),
                icon: const Icon(Icons.auto_awesome, size: 13, color: C.dim),
                label: Text(q.label, style: const TextStyle(fontSize: 12, color: C.dim)),
                style: TextButton.styleFrom(
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  minimumSize: const Size(0, 32),
                  tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                  visualDensity: VisualDensity.compact,
                  backgroundColor: C.card,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                    side: const BorderSide(color: C.border, width: 0.6),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ---------- 空状态 ----------

  Widget _emptyState(AppState st) {
    return LayoutBuilder(
      builder: (context, box) => SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(18, 8, 18, 12),
        child: ConstrainedBox(
          constraints: BoxConstraints(minHeight: box.maxHeight - 24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
          Container(
            width: 92,
            height: 92,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFF9B7BFF), Color(0xFF5B3FE0)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(24),
            ),
            child: const Icon(Icons.auto_awesome, color: Colors.white, size: 42),
          ),
          const SizedBox(height: 16),
          const Text('AI 写小说', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700)),
          const SizedBox(height: 6),
          const Text('你的 AI 小说写作助手', style: TextStyle(fontSize: 12.5, color: C.dim)),
          const SizedBox(height: 26),
          _entryCard(
            icon: Icons.menu_book,
            title: '新书启航',
            subtitle: '调用写作技能，从头带一本新书',
            onTap: _onNewBook,
          ),
          _entryCard(
            icon: Icons.edit_note,
            title: '继续写作',
            subtitle: '继续上一次的对话',
            onTap: () async {
              if (st.bubbles.isEmpty) {
                await _send('继续');
              } else {
                _focus.requestFocus();
              }
            },
          ),
          _entryCard(
            icon: Icons.help_outline,
            title: '使用教程',
            subtitle: '查看使用手册',
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const GuidePage()),
            ),
          ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _entryCard({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(14),
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: C.card,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: C.border, width: 0.6),
          ),
          child: Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: const Color(0x337B5CFF),
                  borderRadius: BorderRadius.circular(11),
                ),
                child: Icon(icon, color: C.purpleSoft, size: 20),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: const TextStyle(fontSize: 14.5, fontWeight: FontWeight.w600)),
                    const SizedBox(height: 3),
                    Text(subtitle, style: const TextStyle(fontSize: 11.5, color: C.dim)),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right, color: C.faint, size: 18),
            ],
          ),
        ),
      ),
    );
  }

  // ---------- 气泡 ----------

  /// 最后一条助手消息的下标（-1 表示还没有）
  static int _lastAssistantIndex(AppState st) {
    for (var i = st.bubbles.length - 1; i >= 0; i--) {
      if (st.bubbles[i].role == 'assistant') return i;
    }
    return -1;
  }

  Widget _bubbleItem(BuildContext context, int i, AppState st) {
    final b = st.bubbles[i];
    final isUser = b.role == 'user';
    // 只有「最后一条消息且是助手」才给选项，避免空气泡顶掉按钮
    final isLast = i == st.bubbles.length - 1 && i == _lastAssistantIndex(st);
    final showOptions =
        isLast && !isUser && !st.busy && st.pending == Pending.none && !st.wizardOpen;

    return Column(
      crossAxisAlignment: isUser ? CrossAxisAlignment.end : CrossAxisAlignment.start,
      children: [
        if (!isUser && b.tools.isNotEmpty) _toolCard(i, b),
        if (!isUser && (b.ms > 0 || b.raw.isNotEmpty)) _processHeader(i, b),
        Container(
          constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.82),
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
          decoration: BoxDecoration(
            color: isUser ? C.purple : C.card,
            borderRadius: BorderRadius.only(
              topLeft: const Radius.circular(15),
              topRight: const Radius.circular(15),
              bottomLeft: Radius.circular(isUser ? 15 : 4),
              bottomRight: Radius.circular(isUser ? 4 : 15),
            ),
            border: isUser ? null : Border.all(color: C.border, width: 0.6),
          ),
          child: b.text.trim().isEmpty
              ? (isLast && st.busy
                  ? Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const SizedBox(
                          width: 12,
                          height: 12,
                          child: CircularProgressIndicator(
                              strokeWidth: 1.6, color: C.purpleSoft),
                        ),
                        const SizedBox(width: 8),
                        Text(
                          b.reasoning.trim().isEmpty ? '思考中…' : '正在写…',
                          style: const TextStyle(fontSize: 13, color: C.dim),
                        ),
                      ],
                    )
                  : Text(
                      b.options.isNotEmpty ? '选一个方向：' : '（这一轮没有正文）',
                      style: const TextStyle(fontSize: 13, color: C.dim),
                    ))
              : Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (isUser)
                      SelectableText(
                        b.text,
                        style: const TextStyle(
                          fontSize: 14,
                          height: 1.68,
                          color: Colors.white,
                        ),
                      )
                    else
                      MarkdownText(
                        b.text,
                        style: const TextStyle(
                          fontSize: 14,
                          height: 1.68,
                          color: Color(0xFFE3E3EE),
                        ),
                      ),
                    if (b.attachments.isNotEmpty)
                      Padding(
                        padding: const EdgeInsets.only(top: 7),
                        child: Wrap(
                          spacing: 6,
                          runSpacing: 6,
                          children: [
                            for (final name in b.attachments)
                              Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 8, vertical: 4),
                                decoration: BoxDecoration(
                                  color: isUser
                                      ? const Color(0x33FFFFFF)
                                      : C.cardHi,
                                  borderRadius: BorderRadius.circular(6),
                                ),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Icon(Icons.description_outlined,
                                        size: 12,
                                        color: isUser ? Colors.white70 : C.dim),
                                    const SizedBox(width: 4),
                                    ConstrainedBox(
                                      constraints:
                                          const BoxConstraints(maxWidth: 170),
                                      child: Text(
                                        name,
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: TextStyle(
                                          fontSize: 10.5,
                                          color: isUser ? Colors.white : C.dim,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                          ],
                        ),
                      ),
                  ],
                ),
        ),
        if (!isUser && b.sources.isNotEmpty) _sourcesBlock(i, b),
        if (!isUser && b.alts.isNotEmpty) _altsBlock(i, b, st),
        if (showOptions) _optionsBlock(b, i == st.bubbles.length - 1),
        if (!isUser && _looksLikeSkill(b.text))
          Padding(
            padding: const EdgeInsets.only(top: 8),
            child: SizedBox(
              height: 32,
              child: OutlinedButton.icon(
                onPressed: () => _saveAsSkill(b.text),
                icon: const Icon(Icons.save_alt, size: 14, color: C.purpleSoft),
                label: const Text('存为技能', style: TextStyle(fontSize: 12, color: C.purpleSoft)),
                style: OutlinedButton.styleFrom(
                  side: const BorderSide(color: Color(0xFF3B2F6B)),
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                ),
              ),
            ),
          ),
        if (!isUser && b.tokens > 0)
          Padding(
            padding: const EdgeInsets.only(top: 4, right: 2),
            child: Text(
              '上下文已用 ${_k(b.tokens)}',
              style: const TextStyle(fontSize: 10, color: C.faint),
            ),
          ),
        if (!isUser && b.text.trim().isNotEmpty) _msgActions(i, b, st),
        const SizedBox(height: 12),
      ],
    );
  }

  /// 「⌄ 已思考 2s」这一行，点开能看到技能加载和模型原始返回
  Widget _processHeader(int i, ChatBubble b) {
    final streaming = AppState.I.busy && i == AppState.I.bubbles.length - 1;
    final open = _expanded.contains(i) || (streaming && b.reasoning.trim().isNotEmpty);
    final secs = (b.ms / 1000).toStringAsFixed(b.ms < 10000 ? 1 : 0);
    return Padding(
      padding: const EdgeInsets.only(bottom: 5),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          InkWell(
            onTap: () => setState(() {
              if (open) {
                _expanded.remove(i);
              } else {
                _expanded.add(i);
              }
            }),
            borderRadius: BorderRadius.circular(6),
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 2),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 16,
                    height: 16,
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [Color(0xFF9B7BFF), Color(0xFF5B3FE0)],
                      ),
                      borderRadius: BorderRadius.circular(4),
                    ),
                    child: const Icon(Icons.auto_awesome, size: 10, color: Colors.white),
                  ),
                  const SizedBox(width: 6),
                  const Icon(Icons.expand_more, size: 13, color: C.faint),
                  const SizedBox(width: 2),
                  Text(
                    streaming
                        ? '思考中…'
                        : (b.ms > 0 ? '已思考 ${secs}s' : '查看过程'),
                    style: TextStyle(
                      fontSize: 11,
                      color: streaming ? C.purpleSoft : C.dim,
                    ),
                  ),
                ],
              ),
            ),
          ),
          if (open)
            Container(
              margin: const EdgeInsets.only(top: 4),
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: C.card,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: C.border, width: 0.6),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    b.reasoning.trim().isNotEmpty ? '思考过程' : '模型原始返回',
                    style: const TextStyle(fontSize: 10.5, color: C.purpleSoft),
                  ),
                  const SizedBox(height: 4),
                  SelectableText(
                    _clip(b.reasoning.trim().isNotEmpty ? b.reasoning : b.raw, 1200),
                    style: const TextStyle(fontSize: 10.5, height: 1.6, color: C.faint),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }

  // ---------- 思考强度 ----------

  static const List<List<String>> _thinkOptions = [
    ['default', '默认', '按模型自己的习惯'],
    ['off', '关闭思考', '直接给结果，不写推理'],
    ['low', '低', '想一两句就动笔'],
    ['medium', '中', '先走三四步再写'],
    ['high', '高', '先列要点和结构'],
    ['deep', '深度', '完整推演动机与伏笔'],
  ];

  static const List<IconData> _thinkIcons = [
    Icons.auto_awesome,
    Icons.remove_circle_outline,
    Icons.show_chart,
    Icons.arrow_forward,
    Icons.trending_up,
    Icons.local_fire_department,
  ];

  static String _thinkLabel(String level) {
    switch (level) {
      case 'off':
        return '不思考';
      case 'low':
        return '低';
      case 'medium':
        return '中';
      case 'high':
        return '高';
      case 'deep':
        return '深度';
      default:
        return '思考';
    }
  }

  Widget _thinkChip(AppState st, {bool compact = false}) {
    final active = st.settings.thinkingLevel != 'default';
    return InkWell(
      onTap: _openThinkSheet,
      borderRadius: BorderRadius.circular(20),
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: compact ? 6 : 8, vertical: 6),
        decoration: BoxDecoration(
          color: active ? const Color(0x337B5CFF) : C.cardHi,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: active ? C.purple : C.border, width: 0.6),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.psychology_outlined,
                size: 13, color: active ? C.purpleSoft : C.dim),
            if (!compact) ...[
              const SizedBox(width: 3),
              Text(
                _thinkLabel(st.settings.thinkingLevel),
                style: TextStyle(fontSize: 11, color: active ? C.purpleSoft : C.dim),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Future<void> _openThinkSheet() async {
    final current = AppState.I.settings.thinkingLevel;
    final picked = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => Container(
        decoration: const BoxDecoration(
          color: C.surface,
          borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
        ),
        child: SafeArea(
          top: false,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 38,
                height: 4,
                margin: const EdgeInsets.symmetric(vertical: 10),
                decoration: BoxDecoration(
                  color: Colors.white24,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(18, 2, 18, 10),
                child: Row(
                  children: const [
                    Icon(Icons.psychology_outlined, size: 17, color: C.purpleSoft),
                    SizedBox(width: 8),
                    Text('思考强度',
                        style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
                  ],
                ),
              ),
              for (var i = 0; i < _thinkOptions.length; i++)
                ListTile(
                  dense: true,
                  leading: Icon(_thinkIcons[i], size: 19,
                      color: _thinkOptions[i][0] == current ? C.purpleSoft : C.dim),
                  title: Text(
                    _thinkOptions[i][1],
                    style: TextStyle(
                      fontSize: 13.5,
                      color: _thinkOptions[i][0] == current ? C.purpleSoft : C.text,
                    ),
                  ),
                  subtitle: Text(_thinkOptions[i][2],
                      style: const TextStyle(fontSize: 10.5, color: C.faint)),
                  trailing: _thinkOptions[i][0] == current
                      ? const Icon(Icons.check, size: 15, color: C.purpleSoft)
                      : null,
                  onTap: () => Navigator.pop(context, _thinkOptions[i][0]),
                ),
              const SizedBox(height: 8),
            ],
          ),
        ),
      ),
    );
    if (picked != null) await AppState.I.setThinkingLevel(picked);
  }

  // ---------- # 引用资料 ----------

  // ---------- # 引用资料（输入框上方浮层） ----------

  bool _refOpen = false;
  String _refQuery = '';
  int _refStart = -1;

  List<List<String>> get _refDocs {
    final b = AppState.I.novel;
    return [
      ['世界观.md', b.world],
      ['人物库.md', b.characters],
      ['章节摘要.md', b.summary],
    ];
  }

  List<List<String>> get _refMatches {
    final q = _refQuery.trim();
    if (q.isEmpty) return _refDocs;
    return _refDocs.where((d) => d[0].contains(q)).toList();
  }

  int _refChars(String text) => text.replaceAll(RegExp(r"\s"), '').length;

  void _onInputChanged(String v) {
    final sel = _input.selection;
    final caret = sel.isValid ? sel.baseOffset.clamp(0, v.length) : v.length;
    final before = v.substring(0, caret);
    final idx = before.lastIndexOf('#');

    var open = false;
    var query = '';
    if (idx >= 0) {
      final prevOk = idx == 0 || ' \n\t'.contains(before[idx - 1]);
      final q = before.substring(idx + 1);
      // # 前面必须是行首或空白；# 后面不能有空格（有空格说明已经在写正文了）
      if (prevOk && !q.contains(' ') && !q.contains('\n')) {
        open = true;
        query = q;
      }
    }

    if (!open) {
      if (_refOpen) setState(() => _refOpen = false);
      return;
    }
    setState(() {
      _refOpen = true;
      _refQuery = query;
      _refStart = idx;
    });
  }

  /// 点「引用资料」按钮：在光标处插入 # 并弹出浮层
  void _insertRef() {
    if (_refOpen) {
      setState(() => _refOpen = false);
      return;
    }
    final text = _input.text;
    final sel = _input.selection;
    final pos = sel.isValid ? sel.baseOffset.clamp(0, text.length) : text.length;
    final newText = text.replaceRange(pos, pos, '#');
    _input.value = TextEditingValue(
      text: newText,
      selection: TextSelection.collapsed(offset: pos + 1),
    );
    _onInputChanged(newText);
    _focus.requestFocus();
  }

  void _applyRef(String name) {
    final text = _input.text;
    final start = _refStart.clamp(0, text.length);
    final sel = _input.selection;
    final end = sel.isValid ? sel.baseOffset.clamp(start, text.length) : text.length;
    final insert = '#$name ';
    final newText = text.replaceRange(start, end, insert);
    _input.value = TextEditingValue(
      text: newText,
      selection: TextSelection.collapsed(offset: start + insert.length),
    );
    setState(() => _refOpen = false);
    _focus.requestFocus();
  }

  Widget _refPanel() {
    final matches = _refMatches;
    return Container(
      margin: const EdgeInsets.only(bottom: 6),
      decoration: BoxDecoration(
        color: const Color(0xFF141C17),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFF2F5B41), width: 0.8),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          for (var i = 0; i < matches.length; i++)
            InkWell(
              onTap: () => _applyRef(matches[i][0]),
              borderRadius: BorderRadius.vertical(
                top: Radius.circular(i == 0 ? 12 : 0),
              ),
              child: Container(
                padding: const EdgeInsets.fromLTRB(12, 9, 12, 9),
                decoration: BoxDecoration(
                  border: i == matches.length - 1
                      ? null
                      : const Border(
                          bottom: BorderSide(color: Color(0xFF23402F), width: 0.6),
                        ),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.description_outlined,
                        size: 17, color: Color(0xFF6FD79B)),
                    const SizedBox(width: 9),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            matches[i][0],
                            style: const TextStyle(
                              fontSize: 12.5,
                              color: Color(0xFF6FD79B),
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            '小说资料/${matches[i][0]} · ${_refChars(matches[i][1])} 字',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontSize: 10, color: C.faint),
                          ),
                        ],
                      ),
                    ),
                    const Icon(Icons.north_west, size: 13, color: C.faint),
                  ],
                ),
              ),
            ),
          if (matches.isEmpty)
            const Padding(
              padding: EdgeInsets.fromLTRB(12, 12, 12, 12),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Text('没有匹配的资料，换个关键词',
                    style: TextStyle(fontSize: 11, color: C.dim)),
              ),
            ),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.fromLTRB(12, 6, 12, 7),
            decoration: const BoxDecoration(
              border: Border(top: BorderSide(color: Color(0xFF23402F), width: 0.6)),
            ),
            child: const Text(
              '继续输入可筛选 · 点一条插入',
              style: TextStyle(fontSize: 9.5, color: C.faint),
            ),
          ),
        ],
      ),
    );
  }

  // ---------- 工具动作卡片 ----------

  final TextEditingController _optionInput = TextEditingController();
  final Set<String> _toolOpen = <String>{};
  final Set<int> _altsOpen = <int>{};
  final Set<int> _srcOpen = <int>{};

  Widget _toolCard(int i, ChatBubble b) {
    return Container(
      margin: const EdgeInsets.only(bottom: 6),
      decoration: BoxDecoration(
        color: C.card,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: C.border, width: 0.6),
      ),
      child: Column(
        children: [
          for (var k = 0; k < b.tools.length; k++) _toolRow(i, k, b.tools[k]),
        ],
      ),
    );
  }

  Widget _toolRow(int i, int k, ToolStep t) {
    final key = '$i:$k';
    final open = _toolOpen.contains(key);
    final detail = t.detail.trim();
    final hasDetail = detail.isNotEmpty && detail != '（空）';
    return InkWell(
      onTap: hasDetail
          ? () => setState(() {
                if (open) {
                  _toolOpen.remove(key);
                } else {
                  _toolOpen.add(key);
                }
              })
          : null,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(12, 9, 10, 9),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.check_circle, size: 13, color: C.green),
                const SizedBox(width: 7),
                Text('${t.action}：', style: const TextStyle(fontSize: 11.5, color: C.dim)),
                Expanded(
                  child: Text(
                    t.name,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 11.5, color: Color(0xFFD6D6E4)),
                  ),
                ),
                if (hasDetail)
                  Icon(open ? Icons.expand_less : Icons.expand_more, size: 14, color: C.faint),
              ],
            ),
            if (open && hasDetail)
              Padding(
                padding: const EdgeInsets.only(top: 6, left: 20),
                child: Text(
                  detail,
                  style: const TextStyle(fontSize: 10.5, height: 1.6, color: C.faint),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Future<void> _pickAttachment() async {
    final messenger = ScaffoldMessenger.of(context);
    try {
      final f = await pickTextFile();
      if (f == null) return;
      AppState.I.addPendingFile(f.name, f.content);
      if (!mounted) return;
      final clip = f.content.replaceAll(RegExp(r'\s'), '').length;
      messenger.showSnackBar(
        SnackBar(
          content: Text(clip > AppState.kMaxFileChars
              ? '已添加 ${f.name}（过长，只带前 ${AppState.kMaxFileChars ~/ 10000} 万字）'
              : '已添加 ${f.name}（$clip 字）'),
          duration: const Duration(seconds: 3),
        ),
      );
    } on SkillPickException catch (e) {
      messenger.showSnackBar(SnackBar(content: Text(e.message)));
    } on FormatException catch (e) {
      messenger.showSnackBar(SnackBar(content: Text(e.message)));
    } catch (e) {
      messenger.showSnackBar(SnackBar(content: Text('加附件失败：$e')));
    }
  }

  Widget _pendingFileChip(AppState st, int i) {
    final f = st.pendingFiles[i];
    return Container(
      padding: const EdgeInsets.fromLTRB(9, 5, 5, 5),
      decoration: BoxDecoration(
        color: const Color(0x337B5CFF),
        borderRadius: BorderRadius.circular(7),
        border: Border.all(color: C.purple, width: 0.5),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.description_outlined, size: 12, color: C.purpleSoft),
          const SizedBox(width: 5),
          ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 150),
            child: Text(
              f.name,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 11, color: C.purpleSoft),
            ),
          ),
          const SizedBox(width: 4),
          Text('${f.chars} 字',
              style: const TextStyle(fontSize: 9.5, color: C.faint)),
          const SizedBox(width: 2),
          InkWell(
            onTap: () => st.removePendingFile(i),
            borderRadius: BorderRadius.circular(10),
            child: const Padding(
              padding: EdgeInsets.all(2),
              child: Icon(Icons.close, size: 13, color: C.dim),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _toggleSearch() async {
    final st = AppState.I;
    if (st.settings.searchEnabled) {
      await st.setSearchEnabled(false);
      return;
    }
    // 打开前先确认配置：博查没 Key 直接跳到设置面板
    if (st.settings.searchProvider == 'bocha' && st.settings.searchKey.trim().isEmpty) {
      await _openSearchSheet();
      return;
    }
    await st.setSearchEnabled(true);
  }

  Future<void> _openSearchSheet() async {
    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => const SearchSheet(),
    );
    if (mounted) setState(() {});
  }

  Widget _sourcesBlock(int i, ChatBubble b) {
    final open = _srcOpen.contains(i);
    return Padding(
      padding: const EdgeInsets.only(top: 6),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          InkWell(
            onTap: () => setState(() {
              if (open) {
                _srcOpen.remove(i);
              } else {
                _srcOpen.add(i);
              }
            }),
            borderRadius: BorderRadius.circular(6),
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 3, horizontal: 2),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.language, size: 13, color: C.purpleSoft),
                  const SizedBox(width: 5),
                  Text('已联网 · ${b.sources.length} 条来源',
                      style: const TextStyle(fontSize: 11, color: C.dim)),
                  Icon(open ? Icons.expand_less : Icons.expand_more,
                      size: 14, color: C.faint),
                ],
              ),
            ),
          ),
          if (open)
            for (var k = 0; k < b.sources.length; k++)
              Container(
                width: double.infinity,
                margin: const EdgeInsets.only(top: 6),
                padding: const EdgeInsets.fromLTRB(10, 8, 10, 8),
                decoration: BoxDecoration(
                  color: C.card,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: C.border, width: 0.6),
                ),
                child: InkWell(
                  onTap: () => _showSource(b.sources[k], k + 1),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '[${k + 1}] ${b.sources[k].title}',
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontSize: 11.5, height: 1.45, color: C.text),
                      ),
                      if (b.sources[k].snippet.isNotEmpty)
                        Padding(
                          padding: const EdgeInsets.only(top: 3),
                          child: Text(
                            b.sources[k].snippet,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontSize: 10.5, height: 1.5, color: C.dim),
                          ),
                        ),
                      Padding(
                        padding: const EdgeInsets.only(top: 3),
                        child: Text(
                          b.sources[k].site,
                          style: const TextStyle(fontSize: 9.5, color: C.faint),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
        ],
      ),
    );
  }

  Future<void> _showSource(WebSource s, int index) async {
    final messenger = ScaffoldMessenger.of(context);
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: C.surface,
        title: Text('[$index] ${s.title}',
            style: const TextStyle(fontSize: 14, height: 1.4)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (s.snippet.isNotEmpty)
              Text(s.snippet, style: const TextStyle(fontSize: 12, height: 1.7)),
            const SizedBox(height: 10),
            SelectableText(
              s.url,
              style: const TextStyle(fontSize: 10.5, height: 1.5, color: C.purpleSoft),
            ),
            const SizedBox(height: 6),
            const Text(
              'App 里没接浏览器跳转，复制链接粘到浏览器打开。',
              style: TextStyle(fontSize: 10, color: C.faint),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () async {
              final nav = Navigator.of(ctx);
              await Clipboard.setData(ClipboardData(text: s.url));
              nav.pop();
              messenger.showSnackBar(const SnackBar(content: Text('链接已复制')));
            },
            child: const Text('复制链接', style: TextStyle(fontSize: 12.5, color: C.purpleSoft)),
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('关闭', style: TextStyle(fontSize: 12.5, color: C.dim)),
          ),
        ],
      ),
    );
  }

  // ---------- 抽卡 ----------

  Future<void> _openDraw() async {
    final st = AppState.I;
    if (st.busy || st.drawing) return;
    if (st.bubbles.isEmpty && _input.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('先写点要求，或先聊一句再抽卡')),
      );
      return;
    }
    final text = _input.text.trim();
    _input.clear();
    final task = st.drawCards(text);
    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => const DrawSheet(),
    );
    await task;
  }

  Widget _altsBlock(int i, ChatBubble b, AppState st) {
    final open = _altsOpen.contains(i);
    return Padding(
      padding: const EdgeInsets.only(top: 4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          InkWell(
            onTap: () => setState(() {
              if (open) {
                _altsOpen.remove(i);
              } else {
                _altsOpen.add(i);
              }
            }),
            borderRadius: BorderRadius.circular(6),
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 3, horizontal: 2),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.style_outlined, size: 13, color: C.faint),
                  const SizedBox(width: 5),
                  Text('其他候选 ${b.alts.length} 份',
                      style: const TextStyle(fontSize: 11, color: C.dim)),
                  Icon(open ? Icons.expand_less : Icons.expand_more,
                      size: 14, color: C.faint),
                ],
              ),
            ),
          ),
          if (open)
            for (var k = 0; k < b.alts.length; k++)
              Container(
                width: double.infinity,
                margin: const EdgeInsets.only(top: 6),
                padding: const EdgeInsets.fromLTRB(10, 8, 10, 4),
                decoration: BoxDecoration(
                  color: C.card,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: C.border, width: 0.6),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      _clip(b.alts[k].trim(), 160),
                      style: const TextStyle(fontSize: 11.5, height: 1.65, color: C.dim),
                    ),
                    Row(
                      children: [
                        TextButton(
                          onPressed: () => st.useAlt(i, k),
                          child: const Text('换成这份',
                              style: TextStyle(fontSize: 11.5, color: C.purpleSoft)),
                        ),
                        TextButton(
                          onPressed: () => st.removeAlt(i, k),
                          child: const Text('删除',
                              style: TextStyle(fontSize: 11.5, color: C.faint)),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
        ],
      ),
    );
  }

  // ---------- 消息操作条 ----------

  Widget _msgActions(int i, ChatBubble b, AppState st) {
    final isLast = i == st.bubbles.length - 1;
    return Padding(
      padding: const EdgeInsets.only(top: 2),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          _miniBtn(Icons.copy_rounded, () async {
            await Clipboard.setData(ClipboardData(text: b.text));
            if (!mounted) return;
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('已复制这条回复')),
            );
          }),
          if (isLast) _miniBtn(Icons.refresh_rounded, () => st.regenerateLast()),
          _miniBtn(Icons.delete_outline, () => st.deleteBubble(i)),
        ],
      ),
    );
  }

  Widget _miniBtn(IconData icon, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(6),
      child: Padding(
        padding: const EdgeInsets.all(5),
        child: Icon(icon, size: 14, color: C.faint),
      ),
    );
  }

  /// 这段文字像不像一份技能（有 frontmatter 或 SKILL.md 结构）
  static bool _looksLikeSkill(String t) {
    if (t.length < 150) return false;
    final hasFront = RegExp(r'^---[\s\S]{0,400}?name\s*:', multiLine: true).hasMatch(t);
    final hasTitle = t.contains('# ') && (t.contains('description') || t.contains('技能'));
    return hasFront || (hasTitle && t.length > 400);
  }

  Future<void> _saveAsSkill(String content) async {
    final guessed = RegExp(r'name\s*:\s*(.+)').firstMatch(content)?.group(1)?.trim() ??
        RegExp(r'^#\s+(.+)$', multiLine: true).firstMatch(content)?.group(1)?.trim() ??
        '我的技能';
    final ctrl = TextEditingController(text: guessed);
    var asStyle = false;

    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDlg) => AlertDialog(
          backgroundColor: C.card,
          title: const Text('存为技能'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              TextField(
                controller: ctrl,
                style: const TextStyle(fontSize: 13),
                decoration: const InputDecoration(labelText: '技能名称'),
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  Checkbox(
                    value: asStyle,
                    activeColor: C.purple,
                    onChanged: (v) => setDlg(() => asStyle = v ?? false),
                  ),
                  const Expanded(
                    child: Text(
                      '同时作为写作风格附加（写小说时套用它的风格）',
                      style: TextStyle(fontSize: 11.5, height: 1.5, color: C.dim),
                    ),
                  ),
                ],
              ),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('取消')),
            ElevatedButton(
              onPressed: () => Navigator.pop(ctx, true),
              style: ButtonStyle(
                backgroundColor: MaterialStateProperty.all<Color>(C.purple),
                foregroundColor: MaterialStateProperty.all<Color>(Colors.white),
              ),
              child: const Text('保存'),
            ),
          ],
        ),
      ),
    );
    if (ok != true) return;

    final doc = await AppState.I.saveSkillFromText(ctrl.text, content);
    if (asStyle) await AppState.I.setStyleSkill(doc.id);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          asStyle
              ? '已存为「${doc.name}」，并作为写作风格附加'
              : '已存为「${doc.name}」，可在 Skill 管理里设为主技能或风格',
        ),
      ),
    );
  }

  static String _clip(String t, int max) =>
      t.length <= max ? t : '${t.substring(0, max)}…';

  static String _k(int n) {
    if (n < 1000) return '$n';
    if (n < 1000000) return '${(n / 1000).toStringAsFixed(1)}K';
    return '${(n / 1000000).toStringAsFixed(2)}M';
  }

  /// 对话里的选项：和「新书问卷」同一套样式（卡片 + 小胶囊 + 内联输入）
  Widget _optionsBlock(ChatBubble b, bool showInput) {
    final opts = b.options.isEmpty
        ? <Choice>[
            const Choice('继续', '让它接着往下说'),
            const Choice('给我选项', '要求它列出可点选项'),
          ]
        : b.options;

    return Container(
      margin: const EdgeInsets.only(top: 8, bottom: 2),
      decoration: BoxDecoration(
        color: C.card,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: C.border, width: 0.8),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Padding(
            padding: EdgeInsets.fromLTRB(12, 10, 12, 0),
            child: Row(
              children: [
                Icon(Icons.help_outline, size: 14, color: C.purpleSoft),
                SizedBox(width: 6),
                Text('选一个，或者直接说你的想法',
                    style: TextStyle(fontSize: 11, color: C.dim)),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 9, 12, 10),
            child: Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                for (final o in opts) _optionPill(o),
              ],
            ),
          ),
          if (showInput)
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
              child: Row(
                children: [
                  Expanded(
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 2),
                      decoration: BoxDecoration(
                        color: const Color(0xFF12121B),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: C.border, width: 0.7),
                      ),
                      child: TextField(
                        controller: _optionInput,
                        style: const TextStyle(fontSize: 12.5, color: C.text),
                        textInputAction: TextInputAction.send,
                        onSubmitted: (v) {
                          final t = v.trim();
                          if (t.isEmpty) return;
                          _optionInput.clear();
                          _send(t);
                        },
                        decoration: const InputDecoration(
                          hintText: '输入自定义答案…',
                          hintStyle: TextStyle(fontSize: 12, color: C.faint),
                          contentPadding: EdgeInsets.symmetric(vertical: 10),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  SizedBox(
                    height: 38,
                    child: ElevatedButton(
                      onPressed: () {
                        final t = _optionInput.text.trim();
                        if (t.isEmpty) return;
                        _optionInput.clear();
                        _send(t);
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: C.purple,
                        elevation: 0,
                        padding: const EdgeInsets.symmetric(horizontal: 14),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(9)),
                      ),
                      child: const Text('发送',
                          style: TextStyle(fontSize: 12.5, color: Colors.white)),
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }

  Widget _optionPill(Choice o) {
    final hint = o.hint.trim();
    final pill = InkWell(
      onTap: () => _send(o.label),
      borderRadius: BorderRadius.circular(9),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
        decoration: BoxDecoration(
          color: C.cardHi,
          borderRadius: BorderRadius.circular(9),
          border: Border.all(color: C.border, width: 0.9),
        ),
        child: Text(
          o.label,
          style: const TextStyle(fontSize: 12.5, color: C.text),
        ),
      ),
    );
    // 说明文字不挤在胶囊里，长按能看到，避免把一行撑成两行
    return hint.isEmpty ? pill : Tooltip(message: hint, child: pill);
  }

  // ---------- 新建小说三步问卷 ----------

  Widget _wizardCard(AppState st) {
    final step = kNewBookWizard[st.wizardStep];
    final total = kNewBookWizard.length;
    final current = st.wizardAnswers[st.wizardStep];
    if (_wizardSeenStep != st.wizardStep) {
      _wizardSeenStep = st.wizardStep;
      _wizardInput.text = current;
    }

    return Container(
      margin: const EdgeInsets.only(top: 2, bottom: 8),
      decoration: BoxDecoration(
        color: C.card,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: C.border, width: 0.8),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 12, 8, 0),
            child: Row(
              children: [
                const Icon(Icons.help_outline, size: 15, color: C.purpleSoft),
                const SizedBox(width: 7),
                Text(step.title,
                    style: const TextStyle(fontSize: 13.5, fontWeight: FontWeight.w600)),
                const Spacer(),
                Text('${st.wizardStep + 1}/$total',
                    style: const TextStyle(fontSize: 11.5, color: C.dim)),
                const SizedBox(width: 6),
                GestureDetector(
                  onTap: st.wizardCancel,
                  child: const Icon(Icons.close, size: 15, color: C.faint),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 8, 14, 10),
            child: Text(step.question,
                style: const TextStyle(fontSize: 13, color: Color(0xFFCFCFDE))),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14),
            child: Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                for (final o in step.options)
                  GestureDetector(
                    onTap: () {
                      st.wizardPick(o);
                      _wizardInput.text = o;
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 7),
                      decoration: BoxDecoration(
                        color: current == o ? const Color(0xFF2A2154) : C.cardHi,
                        borderRadius: BorderRadius.circular(9),
                        border: Border.all(
                          color: current == o ? C.purple : C.border,
                          width: 0.9,
                        ),
                      ),
                      child: Text(
                        o,
                        style: TextStyle(
                          fontSize: 12,
                          color: current == o ? C.purpleSoft : C.text,
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 12, 14, 0),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 2),
              decoration: BoxDecoration(
                color: const Color(0xFF12121B),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: C.border, width: 0.7),
              ),
              child: TextField(
                controller: _wizardInput,
                style: const TextStyle(fontSize: 12.5, color: C.text),
                decoration: const InputDecoration(
                  hintText: '输入自定义答案…',
                  hintStyle: TextStyle(fontSize: 12, color: C.faint),
                  isDense: true,
                  contentPadding: EdgeInsets.symmetric(vertical: 10),
                ),
                onChanged: (v) => st.wizardPick(v),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 10, 14, 12),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                if (st.wizardStep > 0)
                  TextButton(
                    onPressed: st.wizardPrev,
                    child: const Text('上一题',
                        style: TextStyle(fontSize: 12.5, color: C.dim)),
                  ),
                const SizedBox(width: 6),
                SizedBox(
                  height: 36,
                  child: ElevatedButton(
                    onPressed: current.trim().isEmpty
                        ? null
                        : (st.wizardStep == total - 1 ? _finishWizard : st.wizardNext),
                    style: ButtonStyle(
                      backgroundColor: MaterialStateProperty.all<Color>(
                        current.trim().isEmpty ? C.cardHi : C.purple,
                      ),
                      foregroundColor: MaterialStateProperty.all<Color>(Colors.white),
                      shape: MaterialStateProperty.all(
                        RoundedRectangleBorder(borderRadius: BorderRadius.circular(9)),
                      ),
                    ),
                    child: Text(
                      st.wizardStep == total - 1 ? '提交' : '下一题',
                      style: const TextStyle(fontSize: 12.5, color: Colors.white),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ---------- 提示条与确认条 ----------

  Widget _errorBar(AppState st) {
    return Container(
      width: double.infinity,
      color: const Color(0xFF2A1618),
      padding: const EdgeInsets.fromLTRB(12, 8, 6, 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Icon(Icons.error_outline, size: 16, color: Color(0xFFE06C63)),
          const SizedBox(width: 6),
          Expanded(
            child: Text(st.errorText!, style: const TextStyle(fontSize: 11.5, color: Color(0xFFE8A9A4))),
          ),
          if (st.canRetry)
            TextButton(
              onPressed: st.retry,
              child: const Text('重试', style: TextStyle(fontSize: 12, color: C.purpleSoft)),
            ),
        ],
      ),
    );
  }

  Widget _actionBar(AppState st) {
    if (st.pending == Pending.saveChapter) {
      return _bar(
        label: '这一章「${st.pendingTitle}」写完了，存吗？',
        primaryText: '保存这一章',
        onPrimary: () async {
          st.confirmSaveChapter();
          await st.requestDocsUpdate();
        },
        secondaryText: '我再想想',
        onSecondary: st.cancelSaveChapter,
      );
    }
    if (st.pending == Pending.syncDocs) {
      return _bar(
        label: '人物库、世界观、章节摘要要一起更新吗？',
        primaryText: '同步资料',
        onPrimary: st.confirmSyncDocs,
        secondaryText: '先不同步',
        onSecondary: st.cancelSyncDocs,
      );
    }
    return const SizedBox.shrink();
  }

  Widget _bar({
    required String label,
    required String primaryText,
    required VoidCallback onPrimary,
    required String secondaryText,
    required VoidCallback onSecondary,
  }) {
    return Container(
      width: double.infinity,
      color: const Color(0xFF191926),
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(fontSize: 11.5, color: C.purpleSoft)),
          const SizedBox(height: 6),
          Row(
            children: [
              Expanded(
                child: SizedBox(
                  height: 38,
                  child: ElevatedButton(
                    onPressed: onPrimary,
                    style: ButtonStyle(
                      backgroundColor: MaterialStateProperty.all<Color>(C.purple),
                      foregroundColor: MaterialStateProperty.all<Color>(Colors.white),
                      shape: MaterialStateProperty.all(
                        RoundedRectangleBorder(borderRadius: BorderRadius.circular(9)),
                      ),
                    ),
                    child: Text(primaryText, style: const TextStyle(fontSize: 13)),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: SizedBox(
                  height: 38,
                  child: OutlinedButton(
                    onPressed: onSecondary,
                    style: OutlinedButton.styleFrom(
                      side: const BorderSide(color: C.border),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(9)),
                    ),
                    child: Text(secondaryText, style: const TextStyle(fontSize: 13, color: C.dim)),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ---------- 输入区 ----------

  Widget _composer(AppState st) {
    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(10, 6, 10, 8),
        child: Column(
          children: [
            // 联网搜索：点一下开、再点一下关，靠高亮表示状态；右边不再放开关
            Padding(
              padding: const EdgeInsets.only(bottom: 6, left: 2, right: 2),
              child: Row(
                children: [
                  InkWell(
                    onTap: _toggleSearch,
                    onLongPress: _openSearchSheet,
                    borderRadius: BorderRadius.circular(20),
                    child: Container(
                      padding: const EdgeInsets.fromLTRB(8, 5, 9, 5),
                      decoration: BoxDecoration(
                        color: st.settings.searchEnabled
                            ? const Color(0x337B5CFF)
                            : Colors.transparent,
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                          color: st.settings.searchEnabled ? C.purple : Colors.transparent,
                          width: 0.7,
                        ),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            Icons.language,
                            size: 13,
                            color: st.settings.searchEnabled ? C.purpleSoft : C.faint,
                          ),
                          const SizedBox(width: 5),
                          Text(
                            '联网搜索',
                            style: TextStyle(
                              fontSize: 11.5,
                              color: st.settings.searchEnabled ? C.purpleSoft : C.faint,
                            ),
                          ),
                          if (st.settings.searchEnabled) ...[
                            const SizedBox(width: 5),
                            InkWell(
                              onTap: _openSearchSheet,
                              borderRadius: BorderRadius.circular(6),
                              child: Padding(
                                padding: const EdgeInsets.symmetric(horizontal: 2, vertical: 1),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Text(
                                      st.settings.searchProvider == 'bocha' ? '博查' : '必应',
                                      style: const TextStyle(fontSize: 9.5, color: C.dim),
                                    ),
                                    const Icon(Icons.settings, size: 10, color: C.faint),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ],
                      ),
                    ),
                  ),
                  const Spacer(),
                  GestureDetector(
                    onTap: () => _showUsage(st),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
                      decoration: BoxDecoration(
                        color: const Color(0xFF1A1A28),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: C.border, width: 0.6),
                      ),
                      child: Row(
                        children: [
                          const Icon(Icons.bolt, size: 11, color: C.purpleSoft),
                          const SizedBox(width: 3),
                          Text(
                            '${st.settings.requestCount} 次 · ${_k(st.settings.totalTokens)} tokens',
                            style: const TextStyle(fontSize: 10.5, color: C.dim),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            if (_refOpen) _refPanel(),
            Container(
              padding: const EdgeInsets.fromLTRB(12, 10, 10, 8),
              decoration: BoxDecoration(
                color: C.card,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: C.border, width: 0.8),
              ),
              child: Column(
                children: [
                  if (st.pendingFiles.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: Wrap(
                        spacing: 6,
                        runSpacing: 6,
                        children: [
                          for (var i = 0; i < st.pendingFiles.length; i++)
                            _pendingFileChip(st, i),
                        ],
                      ),
                    ),
                  TextField(
                    controller: _input,
                    focusNode: _focus,
                    enabled: !st.busy,
                    minLines: 1,
                    maxLines: 5,
                    textInputAction: TextInputAction.newline,
                    onChanged: _onInputChanged,
                    style: const TextStyle(fontSize: 14, color: C.text),
                    decoration: const InputDecoration(
                      hintText: '写下你的故事…',
                      hintStyle: TextStyle(fontSize: 14, color: C.faint),
                      contentPadding: EdgeInsets.zero,
                    ),
                  ),
                  const SizedBox(height: 8),
                  LayoutBuilder(
                    builder: (context, box) {
                      // 窄屏时「思考」只留图标，把宽度让给模型名
                      final compactThink = box.maxWidth < 348;
                      return Row(
                        children: [
                          _iconBtn(Icons.alternate_email, '技能', _openSkillSheet),
                          _iconBtn(Icons.article_outlined, '引用资料', _insertRef,
                              color: const Color(0xFF6FD79B)),
                          _iconBtn(Icons.attach_file, '附件', _pickAttachment),
                          // 中间弹性：即使模型名很长也不会把发送键挤出去
                          Expanded(
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                _thinkChip(st, compact: compactThink),
                                const SizedBox(width: 6),
                                Flexible(
                                  child: InkWell(
                                    onTap: () => showModelSheet(context),
                                    borderRadius: BorderRadius.circular(20),
                                    child: Container(
                                      padding: const EdgeInsets.fromLTRB(8, 6, 2, 6),
                                      decoration: BoxDecoration(
                                        color: const Color(0x337B5CFF),
                                        borderRadius: BorderRadius.circular(20),
                                      ),
                                      child: Row(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          Flexible(
                                            child: Text(
                                              st.settings.model,
                                              maxLines: 1,
                                              overflow: TextOverflow.ellipsis,
                                              style: const TextStyle(
                                                  fontSize: 11, color: C.purpleSoft),
                                            ),
                                          ),
                                          const Icon(Icons.arrow_drop_down,
                                              size: 15, color: C.purpleSoft),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(width: 6),
                          InkWell(
                            onTap: st.busy || st.drawing ? null : _openDraw,
                            borderRadius: BorderRadius.circular(10),
                            child: Container(
                              width: 32,
                              height: 32,
                              decoration: BoxDecoration(
                                color: C.cardHi,
                                borderRadius: BorderRadius.circular(10),
                                border: Border.all(color: C.border, width: 0.6),
                              ),
                              child: Icon(
                                Icons.casino_outlined,
                                size: 17,
                                color: st.busy || st.drawing ? C.faint : C.dim,
                              ),
                            ),
                          ),
                          const SizedBox(width: 8),
                          InkWell(
                            onTap: st.busy ? st.cancelGeneration : () => _send(_input.text),
                            borderRadius: BorderRadius.circular(20),
                            child: Container(
                              width: 38,
                              height: 38,
                              decoration: BoxDecoration(
                                color: st.busy ? const Color(0xFFE05B4F) : C.purple,
                                shape: BoxShape.circle,
                              ),
                              child: Icon(
                                st.busy ? Icons.stop_rounded : Icons.send_rounded,
                                size: 18,
                                color: Colors.white,
                              ),
                            ),
                          ),
                        ],
                      );
                    },
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showUsage(AppState st) {
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: C.card,
        title: const Text('用量统计'),
        content: Text(
          '本地统计，只算这台手机上的请求，不会上传。\n\n'
          '请求次数：${st.settings.requestCount}\n'
          '累计 tokens：${st.settings.totalTokens}\n'
          '当前模型：${st.settings.model}\n\n'
          '费用按供应商账单为准，这里只是让你心里有数。',
          style: const TextStyle(fontSize: 12.5, height: 1.8),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('知道了')),
        ],
      ),
    );
  }

  Widget _iconBtn(IconData icon, String tooltip, VoidCallback onTap, {Color? color}) {
    return Tooltip(
      message: tooltip,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(17),
        child: SizedBox(
          width: 28,
          height: 28,
          child: Icon(icon, size: 18, color: color ?? C.dim),
        ),
      ),
    );
  }

}


/// 一条快捷指令
class _Quick {
  final String label;
  final String hint;
  final String payload;
  const _Quick(this.label, this.hint, this.payload);
}
