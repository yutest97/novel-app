import 'package:flutter/services.dart';

const MethodChannel _channel = MethodChannel('novel_app/sound');
bool _nativeUnavailable = false;

/// 播一声「写完了」的提示音。
///
/// 优先用原生 ToneGenerator（走通知音轨，不依赖系统「触摸提示音」开关）；
/// 原生通道不可用时退回 SystemSound.click，返回值表示原生是否响成功。
Future<bool> playDoneSound() async {
  if (!_nativeUnavailable) {
    try {
      final ok = await _channel.invokeMethod<bool>('beep');
      if (ok == true) return true;
      _nativeUnavailable = true;
    } on MissingPluginException {
      _nativeUnavailable = true;
    } catch (_) {
      _nativeUnavailable = true;
    }
  }
  try {
    await SystemSound.play(SystemSoundType.click);
  } catch (_) {
    // 测试环境或桌面端没有系统音，忽略
  }
  return false;
}
