import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../llm.dart';
import '../models.dart';
import '../store.dart';
import '../theme.dart';
import 'simple_pages.dart';

/// 一家预设供应商
class _Provider {
  final String name;
  final String provider;
  final String url;
  final String model;
  final String note;
  final String keyUrl;
  final bool free;
  final List<String> models; // 同一家可切的模型

  const _Provider(
    this.name,
    this.provider,
    this.url,
    this.model,
    this.note,
    this.keyUrl, {
    this.free = false,
    this.models = const [],
  });
}

const List<_Provider> _providers = [
  _Provider('智谱 GLM-4-Flash', '智谱', 'https://open.bigmodel.cn/api/paas/v4', 'glm-4-flash',
      '永久免费，支持 JSON 格式，最适合先跑通', 'https://bigmodel.cn/usercenter/proj-mgmt/apikeys',
      free: true, models: ['glm-4-flash', 'glm-4-air', 'glm-4-plus']),
  _Provider('硅基流动', '硅基流动', 'https://api.siliconflow.cn/v1', 'Qwen/Qwen2.5-7B-Instruct',
      '免费小模型，写长篇容易断', 'https://cloud.siliconflow.cn/account/ak',
      free: true,
      models: [
        'Qwen/Qwen2.5-7B-Instruct',
        'Qwen/Qwen2.5-14B-Instruct',
        'deepseek-ai/DeepSeek-V3',
      ]),
  _Provider('DeepSeek', 'DeepSeek', 'https://api.deepseek.com/v1', 'deepseek-chat',
      '一章几分钱，中文小说手感最好', 'https://platform.deepseek.com/api_keys',
      models: ['deepseek-chat', 'deepseek-reasoner']),
  _Provider('通义千问', '通义千问', 'https://dashscope.aliyuncs.com/compatible-mode/v1', 'qwen-plus',
      '阿里云，国内直连', 'https://bailian.console.aliyun.com/',
      models: ['qwen-plus', 'qwen-turbo', 'qwen-max']),
  _Provider('OpenAI', 'OpenAI', 'https://api.openai.com/v1', 'gpt-4o-mini',
      '国内需自备网络', 'https://platform.openai.com/api-keys',
      models: ['gpt-4o-mini', 'gpt-4o']),
];

/// AI 提供商：套餐 / 公益 / 自定义接入 三个子页
class AiSettingsPage extends StatefulWidget {
  const AiSettingsPage({super.key});

  @override
  State<AiSettingsPage> createState() => _AiSettingsPageState();
}

class _AiSettingsPageState extends State<AiSettingsPage> {
  int _seg = 0;

  int _providerIdx = 0;
  final TextEditingController _key = TextEditingController();

  int _freeIdx = 0;
  final TextEditingController _freeKey = TextEditingController();

  final TextEditingController _name = TextEditingController();
  final TextEditingController _url = TextEditingController();
  final TextEditingController _customKey = TextEditingController();
  final TextEditingController _model = TextEditingController();
  String _format = 'openai';
  List<String> _models = [];
  bool _testing = false;
  bool _fetching = false;
  bool _obscure = true;

  List<ModelOption> get _freeModels => kModels.where((m) => m.free).toList();

  @override
  void initState() {
    super.initState();
    final s = AppState.I.settings;
    final i = _providers.indexWhere((p) => p.provider == s.provider);
    _providerIdx = i < 0 ? 0 : i;
    _key.text = s.apiKey;
    _freeKey.text = s.keys[_freeModels.first.provider] ?? '';
    _format = s.format == 'anthropic' ? 'anthropic' : 'openai';
    if (s.provider == '自定义') {
      _seg = 2;
      _name.text = '我的配置';
      _url.text = s.baseUrl;
      _customKey.text = s.apiKey;
      _model.text = s.model;
    }
  }

  @override
  void dispose() {
    _key.dispose();
    _freeKey.dispose();
    _name.dispose();
    _url.dispose();
    _customKey.dispose();
    _model.dispose();
    super.dispose();
  }

  bool get _connected => AppState.I.settings.isReady;

  /// 已连接后默认看「连接成功页」，点「修改配置」才回到表单
  bool _editing = false;

  _Provider? get _currentProvider {
    final url = AppState.I.settings.baseUrl.trim();
    for (final p in _providers) {
      if (p.url == url) return p;
    }
    return null;
  }

  Future<void> _copy(String text, String tip) async {
    await Clipboard.setData(ClipboardData(text: text));
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(tip)));
  }

  /// 统一保存 + 测试
  Future<void> _applyAndTest({
    required String baseUrl,
    required String apiKey,
    required String model,
    required String provider,
    required String format,
    List<CustomConfig>? customConfigs,
  }) async {
    final st = AppState.I;
    st.settings.keys[provider] = apiKey.trim();
    final s = Settings(
      baseUrl: baseUrl,
      apiKey: apiKey.trim(),
      model: model,
      provider: provider,
      keys: Map<String, String>.from(st.settings.keys),
      temperature: st.settings.temperature,
      followSystemTheme: st.settings.followSystemTheme,
      format: format,
      customConfigs: customConfigs ?? st.settings.customConfigs,
    );
    await st.saveSettings(s);

    setState(() => _testing = true);
    try {
      final reply = await callModel(
        settings: s,
        messages: [
          {'role': 'user', 'content': '只回复两个字：正常'}
        ],
      );
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('已连接，模型回复：${reply.text.trim()}')),
      );
      setState(() => _editing = false);
    } on LlmException catch (e) {
      if (!mounted) return;
      showDialog(
        context: context,
        builder: (ctx) => AlertDialog(
          backgroundColor: C.card,
          title: const Text('连接失败'),
          content: Text(e.message, style: const TextStyle(fontSize: 13, height: 1.6)),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('知道了')),
          ],
        ),
      );
    } finally {
      if (mounted) setState(() => _testing = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_connected && !_editing) return _connectedScaffold();
    return Scaffold(
      appBar: AppBar(
        title: const Text('AI 提供商'),
        actions: [
          if (_connected)
            TextButton(
              onPressed: () => setState(() => _editing = false),
              child: const Text('取消', style: TextStyle(fontSize: 12.5, color: C.dim)),
            ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(14, 6, 14, 30),
        children: [
          Container(
            decoration: BoxDecoration(
              color: C.card,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: C.border, width: 0.8),
            ),
            child: Column(
              children: [
                _header(),
                _segment(),
                Padding(
                  padding: const EdgeInsets.fromLTRB(12, 12, 12, 14),
                  child: _seg == 0
                      ? _planBody()
                      : _seg == 1
                          ? _freeBody()
                          : _customBody(),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          Container(
            padding: const EdgeInsets.all(13),
            decoration: BoxDecoration(color: C.card, borderRadius: BorderRadius.circular(12)),
            child: const Text(
              '· Key 只存在这台手机本地，不经过任何服务器\n'
              '· 不同供应商的 Key 分开存，换模型自动切换\n'
              '· 断网时只能看已保存章节，不能生成',
              style: TextStyle(fontSize: 11, height: 1.8, color: C.dim),
            ),
          ),
        ],
      ),
    );
  }

  // ---------- 连接成功页 ----------

  String _maskKey(String key) {
    final k = key.trim();
    if (k.isEmpty) return '未填写';
    if (k.length <= 8) return '${k.substring(0, 2)}••••';
    return '${k.substring(0, 5)}••••${k.substring(k.length - 4)}';
  }

  String _host(String url) {
    final u = Uri.tryParse(url.trim());
    return u?.host.isNotEmpty == true ? u!.host : url;
  }

  Future<void> _disconnect() async {
    final messenger = ScaffoldMessenger.of(context);
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: C.surface,
        title: const Text('断开连接？', style: TextStyle(fontSize: 15)),
        content: const Text(
          '只清除这台手机上保存的 API Key，接口地址和模型名会留着，'
          '下次填回 Key 就能继续用。已有书稿和章节不受影响。',
          style: TextStyle(fontSize: 12, height: 1.7),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('取消', style: TextStyle(color: C.dim)),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFD9534F)),
            child: const Text('断开'),
          ),
        ],
      ),
    );
    if (ok != true) return;

    final st = AppState.I;
    final provider = st.settings.provider;
    final json = st.settings.toJson();
    json['apiKey'] = '';
    final keys = Map<String, String>.from(st.settings.keys)..remove(provider);
    json['keys'] = keys;
    await st.saveSettings(Settings.fromJson(json));
    if (!mounted) return;
    setState(() => _editing = true);
    messenger.showSnackBar(const SnackBar(content: Text('已断开，Key 已从本机清除')));
  }

  Future<void> _switchModel(String model) async {
    final st = AppState.I;
    if (st.settings.model == model) return;
    final json = st.settings.toJson();
    json['model'] = model;
    await st.saveSettings(Settings.fromJson(json));
    if (!mounted) return;
    setState(() {});
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('已切到 $model，下一轮对话生效')),
    );
  }

  Widget _connectedScaffold() {
    final st = AppState.I;
    final s = st.settings;
    final p = _currentProvider;
    final models = (p?.models ?? const <String>[]).isEmpty
        ? <String>[s.model]
        : p!.models;

    return Scaffold(
      appBar: AppBar(title: const Text('AI 提供商')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(14, 8, 14, 30),
        children: [
          // 状态卡
          Container(
            padding: const EdgeInsets.fromLTRB(16, 20, 16, 14),
            decoration: BoxDecoration(
              color: const Color(0xFF13251C),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: const Color(0xFF2F6B47), width: 0.8),
            ),
            child: Column(
              children: [
                Container(
                  width: 46,
                  height: 46,
                  decoration: const BoxDecoration(
                    color: Color(0xFF1E3A2A),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(Icons.check, size: 26, color: Color(0xFF6FD79B)),
                ),
                const SizedBox(height: 10),
                const Text('已连接',
                    style: TextStyle(fontSize: 15, color: Color(0xFF6FD79B))),
                const SizedBox(height: 4),
                Text(
                  s.model,
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 13, color: Color(0xFF9CBFAC)),
                ),
                const SizedBox(height: 8),
                Text(
                  '${p?.name ?? s.provider} · ${_host(s.baseUrl)}',
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 10.5, color: C.faint),
                ),
                const SizedBox(height: 14),
                Row(
                  children: [
                    Expanded(
                      child: SizedBox(
                        height: 40,
                        child: ElevatedButton.icon(
                          onPressed: () => setState(() => _editing = true),
                          icon: const Icon(Icons.edit_outlined,
                              size: 15, color: Colors.white),
                          label: const Text('修改配置',
                              style: TextStyle(fontSize: 12.5, color: Colors.white)),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: C.purple,
                            elevation: 0,
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(9)),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: SizedBox(
                        height: 40,
                        child: OutlinedButton.icon(
                          onPressed: _disconnect,
                          icon: const Icon(Icons.link_off, size: 15, color: C.dim),
                          label: const Text('断开连接',
                              style: TextStyle(fontSize: 12.5, color: C.dim)),
                          style: OutlinedButton.styleFrom(
                            side: const BorderSide(color: C.border),
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(9)),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),

          // 参数摘要
          InkWell(
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const ParamsPage()),
            ),
            borderRadius: BorderRadius.circular(12),
            child: Container(
              padding: const EdgeInsets.fromLTRB(14, 12, 12, 12),
              decoration: BoxDecoration(
                color: C.card,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: C.border, width: 0.6),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Text('当前参数',
                          style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w500)),
                      const Spacer(),
                      const Text('去调整',
                          style: TextStyle(fontSize: 11, color: C.purpleSoft)),
                      const Icon(Icons.chevron_right, size: 15, color: C.purpleSoft),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 6,
                    runSpacing: 6,
                    children: [
                      _tag('温度 ${s.temperature.toStringAsFixed(1)}'),
                      _tag('思考 ${s.thinkingLevel == 'default' ? '默认' : s.thinkingLevel}'),
                      _tag(s.agentEnabled ? 'Agent 开' : 'Agent 关'),
                      _tag(s.searchEnabled
                          ? '联网 ${s.searchProvider == 'bocha' ? '博查' : '必应'}'
                          : '联网 关'),
                      _tag('窗口 ${s.contextWindowK}K'),
                    ],
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),

          // 用量
          Container(
            padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
            decoration: BoxDecoration(
              color: C.card,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: C.border, width: 0.6),
            ),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('本机用量',
                          style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w500)),
                      const SizedBox(height: 4),
                      Text(
                        '${s.requestCount} 次请求 · ${_fmtToken(s.totalTokens)} tokens',
                        style: const TextStyle(fontSize: 11.5, color: C.dim),
                      ),
                      const SizedBox(height: 3),
                      const Text('只统计这台手机，不含供应商后台的账单',
                          style: TextStyle(fontSize: 9.5, color: C.faint)),
                    ],
                  ),
                ),
                SizedBox(
                  width: 56,
                  height: 30,
                  child: OutlinedButton(
                    onPressed: () async {
                      final json = st.settings.toJson();
                      json['requestCount'] = 0;
                      json['totalTokens'] = 0;
                      await st.saveSettings(Settings.fromJson(json));
                      if (mounted) setState(() {});
                    },
                    style: OutlinedButton.styleFrom(
                      padding: EdgeInsets.zero,
                      side: const BorderSide(color: C.border),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8)),
                    ),
                    child: const Text('清零',
                        style: TextStyle(fontSize: 11, color: C.dim)),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),

          // 换模型
          Container(
            padding: const EdgeInsets.fromLTRB(14, 12, 14, 14),
            decoration: BoxDecoration(
              color: C.card,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: C.border, width: 0.6),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Text('换个模型',
                        style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w500)),
                    const Spacer(),
                    Text(p?.name ?? '当前供应商',
                        style: const TextStyle(fontSize: 10, color: C.faint)),
                  ],
                ),
                const SizedBox(height: 9),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    for (final m in models)
                      InkWell(
                        onTap: () => _switchModel(m),
                        borderRadius: BorderRadius.circular(8),
                        child: Container(
                          padding:
                              const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                          decoration: BoxDecoration(
                            color: m == s.model ? const Color(0x337B5CFF) : C.surface,
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(
                              color: m == s.model ? C.purple : C.border,
                              width: 0.6,
                            ),
                          ),
                          child: Text(
                            m,
                            style: TextStyle(
                              fontSize: 11.5,
                              color: m == s.model ? C.purpleSoft : C.dim,
                            ),
                          ),
                        ),
                      ),
                  ],
                ),
                const SizedBox(height: 8),
                Text(
                  p == null
                      ? '自定义接入的模型，直接在「修改配置」里改模型名。'
                      : '同一家的 Key 通用，换模型不用重新填 Key。'
                          '换成别家要去「修改配置」重填。',
                  style: const TextStyle(fontSize: 9.5, height: 1.5, color: C.faint),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),

          // Key 与安全
          Container(
            padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
            decoration: BoxDecoration(
              color: C.card,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: C.border, width: 0.6),
            ),
            child: Column(
              children: [
                Row(
                  children: [
                    const Icon(Icons.key_outlined, size: 15, color: C.dim),
                    const SizedBox(width: 8),
                    const Text('API Key', style: TextStyle(fontSize: 12, color: C.text)),
                    const Spacer(),
                    Text(_maskKey(s.apiKey),
                        style: const TextStyle(fontSize: 11.5, color: C.dim)),
                  ],
                ),
                const SizedBox(height: 8),
                const Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    'Key 只存在这台手机本地，不上传任何服务器；'
                    '换手机需要重新填一次，或用「数据 → 备份」把设置一起搬过去。',
                    style: TextStyle(fontSize: 9.5, height: 1.5, color: C.faint),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _tag(String text) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        decoration: BoxDecoration(
          color: C.surface,
          borderRadius: BorderRadius.circular(6),
          border: Border.all(color: C.border, width: 0.6),
        ),
        child: Text(text, style: const TextStyle(fontSize: 10.5, color: C.dim)),
      );

  String _fmtToken(int n) {
    if (n < 1000) return '$n';
    if (n < 1000000) return '${(n / 1000).toStringAsFixed(1)}K';
    return '${(n / 1000000).toStringAsFixed(2)}M';
  }

  Widget _header() {
    final String title;
    final String sub;
    if (_seg == 0) {
      title = _providers[_providerIdx].name;
      sub = AppState.I.settings.model;
    } else if (_seg == 1) {
      title = '公益模型';
      sub = _freeModels[_freeIdx].model;
    } else {
      title = '自定义接入';
      sub = _model.text.isEmpty ? '未设置模型' : _model.text;
    }

    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 14, 12, 10),
      child: Row(
        children: [
          Container(
            width: 34,
            height: 34,
            decoration: BoxDecoration(
              color: _seg == 1 ? const Color(0xFF1E3A2A) : const Color(0x337B5CFF),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(
              _seg == 0
                  ? Icons.workspace_premium
                  : _seg == 1
                      ? Icons.card_giftcard
                      : Icons.dns,
              size: 18,
              color: _seg == 1 ? const Color(0xFF6FD79B) : C.purpleSoft,
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
                const SizedBox(height: 2),
                Text(sub,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 11, color: C.dim)),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
            decoration: BoxDecoration(
              color: C.cardHi,
              borderRadius: BorderRadius.circular(20),
            ),
            child: Row(
              children: [
                Container(
                  width: 5,
                  height: 5,
                  decoration: BoxDecoration(
                    color: _connected ? C.green : C.faint,
                    shape: BoxShape.circle,
                  ),
                ),
                const SizedBox(width: 5),
                Text(
                  _connected ? '已连接' : '未连接',
                  style: TextStyle(fontSize: 10.5, color: _connected ? C.green : C.dim),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _segment() {
    const labels = ['套餐', '公益', '自定义接入'];
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 10),
      padding: const EdgeInsets.all(3),
      decoration: BoxDecoration(
        color: const Color(0xFF12121B),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        children: [
          for (var i = 0; i < labels.length; i++)
            Expanded(
              child: GestureDetector(
                onTap: () => setState(() => _seg = i),
                child: Container(
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  decoration: BoxDecoration(
                    color: _seg == i ? const Color(0xFF2A2154) : Colors.transparent,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    labels[i],
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 12.5,
                      color: _seg == i ? C.purpleSoft : C.dim,
                      fontWeight: _seg == i ? FontWeight.w600 : FontWeight.w400,
                    ),
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  // ---------- 套餐 ----------

  Widget _planBody() {
    final p = _providers[_providerIdx];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _box(
          child: DropdownButtonHideUnderline(
            child: DropdownButton<int>(
              value: _providerIdx,
              isExpanded: true,
              dropdownColor: C.cardHi,
              icon: const Icon(Icons.unfold_more, size: 17, color: C.dim),
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(fontSize: 13, color: C.text),
              items: [
                for (var i = 0; i < _providers.length; i++)
                  DropdownMenuItem(
                    value: i,
                    child: Row(
                      children: [
                        Flexible(
                          child: Text(
                            _providers[i].name,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontSize: 13, color: C.text),
                          ),
                        ),
                        if (_providers[i].free) ...[
                          const SizedBox(width: 6),
                          _badge('免费'),
                        ],
                      ],
                    ),
                  ),
              ],
              onChanged: (i) {
                if (i == null) return;
                setState(() {
                  _providerIdx = i;
                  _key.text = AppState.I.settings.keys[_providers[i].provider] ?? '';
                });
              },
            ),
          ),
        ),
        const SizedBox(height: 10),
        Row(
          children: [
            const Text('连接方式：', style: TextStyle(fontSize: 11.5, color: C.dim)),
            const SizedBox(width: 4),
            _pill('API Key', true),
            const SizedBox(width: 8),
            _pill('手机号', false),
          ],
        ),
        const SizedBox(height: 10),
        _keyField(_key),
        const SizedBox(height: 6),
        Text(p.note, style: const TextStyle(fontSize: 10.5, color: C.faint)),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
              child: SizedBox(
                height: 42,
                child: OutlinedButton(
                  onPressed: () => _copy(p.keyUrl, '注册地址已复制，用浏览器打开'),
                  style: OutlinedButton.styleFrom(
                    side: const BorderSide(color: C.border),
                    padding: const EdgeInsets.symmetric(horizontal: 6),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  ),
                  child: const Text('获取 Key',
                      maxLines: 1,
                      style: TextStyle(fontSize: 12.5, color: C.purpleSoft)),
                ),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              flex: 2,
              child: SizedBox(
                height: 42,
                child: ElevatedButton(
                  onPressed: _testing
                      ? null
                      : () => _applyAndTest(
                            baseUrl: p.url,
                            apiKey: _key.text,
                            model: p.model,
                            provider: p.provider,
                            format: 'openai',
                          ),
                  style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all<Color>(C.purple),
                    foregroundColor: MaterialStateProperty.all<Color>(Colors.white),
                    shape: MaterialStateProperty.all(
                      RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                    ),
                  ),
                  child: Text(
                    _testing ? '连接中…' : '保存并测试',
                    style: const TextStyle(fontSize: 13, color: Colors.white),
                  ),
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }

  // ---------- 公益 ----------

  Widget _freeBody() {
    final m = _freeModels[_freeIdx];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: const [
            Icon(Icons.info_outline, size: 13, color: C.faint),
            SizedBox(width: 5),
            Expanded(
              child: Text(
                '公益模型为体验性质，可能随时调整或下架，不保证稳定',
                style: TextStyle(fontSize: 10.5, color: C.faint),
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        SizedBox(
          height: 42,
          width: double.infinity,
          child: OutlinedButton.icon(
            onPressed: _showFreeChannels,
            icon: const Icon(Icons.search, size: 16, color: Color(0xFF6FD79B)),
            label: const Text('获取公益模型',
                style: TextStyle(fontSize: 13, color: Color(0xFF6FD79B))),
            style: OutlinedButton.styleFrom(
              side: const BorderSide(color: Color(0xFF2F5B42)),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            ),
          ),
        ),
        const SizedBox(height: 12),
        const Text('模型', style: TextStyle(fontSize: 11, color: C.dim)),
        const SizedBox(height: 6),
        _box(
          child: DropdownButtonHideUnderline(
            child: DropdownButton<int>(
              value: _freeIdx,
              isExpanded: true,
              dropdownColor: C.cardHi,
              icon: const Icon(Icons.unfold_more, size: 17, color: C.dim),
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(fontSize: 12.5, color: C.text),
              items: [
                for (var i = 0; i < _freeModels.length; i++)
                  DropdownMenuItem(
                    value: i,
                    child: Text(_freeModels[i].model),
                  ),
              ],
              onChanged: (i) {
                if (i == null) return;
                setState(() {
                  _freeIdx = i;
                  _freeKey.text = AppState.I.settings.keys[_freeModels[i].provider] ?? '';
                });
              },
            ),
          ),
        ),
        const SizedBox(height: 10),
        _keyField(_freeKey, hint: '${m.provider} 的 API Key'),
        const SizedBox(height: 12),
        SizedBox(
          width: double.infinity,
          height: 44,
          child: ElevatedButton(
            onPressed: _testing
                ? null
                : () => _applyAndTest(
                      baseUrl: m.baseUrl,
                      apiKey: _freeKey.text,
                      model: m.model,
                      provider: m.provider,
                      format: 'openai',
                    ),
            style: ButtonStyle(
              backgroundColor: MaterialStateProperty.all<Color>(C.purple),
              foregroundColor: MaterialStateProperty.all<Color>(Colors.white),
              shape: MaterialStateProperty.all(
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              ),
            ),
            child: Text(_testing ? '连接中…' : '连接公益模型',
                style: const TextStyle(fontSize: 13.5, color: Colors.white)),
          ),
        ),
      ],
    );
  }

  void _showFreeChannels() {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => Container(
        decoration: const BoxDecoration(
          color: C.surface,
          borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
        ),
        child: SafeArea(
          top: false,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 38,
                height: 4,
                margin: const EdgeInsets.symmetric(vertical: 10),
                decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(2)),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(18, 0, 18, 10),
                child: Row(
                  children: const [
                    Icon(Icons.card_giftcard, size: 17, color: Color(0xFF6FD79B)),
                    SizedBox(width: 8),
                    Text('免费的公益渠道', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
                  ],
                ),
              ),
              for (final p in _providers.where((e) => e.free))
                ListTile(
                  title: Text(p.name, style: const TextStyle(fontSize: 13.5)),
                  subtitle: Text(p.note, style: const TextStyle(fontSize: 11, color: C.dim)),
                  trailing: const Icon(Icons.copy, size: 15, color: C.faint),
                  onTap: () {
                    Navigator.pop(context);
                    _copy(p.keyUrl, '${p.name} 注册地址已复制');
                  },
                ),
              const Padding(
                padding: EdgeInsets.fromLTRB(18, 6, 18, 14),
                child: Text(
                  '注册后在后台创建 API Key，粘到上面的输入框，点「连接公益模型」。',
                  style: TextStyle(fontSize: 11, color: C.dim, height: 1.6),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ---------- 自定义 ----------

  Widget _customBody() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          width: double.infinity,
          height: 40,
          child: OutlinedButton.icon(
            onPressed: () {
              setState(() {
                _name.clear();
                _url.clear();
                _customKey.clear();
                _model.clear();
                _models = [];
                _format = 'openai';
              });
            },
            icon: const Icon(Icons.add, size: 15, color: C.purpleSoft),
            label: const Text('添加自定义配置', style: TextStyle(fontSize: 12.5, color: C.purpleSoft)),
            style: OutlinedButton.styleFrom(
              side: const BorderSide(color: C.border),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            ),
          ),
        ),
        const SizedBox(height: 12),
        _label('配置名称'),
        _field(_name, '比如 我的中转'),
        const SizedBox(height: 12),
        _label('API 地址'),
        _field(_url, 'https://xxx.com/v1'),
        const SizedBox(height: 12),
        const Text('API 格式', style: TextStyle(fontSize: 11, color: C.dim)),
        const SizedBox(height: 6),
        Row(
          children: [
            _pill('OpenAI', _format == 'openai', onTap: () => setState(() => _format = 'openai')),
            const SizedBox(width: 8),
            _pill('Anthropic', _format == 'anthropic',
                onTap: () => setState(() => _format = 'anthropic')),
          ],
        ),
        const SizedBox(height: 12),
        _label('API Key'),
        _keyField(_customKey),
        const SizedBox(height: 12),
        _label('模型'),
        _field(_model, '比如 deepseek-chat'),
        const SizedBox(height: 6),
        Row(
          children: [
            const Spacer(),
            TextButton.icon(
              onPressed: _fetching ? null : _fetchModels,
              icon: const Icon(Icons.sync, size: 14, color: C.purpleSoft),
              label: Text(_fetching ? '拉取中…' : '获取模型列表',
                  style: const TextStyle(fontSize: 11.5, color: C.purpleSoft)),
            ),
          ],
        ),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(11),
          decoration: BoxDecoration(
            color: const Color(0xFF12121B),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const Text('模型列表', style: TextStyle(fontSize: 11.5, color: C.dim)),
                  const Spacer(),
                  GestureDetector(
                    onTap: () async {
                      final ctrl = TextEditingController();
                      final v = await showDialog<String>(
                        context: context,
                        builder: (ctx) => AlertDialog(
                          backgroundColor: C.card,
                          title: const Text('手动添加模型'),
                          content: TextField(controller: ctrl, autofocus: true, decoration: const InputDecoration(hintText: '模型 ID')),
                          actions: [
                            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('取消')),
                            ElevatedButton(onPressed: () => Navigator.pop(ctx, ctrl.text), child: const Text('添加')),
                          ],
                        ),
                      );
                      if (v != null && v.trim().isNotEmpty) {
                        setState(() => _models = {..._models, v.trim()}.toList());
                      }
                    },
                    child: Row(
                      children: const [
                        Icon(Icons.add, size: 13, color: C.purpleSoft),
                        SizedBox(width: 3),
                        Text('添加模型', style: TextStyle(fontSize: 11, color: C.purpleSoft)),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              if (_models.isEmpty)
                const Text('暂无模型：可手动添加，或点上方「获取模型列表」自动带出',
                    style: TextStyle(fontSize: 10.5, color: C.faint, height: 1.6))
              else
                Wrap(
                  spacing: 6,
                  runSpacing: 6,
                  children: [
                    for (final m in _models)
                      GestureDetector(
                        onTap: () => setState(() => _model.text = m),
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            color: _model.text == m ? const Color(0xFF2A2154) : C.card,
                            borderRadius: BorderRadius.circular(6),
                            border: Border.all(
                              color: _model.text == m ? C.purple : C.border,
                              width: 0.7,
                            ),
                          ),
                          child: Text(
                            m,
                            style: TextStyle(
                              fontSize: 10.5,
                              color: _model.text == m ? C.purpleSoft : C.dim,
                            ),
                          ),
                        ),
                      ),
                  ],
                ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        Row(
          children: [
            Expanded(
              child: SizedBox(
                height: 44,
                child: ElevatedButton(
                  onPressed: _testing ? null : () => _saveCustom(again: false),
                  style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all<Color>(C.purple),
                    foregroundColor: MaterialStateProperty.all<Color>(Colors.white),
                    shape: MaterialStateProperty.all(
                      RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                    ),
                  ),
                  child: Text(_testing ? '连接中…' : '保存',
                      style: const TextStyle(fontSize: 13.5, color: Colors.white)),
                ),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: SizedBox(
                height: 44,
                child: OutlinedButton(
                  onPressed: _testing ? null : () => _saveCustom(again: true),
                  style: OutlinedButton.styleFrom(
                    side: const BorderSide(color: C.border),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  ),
                  child: const Text('保存并再添加', style: TextStyle(fontSize: 13, color: C.text)),
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Future<void> _saveCustom({required bool again}) async {
    if (_url.text.trim().isEmpty || _model.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('API 地址和模型名都要填')),
      );
      return;
    }
    final st = AppState.I;
    final cfg = CustomConfig(
      name: _name.text.trim().isEmpty ? '我的配置' : _name.text.trim(),
      baseUrl: _url.text.trim(),
      apiKey: _customKey.text.trim(),
      model: _model.text.trim(),
      format: _format,
      models: List<String>.from(_models),
    );
    final list = List<CustomConfig>.from(st.settings.customConfigs)
      ..removeWhere((c) => c.name == cfg.name)
      ..add(cfg);
    await _applyAndTest(
      baseUrl: cfg.baseUrl,
      apiKey: cfg.apiKey,
      model: cfg.model,
      provider: '自定义',
      format: cfg.format,
      customConfigs: list,
    );
    if (again && mounted) {
      setState(() {
        _name.clear();
        _url.clear();
        _customKey.clear();
        _model.clear();
        _models = [];
      });
    }
  }

  Future<void> _fetchModels() async {
    setState(() => _fetching = true);
    try {
      final ids = await fetchModelIds(Settings(
        baseUrl: _url.text.trim(),
        apiKey: _customKey.text.trim(),
        model: _model.text.trim(),
        format: _format,
      ));
      if (!mounted) return;
      setState(() {
        _models = ids.take(60).toList();
        if (_model.text.isEmpty && ids.isNotEmpty) _model.text = ids.first;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('拉到 ${ids.length} 个模型，点下面的标签选一个')),
      );
    } on LlmException catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.message)));
    } finally {
      if (mounted) setState(() => _fetching = false);
    }
  }

  // ---------- 小组件 ----------

  Widget _badge(String t) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
        decoration: BoxDecoration(
          color: const Color(0xFF1E4B2F),
          borderRadius: BorderRadius.circular(3),
        ),
        child: Text(t, style: const TextStyle(fontSize: 8.5, color: Color(0xFF7FD49E))),
      );

  Widget _pill(String t, bool active, {VoidCallback? onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: active ? const Color(0xFF2A2154) : C.card,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: active ? C.purple : C.border, width: 0.8),
        ),
        child: Text(
          t,
          style: TextStyle(fontSize: 11.5, color: active ? C.purpleSoft : C.dim),
        ),
      ),
    );
  }

  Widget _box({required Widget child}) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
        decoration: BoxDecoration(
          color: const Color(0xFF12121B),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: C.border, width: 0.7),
        ),
        child: child,
      );

  Widget _keyField(TextEditingController c, {String hint = 'API Key'}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      decoration: BoxDecoration(
        color: const Color(0xFF12121B),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: C.border, width: 0.7),
      ),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              controller: c,
              obscureText: _obscure,
              autocorrect: false,
              style: const TextStyle(fontSize: 13, color: C.text),
              decoration: InputDecoration(
                hintText: hint,
                hintStyle: const TextStyle(fontSize: 12.5, color: C.faint),
                isDense: true,
                contentPadding: const EdgeInsets.symmetric(vertical: 10),
              ),
            ),
          ),
          IconButton(
            onPressed: () => setState(() => _obscure = !_obscure),
            icon: Icon(
              _obscure ? Icons.visibility_off_outlined : Icons.visibility_outlined,
              size: 17,
              color: C.dim,
            ),
            splashRadius: 16,
            constraints: const BoxConstraints(),
            padding: EdgeInsets.zero,
          ),
        ],
      ),
    );
  }

  Widget _label(String t) => Padding(
        padding: const EdgeInsets.only(bottom: 6),
        child: Text(t, style: const TextStyle(fontSize: 11, color: C.dim)),
      );

  Widget _field(TextEditingController c, String hint) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      decoration: BoxDecoration(
        color: const Color(0xFF12121B),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: C.border, width: 0.7),
      ),
      child: TextField(
        controller: c,
        autocorrect: false,
        onChanged: (_) => setState(() {}),
        style: const TextStyle(fontSize: 13, color: C.text),
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: const TextStyle(fontSize: 12.5, color: C.faint),
          isDense: true,
          contentPadding: const EdgeInsets.symmetric(vertical: 10),
        ),
      ),
    );
  }
}
