import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:novel_app/skill_market.dart';
import 'package:novel_app/store.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  group('订阅源解析', () {
    test('数组格式', () {
      final list = parseMarketFeed('''
      [{"id":"a","name":"甲","desc":"说明","category":"技法","author":"某人","downloads":9,"content":"正文"}]
      ''');
      expect(list.length, 1);
      expect(list.first.name, '甲');
      expect(list.first.downloads, 9);
      expect(list.first.category, '技法');
    });

    test('{"skills": [...]} 格式', () {
      final list = parseMarketFeed('{"skills":[{"name":"乙","content":"内容"}]}');
      expect(list.length, 1);
      expect(list.first.author, '未署名');
      expect(list.first.category, '其他');
      expect(list.first.downloads, 0);
    });

    test('缺 name / content 的条目被跳过', () {
      final list = parseMarketFeed('''
      [{"name":"只有名字"},{"content":"只有正文"},{"name":"完整","content":"ok"}]
      ''');
      expect(list.length, 1);
      expect(list.first.name, '完整');
    });

    test('不是 JSON 时给明确错误', () {
      expect(() => parseMarketFeed('<html>404</html>'),
          throwsA(isA<SkillFeedException>()));
    });

    test('空列表给明确错误', () {
      expect(() => parseMarketFeed('[]'), throwsA(isA<SkillFeedException>()));
    });
  });

  test('从真实地址拉订阅源（含中文）', () async {
    HttpOverrides.global = null;
    final list = await fetchMarketFeed('http://127.0.0.1:8777/skills.json');
    expect(list.length, 2);
    expect(list.first.name, '订阅·去AI味');
    expect(list.first.downloads, 42);
    expect(list.first.content.contains('排比'), isTrue);
  });

  group('技能开关', () {
    setUp(() async {
      SharedPreferences.setMockInitialValues(<String, Object>{});
      await AppState.I.init();
      AppState.I.settings.importedSkills.clear();
      AppState.I.settings.disabledSkills.clear();
      AppState.I.settings.activeSkillId = 'builtin:novel-writer';
      AppState.I.settings.styleSkillId = '';
    });

    test('关掉一个非当前技能，数量减少', () async {
      final before = AppState.I.enabledSkillCount;
      final ok = await AppState.I.setSkillEnabled('builtin:skill-creator', false);
      expect(ok, isTrue);
      expect(AppState.I.enabledSkillCount, before - 1);
      expect(AppState.I.isSkillEnabled('builtin:skill-creator'), isFalse);
    });

    test('关掉当前技能会自动切到另一个', () async {
      await AppState.I.setSkillEnabled('builtin:novel-writer', false);
      expect(AppState.I.settings.activeSkillId, isNot('builtin:novel-writer'));
      expect(AppState.I.isSkillEnabled(AppState.I.settings.activeSkillId), isTrue);
    });

    test('不允许把所有技能都关掉', () async {
      AppState.I.settings.disabledSkills
        ..clear()
        ..add('builtin:skill-creator');
      final ok = await AppState.I.setSkillEnabled('builtin:novel-writer', false);
      expect(ok, isFalse);
      expect(AppState.I.enabledSkillCount, 1);
    });

    test('从广场添加后不重复添加', () async {
      final first = await AppState.I.addMarketSkill(
          id: 'deai-polish', name: '去 AI 味润色', content: '正文');
      final second = await AppState.I.addMarketSkill(
          id: 'deai-polish', name: '去 AI 味润色', content: '正文');
      expect(first, isTrue);
      expect(second, isFalse);
      expect(AppState.I.hasMarketSkill('deai-polish'), isTrue);
      expect(
        AppState.I.settings.importedSkills.where((s) => s.id == 'market:deai-polish').length,
        1,
      );
    });
  });
}
