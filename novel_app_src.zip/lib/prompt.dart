import 'models.dart';
import 'skill.dart';

const String _persona = """你是手机 App 里的「AI 写小说助手」，服务零基础用户。用户只会点按钮，不会写提示词。""";

const String _formatRules = """【输出格式：技能优先，App 的标记是可选的】
当前技能如果规定了输出结构（章节怎么写、选项怎么给、资料怎么整理），按技能来。
下面这些标记只决定「App 能不能把它变成按钮、保存条、资料」，不是硬性要求：

- 想生成可点按钮：写 [选项]，后面每行「- 选项文字 | 一句话说明」
- 想弹出「保存这一章」：写 [章节]，下一行「第X章 标题」，再往下是正文
- 想写进「小说资料」：写 [人物库] / [世界观] / [章节摘要]，后面跟完整内容

技能用 Markdown 也可以：App 会把「第X章 + 长正文」认成一章，把短列表项认成选项，标题按层级显示。

不管用什么结构，这四条必须遵守：
1. 不要用 JSON 输出。
2. 不要问"是否保存""要不要继续"——保存和继续由 App 的按钮处理。
3. 不要写"以下是…""已为您完成""稍等片刻"这类话。
4. 同一轮要么给章节，要么给选项，不要两样都塞。

写得好的示意：
[选项]
- 现实主义 | 展现真实都市生活
- 轻松幽默 | 轻松愉快的阅读体验

[章节]
第1章 捡到系统的那个雨夜
雨下得很大，陈烬把电动车停在桥洞下……
""";

const String _appRules = '$_persona\n\n$_formatRules';

String _thinkingName(String level) {
  switch (level) {
    case 'off':
      return '关闭思考';
    case 'low':
      return '低';
    case 'medium':
      return '中';
    case 'high':
      return '高';
    case 'deep':
      return '深度';
    default:
      return '默认';
  }
}

/// 把「思考强度」翻译成模型能执行的指令。不传任何新参数，避免不同供应商 400。
String _thinkingHint(String level) {
  switch (level) {
    case 'off':
      return '不要写分析、不要列提纲，直接给最终结果。';
    case 'low':
      return '动笔前只想 1~2 句关键判断，然后直接写。';
    case 'medium':
      return '动笔前先在内部走 3~5 步：目标、冲突、接下来怎么走，再写。';
    case 'high':
      return '动笔前先列 5~8 条要点（人物动机、场景目标、冲突、伏笔），再展开写。';
    case 'deep':
      return '动笔前做完整推演：人物当前诉求、与谁冲突、这一段的转折、留下的伏笔，全部想清楚再写，篇幅可以更长。';
    default:
      return '';
  }
}

String _clip(String s, int max) => s.length <= max ? s : '${s.substring(0, max)}…（后略）';

/// 组装 system 提示：App 规则 + 技能包原文 + 当前小说状态
Future<String> buildSystemPrompt(
  Novel novel, {
  String? skillText,
  String skillId = 'builtin:novel-writer',
  String skillName = '小说写作',
  String? styleName,
  String? styleText,
  String thinkingLevel = 'default',
  bool agentMode = false,
  bool webSearch = false,
  String customPrompt = '',
}) async {
  final skill = (skillText != null && skillText.trim().isNotEmpty)
      ? skillText
      : await SkillPack.load(skillId);
  final buf = StringBuffer();
  final custom = customPrompt.trim();
  if (custom.isNotEmpty) {
    buf.writeln(custom);
    buf.writeln();
    buf.writeln(_formatRules);
  } else {
    buf.writeln(_appRules);
  }
  if (skillId != 'builtin:novel-writer') {
    buf.writeln('【当前启用的技能：$skillName】');
    buf.writeln('如果这个技能与写小说无关，就按它自己的流程办事，'
        '但对外输出仍然只用 [选项] / [章节] 两种格式，不要输出别的结构。');
    buf.writeln();
  }
  buf.writeln(skill);
  buf.writeln();
  buf.writeln('【App 环境说明】技能原文里如果提到 file_write / file_read / question / create_project / '
      'create_skill / skill_lookup，或者让你读写「小说资料/人物库.md」「章节内容/第X章.md」这类文件，'
      '一律跳过：App 里没有文件，也没有这些工具。技能没有别的写法时，按 App 的标记来——章节用 [章节]；'
      '人物库、世界观、章节摘要用 [人物库] / [世界观] / [章节摘要]；保存和确认交给 App 的按钮，'
      '不要问「是否保存」、也不要说已经写入文件。技能原文和这段说明冲突时，以这段说明为准。');
  buf.writeln();
  final think = _thinkingHint(thinkingLevel);
  if (think.isNotEmpty) {
    buf.writeln('【思考强度：${_thinkingName(thinkingLevel)}】$think');
    buf.writeln();
  }
  if (agentMode) {
    buf.writeln('【工具】你有这些工具，可以自己调用：');
    buf.writeln('- read_doc(name)：读本书资料，name 取「世界观」「人物库」「章节摘要」');
    buf.writeln('- list_chapters()：列出已保存的章节标题和字数');
    buf.writeln('- read_chapter(index)：读第 index 章正文（从 1 开始）');
    buf.writeln('- search_book(title)：在书源网站搜索书名，返回前几条结果');
    buf.writeln('- read_notes()：读用户的备忘录');
    if (webSearch) {
      buf.writeln('- web_search(query)：联网搜索，返回标题、链接和摘要');
    }
    buf.writeln();
    buf.writeln('规则：');
    buf.writeln('1. 要引用书里的具体设定或前文细节时，先调工具读取，不要凭印象编。');
    buf.writeln('2. 写新章前，先 read_doc(章节摘要)，再用 read_chapter 看最后一章结尾；本章内容要和上一章接得上。');
    buf.writeln('3. 用户让你找书、搜书、参考热门书时，必须调 search_book，不许编书名和作者。');
    buf.writeln('4. 工具返回空或失败，就如实说「没查到」，不要假装查到了。');
    if (webSearch) {
      buf.writeln('5. 涉及最新榜单、行业动态、某本书/作者的真实信息时，先 web_search；'
          '回答里标出来源编号 [1][2]，搜索结果没有的就说不确定。');
    }
    buf.writeln('5. 只调必要的工具，别为了显得忙而乱调；同一份资料不要重复读。');
    buf.writeln();
  }
  if (styleText != null && styleText.trim().isNotEmpty) {
    buf.writeln('【附加风格技能：${styleName ?? "风格"}】');
    buf.writeln('下面是用户蒸馏出来的风格约束。写作时必须遵守它的用词、句长、节奏、桥段偏好；'
        '但它不改变主技能的流程，也不要把它当成项目资料。');
    buf.writeln(_clip(styleText, 4000));
    buf.writeln();
  }
  buf.writeln('【当前小说状态】');
  if (novel.needsSetup) {
    buf.writeln('书名：${novel.title.trim().isEmpty ? "（还没有，正在初始化）" : novel.title.trim()}');
    buf.writeln('说明：这本书还没有任何设定和章节。第一轮按技能包【初始化模式】开始，只问题材；'
        '设定聊够了就输出 [人物库] / [世界观] / [章节摘要] 三份完整资料，App 会存进「小说资料」。');
  } else {
    buf.writeln('书名：${novel.title}');
    buf.writeln('已保存章节数：${novel.chapters.length}');
    buf.writeln();
    buf.writeln('--- 人物库 ---');
    buf.writeln(novel.characters.trim().isEmpty ? '（空）' : novel.characters);
    buf.writeln();
    buf.writeln('--- 世界观 ---');
    buf.writeln(novel.world.trim().isEmpty ? '（空）' : novel.world);
    buf.writeln();
    if (!agentMode) {
      buf.writeln('--- 章节摘要 ---');
      buf.writeln(novel.summary.trim().isEmpty ? '（空）' : novel.summary);
      buf.writeln();
      buf.writeln('--- 最近章节正文（最多 5 章）---');
      buf.writeln(novel.recentChapters(5));
    } else {
      buf.writeln('--- 章节摘要与正文 ---');
      buf.writeln('摘要 ${novel.summary.replaceAll(RegExp(r"\s"), "").length} 字，'
          '已保存 ${novel.chapters.length} 章。这部分没有直接塞进上下文，'
          '需要时用 read_doc(章节摘要) 或 read_chapter(index) 读取。');
    }
  }
  return buf.toString();
}

/// 章节保存之后，让模型更新三份维护文档
String buildSyncPrompt(Novel novel) {
  return '【App 内部指令】用户已确认保存「${novel.chapters.isEmpty ? "最新一章" : novel.chapters.last.title}」。\n'
      '现在请按技能包【Step 8】更新三份维护文档，严格按下面格式输出，三段都要给完整的新版本（不是只给改动）：\n\n'
      '[人物库]\n（更新后的完整人物库，沿用原来的字段格式）\n\n'
      '[世界观]\n（更新后的完整世界观）\n\n'
      '[章节摘要]\n（更新后的完整章节摘要，每章一句话）\n\n'
      '不要写任何解释、不要写"以下是"，直接给三段内容。';
}
