import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:novel_app/markdown_light.dart';
import 'package:novel_app/models.dart';

void main() {
  test('Markdown 小标题形式的资料能认出来', () {
    final reply = AiReply.parse('''
好，设定先这样。

## 人物库
## 主角
陈烬，26 岁，外卖员，觉醒后能看见死气，代价是失眠。林晚是他的旧同学。

## 世界观
末世第三年，城市断电。异能者靠吸收死气变强，吸多了会失去一段记忆。

## 章节摘要
## 第0章 前情
故事尚未开始，主角还在送最后一单外卖。
''');
    expect(reply.hasDocs, isTrue);
    expect(reply.docs.keys.toSet(), {'characters', 'world', 'summary'});
    expect(reply.docs['characters'], contains('陈烬'));
    expect(reply.docs['world'], contains('末世'));
    // 资料正文不该在气泡里重复显示
    expect(reply.message.contains('末世第三年'), isFalse);
  });

  test('没有标记时，Markdown 的「第X章 + 长正文」也能认成一章', () {
    final body = '雨下得很大，陈烬把电动车停在桥洞下。' * 40;
    final reply = AiReply.parse('# 第一章 雨夜\n$body');
    expect(reply.hasChapter, isTrue);
    expect(reply.chapterTitle, '第一章 雨夜');
    expect(reply.chapterContent.contains('桥洞'), isTrue);
  });

  test('技能用短列表给选项时，仍然变成按钮', () {
    final reply = AiReply.parse('先选题材：\n- 都市异能 | 现代都市觉醒\n- 玄幻修真 | 修炼升级');
    expect(reply.options.length, 2);
    expect(reply.options.first.label, '都市异能');
    expect(reply.message.contains('都市异能'), isFalse, reason: '选项不该在正文里重复');
  });

  test('长回复末尾的选项列表也能变成按钮', () {
    final long = '这段是解释，讲清楚为什么这么写。' * 40;
    final reply = AiReply.parse('$long\n\n想怎么走？\n- 先写第一章 | 直接开写\n- 再改设定 | 调整人物');
    expect(reply.options.length, 2);
    expect(reply.options.last.label, '再改设定');
  });

  test('Markdown 渲染吃掉标题井号和加粗星号', () {
    final spans = buildMarkdownSpans(
      '# 标题\n**粗体**和`代码`\n- 列表项\n> 引用',
      const TextStyle(fontSize: 14),
    );
    final plain = spans.map((s) => (s as TextSpan).text ?? '').join();
    expect(plain, contains('标题'));
    expect(plain, contains('粗体'));
    expect(plain, contains('列表项'));
    expect(plain.contains('##'), isFalse);
    expect(plain.contains('**'), isFalse);
    expect(plain, contains('•'));
  });

  testWidgets('气泡里的 Markdown 能正常渲染', (tester) async {
    await tester.pumpWidget(const MaterialApp(
      home: Scaffold(
        body: MarkdownText('## 第二章 停电\n**陈烬**走进楼道。\n- 手电筒\n- 打火机'),
      ),
    ));
    await tester.pumpAndSettle();
    expect(find.byType(MarkdownText), findsOneWidget);
    expect(tester.takeException(), isNull);
  });
}
