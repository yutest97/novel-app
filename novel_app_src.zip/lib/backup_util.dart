/// 备份文件名：novel_app_backup_20261023_1415.json
String backupFileName([DateTime? now]) {
  final d = now ?? DateTime.now();
  String two(int n) => n.toString().padLeft(2, '0');
  return 'novel_app_backup_${d.year}${two(d.month)}${two(d.day)}_'
      '${two(d.hour)}${two(d.minute)}.json';
}
