import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../models.dart';
import '../store.dart';
import '../theme.dart';

/// 脑洞生成器：频道 + 题材 + 补充要求，可联动扫榜数据
class IdeaSheet extends StatefulWidget {
  const IdeaSheet({super.key});

  @override
  State<IdeaSheet> createState() => _IdeaSheetState();
}

class _IdeaSheetState extends State<IdeaSheet> {
  int _tab = 0; // 0 生成，1 历史

  static const List<String> _channels = ['男频', '女频', '不限'];
  static const List<String> _genres = [
    '都市', '高武', '玄幻', '仙侠', '悬疑', '科幻', '历史', '游戏', '跟随榜单',
  ];

  int _channel = 0;
  int _genre = 0;
  bool _useTrend = false;
  bool _generating = false;

  final TextEditingController _extra = TextEditingController();

  @override
  void dispose() {
    _extra.dispose();
    super.dispose();
  }

  Future<void> _generate() async {
    final messenger = ScaffoldMessenger.of(context);
    final st = AppState.I;
    final genre = _genres[_genre];

    if (!st.settings.isReady) {
      messenger.showSnackBar(const SnackBar(
        content: Text('还没填 API Key。请到「设置 → AI 提供商」填好，再回来。'),
      ));
      return;
    }
    if ((genre == '跟随榜单' || _useTrend) && !st.hasRank) {
      messenger.showSnackBar(const SnackBar(
        content: Text('勾了「跟随榜单 / 参考市场趋势」，但还没有扫榜数据。先去「扫榜」抓一次。'),
        duration: Duration(seconds: 5),
      ));
      return;
    }

    final channel = _channels[_channel];
    final extra = _extra.text.trim();
    final buf = StringBuffer('【脑洞】频道：$channel；题材：$genre。');
    if (extra.isNotEmpty) buf.writeln('\n补充要求：$extra');

    if (genre == '跟随榜单' || _useTrend) {
      buf.writeln('\n【市场参考】刚从榜单抓到的热门书（按榜单顺序，共 ${st.lastRank.length} 本）：');
      for (var i = 0; i < st.lastRank.length && i < 20; i++) {
        final b = st.lastRank[i];
        buf.writeln('${i + 1}. ${b.title}${b.extra.isEmpty ? '' : '（${b.extra}）'}');
      }
      buf.writeln('先归纳这些书共同的题材、设定、爽点，再动笔。不要照抄书名和设定。');
    }

    buf
      ..writeln()
      ..writeln('给 5 个能直接开写的网文脑洞，每个包含：')
      ..writeln('1) 书名（2~8 字，符合频道调性）')
      ..writeln('2) 一句话梗概（30 字内）')
      ..writeln('3) 金手指 / 核心设定（一句话说清规则和代价）')
      ..writeln('4) 核心冲突与爽点')
      ..writeln('5) 差异化卖点（和同类书比新在哪）')
      ..writeln()
      ..writeln('要具体、能落地，不要「一个神秘的空间」这种空话。');
    buf.writeln('最后用 [选项] 让我挑一个继续展开成大纲。');

    final prompt = buf.toString();
    final title = '$channel · $genre';
    final nav = Navigator.of(context);

    setState(() => _generating = true);
    nav.pop();
    await st.send(prompt);

    // 把这次的结果存进历史
    final chats = st.novel.chats;
    if (chats.isNotEmpty && chats.last.role == 'assistant') {
      final out = chats.last.text.trim();
      if (out.isNotEmpty) {
        await st.addGen(GenRecord(
          kind: 'idea',
          title: title,
          input: extra,
          output: out,
        ));
      }
    }
    _generating = false;
  }

  @override
  Widget build(BuildContext context) {
    final st = AppState.I;
    final history = st.gensOf('idea');
    return Container(
      constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * 0.86),
      decoration: const BoxDecoration(
        color: C.surface,
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: SafeArea(
        top: false,
        child: Padding(
          padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 38,
                height: 4,
                margin: const EdgeInsets.symmetric(vertical: 10),
                decoration: BoxDecoration(
                  color: Colors.white24,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(18, 2, 10, 4),
                child: Row(
                  children: [
                    Container(
                      width: 26,
                      height: 26,
                      decoration: BoxDecoration(
                        color: const Color(0x337B5CFF),
                        borderRadius: BorderRadius.circular(7),
                      ),
                      child: const Icon(Icons.lightbulb_outline, size: 14, color: C.purpleSoft),
                    ),
                    const SizedBox(width: 9),
                    const Text('脑洞生成器',
                        style: TextStyle(fontSize: 14.5, fontWeight: FontWeight.w600)),
                    const Spacer(),
                    IconButton(
                      icon: const Icon(Icons.close, size: 19, color: C.dim),
                      onPressed: () => Navigator.of(context).pop(),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(18, 0, 18, 0),
                child: Row(
                  children: [
                    _tabPill('生成', _tab == 0, () => setState(() => _tab = 0)),
                    const SizedBox(width: 8),
                    _tabPill('历史 (${history.length})', _tab == 1,
                        () => setState(() => _tab = 1)),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              Flexible(
                child: _tab == 0
                    ? SingleChildScrollView(
                        padding: const EdgeInsets.fromLTRB(18, 0, 18, 4),
                        child: _form(st),
                      )
                    : _historyList(history),
              ),
              if (_tab == 0)
                Padding(
                  padding: const EdgeInsets.fromLTRB(18, 8, 18, 12),
                  child: SizedBox(
                    height: 46,
                    width: double.infinity,
                    child: ElevatedButton.icon(
                      onPressed: _generating ? null : _generate,
                      icon: const Icon(Icons.auto_awesome, size: 17, color: Colors.white),
                      label: const Text('生成脑洞',
                          style: TextStyle(fontSize: 13.5, color: Colors.white)),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: C.purple,
                        shape:
                            RoundedRectangleBorder(borderRadius: BorderRadius.circular(11)),
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _form(AppState st) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('频道', style: TextStyle(fontSize: 11, color: C.dim)),
        const SizedBox(height: 7),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            for (var i = 0; i < _channels.length; i++)
              _chip(_channels[i], _channel == i, () => setState(() => _channel = i)),
          ],
        ),
        const SizedBox(height: 14),
        const Text('题材', style: TextStyle(fontSize: 11, color: C.dim)),
        const SizedBox(height: 7),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            for (var i = 0; i < _genres.length; i++)
              _chip(_genres[i], _genre == i, () => setState(() => _genre = i)),
          ],
        ),
        const SizedBox(height: 14),
        const Text('补充要求（风格 / 元素 / 雷点，自由填写）',
            style: TextStyle(fontSize: 11, color: C.dim)),
        const SizedBox(height: 7),
        TextField(
          controller: _extra,
          minLines: 3,
          maxLines: 5,
          style: const TextStyle(fontSize: 12.5, color: C.text),
          decoration: InputDecoration(
            hintText: '例如：轻松搞笑风、重生+系统、不要后宫…',
            hintStyle: const TextStyle(fontSize: 11.5, color: C.faint),
            filled: true,
            fillColor: C.card,
            contentPadding: const EdgeInsets.all(12),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: const BorderSide(color: C.border, width: 0.7),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: const BorderSide(color: C.border, width: 0.7),
            ),
          ),
        ),
        const SizedBox(height: 12),
        Container(
          padding: const EdgeInsets.fromLTRB(12, 10, 8, 10),
          decoration: BoxDecoration(
            color: C.card,
            borderRadius: BorderRadius.circular(11),
            border: Border.all(color: C.border, width: 0.6),
          ),
          child: Row(
            children: [
              const Icon(Icons.bar_chart, size: 17, color: C.purpleSoft),
              const SizedBox(width: 9),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('参考市场趋势（联动扫榜数据）',
                        style: TextStyle(fontSize: 12.5)),
                    const SizedBox(height: 2),
                    Text(
                      st.hasRank
                          ? '已抓 ${st.lastRank.length} 本 · ${st.lastRankAt}'
                          : '还没有扫榜数据，先去「扫榜」抓一次',
                      style: const TextStyle(fontSize: 10, color: C.faint),
                    ),
                  ],
                ),
              ),
              Switch(
                value: _useTrend,
                activeColor: Colors.white,
                activeTrackColor: C.purple,
                inactiveThumbColor: const Color(0xFFBFC2D4),
                inactiveTrackColor: C.cardHi,
                onChanged: (v) => setState(() => _useTrend = v),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _historyList(List<GenRecord> list) {
    if (list.isEmpty) {
      return const Padding(
        padding: EdgeInsets.symmetric(vertical: 40),
        child: Text('还没有生成记录', style: TextStyle(fontSize: 12, color: C.dim)),
      );
    }
    return ListView.builder(
      shrinkWrap: true,
      padding: const EdgeInsets.fromLTRB(18, 0, 18, 8),
      itemCount: list.length,
      itemBuilder: (context, i) {
        final r = list[i];
        return Padding(
          padding: const EdgeInsets.only(bottom: 8),
          child: InkWell(
            onTap: () => _openRecord(r),
            borderRadius: BorderRadius.circular(10),
            child: Container(
              padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
              decoration: BoxDecoration(
                color: C.card,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: C.border, width: 0.6),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(r.title, style: const TextStyle(fontSize: 12, color: C.purpleSoft)),
                      const Spacer(),
                      Text(_time(r.createdAt),
                          style: const TextStyle(fontSize: 9.5, color: C.faint)),
                    ],
                  ),
                  const SizedBox(height: 5),
                  Text(
                    r.output.replaceAll(RegExp(r'\s+'), ' '),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 11.5, height: 1.6, color: C.dim),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Future<void> _openRecord(GenRecord r) async {
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: C.surface,
        title: Text(r.title, style: const TextStyle(fontSize: 15)),
        content: SizedBox(
          width: double.maxFinite,
          child: SingleChildScrollView(
            child: SelectableText(
              r.output,
              style: const TextStyle(fontSize: 12.5, height: 1.7, color: C.text),
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () async {
              final nav = Navigator.of(ctx);
              await Clipboard.setData(ClipboardData(text: r.output));
              nav.pop();
              if (mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('已复制')),
                );
              }
            },
            child: const Text('复制', style: TextStyle(fontSize: 12.5, color: C.purpleSoft)),
          ),
          TextButton(
            onPressed: () async {
              final nav = Navigator.of(ctx);
              await AppState.I.removeGen(r.id);
              nav.pop();
              if (mounted) setState(() {});
            },
            child: const Text('删除', style: TextStyle(fontSize: 12.5, color: C.faint)),
          ),
        ],
      ),
    );
  }

  String _time(int ms) {
    final d = DateTime.fromMillisecondsSinceEpoch(ms);
    final now = DateTime.now();
    final sameDay = d.year == now.year && d.month == now.month && d.day == now.day;
    final hm =
        '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';
    return sameDay ? hm : '${d.month}/${d.day} $hm';
  }

  Widget _tabPill(String label, bool on, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(7),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: on ? const Color(0x337B5CFF) : Colors.transparent,
          borderRadius: BorderRadius.circular(7),
        ),
        child: Text(
          label,
          style: TextStyle(fontSize: 12, color: on ? C.purpleSoft : C.dim),
        ),
      ),
    );
  }

  Widget _chip(String label, bool on, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(8),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: on ? C.purple : C.card,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: on ? C.purple : C.border, width: 0.6),
        ),
        child: Text(
          label,
          style: TextStyle(fontSize: 12, color: on ? Colors.white : C.text),
        ),
      ),
    );
  }
}
