import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:novel_app/book_storage.dart';
import 'package:novel_app/models.dart';
import 'package:novel_app/store.dart';

/// 内存里的存储，模拟外部目录
class MemoryStorage implements BookStorage {
  MemoryStorage({this.failOnSave = false, this.failOnLoad = false});

  List<Novel> data = <Novel>[];
  bool failOnSave;
  bool failOnLoad;
  int saves = 0;

  @override
  String get label => '测试目录';

  @override
  bool get external => true;

  @override
  Future<List<Novel>> loadAll() async {
    if (failOnLoad) throw Exception('读不了');
    return List<Novel>.from(data);
  }

  @override
  Future<void> saveAll(List<Novel> books) async {
    if (failOnSave) throw Exception('写不了');
    saves++;
    data = List<Novel>.from(books);
  }

  @override
  Future<Novel?> readOne(String id) async {
    for (final b in data) {
      if (b.id == id) return b;
    }
    return null;
  }
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  setUp(() async {
    SharedPreferences.setMockInitialValues(<String, Object>{});
    await AppState.I.init();
    AppState.I.settings
      ..storageMode = 'app'
      ..safUri = ''
      ..safName = '';
    AppState.I.books = [
      Novel(title: '灰烬纪元')
        ..chapters = [Chapter(title: '第1章', content: '雨停了。')],
    ];
    AppState.I.currentId = AppState.I.books.first.id;
  });

  test('保存会写到当前生效的存储', () async {
    final mem = MemoryStorage();
    AppState.I.useStorageForTest(mem);

    await AppState.I.renameBook(AppState.I.books.first.id, '改过的书名');

    expect(mem.data.length, 1);
    expect(mem.data.first.title, '改过的书名');
  });

  test('迁移：写入后校验通过才切换', () async {
    final mem = MemoryStorage();
    await AppState.I.migrateToStorage(mem, mode: 'saf', uri: 'content://dir', name: '我的书稿');

    expect(mem.data.length, 1);
    expect(AppState.I.storageLabel, '测试目录');
    expect(AppState.I.settings.storageMode, 'saf');
    expect(AppState.I.settings.safUri, 'content://dir');
    expect(AppState.I.storageNote.contains('我的书稿'), isTrue);

    // 迁移后新写入也走外部
    final before = mem.saves;
    await AppState.I.renameBook(AppState.I.books.first.id, '迁移后改名');
    expect(mem.saves, greaterThan(before));
    expect(mem.data.first.title, '迁移后改名');
  });

  test('迁移失败时不动设置，也不丢数据', () async {
    final mem = MemoryStorage(failOnSave: true);
    final beforeTitle = AppState.I.books.first.title;

    await expectLater(
      AppState.I.migrateToStorage(mem, mode: 'saf', uri: 'content://x', name: '坏的'),
      throwsA(isA<Exception>()),
    );
    expect(AppState.I.settings.storageMode, 'app');
    expect(AppState.I.books.first.title, beforeTitle);
  });

  test('外部目录授权失效时，启动回退到应用内', () async {
    SharedPreferences.setMockInitialValues(<String, Object>{
      'settings_v1':
          '{"storageMode":"saf","safUri":"content://gone","safName":"旧目录"}',
      'books_v1':
          '[{"id":"b1","title":"应用内的书","chapters":[],"chats":[],"notes":[],"gens":[]}]',
      'current_v1': 'b1',
    });

    await AppState.I.init();

    expect(AppState.I.books.first.title, '应用内的书');
    expect(AppState.I.storageExternal, isFalse);
    expect(AppState.I.storageNote.contains('外部目录'), isTrue);
  });
}
