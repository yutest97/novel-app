import 'package:flutter/material.dart';

import '../store.dart';
import '../theme.dart';

/// 起名工具：选类型 + 补充要求，交给 AI 生成
class NamingSheet extends StatefulWidget {
  const NamingSheet({super.key});

  @override
  State<NamingSheet> createState() => _NamingSheetState();
}

class _NamingSheetState extends State<NamingSheet> {
  static const List<List<String>> _types = [
    ['男性名字', 'male'],
    ['女性名字', 'female'],
    ['功法名称', 'skill'],
    ['地名', 'place'],
    ['门派名称', 'sect'],
    ['兵器名称', 'weapon'],
    ['法宝名称', 'artifact'],
    ['体质名称', 'physique'],
  ];

  static const List<IconData> _icons = [
    Icons.male,
    Icons.female,
    Icons.auto_awesome,
    Icons.place_outlined,
    Icons.account_balance_outlined,
    Icons.gavel,
    Icons.diamond_outlined,
    Icons.bolt,
  ];

  int _type = 0;
  final TextEditingController _extra = TextEditingController();

  @override
  void dispose() {
    _extra.dispose();
    super.dispose();
  }

  Future<void> _generate() async {
    final st = AppState.I;
    final type = _types[_type][0];
    final extra = _extra.text.trim();
    final prompt = StringBuffer('【起名】类型：$type，生成 10 个。');
    if (extra.isNotEmpty) prompt.write('\n补充要求：$extra');
    prompt.write('\n每个名字后面用一句话说明含义或气质。用 [选项] 列出，让我直接挑。');

    final nav = Navigator.of(context);
    nav.pop();
    await st.send(prompt.toString());
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: C.surface,
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: SafeArea(
        top: false,
        child: Padding(
          padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 38,
                height: 4,
                margin: const EdgeInsets.symmetric(vertical: 10),
                decoration: BoxDecoration(
                  color: Colors.white24,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(18, 2, 10, 10),
                child: Row(
                  children: [
                    Container(
                      width: 26,
                      height: 26,
                      decoration: BoxDecoration(
                        color: const Color(0x337B5CFF),
                        borderRadius: BorderRadius.circular(7),
                      ),
                      child: const Icon(Icons.text_fields, size: 14, color: C.purpleSoft),
                    ),
                    const SizedBox(width: 9),
                    const Text('起名工具',
                        style: TextStyle(fontSize: 14.5, fontWeight: FontWeight.w600)),
                    const Spacer(),
                    IconButton(
                      icon: const Icon(Icons.close, size: 19, color: C.dim),
                      onPressed: () => Navigator.of(context).pop(),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(18, 0, 18, 8),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Text('选择类型',
                      style: TextStyle(fontSize: 11.5, color: C.dim.withOpacity(0.9))),
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 18),
                child: Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    for (var i = 0; i < _types.length; i++)
                      GestureDetector(
                        onTap: () => setState(() => _type = i),
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 8),
                          decoration: BoxDecoration(
                            color: _type == i ? const Color(0xFF2A2154) : C.card,
                            borderRadius: BorderRadius.circular(9),
                            border: Border.all(
                              color: _type == i ? C.purple : C.border,
                              width: 0.8,
                            ),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(_icons[i],
                                  size: 14, color: _type == i ? C.purpleSoft : C.dim),
                              const SizedBox(width: 6),
                              Text(
                                _types[i][0],
                                style: TextStyle(
                                  fontSize: 12,
                                  color: _type == i ? C.purpleSoft : C.text,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(18, 16, 18, 8),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Text('补充要求（可选）',
                      style: TextStyle(fontSize: 11.5, color: C.dim.withOpacity(0.9))),
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 18),
                child: TextField(
                  controller: _extra,
                  minLines: 2,
                  maxLines: 4,
                  style: const TextStyle(fontSize: 13, height: 1.6, color: C.text),
                  decoration: InputDecoration(
                    hintText: '例如：古风、带仙气、适合修仙小说…',
                    hintStyle: const TextStyle(fontSize: 12, color: C.faint),
                    filled: true,
                    fillColor: const Color(0xFF14141E),
                    contentPadding: const EdgeInsets.all(11),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: const BorderSide(color: C.border, width: 0.7),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: const BorderSide(color: C.border, width: 0.7),
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(18, 14, 18, 12),
                child: SizedBox(
                  height: 44,
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    onPressed: _generate,
                    icon: const Icon(Icons.auto_awesome, size: 17),
                    label: const Text('生成名字',
                        style: TextStyle(fontSize: 14, color: Colors.white)),
                    style: ButtonStyle(
                      backgroundColor: MaterialStateProperty.all<Color>(C.purple),
                      foregroundColor: MaterialStateProperty.all<Color>(Colors.white),
                      shape: MaterialStateProperty.all(
                        RoundedRectangleBorder(borderRadius: BorderRadius.circular(11)),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
