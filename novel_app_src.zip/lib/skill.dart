import 'package:flutter/services.dart' show rootBundle;

/// 读取打包进 App 的技能包原文（novel-writer）
class SkillPack {
  static String? _cache;

  static Future<String> load() async {
    if (_cache != null) return _cache!;
    final skill = await rootBundle.loadString('assets/skills/novel-writer/SKILL.md');
    final tpl = await rootBundle.loadString('assets/skills/novel-writer/references/templates.md');
    _cache = '===== SKILL.md 原文开始 =====\n$skill\n===== SKILL.md 原文结束 =====\n\n'
        '===== references/templates.md 原文开始 =====\n$tpl\n===== references/templates.md 原文结束 =====';
    return _cache!;
  }
}
