import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:novel_app/main.dart';
import 'package:novel_app/models.dart';
import 'package:novel_app/store.dart';
import 'package:novel_app/theme.dart';

Future<void> _loadFonts() async {
  final cjk = File('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc').readAsBytesSync();
  for (final f in ['CJK', 'monospace', 'Roboto']) {
    await (FontLoader(f)..addFont(Future.value(ByteData.view(cjk.buffer)))).load();
  }
  final icon = File('/opt/f3/flutter/bin/cache/artifacts/material_fonts/MaterialIcons-Regular.otf').readAsBytesSync();
  await (FontLoader('MaterialIcons')..addFont(Future.value(ByteData.view(icon.buffer)))).load();
}

Widget _wrap(Widget home) {
  final t = buildDarkTheme();
  return MaterialApp(
    debugShowCheckedModeBanner: false,
    theme: t.copyWith(
      textTheme: t.textTheme.apply(fontFamily: 'CJK'),
      primaryTextTheme: t.primaryTextTheme.apply(fontFamily: 'CJK'),
      appBarTheme: t.appBarTheme.copyWith(
        titleTextStyle: (t.appBarTheme.titleTextStyle ?? const TextStyle())
            .copyWith(fontFamily: 'CJK', color: const Color(0xFFEDEDF5)),
      ),
    ),
    home: home,
  );
}

Future<void> _setup(WidgetTester tester) async {
  tester.view.physicalSize = const Size(1080, 2280);
  tester.view.devicePixelRatio = 3.0;
  addTearDown(tester.view.resetPhysicalSize);
  addTearDown(tester.view.resetDevicePixelRatio);

  SharedPreferences.setMockInitialValues(<String, Object>{});
  await AppState.I.init();
  final b = Novel(title: '灰烬纪元')
    ..world = '# 世界观\n近未来江城，异能者被登记管理。'
    ..characters = '# 人物库\n叶烬，24 岁，殡仪馆火化工。'
    ..summary = '第1章 雨夜：捡到一枚芯片';
  AppState.I.books = [b];
  AppState.I.currentId = b.id;
  AppState.I.goTab(0);
  await tester.pumpWidget(_wrap(const HomeShell()));
  await tester.pumpAndSettle();
}

Finder get _field => find.byType(TextField).last;

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  setUp(() async => _loadFonts());

  testWidgets('打 # 弹出资料浮层，列出三份', (tester) async {
    await _setup(tester);
    await tester.enterText(_field, '#');
    await tester.pumpAndSettle();

    expect(find.text('世界观.md'), findsOneWidget);
    expect(find.text('人物库.md'), findsOneWidget);
    expect(find.text('章节摘要.md'), findsOneWidget);
    expect(find.textContaining('继续输入可筛选'), findsOneWidget);
  });

  testWidgets('继续输入就筛选', (tester) async {
    await _setup(tester);
    await tester.enterText(_field, '#');
    await tester.pumpAndSettle();
    await tester.enterText(_field, '#人');
    await tester.pumpAndSettle();

    expect(find.text('人物库.md'), findsOneWidget);
    expect(find.text('世界观.md'), findsNothing);
    expect(find.text('章节摘要.md'), findsNothing);
  });

  testWidgets('筛不到时给提示，不是空白', (tester) async {
    await _setup(tester);
    await tester.enterText(_field, '#xyz');
    await tester.pumpAndSettle();
    expect(find.textContaining('没有匹配的资料'), findsOneWidget);
  });

  testWidgets('点一条，输入框变成 #文件名 并关掉浮层', (tester) async {
    await _setup(tester);
    await tester.enterText(_field, '#');
    await tester.pumpAndSettle();
    await tester.tap(find.text('人物库.md'));
    await tester.pumpAndSettle();

    final controller = tester.widget<TextField>(_field).controller!;
    expect(controller.text, '#人物库.md ');
    expect(find.text('继续输入可筛选'), findsNothing);
  });

  testWidgets('继续写正文（带空格）浮层就收起', (tester) async {
    await _setup(tester);
    await tester.enterText(_field, '#人物库.md 让叶烬和沈胭吵一架');
    await tester.pumpAndSettle();
    expect(find.text('继续输入可筛选'), findsNothing);
  });

  testWidgets('点「引用资料」按钮自动打 # 并弹出浮层，再点一次收起', (tester) async {
    await _setup(tester);

    await tester.tap(find.byTooltip('引用资料'));
    await tester.pumpAndSettle();

    final controller = tester.widget<TextField>(_field).controller!;
    expect(controller.text, '#');
    expect(find.textContaining('继续输入可筛选'), findsOneWidget);

    await tester.tap(find.byTooltip('引用资料'));
    await tester.pumpAndSettle();
    expect(find.textContaining('继续输入可筛选'), findsNothing);
  });

  testWidgets('正文里的 # 不触发浮层', (tester) async {
    await _setup(tester);
    await tester.enterText(_field, '第 3 章标题想用 #符号 开头');
    await tester.pumpAndSettle();
    expect(find.text('继续输入可筛选'), findsNothing);
  });
}
