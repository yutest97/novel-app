import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:novel_app/theme.dart';

void main() {
  test('Android 用 Material 3 的 FadeForwards，不是缩放也不是 iOS 横滑', () {
    final t = buildDarkTheme();
    expect(
      t.pageTransitionsTheme.builders[TargetPlatform.android],
      isA<FadeForwardsPageTransitionsBuilder>(),
    );
    expect(
      t.pageTransitionsTheme.builders[TargetPlatform.android],
      isNot(isA<ZoomPageTransitionsBuilder>()),
    );
    expect(
      t.pageTransitionsTheme.builders[TargetPlatform.android],
      isNot(isA<CupertinoPageTransitionsBuilder>()),
    );
  });

  test('iOS 仍是横滑，不跟着 Android 变', () {
    final t = buildDarkTheme();
    expect(
      t.pageTransitionsTheme.builders[TargetPlatform.iOS],
      isA<CupertinoPageTransitionsBuilder>(),
    );
  });
}
