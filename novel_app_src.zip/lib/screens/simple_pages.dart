import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../app_version.dart';
import '../backup_util.dart';
import '../book_storage.dart';
import '../builtin_skills.dart';
import '../skill_import.dart';
import '../sound.dart';
import '../store.dart';
import '../theme.dart';

export 'skill_page.dart' show SkillPage, SkillDetailPage;

/// 通用：占位页
class ComingPage extends StatelessWidget {
  const ComingPage({super.key, required this.title, required this.desc});

  final String title;
  final String desc;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(30),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.hourglass_empty, size: 36, color: C.faint),
              const SizedBox(height: 14),
              const Text('下一版开放', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
              const SizedBox(height: 10),
              Text(
                desc,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 12, height: 1.8, color: C.dim),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// 参数
class ParamsPage extends StatefulWidget {
  const ParamsPage({super.key});

  @override
  State<ParamsPage> createState() => _ParamsPageState();
}

class _ParamsPageState extends State<ParamsPage> {
  late double _temp;
  late bool _agent;
  late bool _auto;
  late final TextEditingController _window;
  late final TextEditingController _maxOut;
  late final TextEditingController _reserve;
  late final TextEditingController _prompt;

  @override
  void initState() {
    super.initState();
    final s = AppState.I.settings;
    _temp = s.temperature;
    _agent = s.agentEnabled;
    _auto = s.autoCompact;
    _window = TextEditingController(text: '${s.contextWindowK}');
    _maxOut = TextEditingController(text: '${s.maxOutputK}');
    _reserve = TextEditingController(text: '${s.outputReserveK}');
    _prompt = TextEditingController(text: s.customPrompt);
  }

  @override
  void dispose() {
    _window.dispose();
    _maxOut.dispose();
    _reserve.dispose();
    _prompt.dispose();
    super.dispose();
  }

  String get _tempHint {
    if (_temp <= 0.5) return '偏保守：用词稳、情节平，适合按大纲推进';
    if (_temp <= 1.0) return '均衡：稳中带点变化';
    return '偏发散：脑洞大、用词飘，可能跑题';
  }

  Future<void> _saveParams() async {
    final st = AppState.I;
    final messenger = ScaffoldMessenger.of(context);
    final w = int.tryParse(_window.text.trim()) ?? 200;
    final m = int.tryParse(_maxOut.text.trim()) ?? 32;
    final r = int.tryParse(_reserve.text.trim()) ?? 16;
    if (w < 8 || w > 2000) {
      messenger.showSnackBar(const SnackBar(content: Text('上下文窗口填 8 ~ 2000 之间的整数（单位 K）。')));
      return;
    }
    if (r >= w) {
      messenger.showSnackBar(const SnackBar(content: Text('输出预留要小于上下文窗口，否则没地方放对话。')));
      return;
    }
    final mm = m.clamp(1, 128);
    final rr = r.clamp(0, w - 1);
    await st.saveParams(
      autoCompact: _auto,
      contextWindowK: w,
      maxOutputK: mm,
      outputReserveK: rr,
    );
    if (!mounted) return;
    setState(() {
      _window.text = '$w';
      _maxOut.text = '$mm';
      _reserve.text = '$rr';
    });
    messenger.showSnackBar(const SnackBar(content: Text('参数已保存')));
  }

  Future<void> _savePrompt() async {
    final messenger = ScaffoldMessenger.of(context);
    await AppState.I.setCustomPrompt(_prompt.text);
    if (!mounted) return;
    messenger.showSnackBar(
      SnackBar(
        content: Text(_prompt.text.trim().isEmpty
            ? '已清空，恢复默认提示词'
            : '提示词已保存，下一轮对话生效'),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final st = AppState.I;
    return Scaffold(
      appBar: AppBar(title: const Text('参数')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 30),
        children: [
          _card(
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Text('温度', style: TextStyle(fontSize: 13)),
                    const Spacer(),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: const Color(0x337B5CFF),
                        borderRadius: BorderRadius.circular(7),
                      ),
                      child: Text(
                        _temp.toStringAsFixed(1),
                        style: const TextStyle(fontSize: 13, color: C.purpleSoft),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 6),
                const Text(
                  '控制 AI 回复的随机性：越低越稳定确定，越高越多随机。',
                  style: TextStyle(fontSize: 10.5, height: 1.6, color: C.dim),
                ),
                Slider(
                  value: _temp,
                  min: 0.0,
                  max: 1.4,
                  divisions: 14,
                  activeColor: C.purple,
                  onChanged: (v) => setState(() => _temp = v),
                  onChangeEnd: (v) => st.setTemperature(v),
                ),
                Text(_tempHint, style: const TextStyle(fontSize: 10.5, color: C.faint)),
              ],
            ),
          ),
          const SizedBox(height: 12),
          _card(
            Row(
              children: [
                const Icon(Icons.extension_outlined, size: 18, color: C.purpleSoft),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: const [
                      Text('Agent 模式（工具调用）', style: TextStyle(fontSize: 13)),
                      SizedBox(height: 3),
                      Text(
                        '开：AI 自己决定读哪份资料、查哪一章、搜哪本书；'
                        '关：资料一次性全塞进上下文。',
                        style: TextStyle(fontSize: 10.5, height: 1.5, color: C.dim),
                      ),
                    ],
                  ),
                ),
                Switch(
                  value: _agent,
                  activeColor: Colors.white,
                  activeTrackColor: C.purple,
                  inactiveThumbColor: const Color(0xFFBFC2D4),
                  inactiveTrackColor: C.cardHi,
                  onChanged: (v) async {
                    await st.setAgentEnabled(v);
                    if (mounted) setState(() => _agent = v);
                  },
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          _card(
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('上下文自动压缩',
                    style: TextStyle(fontSize: 13, fontWeight: FontWeight.w500)),
                const SizedBox(height: 6),
                const Text(
                  '对话超过设定预算时，从最早的对话开始折叠，只影响发给 AI 的上下文，'
                  '不删除聊天记录。折叠后 AI 需要前文时会用工具去读章节和资料。',
                  style: TextStyle(fontSize: 10.5, height: 1.6, color: C.dim),
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    const Text('启用自动压缩', style: TextStyle(fontSize: 12.5)),
                    const Spacer(),
                    Switch(
                      value: _auto,
                      activeColor: Colors.white,
                      activeTrackColor: C.purple,
                      inactiveThumbColor: const Color(0xFFBFC2D4),
                      inactiveTrackColor: C.cardHi,
                      onChanged: (v) => setState(() => _auto = v),
                    ),
                  ],
                ),
                _numberRow(_window, '上下文窗口（K）', '模型一次能装多少 token，常见 128 / 200'),
                _numberRow(_maxOut, '最大输出（K）· 仅 Anthropic', '只对 Anthropic 协议生效，OpenAI 不传这个参数'),
                _numberRow(_reserve, '输出预留（K）', '留给回答的额度，会从窗口里扣掉'),
                const SizedBox(height: 10),
                SizedBox(
                  height: 42,
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _saveParams,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: C.purple,
                      elevation: 0,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                    ),
                    child: const Text('保存参数',
                        style: TextStyle(fontSize: 13, color: Colors.white)),
                  ),
                ),
                const SizedBox(height: 6),
                const Text(
                  '注：token 是按字数估算的（中文约 1.6 字/token），用来裁剪历史；'
                  '不同模型的真实窗口以官方为准。',
                  style: TextStyle(fontSize: 9.5, height: 1.5, color: C.faint),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          _card(
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('自定义提示词',
                    style: TextStyle(fontSize: 13, fontWeight: FontWeight.w500)),
                const SizedBox(height: 6),
                const Text(
                  '自定义 AI 助手的行为，留空则使用默认的小说写作助手提示词。'
                  '填写后替换默认人设，但 [选项] / [章节] 的输出格式仍会追加在后面。',
                  style: TextStyle(fontSize: 10.5, height: 1.6, color: C.dim),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: _prompt,
                  minLines: 5,
                  maxLines: 10,
                  style: const TextStyle(fontSize: 12, height: 1.7, color: C.text),
                  decoration: InputDecoration(
                    hintText: '留空使用默认提示词。例如：你是一个专写都市爽文的写手，'
                        '每章必须有两次反转，主角绝不主动解释自己的能力……',
                    hintStyle: const TextStyle(fontSize: 11, height: 1.6, color: C.faint),
                    filled: true,
                    fillColor: C.surface,
                    contentPadding: const EdgeInsets.all(11),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(9),
                      borderSide: const BorderSide(color: C.border, width: 0.7),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(9),
                      borderSide: const BorderSide(color: C.border, width: 0.7),
                    ),
                  ),
                ),
                const SizedBox(height: 10),
                SizedBox(
                  height: 42,
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _savePrompt,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: C.purple,
                      elevation: 0,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                    ),
                    child: const Text('保存提示词',
                        style: TextStyle(fontSize: 13, color: Colors.white)),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _card(Widget child) => Container(
        padding: const EdgeInsets.fromLTRB(14, 13, 14, 13),
        decoration: BoxDecoration(
          color: C.card,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: C.border, width: 0.6),
        ),
        child: child,
      );

  Widget _numberRow(TextEditingController c, String label, String tip) {
    return Padding(
      padding: const EdgeInsets.only(top: 8),
      child: Row(
        children: [
          Expanded(
            child: Text(label, style: const TextStyle(fontSize: 12.5, color: C.text)),
          ),
          Tooltip(
            message: tip,
            triggerMode: TooltipTriggerMode.tap,
            child: const Icon(Icons.help_outline, size: 14, color: C.faint),
          ),
          const SizedBox(width: 8),
          SizedBox(
            width: 86,
            height: 34,
            child: TextField(
              controller: c,
              keyboardType: TextInputType.number,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 13, color: C.text),
              decoration: InputDecoration(
                filled: true,
                fillColor: C.surface,
                isDense: true,
                contentPadding: const EdgeInsets.symmetric(vertical: 8),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: const BorderSide(color: C.border, width: 0.7),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: const BorderSide(color: C.border, width: 0.7),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// 主题
class ThemePage extends StatefulWidget {
  const ThemePage({super.key});

  @override
  State<ThemePage> createState() => _ThemePageState();
}

class _ThemePageState extends State<ThemePage> {
  late double _chatFont;
  late double _editorFont;
  late bool _sound;

  @override
  void initState() {
    super.initState();
    final s = AppState.I.settings;
    _chatFont = s.chatFontSize;
    _editorFont = s.editorFontSize;
    _sound = s.soundEnabled;
  }

  @override
  Widget build(BuildContext context) {
    final st = AppState.I;
    final mode = st.settings.themeMode;
    return Scaffold(
      appBar: AppBar(title: const Text('主题')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 30),
        children: [
          const Text('外观', style: TextStyle(fontSize: 11, color: C.faint)),
          const SizedBox(height: 8),
          _card(
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('主题模式', style: TextStyle(fontSize: 12.5, color: C.dim)),
                const SizedBox(height: 9),
                Row(
                  children: [
                    _modeChip('跟随系统', mode == 'system',
                        () => st.setThemeMode('system')),
                    const SizedBox(width: 8),
                    _modeChip('深色', mode == 'dark', () => st.setThemeMode('dark')),
                    const SizedBox(width: 8),
                    _modeChip('浅色', false, _explainLight),
                  ],
                ),
                const SizedBox(height: 10),
                const Text(
                  '现在整套界面按深色设计（卡片、边框、代码块都是深色调）。'
                  '浅色需要把 30 多个页面的配色重做一遍，这一版先不开放，避免白底白字。',
                  style: TextStyle(fontSize: 10, height: 1.6, color: C.faint),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          const Text('字体', style: TextStyle(fontSize: 11, color: C.faint)),
          const SizedBox(height: 8),
          _card(
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _fontRow('聊天字体', _chatFont, (v) => setState(() => _chatFont = v),
                    (v) => st.setChatFontSize(v)),
                const Divider(height: 22, color: C.border),
                _fontRow('编辑器字体', _editorFont, (v) => setState(() => _editorFont = v),
                    (v) => st.setEditorFontSize(v)),
                const SizedBox(height: 4),
                const Text('只改正文阅读和编辑的字号，菜单按钮不受影响。',
                    style: TextStyle(fontSize: 10, color: C.faint)),
              ],
            ),
          ),
          const SizedBox(height: 16),
          const Text('提示音', style: TextStyle(fontSize: 11, color: C.faint)),
          const SizedBox(height: 8),
          _card(
            Column(
              children: [
                Row(
                  children: [
                    const Icon(Icons.volume_up_outlined, size: 18, color: C.purpleSoft),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: const [
                          Text('完成提示音', style: TextStyle(fontSize: 12.5)),
                          SizedBox(height: 2),
                          Text('AI 写完回复、或弹出提问/确认窗口时响一声',
                              style: TextStyle(fontSize: 10, color: C.faint)),
                        ],
                      ),
                    ),
                    Switch(
                      value: _sound,
                      activeColor: Colors.white,
                      activeTrackColor: C.purple,
                      inactiveThumbColor: const Color(0xFFBFC2D4),
                      inactiveTrackColor: C.cardHi,
                      onChanged: (v) async {
                        await st.setSoundEnabled(v);
                        if (mounted) setState(() => _sound = v);
                      },
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    const Icon(Icons.notifications_active_outlined,
                        size: 16, color: C.dim),
                    const SizedBox(width: 8),
                    const Text('系统提示音', style: TextStyle(fontSize: 12)),
                    const Spacer(),
                    TextButton.icon(
                      onPressed: () async {
                        final messenger = ScaffoldMessenger.of(context);
                        final ok = await playDoneSound();
                        if (!ok && mounted) {
                          messenger.showSnackBar(
                            const SnackBar(
                              content: Text('原生提示音不可用，已退回系统点击音；'
                                  '还听不到就去系统设置打开「触摸提示音」并调大通知音量。'),
                              duration: Duration(seconds: 5),
                            ),
                          );
                        }
                      },
                      icon: const Icon(Icons.play_arrow, size: 16, color: C.purpleSoft),
                      label: const Text('试听',
                          style: TextStyle(fontSize: 11.5, color: C.purpleSoft)),
                    ),
                  ],
                ),
                const Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    '用系统通知音轨播放短提示音，跟随「通知音量」，静音模式不响；'
                    '不打包音频文件，不占体积。',
                    style: TextStyle(fontSize: 9.5, height: 1.5, color: C.faint),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _explainLight() {
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: C.surface,
        title: const Text('浅色主题还没做', style: TextStyle(fontSize: 15)),
        content: const Text(
          '整套界面用的是写死的深色配色：卡片、边框、代码块、弹窗都是深色。'
          '只切一个开关会出现白底白字、看不清按钮。\n\n'
          '要做浅色，得把每个页面的颜色抽成主题变量再重排一遍，'
          '这一步单独排期，不混在参数里糊弄。',
          style: TextStyle(fontSize: 12, height: 1.7),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('知道了', style: TextStyle(fontSize: 12.5, color: C.purpleSoft)),
          ),
        ],
      ),
    );
  }

  Widget _card(Widget child) => Container(
        padding: const EdgeInsets.fromLTRB(14, 13, 14, 13),
        decoration: BoxDecoration(
          color: C.card,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: C.border, width: 0.6),
        ),
        child: child,
      );

  Widget _modeChip(String label, bool on, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(8),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: on ? C.purple : C.surface,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: on ? C.purple : C.border, width: 0.6),
        ),
        child: Text(
          label,
          style: TextStyle(fontSize: 12, color: on ? Colors.white : C.dim),
        ),
      ),
    );
  }

  Widget _fontRow(
    String label,
    double value,
    ValueChanged<double> onChanged,
    ValueChanged<double> onDone,
  ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Text(label, style: const TextStyle(fontSize: 12.5)),
            const Spacer(),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 3),
              decoration: BoxDecoration(
                color: const Color(0x337B5CFF),
                borderRadius: BorderRadius.circular(6),
              ),
              child: Text('${value.round()}',
                  style: const TextStyle(fontSize: 12, color: C.purpleSoft)),
            ),
          ],
        ),
        Slider(
          value: value,
          min: 12,
          max: 20,
          divisions: 8,
          activeColor: C.purple,
          onChanged: onChanged,
          onChangeEnd: onDone,
        ),
      ],
    );
  }
}

/// 数据
class DataPage extends StatelessWidget {
  const DataPage({super.key});

  @override
  Widget build(BuildContext context) {
    final st = AppState.I;
    final skills = kBuiltinSkills.length + st.settings.importedSkills.length;
    final notes = st.books.fold<int>(0, (n, b) => n + b.notes.length);
    final bytes = st.storageBytes;

    return Scaffold(
      appBar: AppBar(title: const Text('数据')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 30),
        children: [
          Container(
            padding: const EdgeInsets.fromLTRB(14, 13, 14, 14),
            decoration: BoxDecoration(
              color: C.card,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: C.border, width: 0.6),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      width: 30,
                      height: 30,
                      decoration: BoxDecoration(
                        color: const Color(0x337B5CFF),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: const Icon(Icons.storage, size: 15, color: C.purpleSoft),
                    ),
                    const SizedBox(width: 9),
                    const Text('数据管理', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w500)),
                  ],
                ),
                const SizedBox(height: 10),
                Text(
                  '${st.books.length} 部作品 · $skills 个 Skill · $notes 条备忘录 · 共占用 ${_fmtBytes(bytes)}',
                  style: const TextStyle(fontSize: 11.5, height: 1.6, color: C.dim),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.fromLTRB(14, 13, 14, 14),
            decoration: BoxDecoration(
              color: C.card,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: C.border, width: 0.6),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('存储位置', style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w500)),
                const SizedBox(height: 6),
                Text(
                  st.storageExternal
                      ? '书稿存在你选的外部目录里（系统文档授权），设置仍在应用内。'
                          '卸载 App 不会删这个目录，但重建系统或拔掉 SD 卡会读不到。'
                      : '书稿存在 App 私有目录里（/data/data/包名/shared_prefs）。'
                          '想放到自己能看到的文件夹，点下面的「更改」。',
                  style: const TextStyle(fontSize: 10.5, height: 1.65, color: C.dim),
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    const Icon(Icons.folder_outlined, size: 16, color: C.purpleSoft),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(st.storageLabel, style: const TextStyle(fontSize: 12)),
                          const SizedBox(height: 2),
                          Text(
                            st.storageExternal ? '外部目录（SAF 授权）' : '应用内私有目录',
                            style: const TextStyle(fontSize: 10, color: C.faint),
                          ),
                        ],
                      ),
                    ),
                    TextButton(
                      onPressed: () => _changeStorage(context),
                      child: const Text('更改',
                          style: TextStyle(fontSize: 12, color: C.purpleSoft)),
                    ),
                  ],
                ),
                if (st.storageNote.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 6),
                    child: Text(
                      st.storageNote,
                      style: const TextStyle(fontSize: 10, height: 1.5, color: Color(0xFFE0A05C)),
                    ),
                  ),
                if (st.storageExternal)
                  Align(
                    alignment: Alignment.centerLeft,
                    child: TextButton(
                      onPressed: () => _backToInternal(context),
                      child: const Text('改回应用内存储',
                          style: TextStyle(fontSize: 11.5, color: C.dim)),
                    ),
                  ),
                const Divider(height: 18, color: C.border),
                _locRow(Icons.auto_awesome_outlined, 'Skill 与配置',
                    '内置技能 + ${st.settings.importedSkills.length} 个导入技能'),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.fromLTRB(14, 13, 14, 14),
            decoration: BoxDecoration(
              color: C.card,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: C.border, width: 0.6),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: const [
                    Icon(Icons.backup_outlined, size: 16, color: C.purpleSoft),
                    SizedBox(width: 8),
                    Text('备份与恢复', style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w500)),
                  ],
                ),
                const SizedBox(height: 6),
                const Text(
                  '备份是一个 JSON 文件，包含全部书稿、章节、对话、备忘录和设置。'
                  '保存时选坚果云 / OneDrive 的同步文件夹，它会自动同步；'
                  '文件名带日期，不会覆盖旧备份。',
                  style: TextStyle(fontSize: 10.5, height: 1.65, color: C.dim),
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Expanded(
                      child: SizedBox(
                        height: 40,
                        child: OutlinedButton.icon(
                          onPressed: () => _exportFile(context),
                          icon: const Icon(Icons.save_alt, size: 15, color: C.purpleSoft),
                          label: const Text('保存为文件',
                              style: TextStyle(fontSize: 12, color: C.purpleSoft)),
                          style: OutlinedButton.styleFrom(
                            side: const BorderSide(color: C.border),
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(9)),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: SizedBox(
                        height: 40,
                        child: OutlinedButton.icon(
                          onPressed: () => _import(context),
                          icon: const Icon(Icons.restore, size: 15, color: C.text),
                          label: const Text('从备份恢复',
                              style: TextStyle(fontSize: 12, color: C.text)),
                          style: OutlinedButton.styleFrom(
                            side: const BorderSide(color: C.border),
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(9)),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                Align(
                  alignment: Alignment.centerLeft,
                  child: TextButton.icon(
                    onPressed: () => _exportClipboard(context),
                    icon: const Icon(Icons.copy_all, size: 14, color: C.dim),
                    label: const Text('复制备份到剪贴板',
                        style: TextStyle(fontSize: 11, color: C.dim)),
                    style: TextButton.styleFrom(
                      padding: const EdgeInsets.symmetric(horizontal: 4),
                      minimumSize: const Size(0, 30),
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.fromLTRB(14, 13, 14, 14),
            decoration: BoxDecoration(
              color: const Color(0xFF2A1A1A),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: const Color(0xFF5A2E2E), width: 0.7),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: const [
                    Icon(Icons.warning_amber_rounded, size: 16, color: Color(0xFFE0A05C)),
                    SizedBox(width: 8),
                    Text('危险操作', style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w500)),
                  ],
                ),
                const SizedBox(height: 6),
                const Text(
                  '清除聊天记录、导入的 Skill 和自定义参数（温度、提示词、字号、同步配置）。'
                  '作品、章节、备忘录和 API Key 会保留。',
                  style: TextStyle(fontSize: 10.5, height: 1.65, color: Color(0xFFD8B9B0)),
                ),
                const SizedBox(height: 10),
                SizedBox(
                  height: 38,
                  child: OutlinedButton.icon(
                    onPressed: () => _reset(context),
                    icon: const Icon(Icons.restart_alt, size: 15, color: Color(0xFFE0736E)),
                    label: const Text('重置数据',
                        style: TextStyle(fontSize: 12, color: Color(0xFFE0736E))),
                    style: OutlinedButton.styleFrom(
                      side: const BorderSide(color: Color(0xFF7A3A3A)),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(9)),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _locRow(IconData icon, String title, String sub) {
    return Row(
      children: [
        Icon(icon, size: 16, color: C.dim),
        const SizedBox(width: 10),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: const TextStyle(fontSize: 12)),
              const SizedBox(height: 2),
              Text(sub, style: const TextStyle(fontSize: 10, color: C.faint)),
            ],
          ),
        ),
      ],
    );
  }

  Future<void> _changeStorage(BuildContext context) async {
    final messenger = ScaffoldMessenger.of(context);
    final st = AppState.I;
    SafDirectory? dir;
    try {
      dir = await SafStorage.pickDirectory();
    } catch (e) {
      messenger.showSnackBar(SnackBar(content: Text('打不开目录选择器：$e')));
      return;
    }
    if (dir == null) return;

    if (st.books.isEmpty) {
      messenger.showSnackBar(const SnackBar(content: Text('还没有书可以迁移。')));
      return;
    }
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: C.surface,
        title: const Text('把书稿放到这个目录？'),
        content: Text(
          '目录：${dir!.name}\n\n'
          '现在 ${st.books.length} 本书会复制过去，之后新写的章节也存那里。'
          '应用内会保留一份完整备份，随时可以改回来；外部目录里的文件不会自动删除。\n\n'
          '如果这个目录在网盘同步范围内，书稿会跟着同步，但别在两台设备上同时改同一本书。',
          style: const TextStyle(fontSize: 12, height: 1.7),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('取消', style: TextStyle(color: C.dim)),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('迁移'),
          ),
        ],
      ),
    );
    if (ok != true) return;

    try {
      await st.migrateToExternal(dir);
      messenger.showSnackBar(SnackBar(content: Text(st.storageNote)));
    } catch (e) {
      messenger.showSnackBar(SnackBar(content: Text('迁移失败，数据没动：$e')));
    }
  }

  Future<void> _backToInternal(BuildContext context) async {
    final messenger = ScaffoldMessenger.of(context);
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: C.surface,
        title: const Text('改回应用内存储？'),
        content: const Text(
          '当前书稿会复制回应用内，外部目录里的文件保留不动。'
          '如果外部目录里的内容比现在新，先确认再切。',
          style: TextStyle(fontSize: 12, height: 1.7),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('取消', style: TextStyle(color: C.dim)),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('改回'),
          ),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await AppState.I.migrateToInternal();
      messenger.showSnackBar(SnackBar(content: Text(AppState.I.storageNote)));
    } catch (e) {
      messenger.showSnackBar(SnackBar(content: Text('切换失败：$e')));
    }
  }

  Future<void> _exportFile(BuildContext context) async {
    final messenger = ScaffoldMessenger.of(context);
    final json = AppState.I.exportBackupJson();
    final name = backupFileName();
    try {
      final path = await saveBackupFile(name, json);
      if (path == null) {
        messenger.showSnackBar(const SnackBar(content: Text('已取消，没有保存')));
        return;
      }
      messenger.showSnackBar(
        SnackBar(
          content: Text('已保存 $name（${_fmtBytes(json.length)}）'),
          duration: const Duration(seconds: 5),
        ),
      );
    } on SkillPickException catch (e) {
      messenger.showSnackBar(
        SnackBar(
          content: Text('${e.message}。可以先复制到剪贴板。'),
          duration: const Duration(seconds: 8),
          action: SnackBarAction(
            label: '复制',
            onPressed: () => Clipboard.setData(ClipboardData(text: json)),
          ),
        ),
      );
    } catch (e) {
      messenger.showSnackBar(SnackBar(content: Text('保存失败：$e')));
    }
  }

  Future<void> _exportClipboard(BuildContext context) async {
    final messenger = ScaffoldMessenger.of(context);
    final st = AppState.I;
    final json = st.exportBackupJson();
    await Clipboard.setData(ClipboardData(text: json));
    messenger.showSnackBar(
      SnackBar(
        content: Text('已复制备份（${_fmtBytes(json.length)}），粘贴到备忘录或网盘保存'),
        duration: const Duration(seconds: 5),
      ),
    );
  }

  Future<void> _import(BuildContext context) async {
    final messenger = ScaffoldMessenger.of(context);
    final st = AppState.I;
    final ctrl = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: C.surface,
        title: const Text('从备份恢复', style: TextStyle(fontSize: 15)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              '把之前导出的 JSON 粘贴进来。恢复会用备份替换本机全部数据，'
              '当前数据不保留。',
              style: TextStyle(fontSize: 11, height: 1.6, color: C.dim),
            ),
            const SizedBox(height: 9),
            TextField(
              controller: ctrl,
              minLines: 4,
              maxLines: 8,
              style: const TextStyle(fontSize: 11, color: C.text),
              decoration: InputDecoration(
                hintText: '{"app":"novel_app", ...}',
                hintStyle: const TextStyle(fontSize: 11, color: C.faint),
                filled: true,
                fillColor: C.card,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(9),
                  borderSide: const BorderSide(color: C.border, width: 0.7),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(9),
                  borderSide: const BorderSide(color: C.border, width: 0.7),
                ),
              ),
            ),
            const SizedBox(height: 6),
            Wrap(
              spacing: 4,
              children: [
                TextButton.icon(
                  onPressed: () async {
                    final data = await Clipboard.getData('text/plain');
                    if (data?.text != null) ctrl.text = data!.text!;
                  },
                  icon: const Icon(Icons.content_paste, size: 14, color: C.purpleSoft),
                  label: const Text('从剪贴板粘贴',
                      style: TextStyle(fontSize: 11, color: C.purpleSoft)),
                ),
                TextButton.icon(
                  onPressed: () async {
                    try {
                      final f = await pickBackupFile();
                      if (f != null) ctrl.text = f.content;
                    } on SkillPickException catch (e) {
                      messenger.showSnackBar(SnackBar(content: Text(e.message)));
                    }
                  },
                  icon: const Icon(Icons.folder_open, size: 14, color: C.purpleSoft),
                  label: const Text('选择备份文件',
                      style: TextStyle(fontSize: 11, color: C.purpleSoft)),
                ),
              ],
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('取消', style: TextStyle(color: C.dim)),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('恢复'),
          ),
        ],
      ),
    );
    if (ok != true) return;
    try {
      final msg = await st.importBackupJson(ctrl.text);
      messenger.showSnackBar(SnackBar(content: Text(msg)));
    } catch (e) {
      messenger.showSnackBar(SnackBar(content: Text('恢复失败：$e')));
    }
  }

  Future<void> _reset(BuildContext context) async {
    final messenger = ScaffoldMessenger.of(context);
    final st = AppState.I;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: C.surface,
        title: const Text('重置数据？'),
        content: const Text(
          '会清空所有聊天记录、导入的 Skill、自定义参数和同步配置。\n'
          '作品、章节、备忘录和 API Key 不受影响，但清掉的聊天记录不能恢复。',
          style: TextStyle(fontSize: 12, height: 1.7),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('算了', style: TextStyle(color: C.dim)),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: ButtonStyle(
              backgroundColor: MaterialStateProperty.all<Color>(const Color(0xFFD9534F)),
            ),
            child: const Text('重置'),
          ),
        ],
      ),
    );
    if (ok != true) return;
    await st.resetUserData();
    messenger.showSnackBar(const SnackBar(content: Text('已重置：聊天记录和配置已清空')));
  }
}

String _fmtBytes(int bytes) {
  if (bytes < 1024) return '$bytes B';
  if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB';
  return '${(bytes / 1024 / 1024).toStringAsFixed(1)} MB';
}

/// 关于
class AboutPage extends StatelessWidget {
  const AboutPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('关于')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 22, 20, 30),
        children: [
          Center(
            child: Container(
              width: 72,
              height: 72,
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFF9B7BFF), Color(0xFF5B3FE0)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(20),
              ),
              child: const Icon(Icons.auto_awesome, color: Colors.white, size: 32),
            ),
          ),
          const SizedBox(height: 14),
          const Center(
            child: Text('AI 写小说',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
          ),
          const SizedBox(height: 6),
          Center(
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
              decoration: BoxDecoration(
                color: C.card,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: C.border, width: 0.6),
              ),
              child: const Text('版本 $kAppVersion',
                  style: TextStyle(fontSize: 11, color: C.dim)),
            ),
          ),
          const SizedBox(height: 8),
          const Center(
            child: Text('你的 AI 小说写作助手', style: TextStyle(fontSize: 11.5, color: C.faint)),
          ),
          const SizedBox(height: 24),
          _group(context, [
            _row(context, Icons.menu_book_outlined, '使用教程', '从填 Key 到写出第一章',
                () => Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => const GuidePage()),
                    )),
            _row(context, Icons.monitor_heart_outlined, '诊断信息', '版本、模型、存储与最近一次错误',
                () => Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => const DiagnosticsPage()),
                    )),
          ]),
          const SizedBox(height: 16),
          _group(context, [
            _row(context, Icons.update, '检查更新', '当前版本 $kAppVersion', () {
              showDialog<void>(
                context: context,
                builder: (ctx) => AlertDialog(
                  backgroundColor: C.surface,
                  title: const Text('检查更新', style: TextStyle(fontSize: 15)),
                  content: const Text(
                    '当前是最新安装的版本 $kAppVersion。\n\n'
                    'App 内暂未接更新源：更新包通过构建流水线生成，'
                    '装上新的安装包后这里会跟着变。没有联网检查版本，也不会弹更新广告。',
                    style: TextStyle(fontSize: 12, height: 1.75),
                  ),
                  actions: [
                    TextButton(
                      onPressed: () => Navigator.pop(ctx),
                      child: const Text('知道了', style: TextStyle(color: C.purpleSoft)),
                    ),
                  ],
                ),
              );
            }),
          ]),
          const SizedBox(height: 20),
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: C.card, borderRadius: BorderRadius.circular(12)),
            child: const Text(
              '一个手机上的写小说助手：AI 一步步问你设定，然后按章写出来，'
              '人物库和世界观会自动维护，防止前后串戏。\n\n'
              '所有内容存在手机本地，API Key 也只存在本地，不上传任何服务器。'
              '开启云同步时，备份才会发到你自己的 WebDAV。',
              style: TextStyle(fontSize: 11.5, height: 1.8, color: Color(0xFFCFCFDE)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _group(BuildContext context, List<Widget> children) {
    return Container(
      decoration: BoxDecoration(
        color: C.card,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: C.border, width: 0.6),
      ),
      child: Column(
        children: [
          for (var i = 0; i < children.length; i++) ...[
            if (i > 0) const Divider(height: 1, indent: 48, endIndent: 12),
            children[i],
          ],
        ],
      ),
    );
  }

  Widget _row(BuildContext context, IconData icon, String title, String sub, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(12, 11, 10, 11),
        child: Row(
          children: [
            Icon(icon, size: 17, color: C.purpleSoft),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(fontSize: 12.5)),
                  const SizedBox(height: 2),
                  Text(sub, style: const TextStyle(fontSize: 10, color: C.faint)),
                ],
              ),
            ),
            const Icon(Icons.chevron_right, size: 16, color: C.faint),
          ],
        ),
      ),
    );
  }
}

/// 诊断信息
class DiagnosticsPage extends StatelessWidget {
  const DiagnosticsPage({super.key});

  @override
  Widget build(BuildContext context) {
    final st = AppState.I;
    final s = st.settings;
    final key = s.apiKey.trim();
    final masked = key.isEmpty
        ? '未填写'
        : '${key.substring(0, key.length > 6 ? 6 : key.length)}…（${key.length} 位）';
    final rows = <List<String>>[
      ['版本', kAppVersion],
      ['模型', s.model],
      ['接口地址', s.baseUrl],
      ['协议', s.format],
      ['API Key', masked],
      ['Agent 模式', s.agentEnabled ? '开' : '关'],
      ['上下文窗口', '${s.contextWindowK}K（预留 ${s.outputReserveK}K）'],
      ['作品', '${st.books.length} 部 / ${st.books.fold<int>(0, (n, b) => n + b.chapters.length)} 章'],
      ['存储占用', _fmtBytes(st.storageBytes)],
      [
        '联网搜索',
        s.searchEnabled
            ? '开 · ${s.searchProvider == 'bocha' ? '博查' : '必应'} · ${s.searchCount} 条'
            : '关',
      ],
      ['WebDAV', s.webdavUrl.isEmpty ? '未配置' : s.webdavUrl],
      ['最近错误', _lastError(st)],
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('诊断信息')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
        children: [
          Container(
            decoration: BoxDecoration(
              color: C.card,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: C.border, width: 0.6),
            ),
            child: Column(
              children: [
                for (var i = 0; i < rows.length; i++) ...[
                  if (i > 0) const Divider(height: 1, indent: 14, endIndent: 14),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(14, 10, 14, 10),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(
                          width: 76,
                          child: Text(rows[i][0],
                              style: const TextStyle(fontSize: 11.5, color: C.dim)),
                        ),
                        Expanded(
                          child: SelectableText(
                            rows[i][1],
                            style: const TextStyle(
                                fontSize: 11.5, height: 1.5, color: C.text),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ],
            ),
          ),
          const SizedBox(height: 10),
          const Text(
            '这份信息用于排查问题，不含密码。可以把这段内容复制给开发者。',
            style: TextStyle(fontSize: 10, height: 1.6, color: C.faint),
          ),
        ],
      ),
    );
  }

  String _lastError(AppState st) {
    final e = st.errorText;
    if (e == null || e.trim().isEmpty) return '无';
    return e.length > 80 ? '${e.substring(0, 80)}…' : e;
  }
}

/// 使用教程
class GuidePage extends StatelessWidget {
  const GuidePage({super.key});

  @override
  Widget build(BuildContext context) {
    const items = [
      ['1. 先填 Key', '设置 → AI 提供商 → 选智谱 GLM-4-Flash（免费）→ 注册拿 Key 粘进去 → 测试连接。'],
      ['2. 新书启航', '对话页点「新书启航」，AI 会问题材、主角、金手指，全点选项就行。'],
      ['3. 一章一章写', '它写完整章会先给你看，底部出现「保存这一章」，点了才存。'],
      ['4. 同步资料', '存完会问要不要更新人物库/世界观/摘要，选「同步」它就不会忘设定。'],
      ['5. 书架', '「小说」页能开多本、改名、删除，点开任意一本继续写。'],
      ['6. 拿出去', '设置 → 数据 → 复制当前书全文，粘到备忘录或微信里。'],
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('使用教程')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(18, 10, 18, 30),
        children: [
          for (final it in items)
            Padding(
              padding: const EdgeInsets.only(bottom: 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(it[0], style: const TextStyle(fontSize: 13.5, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 5),
                  Text(it[1], style: const TextStyle(fontSize: 12, height: 1.8, color: C.dim)),
                ],
              ),
            ),
        ],
      ),
    );
  }
}
