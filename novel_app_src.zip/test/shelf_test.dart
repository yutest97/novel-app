import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:novel_app/book_text.dart';
import 'package:novel_app/main.dart';
import 'package:novel_app/models.dart';
import 'package:novel_app/store.dart';
import 'package:novel_app/theme.dart';

Future<void> _loadFonts() async {
  final cjk = File('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc').readAsBytesSync();
  for (final f in ['CJK', 'monospace', 'Roboto']) {
    await (FontLoader(f)..addFont(Future.value(ByteData.view(cjk.buffer)))).load();
  }
  final icon =
      File('/opt/f3/flutter/bin/cache/artifacts/material_fonts/MaterialIcons-Regular.otf')
          .readAsBytesSync();
  await (FontLoader('MaterialIcons')..addFont(Future.value(ByteData.view(icon.buffer)))).load();
}

Widget _wrap(Widget home) {
  final t = buildDarkTheme();
  return MaterialApp(
    debugShowCheckedModeBanner: false,
    theme: t.copyWith(
      textTheme: t.textTheme.apply(fontFamily: 'CJK'),
      primaryTextTheme: t.primaryTextTheme.apply(fontFamily: 'CJK'),
      appBarTheme: t.appBarTheme.copyWith(
        titleTextStyle: (t.appBarTheme.titleTextStyle ?? const TextStyle())
            .copyWith(fontFamily: 'CJK', color: const Color(0xFFEDEDF5)),
      ),
    ),
    home: home,
  );
}

Novel _book() => Novel(title: '灰烬纪元')
  ..chapters = [
    Chapter(title: '第一章 火', content: '火从地底烧上来，' * 20),
  ];

Future<void> _setup(WidgetTester tester, {Novel? book}) async {
  tester.view.physicalSize = const Size(1080, 2400);
  tester.view.devicePixelRatio = 3.0;
  addTearDown(tester.view.resetPhysicalSize);
  addTearDown(tester.view.resetDevicePixelRatio);

  SharedPreferences.setMockInitialValues(<String, Object>{});
  await AppState.I.init();
  final b = book ?? _book();
  AppState.I.books = [b];
  AppState.I.currentId = b.id;
  AppState.I.settings
    ..baseUrl = 'http://127.0.0.1:9/v1'
    ..apiKey = ''
    ..model = 'm'
    ..webdavUrl = '';
  AppState.I.goTab(1);
  await tester.pumpWidget(_wrap(const HomeShell()));
  await tester.pumpAndSettle();
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  setUp(() async => _loadFonts());

  testWidgets('书架右上角是同步 / 新建 / 更多 三个按钮', (tester) async {
    await _setup(tester);
    expect(find.byTooltip('同步'), findsOneWidget);
    expect(find.byTooltip('新建'), findsOneWidget);
    expect(find.byTooltip('更多'), findsOneWidget);
    expect(find.text('我的小说'), findsOneWidget);
  });

  testWidgets('同步浮层：没配置时提示去设置', (tester) async {
    await _setup(tester);
    await tester.tap(find.byTooltip('同步'));
    await tester.pumpAndSettle();
    expect(find.text('通过 WebDAV 云端互传'), findsOneWidget);
    expect(find.text('未配置同步，点此前往设置'), findsOneWidget);
    expect(find.text('同步设置...'), findsOneWidget);
  });

  testWidgets('同步浮层：配置过后显示主机名和立即备份', (tester) async {
    await _setup(tester);
    AppState.I.settings.webdavUrl = 'https://dav.jianguoyun.com/dav/';
    await tester.tap(find.byTooltip('同步'));
    await tester.pumpAndSettle();
    expect(find.text('已配置：dav.jianguoyun.com'), findsOneWidget);
    expect(find.text('立即备份到云端'), findsOneWidget);
  });

  testWidgets('新建要输入书名，建完跳到对话并显示在书架', (tester) async {
    await _setup(tester);
    await tester.tap(find.byTooltip('新建'));
    await tester.pumpAndSettle();
    expect(find.text('新建小说'), findsOneWidget);
    expect(find.text('将创建：应用内存储/小说名称/'), findsOneWidget);

    await tester.enterText(find.widgetWithText(TextField, '输入小说名称'), '长夜将至');
    await tester.pump();
    expect(find.text('将创建：应用内存储/长夜将至/'), findsOneWidget);

    await tester.tap(find.text('创建'));
    await tester.pumpAndSettle();

    expect(AppState.I.books.any((b) => b.title == '长夜将至'), isTrue);
    expect(AppState.I.novel.title, '长夜将至');
    expect(AppState.I.tabIndex, 0); // 跳到对话
  });

  testWidgets('名字空着时创建按钮不可点', (tester) async {
    await _setup(tester);
    await tester.tap(find.byTooltip('新建'));
    await tester.pumpAndSettle();
    final btn = tester.widget<ElevatedButton>(find.widgetWithText(ElevatedButton, '创建'));
    expect(btn.onPressed, isNull);
  });

  testWidgets('更多菜单里有导入 / 导出 / 回收站', (tester) async {
    await _setup(tester);
    await tester.tap(find.byTooltip('更多'));
    await tester.pumpAndSettle();
    expect(find.text('导入'), findsOneWidget);
    expect(find.text('导出'), findsOneWidget);
    expect(find.text('回收站'), findsOneWidget);

    await tester.tap(find.text('回收站'));
    await tester.pumpAndSettle();
    expect(find.text('回收站是空的'), findsOneWidget);
  });

  testWidgets('删除进回收站，能恢复出来', (tester) async {
    await _setup(tester);
    final id = AppState.I.novel.id;
    await AppState.I.deleteBook(id);
    await tester.pumpAndSettle();

    expect(AppState.I.visibleBooks, isEmpty);
    expect(AppState.I.trashedBooks.length, 1);
    expect(find.text('还没有小说，点右上角新建'), findsOneWidget);

    // 打开回收站恢复
    await tester.tap(find.byTooltip('更多'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('回收站'));
    await tester.pumpAndSettle();
    expect(find.text('灰烬纪元'), findsOneWidget);
    await tester.tap(find.text('恢复'));
    await tester.pumpAndSettle();

    expect(AppState.I.trashedBooks, isEmpty);
    expect(AppState.I.visibleBooks.length, 1);
    expect(AppState.I.novel.id, id);
  });

  testWidgets('点书卡进详情页，能从详情页回到对话', (tester) async {
    await _setup(tester);
    await tester.tap(find.text('灰烬纪元'));
    await tester.pumpAndSettle();
    expect(find.text('继续对话'), findsOneWidget);
    expect(find.text('小说资料'), findsOneWidget);
    expect(find.text('章节内容'), findsOneWidget);

    await tester.tap(find.text('继续对话'));
    await tester.pumpAndSettle();
    expect(AppState.I.tabIndex, 0);
  });

  testWidgets('书的菜单是重命名 / 导出 / 移至回收站', (tester) async {
    await _setup(tester);
    await tester.tap(find.byTooltip('这本书的更多操作'));
    await tester.pumpAndSettle();
    expect(find.text('重命名'), findsOneWidget);
    expect(find.text('导出'), findsOneWidget);
    expect(find.text('移至回收站'), findsOneWidget);
  });

  testWidgets('重命名后书架和当前书都变', (tester) async {
    await _setup(tester);
    await tester.tap(find.byTooltip('这本书的更多操作'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('重命名'));
    await tester.pumpAndSettle();

    await tester.enterText(find.byType(TextField), '灰烬纪元·改');
    await tester.pump();
    await tester.tap(find.text('保存'));
    await tester.pumpAndSettle();

    expect(find.text('灰烬纪元·改'), findsOneWidget);
    expect(AppState.I.novel.title, '灰烬纪元·改');
  });

  testWidgets('移入回收站要确认，确认后从书架消失', (tester) async {
    await _setup(tester);
    await tester.tap(find.byTooltip('这本书的更多操作'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('移至回收站'));
    await tester.pumpAndSettle();
    expect(find.text('移入回收站？'), findsOneWidget);

    await tester.tap(find.widgetWithText(ElevatedButton, '移入回收站'));
    await tester.pumpAndSettle();

    expect(AppState.I.visibleBooks, isEmpty);
    expect(AppState.I.trashedBooks.length, 1);
    expect(find.text('还没有小说，点右上角新建'), findsOneWidget);
  });

  test('回收站里彻底删除不会留下空壳', () async {
    SharedPreferences.setMockInitialValues(<String, Object>{});
    await AppState.I.init();
    final a = _book();
    final b = Novel(title: '第二本')..chapters = [Chapter(title: '第一章', content: '内容')];
    AppState.I.books = [a, b];
    AppState.I.currentId = a.id;

    await AppState.I.deleteBook(a.id);
    await AppState.I.purgeBook(a.id);
    expect(AppState.I.books.any((x) => x.id == a.id), isFalse);
    expect(AppState.I.novel.id, b.id);
  });

  test('导入：按「第X章」切章，没标题就整体一章', () {
    final parts = splitChapters('第一章 雨夜\n雨很大。\n\n第二章 天亮\n雨停了。');
    expect(parts.length, 2);
    expect(parts.first.title, '第一章 雨夜');
    expect(parts.first.content, contains('雨很大'));
    expect(parts.last.title, '第二章 天亮');

    final one = splitChapters('只有一段没有章节标记的文字。');
    expect(one.length, 1);
    expect(one.first.title, '正文');
    expect(one.first.content, contains('没有章节标记'));

    expect(splitChapters('   '), isEmpty);
  });

  test('导出文本带书名和每章正文', () {
    final b = Novel(title: '灰烬纪元')
      ..chapters = [Chapter(title: '第一章 火', content: '火从地底烧上来。')];
    final text = exportBookText(b);
    expect(text, contains('《灰烬纪元》'));
    expect(text, contains('第一章 火'));
    expect(text, contains('火从地底烧上来。'));
  });

  test('回收站超过 30 天自动清理，没到期的留着', () async {
    final now = DateTime.now();
    final old = Novel(title: '很久以前删的')
      ..chapters = [Chapter(title: '第一章', content: '内容')]
      ..deletedAt = now.subtract(const Duration(days: AppState.trashKeepDays + 1)).millisecondsSinceEpoch;
    final fresh = Novel(title: '昨天删的')
      ..chapters = [Chapter(title: '第一章', content: '内容')]
      ..deletedAt = now.subtract(const Duration(days: 1)).millisecondsSinceEpoch;

    SharedPreferences.setMockInitialValues(<String, Object>{
      'books_v1': jsonEncode([old.toJson(), fresh.toJson()]),
    });
    await AppState.I.init();

    expect(AppState.I.books.any((b) => b.id == old.id), isFalse);
    expect(AppState.I.trashedBooks.length, 1);
    expect(AppState.I.trashedBooks.first.id, fresh.id);
  });

  test('导入的书能落到书架上', () async {
    SharedPreferences.setMockInitialValues(<String, Object>{});
    await AppState.I.init();
    AppState.I.books = [Novel()];
    final book = await AppState.I.importBook(
      title: '旧稿',
      raw: '第一章 开端\n天亮了。\n\n第二章 出发\n上路了。',
    );
    expect(book.title, '旧稿');
    expect(book.chapters.length, 2);
    expect(AppState.I.novel.id, book.id);
    expect(AppState.I.visibleBooks.length, 1);
  });
}
