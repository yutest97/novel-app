import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:novel_app/main.dart';
import 'package:novel_app/models.dart';
import 'package:novel_app/store.dart';
import 'package:novel_app/theme.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  group('历史里的选项回合', () {
    test('只有选项、没有正文时，用选项拼回 [选项] 段', () {
      final b = ChatBubble(
        role: 'assistant',
        text: '',
        options: const [Choice('连环模仿案', '模仿旧案'), Choice('雨夜抛尸案', '')],
      );
      expect(b.hasHistory, isTrue);
      expect(b.historyText, contains('[选项]'));
      expect(b.historyText, contains('连环模仿案'));
      expect(b.historyText, contains('| 模仿旧案'));
    });

    test('有原始回复时优先用原文，保住 [选项] 和资料段', () {
      final b = ChatBubble(
        role: 'assistant',
        text: '',
        raw: '[选项]\n- 继续 | 往下写',
        options: const [Choice('继续', '往下写')],
      );
      expect(b.historyText, contains('[选项]'));
      expect(b.historyText, contains('往下写'));
    });

    test('真的什么都没有的助手气泡，不进历史', () {
      final b = ChatBubble(role: 'assistant', text: '   ');
      expect(b.hasHistory, isFalse);
      expect(b.historyText, isEmpty);
    });
  });

  testWidgets('只给选项的那轮不再一直显示「正在写…」', (tester) async {
    tester.view.physicalSize = const Size(1080, 2400);
    tester.view.devicePixelRatio = 3.0;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);

    SharedPreferences.setMockInitialValues(<String, Object>{});
    await AppState.I.init();

    final book = Novel(title: '别在三中讲鬼故事')
      ..chats = [
        ChatBubble(role: 'user', text: '给我选项'),
        ChatBubble(
          role: 'assistant',
          text: '',
          options: const [
            Choice('连环模仿案', ''),
            Choice('雨夜抛尸案', ''),
            Choice('灭门旧案重启', ''),
          ],
        ),
      ];
    AppState.I.books = [book];
    AppState.I.currentId = book.id;
    AppState.I.settings
      ..baseUrl = 'http://127.0.0.1:9/v1'
      ..apiKey = ''
      ..model = 'm';
    AppState.I.pending = Pending.none;
    AppState.I.busy = false;
    AppState.I.goTab(0);

    await tester.pumpWidget(MaterialApp(theme: buildDarkTheme(), home: const HomeShell()));
    await tester.pumpAndSettle();

    expect(find.text('选一个方向：'), findsOneWidget);
    expect(find.text('正在写…'), findsNothing);
    expect(find.text('连环模仿案'), findsOneWidget);
  });

  testWidgets('流式输出时最后一条才转圈', (tester) async {
    tester.view.physicalSize = const Size(1080, 2400);
    tester.view.devicePixelRatio = 3.0;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);

    SharedPreferences.setMockInitialValues(<String, Object>{});
    await AppState.I.init();
    final book = Novel(title: '书')
      ..chats = [ChatBubble(role: 'assistant', text: '', reasoning: '想一想')];
    AppState.I.books = [book];
    AppState.I.currentId = book.id;
    AppState.I.settings
      ..baseUrl = 'http://127.0.0.1:9/v1'
      ..apiKey = ''
      ..model = 'm';
    AppState.I.pending = Pending.none;
    AppState.I.busy = true;
    AppState.I.goTab(0);

    await tester.pumpWidget(MaterialApp(theme: buildDarkTheme(), home: const HomeShell()));
    await tester.pump();

    expect(find.text('正在写…'), findsOneWidget);
  });
}
