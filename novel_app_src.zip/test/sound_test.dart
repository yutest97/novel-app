import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:novel_app/screens/simple_pages.dart';
import 'package:novel_app/sound.dart';
import 'package:novel_app/store.dart';
import 'package:novel_app/theme.dart';

Future<void> _loadFonts() async {
  final cjk = File('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc').readAsBytesSync();
  for (final f in ['CJK', 'monospace', 'Roboto']) {
    await (FontLoader(f)..addFont(Future.value(ByteData.view(cjk.buffer)))).load();
  }
  final icon = File('/opt/f3/flutter/bin/cache/artifacts/material_fonts/MaterialIcons-Regular.otf').readAsBytesSync();
  await (FontLoader('MaterialIcons')..addFont(Future.value(ByteData.view(icon.buffer)))).load();
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  setUp(() async => _loadFonts());

  testWidgets('测试环境没有原生通道时不崩，返回 false 走兜底', (tester) async {
    // 平台通道要走真实异步，必须包在 runAsync 里，否则假时钟会一直等
    final ok = await tester.runAsync(() => playDoneSound());
    expect(ok, isFalse);
  });

  testWidgets('点「试听」不抛异常，并提示为什么没走原生', (tester) async {
    tester.view.physicalSize = const Size(1080, 2280);
    tester.view.devicePixelRatio = 3.0;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);

    SharedPreferences.setMockInitialValues(<String, Object>{});
    await AppState.I.init();

    final t = buildDarkTheme();
    await tester.pumpWidget(MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: t.copyWith(textTheme: t.textTheme.apply(fontFamily: 'CJK')),
      home: const ThemePage(),
    ));
    await tester.pumpAndSettle();

    await tester.runAsync(() async {
      await tester.tap(find.text('试听'));
      await Future<void>.delayed(const Duration(milliseconds: 300));
    });
    await tester.pumpAndSettle();
    expect(find.textContaining('原生提示音不可用'), findsOneWidget);
  });
}
