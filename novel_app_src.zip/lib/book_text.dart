import 'models.dart';

/// 章节标题：第1章 / 第十二章 / 第三回 …（整行较短才算标题）
final RegExp _chapterHead =
    RegExp(r'^第\s*[0-9０-９一二三四五六七八九十百千零两]+\s*[章节回](?:\s|[:：、.．\-—]|$)');

/// 把一整段文本切成章节。
/// 认「第X章」这类标题；一个都认不出来就整体当一章「正文」。
List<Chapter> splitChapters(String raw) {
  final text = raw.replaceAll('\r\n', '\n').replaceAll('\r', '\n').trim();
  if (text.isEmpty) return <Chapter>[];

  final out = <Chapter>[];
  String? title;
  final buf = StringBuffer();

  void flush() {
    final body = buf.toString().trim();
    if (title == null && body.isEmpty) return;
    out.add(Chapter(title: (title ?? '正文').trim(), content: body));
    buf.clear();
    title = null;
  }

  for (final line in text.split('\n')) {
    final t = line.trim();
    if (t.isNotEmpty && t.length <= 40 && _chapterHead.hasMatch(t)) {
      flush();
      title = t.replaceAll(RegExp(r'^#+\s*'), '');
    } else {
      buf.writeln(line);
    }
  }
  flush();
  return out;
}

/// 导出成 txt：书名 + 章节正文（不带设定，设定走备份）
String exportBookText(Novel book) {
  final name = book.title.trim().isEmpty ? '未命名作品' : book.title.trim();
  final buf = StringBuffer()
    ..writeln('《$name》')
    ..writeln()
    ..writeln('正文 ${book.chapterWords} 字 · ${book.chapters.length} 章')
    ..writeln();
  for (final c in book.chapters) {
    buf
      ..writeln(c.title.trim().isEmpty ? '正文' : c.title.trim())
      ..writeln()
      ..writeln(c.content.trim())
      ..writeln()
      ..writeln();
  }
  return buf.toString().trimRight();
}
