/// 内置技能：打进安装包，随 App 一起发
class BuiltinSkill {
  final String id;
  final String name;
  final String desc;
  final List<String> files; // 相对 assets/skills/<dir>/ 的文件

  const BuiltinSkill(this.id, this.name, this.desc, this.files);
}

const String kBuiltinDir = 'assets/skills';

const List<BuiltinSkill> kBuiltinSkills = [
  BuiltinSkill(
    'builtin:novel-writer',
    '小说写作',
    '初始化项目 → 人物库/世界观/章节摘要 → 写章 → 同步资料',
    ['novel-writer/SKILL.md', 'novel-writer/references/templates.md'],
  ),
  BuiltinSkill(
    'builtin:skill-creator',
    '技能创作',
    '帮你写自己的技能包：结构、模板、校验',
    ['skill-creator/SKILL.md', 'skill-creator/references/templates.md'],
  ),
];

BuiltinSkill? builtinSkillById(String id) {
  for (final s in kBuiltinSkills) {
    if (s.id == id) return s;
  }
  return null;
}
