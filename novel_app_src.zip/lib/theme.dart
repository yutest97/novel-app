import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

/// 全局配色（对齐参考图的深色 + 紫）
class C {
  static const bg = Color(0xFF0B0B12);
  static const surface = Color(0xFF15151E);
  static const card = Color(0xFF1B1B26);
  static const cardHi = Color(0xFF23232F);
  static const border = Color(0xFF2A2A38);
  static const purple = Color(0xFF7B5CFF);
  static const purpleSoft = Color(0xFF9C8BFF);
  static const text = Color(0xFFEDEDF5);
  static const dim = Color(0xFF8A8AA3);
  static const faint = Color(0xFF5A5A70);
  static const green = Color(0xFF3BA55D);
}

ThemeData buildDarkTheme() {
  final base = ThemeData(brightness: Brightness.dark, useMaterial3: true);
  return base.copyWith(
    scaffoldBackgroundColor: C.bg,
    colorScheme: base.colorScheme.copyWith(
      primary: C.purple,
      secondary: C.purpleSoft,
      surface: C.surface,
    ),
    appBarTheme: const AppBarTheme(
      backgroundColor: C.bg,
      elevation: 0,
      centerTitle: false,
      foregroundColor: C.text,
      titleTextStyle: TextStyle(color: C.text, fontSize: 17, fontWeight: FontWeight.w600),
    ),
    dividerTheme: const DividerThemeData(color: C.border, thickness: 0.6, space: 1),
    // Android 用 Material 3（Android 14 起）的原生转场：新页淡入、
    // 旧页向左退 1/4 并淡出，450ms，easeInOutCubicEmphasized。
    // 之前用的 Zoom 是缩放淡入，返回时整块画面收缩，所以显得硬。
    // iOS / macOS 仍用各自的横滑，不混规范。
    pageTransitionsTheme: const PageTransitionsTheme(
      builders: <TargetPlatform, PageTransitionsBuilder>{
        TargetPlatform.android: FadeForwardsPageTransitionsBuilder(backgroundColor: C.bg),
        TargetPlatform.iOS: CupertinoPageTransitionsBuilder(),
        TargetPlatform.macOS: CupertinoPageTransitionsBuilder(),
      },
    ),
    textTheme: base.textTheme.apply(bodyColor: C.text, displayColor: C.text),
    inputDecorationTheme: const InputDecorationTheme(
      isDense: true,
      hintStyle: TextStyle(color: C.faint, fontSize: 14),
      border: InputBorder.none,
      enabledBorder: InputBorder.none,
      focusedBorder: InputBorder.none,
    ),
    snackBarTheme: const SnackBarThemeData(backgroundColor: C.cardHi, contentTextStyle: TextStyle(color: C.text)),
    bottomSheetTheme: const BottomSheetThemeData(backgroundColor: C.surface),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: const Color(0xFF101018),
      indicatorColor: const Color(0x337B5CFF),
      labelTextStyle: MaterialStateProperty.all(const TextStyle(fontSize: 11, color: C.dim)),
    ),
  );
}
