import 'package:flutter/material.dart';

import 'models.dart';
import 'store.dart';

const Color _bg = Color(0xFF15151F);
const Color _card = Color(0xFF1D1D2B);
const Color _purple = Color(0xFF8B7BF7);
const Color _dim = Color(0xFF8A8AA3);

/// 供应商对应的接口地址（自定义模型时用）
const Map<String, String> kProviderUrls = {
  '智谱': 'https://open.bigmodel.cn/api/paas/v4',
  '硅基流动': 'https://api.siliconflow.cn/v1',
  'DeepSeek': 'https://api.deepseek.com/v1',
  '通义千问': 'https://dashscope.aliyuncs.com/compatible-mode/v1',
  'OpenAI': 'https://api.openai.com/v1',
};

/// 弹出「切换模型」面板
Future<void> showModelSheet(BuildContext context) {
  return showModalBottomSheet<void>(
    context: context,
    backgroundColor: Colors.transparent,
    isScrollControlled: true,
    builder: (_) => const ModelSheet(),
  );
}

class ModelSheet extends StatefulWidget {
  const ModelSheet({super.key});

  @override
  State<ModelSheet> createState() => _ModelSheetState();
}

class _ModelSheetState extends State<ModelSheet> {
  late String _baseUrl;
  late String _model;

  @override
  void initState() {
    super.initState();
    final s = AppState.I.settings;
    _baseUrl = s.baseUrl;
    _model = s.model;
  }

  bool _hit(ModelOption m) => m.model == _model && m.baseUrl == _baseUrl;

  Future<void> _apply() async {
    // 和清单里某项完全一致 → 直接切；否则按当前的供应商/地址切
    final matched = kModels.where(_hit).toList();
    if (matched.isNotEmpty) {
      await AppState.I.switchModel(matched.first);
    } else {
      await AppState.I.switchCustomModel(
        provider: AppState.I.settings.provider,
        baseUrl: _baseUrl,
        model: _model,
      );
    }
    if (mounted) Navigator.of(context).pop();
  }

  Future<void> _openCustom() async {
    final modelCtrl = TextEditingController(text: _model);
    var provider = AppState.I.settings.provider;
    if (!kProviders.contains(provider)) provider = kProviders.first;

    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setDlg) => AlertDialog(
          title: const Text('自定义模型'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              DropdownButtonFormField<String>(
                value: provider,
                decoration: const InputDecoration(labelText: '供应商（决定用哪把 Key）'),
                items: [
                  for (final p in kProviders)
                    DropdownMenuItem(value: p, child: Text(p)),
                ],
                onChanged: (v) => setDlg(() => provider = v ?? provider),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: modelCtrl,
                autocorrect: false,
                decoration: const InputDecoration(
                  labelText: '模型 ID',
                  hintText: '比如 deepseek-chat',
                ),
              ),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('取消')),
            ElevatedButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('用这个')),
          ],
        ),
      ),
    );

    if (ok == true && modelCtrl.text.trim().isNotEmpty) {
      setState(() {
        _model = modelCtrl.text.trim();
        _baseUrl = kProviderUrls[provider] ?? _baseUrl;
      });
      await AppState.I.switchCustomModel(
        provider: provider,
        baseUrl: kProviderUrls[provider] ?? _baseUrl,
        model: _model,
      );
      if (mounted) Navigator.of(context).pop();
    }
  }

  @override
  Widget build(BuildContext context) {
    final free = kModels.where((m) => m.free).toList();
    final paid = kModels.where((m) => !m.free).toList();
    final hasKey = AppState.I.settings.apiKey.trim().isNotEmpty;

    return Container(
      constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * 0.85),
      decoration: const BoxDecoration(
        color: _bg,
        borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
      ),
      child: SafeArea(
        top: false,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 38,
              height: 4,
              margin: const EdgeInsets.only(top: 10, bottom: 8),
              decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(2)),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(18, 2, 10, 6),
              child: Row(
                children: [
                  const Icon(Icons.swap_horiz, color: _purple, size: 20),
                  const SizedBox(width: 8),
                  const Text('切换模型',
                      style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w600)),
                  const Spacer(),
                  TextButton(
                    onPressed: _apply,
                    child: const Text('完成', style: TextStyle(color: _purple, fontSize: 15)),
                  ),
                ],
              ),
            ),
            if (!hasKey)
              Container(
                margin: const EdgeInsets.fromLTRB(14, 0, 14, 8),
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: BoxDecoration(
                  color: const Color(0x33FFB020),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Text(
                  '当前模型还没填 Key，先去「设置」填好再用',
                  style: TextStyle(color: Color(0xFFFFC46B), fontSize: 12),
                ),
              ),
            Flexible(
              child: ListView(
                shrinkWrap: true,
                padding: const EdgeInsets.fromLTRB(14, 0, 14, 16),
                children: [
                  _group('公益模型', free),
                  const SizedBox(height: 14),
                  _group('付费模型', paid),
                  const SizedBox(height: 4),
                ],
              ),
            ),
            // 固定在底部，不随列表滚动
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 4, 14, 10),
              child: InkWell(
                onTap: _openCustom,
                borderRadius: BorderRadius.circular(10),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
                  decoration: BoxDecoration(
                    color: _card,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: const Color(0xFF2C2C3D)),
                  ),
                  child: Row(
                    children: const [
                      Icon(Icons.add, color: _dim, size: 18),
                      SizedBox(width: 10),
                      Text('自定义模型 ID', style: TextStyle(color: _dim, fontSize: 13)),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _group(String title, List<ModelOption> items) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(4, 4, 4, 8),
          child: Row(
            children: [
              const Icon(Icons.folder_open, color: _purple, size: 15),
              const SizedBox(width: 6),
              Text(title, style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w600)),
            ],
          ),
        ),
        Container(
          decoration: BoxDecoration(color: _card, borderRadius: BorderRadius.circular(12)),
          child: Column(
            children: [
              for (var i = 0; i < items.length; i++) ...[
                if (i > 0) const Divider(height: 1, color: Color(0xFF262636), indent: 48, endIndent: 12),
                _row(items[i]),
              ],
            ],
          ),
        ),
      ],
    );
  }

  Widget _row(ModelOption m) {
    final selected = _hit(m);
    return InkWell(
      borderRadius: BorderRadius.circular(12),
      onTap: () => setState(() {
        _model = m.model;
        _baseUrl = m.baseUrl;
      }),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
        child: Row(
          children: [
            Icon(
              selected ? Icons.radio_button_checked : Icons.radio_button_unchecked,
              size: 19,
              color: selected ? _purple : const Color(0xFF4A4A5E),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    m.name,
                    style: TextStyle(
                      color: selected ? _purple : const Color(0xFFE6E6F0),
                      fontSize: 13.5,
                      fontFamily: 'monospace',
                    ),
                  ),
                  if (m.model != m.name)
                    Padding(
                      padding: const EdgeInsets.only(top: 2),
                      child: Text(
                        m.model,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(color: _dim, fontSize: 11, fontFamily: 'monospace'),
                      ),
                    ),
                ],
              ),
            ),
            if (m.free)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                decoration: BoxDecoration(
                  color: const Color(0x332E9E5B),
                  borderRadius: BorderRadius.circular(3),
                ),
                child: const Text('免费', style: TextStyle(color: Color(0xFF6FD79B), fontSize: 9)),
              ),
          ],
        ),
      ),
    );
  }
}
