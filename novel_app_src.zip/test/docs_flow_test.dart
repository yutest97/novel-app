import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:novel_app/models.dart';
import 'package:novel_app/prompt.dart';
import 'package:novel_app/store.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('填了书名但没内容的新书，仍然算「待初始化」', () {
    final book = Novel(title: '长夜将至');
    expect(book.isEmpty, isFalse);
    expect(book.needsSetup, isTrue);

    book.world = '# 世界观\n末世第三年。';
    expect(book.needsSetup, isFalse);
  });

  test('新书的系统提示会带书名，并要求走初始化、交三份资料', () async {
    SharedPreferences.setMockInitialValues(<String, Object>{});
    await AppState.I.init();
    final book = Novel(title: '长夜将至');
    final prompt = await buildSystemPrompt(book);

    expect(prompt, contains('长夜将至'));
    expect(prompt, contains('初始化模式'));
    expect(prompt, contains('[人物库]'));
    expect(prompt, contains('[世界观]'));
    expect(prompt, contains('[章节摘要]'));
    expect(prompt, contains('小说资料'));
  });

  test('初始化那轮回复能同时解析出三份资料和选项', () {
    final reply = AiReply.parse('''
[人物库]
# 人物库
### 陈烬
- 身份：外卖员

[世界观]
# 世界观
## 世界背景
末世第三年。

[章节摘要]
## 第0章 前情
故事尚未开始。

[选项]
- 写第一章 | 直接开写
- 先改设定 | 调整人物和世界
''');
    expect(reply.hasDocs, isTrue);
    expect(reply.docs.keys.toSet(), {'characters', 'world', 'summary'});
    expect(reply.docs['characters'], contains('陈烬'));
    expect(reply.options.length, 2);
    expect(reply.hasChapter, isFalse);
  });

  test('新书资料直接落库，已有资料的书先挂起等确认', () async {
    SharedPreferences.setMockInitialValues(<String, Object>{});
    await AppState.I.init();
    final book = Novel(title: '长夜将至');
    AppState.I.books = [book];
    AppState.I.currentId = book.id;

    final docs = {
      'characters': '# 人物库\n### 陈烬',
      'world': '# 世界观\n末世。',
      'summary': '## 第0章 前情\n故事尚未开始。',
    };
    expect(AppState.I.absorbDocs(docs), DocsOutcome.applied);
    expect(book.characters, contains('陈烬'));
    expect(AppState.I.pendingDocs, isEmpty);

    // 已有资料后再来一版：不覆盖，挂起给用户确认
    final next = {'world': '# 世界观\n末世第五年。'};
    expect(AppState.I.absorbDocs(next), DocsOutcome.pending);
    expect(AppState.I.pendingDocs['world'], contains('第五年'));
    expect(book.world, contains('末世。'), reason: '确认前不能覆盖用户看得到的资料');

    AppState.I.confirmSyncDocs(); // pending 不是 syncDocs 时什么都不做
    expect(book.world, contains('末世。'));

    AppState.I.pending = Pending.syncDocs;
    AppState.I.confirmSyncDocs();
    expect(book.world, contains('第五年'));
    expect(AppState.I.pendingDocs, isEmpty);
  });

  test('书名：没名字时接受模型给的 [书名]，已有名字不覆盖', () async {
    SharedPreferences.setMockInitialValues(<String, Object>{});
    await AppState.I.init();
    final book = Novel();
    AppState.I.books = [book];
    AppState.I.currentId = book.id;

    final reply = AiReply.parse('[书名]\n《长夜将至》\n\n[选项]\n- 写第一章 | 开写');
    expect(reply.hasBookTitle, isTrue);
    expect(reply.bookTitle, '长夜将至');

    expect(AppState.I.absorbBookTitle(reply.bookTitle), isTrue);
    expect(book.title, '长夜将至');

    // 已有名字就不覆盖
    expect(AppState.I.absorbBookTitle('另一个名字'), isFalse);
    expect(book.title, '长夜将至');
  });

  test('书名没定时，提示词要求先问用户，不许自己起名', () async {
    SharedPreferences.setMockInitialValues(<String, Object>{});
    await AppState.I.init();
    final prompt = await buildSystemPrompt(Novel());
    expect(prompt, contains('书名必须让用户定'));
    expect(prompt, contains('[书名]'));
    expect(prompt, contains('不要自己替用户起书名'));
  });

  test('书名已定时，提示词说不要再改', () async {
    SharedPreferences.setMockInitialValues(<String, Object>{});
    await AppState.I.init();
    final prompt = await buildSystemPrompt(Novel(title: '长夜将至'));
    expect(prompt, contains('用户已经定了，不要再改'));
  });

  test('向导只整理文本，不自动发送', () {
    AppState.I.wizardOpen = true;
    AppState.I.wizardStep = 2;
    AppState.I.wizardAnswers = ['都市异能', '爽文快节奏', '男性主角'];
    final text = AppState.I.wizardPromptText();
    expect(text, contains('【新书设定】'));
    expect(text, contains('先问我要书名'));
    expect(text, contains('不要自己起名'));
  });

  test('没有备忘录时，工具清单里不出现 read_notes', () async {
    SharedPreferences.setMockInitialValues(<String, Object>{});
    await AppState.I.init();
    AppState.I.books = [Novel(title: '长夜将至')];
    AppState.I.currentId = AppState.I.books.first.id;
    AppState.I.settings
      ..apiKey = 'k'
      ..baseUrl = 'http://127.0.0.1:9/v1'
      ..model = 'm'
      ..agentEnabled = true;

    final prompt = await buildSystemPrompt(AppState.I.novel, agentMode: true);
    expect(prompt, contains('read_doc(name)'));
    expect(prompt.contains('read_notes()：读用户的备忘录'), isFalse);
    expect(prompt, contains('不要调用 read_notes'));

    AppState.I.novel.notes.add(Note(text: '一句灵感', category: '灵感'));
    final withNotes = await buildSystemPrompt(AppState.I.novel, agentMode: true);
    expect(withNotes, contains('read_notes()'));
    expect(withNotes, contains('只在用户提到备忘录'));
  });

  test('writeDocs 把三段写进当前书', () async {
    SharedPreferences.setMockInitialValues(<String, Object>{});
    await AppState.I.init();
    final book = Novel(title: '长夜将至');
    AppState.I.books = [book];
    AppState.I.currentId = book.id;

    AppState.I.writeDocs({
      'characters': '# 人物库\n### 陈烬',
      'world': '# 世界观\n## 世界背景\n末世。',
      'summary': '## 第0章 前情\n故事尚未开始。',
    });

    expect(book.characters, contains('陈烬'));
    expect(book.world, contains('末世'));
    expect(book.summary, contains('故事尚未开始'));
    expect(book.needsSetup, isFalse);
    expect(book.settingWords, greaterThan(10));
  });
}
