/// 内置书源：常见笔趣阁系镜像站。
/// 这类站点域名换得勤，所以不写死一个，而是列一批逐个试。
const List<String> kBookSources = <String>[
  'https://www.xbiquge.la',
  'https://www.bqg128.com',
  'https://www.biqu5200.net',
  'https://www.ibiquges.info',
  'https://www.shukuge.com',
  'https://www.biquge365.net',
  'https://www.22biqu.com',
  'https://www.biqooge.com',
  'https://www.beqege.com',
  'https://www.ddxs.com',
];
