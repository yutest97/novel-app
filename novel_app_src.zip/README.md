# AI 写小说（第一轮）

Android 优先的 Flutter App：AI 在对话里一步步抛选项，你点选项，它按内置的 `novel-writer` 技能包把书写出来。

## 现在能做什么

- 底部三个页签：**对话**（默认首页）/ **小说** / **设置**
- 左上角汉堡打开侧边栏：会话记录（每本书一条，按今天/昨天/更早分组）、新对话、批量删除、底部「免费版」菜单
- AI 每轮给 2~5 个可点选项，末尾固定一个「自定义」，点开自己写一句
- 技能包原文（`SKILL.md` + `templates.md`）打进 App，每次请求都带上，由模型现场决定下一句问什么
- 章节写完先整章显示，底部出现「保存这一章 / 我先想想」，点了才落盘
- 存完自动问「同步资料吗」，同意后更新人物库 / 世界观 / 章节摘要
- 所有内容存手机本地（shared_preferences），关掉 App 不丢
- 设置页 → AI 提供商：三个子页（套餐 / 公益 / 自定义接入），支持 OpenAI 与 Anthropic 两种格式，可拉取模型列表
- 默认走智谱免费模型，新装即用，不必先充钱
- 新建小说走三步问卷（题材/风格/主角），像聊天里的卡片
- 真流式输出：文字和思考过程边生成边显示，思考过程自动展开
- 生成中可以点红色按钮随时停止
- 每条回复可展开「已思考 Xs」回看过程，右下显示「上下文已用」
- 输入框上方显示本地用量（请求次数 / 累计 tokens）
- 对话页顶部显示当前模型，点一下弹出「切换模型」面板（公益 / 付费两组），每个供应商的 Key 分开存

## 跑起来（三步）

前置：装好 Flutter（3.10 以上）和 Android Studio（自带 Android SDK），终端执行 `flutter doctor` 看到 Android toolchain 打勾即可。

```bash
# 1. 进到项目目录
cd novel_app

# 2. 装依赖
flutter pub get

# 3. 连上手机（USB 调试打开）或启动模拟器，跑起来
flutter run
```

第一次跑会下载 Gradle 依赖，等几分钟正常。

## 打包成 APK

```bash
# 调试包，直接装自己手机，不需要签名
flutter build apk --debug

# 正式包（需要先配签名，见下方坑点）
flutter build apk --release
```

产物在 `build/app/outputs/flutter-apk/`。

## 目录说明

```
lib/
├─ main.dart                 入口 + 底部三页签（对话 / 小说 / 设置）
├─ theme.dart                深色主题与配色
├─ models.dart               数据结构（书、章节、聊天、设置）+ AI 返回解析
├─ store.dart                全局状态：书架、聊天、保存、同步
├─ llm.dart                  调 OpenAI 兼容接口，错误翻译成大白话
├─ prompt.dart               系统提示：App 规则 + 技能包 + 当前小说状态
├─ skill.dart                读取 assets 里的技能包原文
├─ model_sheet.dart          「切换模型」底部面板
└─ screens/
   ├─ chat_screen.dart       对话页（空状态三卡、技能行、输入栏）
   ├─ book_shelf_screen.dart 书架（多本书、改名、删除）
   ├─ book_home_page.dart    书详情（小说资料 / 章节内容 两个入口）+ 资料文件列表 + 可编辑文档
   ├─ settings_screen.dart   设置菜单
   ├─ settings_ai_page.dart  AI 提供商（Key、模型、测试连接）
   └─ simple_pages.dart      Skill 管理、参数、主题、数据、关于、教程
assets/skills/novel-writer/  技能包原文，不要删
signing/                     固定调试签名，保证以后能覆盖安装
test/smoke_test.dart         冒烟测试 + 解析回归测试
```

## 已经验证过的

- `flutter analyze`：0 问题
- `flutter test`：2 个测试通过（首页渲染 + 技能包加载）
- AndroidManifest 已加 `INTERNET` 权限（不加的话 release 包联网必失败）

## 这一轮没做（第二轮）

- 小说资料页只能看不能改（手动编辑）
- 供应商只给了 4 个预设，没做自定义保存多套
- 没有导出 TXT、没有多本书书架、没有云同步
