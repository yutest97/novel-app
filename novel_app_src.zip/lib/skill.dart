import 'package:flutter/services.dart' show rootBundle;

import 'builtin_skills.dart';

/// 读取内置技能原文（SKILL.md + 附带文档）
class SkillPack {
  static final Map<String, String> _cache = <String, String>{};

  /// [id] 形如 builtin:novel-writer；默认读小说写作
  static Future<String> load([String id = 'builtin:novel-writer']) async {
    final hit = _cache[id];
    if (hit != null) return hit;

    final skill = builtinSkillById(id) ?? kBuiltinSkills.first;
    final buf = StringBuffer();
    for (final f in skill.files) {
      try {
        final text = await rootBundle.loadString('$kBuiltinDir/$f');
        if (f.endsWith('SKILL.md')) {
          // 主文件就是技能正文，不加分隔标记
          buf.writeln(text.trim());
        } else {
          final name = f.split('/').last;
          buf.writeln('===== 附件：$name =====');
          buf.writeln(text.trim());
          buf.writeln('===== 附件结束 =====');
        }
        buf.writeln();
      } catch (_) {
        // 某个附件读不到就跳过，不影响主流程
      }
    }
    final out = buf.toString();
    _cache[id] = out;
    return out;
  }
}
