import 'package:flutter/material.dart';

import '../novel_source.dart';
import '../store.dart';
import '../theme.dart';
import 'source_dialog.dart';

/// 网文扫榜：从榜单页抓真实数据，再让 AI 基于数据回答 / 分析
class ScanSheet extends StatefulWidget {
  const ScanSheet({super.key});

  @override
  State<ScanSheet> createState() => _ScanSheetState();
}

class _ScanSheetState extends State<ScanSheet> {
  List<RankBook> _preview = const [];
  String _path = '/rank/hotsales/';
  String _label = '畅销榜';
  bool _busy = false;
  String _progress = '';

  static const List<List<String>> _presets = [
    ['月票榜', '/rank/yuepiao/'],
    ['畅销榜', '/rank/hotsales/'],
    ['新书榜', '/rank/newbook/'],
    ['人气榜', '/rank/popular/'],
  ];

  static const List<String> _queries = [
    '今天都市题材最火的书是什么？',
    '阅读最多的前十本，各自为什么火？',
    '新书榜的风向是什么？现在流行什么设定？',
    '畅销榜 Top10 有哪些共同点？',
    '人气榜前 5 名，哪本最适合我参考？',
  ];

  static const List<String> _filters = [
    '女频新书里，玄幻言情有哪些？',
    '都市高武的新书榜 Top10',
    '仙侠新书榜 Top10',
  ];

  Future<void> _fetch() async {
    final messenger = ScaffoldMessenger.of(context);
    setState(() {
      _busy = true;
      _progress = '正在找可用书源…';
    });
    try {
      final base = await ensureSourceWithManual(
        context,
        onProgress: (m) {
          if (mounted) setState(() => _progress = m);
        },
      );
      if (base.isEmpty) return;
      if (mounted) setState(() => _progress = '正在抓 $_label…');
      final url = '$base$_path';
      final list = await fetchRanking(url);
      if (!mounted) return;
      AppState.I.cacheRank(list, url);
      setState(() => _preview = list.take(10).toList());
      messenger.showSnackBar(SnackBar(content: Text('抓到 ${list.length} 本')));
    } on NovelFetchException catch (e) {
      messenger.showSnackBar(
        SnackBar(content: Text(e.message), duration: const Duration(seconds: 6)),
      );
    } catch (e) {
      messenger.showSnackBar(SnackBar(content: Text('抓取失败：$e')));
    } finally {
      if (mounted) {
        setState(() {
          _busy = false;
          _progress = '';
        });
      }
    }
  }

  /// 确保有榜单数据；没有就先抓一次
  Future<bool> _ensureRank() async {
    if (AppState.I.hasRank) return true;
    await _fetch();
    return AppState.I.hasRank;
  }

  Future<void> _ask(String question) async {
    final messenger = ScaffoldMessenger.of(context);
    final st = AppState.I;
    if (!st.settings.scanEnabled) {
      messenger.showSnackBar(const SnackBar(content: Text('先打开上面的扫榜开关')));
      return;
    }
    if (!st.hasRank) {
      final ok = await _ensureRank();
      if (!ok) {
        messenger.showSnackBar(
          const SnackBar(
            content: Text('还没有榜单数据。点一下「抓取榜单」就行，书源会自动找。'),
            duration: Duration(seconds: 4),
          ),
        );
        return;
      }
    }
    if (!mounted) return;
    final nav = Navigator.of(context);
    nav.pop();
    await st.send(_buildPrompt(question));
  }

  String _buildPrompt(String question) {
    final st = AppState.I;
    final buf = StringBuffer()
      ..writeln('【扫榜数据】来源：${st.lastRankUrl}')
      ..writeln('抓取时间：${st.lastRankAt}，共 ${st.lastRank.length} 本（按榜单顺序）');
    for (var i = 0; i < st.lastRank.length && i < 30; i++) {
      final b = st.lastRank[i];
      final extra = b.extra.isEmpty ? '' : '（${b.extra}）';
      buf.writeln('${i + 1}. ${b.title}$extra');
    }
    buf
      ..writeln()
      ..writeln('【问题】$question')
      ..writeln()
      ..writeln('只根据上面这份抓到的榜单回答。数据里看不出来的就说「这份榜单里看不出」，不要编造。')
      ..writeln('回答简洁、分点；涉及排名或数量时严格按榜单顺序。')
      ..writeln('最后用 [选项] 给 3 个可继续的方向（例如：分析某本的卖点 / 套用趋势做新书脑洞 / 换一个榜单再比）。');
    return buf.toString();
  }

  @override
  Widget build(BuildContext context) {
    final st = AppState.I;
    final enabled = st.settings.scanEnabled;
    return Container(
      constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * 0.86),
      decoration: const BoxDecoration(
        color: C.surface,
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: SafeArea(
        top: false,
        child: Padding(
          padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 38,
                height: 4,
                margin: const EdgeInsets.symmetric(vertical: 10),
                decoration: BoxDecoration(
                  color: Colors.white24,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(18, 2, 10, 8),
                child: Row(
                  children: [
                    Container(
                      width: 26,
                      height: 26,
                      decoration: BoxDecoration(
                        color: const Color(0x337B5CFF),
                        borderRadius: BorderRadius.circular(7),
                      ),
                      child: const Icon(Icons.insights, size: 14, color: C.purpleSoft),
                    ),
                    const SizedBox(width: 9),
                    const Text('网文扫榜',
                        style: TextStyle(fontSize: 14.5, fontWeight: FontWeight.w600)),
                    const Spacer(),
                    IconButton(
                      icon: const Icon(Icons.close, size: 19, color: C.dim),
                      onPressed: () => Navigator.of(context).pop(),
                    ),
                  ],
                ),
              ),
              Flexible(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.fromLTRB(18, 0, 18, 4),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _switchCard(st, enabled),
                      if (enabled) ...[
                        const SizedBox(height: 12),
                        Container(
                          padding: const EdgeInsets.fromLTRB(11, 9, 6, 9),
                          decoration: BoxDecoration(
                            color: C.card,
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(color: C.border, width: 0.6),
                          ),
                          child: Row(
                            children: [
                              const Icon(Icons.hub_outlined, size: 15, color: C.purpleSoft),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    const Text('书源：自动选择',
                                        style: TextStyle(fontSize: 11.5, color: C.text)),
                                    const SizedBox(height: 2),
                                    Text(
                                      st.settings.sourceBase.isEmpty
                                          ? '内置常见站点，能用哪个用哪个'
                                          : '上次可用：${Uri.tryParse(st.settings.sourceBase)?.host ?? st.settings.sourceBase}',
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: const TextStyle(fontSize: 10, color: C.faint),
                                    ),
                                  ],
                                ),
                              ),
                              TextButton(
                                onPressed: _busy
                                    ? null
                                    : () async {
                                        final base = await ensureSourceWithManual(
                                          context,
                                          forceReprobe: true,
                                        );
                                        if (base.isEmpty || !mounted) return;
                                        setState(() {});
                                        ScaffoldMessenger.of(context).showSnackBar(
                                          SnackBar(
                                            content: Text(
                                                '已换到：${Uri.parse(base).host}'),
                                          ),
                                        );
                                      },
                                child: const Text('换源',
                                    style: TextStyle(fontSize: 11.5, color: C.purpleSoft)),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 8),
                        Wrap(
                          spacing: 8,
                          runSpacing: 8,
                          children: [
                            for (final p in _presets)
                              _miniChip(
                                p[0],
                                () => setState(() {
                                  _path = p[1];
                                  _label = p[0];
                                }),
                                selected: _path == p[1],
                              ),
                            _miniChip(
                              _busy ? _progress : '抓取 $_label',
                              _busy ? null : _fetch,
                              accent: true,
                            ),
                          ],
                        ),
                        if (st.hasRank) ...[
                          const SizedBox(height: 12),
                          _rankPreview(st),
                        ],
                      ],
                      const SizedBox(height: 16),
                      _sectionLabel('使用案例'),
                      const SizedBox(height: 6),
                      _groupLabel('榜单查询'),
                      for (final q in _queries) _exampleRow(q, enabled, () => _ask(q)),
                      const SizedBox(height: 10),
                      _groupLabel('分类筛选'),
                      for (final q in _filters) _exampleRow(q, enabled, () => _ask(q)),
                    ],
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(18, 6, 18, 12),
                child: Align(
                  alignment: Alignment.centerRight,
                  child: TextButton(
                    onPressed: () => Navigator.of(context).pop(),
                    child: const Text('关闭', style: TextStyle(fontSize: 12.5, color: C.dim)),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _switchCard(AppState st, bool enabled) {
    return Container(
      padding: const EdgeInsets.fromLTRB(14, 12, 10, 12),
      decoration: BoxDecoration(
        color: C.card,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: C.border, width: 0.6),
      ),
      child: Row(
        children: [
          Icon(Icons.cloud_outlined, size: 20, color: enabled ? C.purpleSoft : C.dim),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(enabled ? '扫榜已开启' : '扫榜未开启',
                    style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500)),
                const SizedBox(height: 3),
                Text(
                  enabled
                      ? (st.hasRank
                          ? '已抓 ${st.lastRank.length} 本 · ${st.lastRankAt}'
                          : '填榜单地址，抓一次真实数据')
                      : '打开开关以启用扫榜功能',
                  style: const TextStyle(fontSize: 10.5, color: C.faint),
                ),
              ],
            ),
          ),
          Switch(
            value: enabled,
            activeColor: Colors.white,
            activeTrackColor: C.purple,
            inactiveThumbColor: const Color(0xFFBFC2D4),
            inactiveTrackColor: C.cardHi,
            onChanged: (v) => st.setScanEnabled(v),
          ),
        ],
      ),
    );
  }

  Widget _rankPreview(AppState st) {
    return Container(
      padding: const EdgeInsets.fromLTRB(12, 9, 12, 9),
      decoration: BoxDecoration(
        color: C.card,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: C.border, width: 0.6),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.format_list_numbered, size: 14, color: C.purpleSoft),
              const SizedBox(width: 6),
              Text('榜单前 ${_preview.isEmpty ? 10 : _preview.length}',
                  style: const TextStyle(fontSize: 11.5, color: C.dim)),
              const Spacer(),
              Text('共 ${st.lastRank.length} 本',
                  style: const TextStyle(fontSize: 10.5, color: C.faint)),
            ],
          ),
          const SizedBox(height: 6),
          for (var i = 0; i < _preview.length; i++)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 3),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    width: 18,
                    child: Text('${i + 1}',
                        style: TextStyle(
                          fontSize: 10.5,
                          color: i < 3 ? C.purpleSoft : C.faint,
                          fontWeight: i < 3 ? FontWeight.w600 : FontWeight.w400,
                        )),
                  ),
                  Expanded(
                    child: Text(
                      _preview[i].title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 12, color: C.text),
                    ),
                  ),
                  if (_preview[i].extra.isNotEmpty)
                    Container(
                      margin: const EdgeInsets.only(left: 6),
                      constraints: const BoxConstraints(maxWidth: 110),
                      child: Text(
                        _preview[i].extra,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontSize: 9.5, color: C.faint),
                      ),
                    ),
                ],
              ),
            ),
        ],
      ),
    );
  }

  Widget _sectionLabel(String text) => Text(text,
      style: TextStyle(
          fontSize: 11, color: C.dim.withOpacity(0.9), fontWeight: FontWeight.w500));

  Widget _groupLabel(String text) => Padding(
        padding: const EdgeInsets.only(bottom: 5),
        child: Text(text, style: const TextStyle(fontSize: 10.5, color: C.faint)),
      );

  Widget _exampleRow(String text, bool enabled, VoidCallback onTap) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 7),
      child: InkWell(
        onTap: enabled ? onTap : null,
        borderRadius: BorderRadius.circular(9),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 11),
          decoration: BoxDecoration(
            color: C.card,
            borderRadius: BorderRadius.circular(9),
            border: Border.all(color: C.border, width: 0.6),
          ),
          child: Row(
            children: [
              Icon(Icons.menu_book_outlined,
                  size: 15, color: enabled ? C.purpleSoft : C.faint),
              const SizedBox(width: 9),
              Expanded(
                child: Text(
                  text,
                  style: TextStyle(
                    fontSize: 12,
                    color: enabled ? C.text : C.faint,
                  ),
                ),
              ),
              Icon(Icons.chevron_right,
                  size: 15, color: enabled ? C.faint : Colors.transparent),
            ],
          ),
        ),
      ),
    );
  }

  Widget _miniChip(String label, VoidCallback? onTap,
      {bool accent = false, bool selected = false}) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(7),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
        decoration: BoxDecoration(
          color: (accent || selected) ? const Color(0x337B5CFF) : C.card,
          borderRadius: BorderRadius.circular(7),
          border: Border.all(
            color: (accent || selected) ? C.purple : C.border,
            width: 0.6,
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (accent) ...[
              const Icon(Icons.download, size: 12, color: C.purpleSoft),
              const SizedBox(width: 4),
            ],
            Text(label,
                style: TextStyle(
                  fontSize: 11.5,
                  color: (accent || selected) ? C.purpleSoft : C.dim,
                )),
          ],
        ),
      ),
    );
  }
}
