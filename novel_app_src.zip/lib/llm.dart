import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;

import 'models.dart';

/// 模型请求的一次工具调用
class ToolCall {
  final String id;
  final String name;
  final String arguments; // JSON 字符串
  const ToolCall(this.id, this.name, this.arguments);
}

/// 一次调用的结果：正文 + 用量 + 工具调用
class LlmResult {
  final String text;
  final int promptTokens;
  final int completionTokens;
  final String reasoning; // 思考过程（DeepSeek-R1 / GLM 推理模型才有）
  final List<ToolCall> toolCalls;

  LlmResult(
    this.text, {
    this.promptTokens = 0,
    this.completionTokens = 0,
    this.reasoning = '',
    this.toolCalls = const <ToolCall>[],
  });

  int get totalTokens => promptTokens + completionTokens;
}

/// 调用模型时的错误，带大白话提示
class LlmException implements Exception {
  final String message;
  LlmException(this.message);
  @override
  String toString() => message;
}

/// 当前模型/接口不认 tools 参数
class ToolUnsupportedException extends LlmException {
  ToolUnsupportedException(super.message);
}

/// 用来中断正在进行的流式请求
class CancelToken {
  bool cancelled = false;
  void cancel() => cancelled = true;
}

/// 流式请求：每收到一小段就回调一次，边收边显示
Future<LlmResult> streamModel({
  required Settings settings,
  required List<Map<String, String>> messages,
  required void Function(String content, String reasoning) onDelta,
  CancelToken? cancel,
}) async {
  // Anthropic 暂不支持流式，退化成一次性返回
  if (settings.format == 'anthropic') {
    final r = await callModel(settings: settings, messages: messages, jsonMode: false);
    onDelta(r.text, '');
    return r;
  }

  final base = settings.baseUrl.trim().replaceAll(RegExp(r'/+$'), '');
  final uri = Uri.parse('$base/chat/completions');
  final headers = {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer ${settings.apiKey.trim()}',
    'Accept': 'text/event-stream',
  };

  Map<String, dynamic> buildBody({required bool withUsage}) => {
        'model': settings.model.trim(),
        'messages': messages,
        'temperature': settings.temperature,
        'stream': true,
        if (withUsage) 'stream_options': {'include_usage': true},
      };

  http.StreamedResponse resp;
  try {
    final req = http.Request('POST', uri)
      ..headers.addAll(headers)
      ..body = jsonEncode(buildBody(withUsage: true));
    resp = await req.send().timeout(const Duration(minutes: 5));
    if (resp.statusCode == 400) {
      // 有的供应商不认 stream_options，去掉重来
      final req2 = http.Request('POST', uri)
        ..headers.addAll(headers)
        ..body = jsonEncode(buildBody(withUsage: false));
      resp = await req2.send().timeout(const Duration(minutes: 5));
    }
  } on TimeoutException {
    throw LlmException('连接超时，检查网络再试。');
  } catch (_) {
    throw LlmException('连不上接口地址：$base\n检查网络和「接口地址」有没有写错。');
  }

  if (resp.statusCode != 200) {
    final body = await resp.stream.bytesToString();
    if (resp.statusCode == 401 || resp.statusCode == 403) {
      throw LlmException('API Key 不对或没权限（HTTP ${resp.statusCode}）。重新粘贴 Key。');
    }
    throw LlmException('接口报错（HTTP ${resp.statusCode}）：${_short(body)}');
  }

  var content = '';
  var reasoning = '';
  var pTok = 0;
  var cTok = 0;

  final lines = resp.stream.transform(utf8.decoder).transform(const LineSplitter());
  await for (final line in lines) {
    if (cancel?.cancelled == true) break;
    final t = line.trim();
    if (!t.startsWith('data:')) continue;
    final payload = t.substring(5).trim();
    if (payload.isEmpty || payload == '[DONE]') continue;
    try {
      final obj = jsonDecode(payload) as Map<String, dynamic>;
      final usage = obj['usage'];
      if (usage is Map) {
        pTok = (usage['prompt_tokens'] as num?)?.toInt() ?? pTok;
        cTok = (usage['completion_tokens'] as num?)?.toInt() ?? cTok;
      }
      final choices = obj['choices'];
      if (choices is List && choices.isNotEmpty) {
        final delta = choices.first['delta'];
        if (delta is Map) {
          final c = delta['content'];
          final r = delta['reasoning_content'] ?? delta['reasoning'];
          var changed = false;
          if (c != null && c.toString().isNotEmpty) {
            content += c.toString();
            changed = true;
          }
          if (r != null && r.toString().isNotEmpty) {
            reasoning += r.toString();
            changed = true;
          }
          if (changed) onDelta(content, reasoning);
        }
      }
    } catch (_) {
      // 单个分片坏了就跳过，不影响整体
    }
  }

  return LlmResult(content, promptTokens: pTok, completionTokens: cTok, reasoning: reasoning);
}

/// 发一次对话请求。
/// [jsonMode] 为 true 时要求接口返回 JSON（少数供应商不认这个参数，会自动去掉重试）。
/// [Settings.format] 为 anthropic 时走 Anthropic 的 /messages 协议。
Future<LlmResult> callModel({
  required Settings settings,
  required List<Map<String, String>> messages,
  bool jsonMode = true,
}) async {
  if (settings.format == 'anthropic') {
    return _callAnthropic(settings, messages);
  }
  return _callOpenAi(settings, messages, jsonMode: jsonMode);
}

Future<LlmResult> _callOpenAi(
  Settings settings,
  List<Map<String, String>> messages, {
  required bool jsonMode,
}) async {
  final base = settings.baseUrl.trim().replaceAll(RegExp(r'/+$'), '');
  final uri = Uri.parse('$base/chat/completions');

  final body = <String, dynamic>{
    'model': settings.model.trim(),
    'messages': messages,
    'temperature': settings.temperature,
    'stream': false,
  };
  if (jsonMode) body['response_format'] = {'type': 'json_object'};

  http.Response resp;
  try {
    resp = await _post(
      uri,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ${settings.apiKey.trim()}',
      },
      body: body,
    );
    // 有的供应商不支持 response_format，去掉再试一次
    if (resp.statusCode == 400 && jsonMode) {
      body.remove('response_format');
      resp = await _post(
        uri,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ${settings.apiKey.trim()}',
        },
        body: body,
      );
    }
  } on TimeoutException {
    throw LlmException('等了 5 分钟还没返回。可能是网络卡住，或者这次要写的字太多。点重试，或把这一章拆短一点。');
  } catch (e) {
    throw LlmException('连不上接口地址：$base\n检查两件事：手机上有没有网、设置页的「接口地址」有没有写错（要带 https://）。');
  }

  _checkStatus(resp, base);

  Map<String, dynamic> data;
  try {
    data = jsonDecode(utf8.decode(resp.bodyBytes)) as Map<String, dynamic>;
  } catch (_) {
    throw LlmException('返回的不是标准 JSON，可能是接口地址填成了网页地址。返回内容开头：${_short(resp.body)}');
  }

  final usage = data['usage'];
  final pTok = usage is Map ? (usage['prompt_tokens'] as num?)?.toInt() ?? 0 : 0;
  final cTok = usage is Map ? (usage['completion_tokens'] as num?)?.toInt() ?? 0 : 0;

  final choices = data['choices'];
  if (choices is List && choices.isNotEmpty) {
    final msg = choices.first['message'];
    if (msg is Map && msg['content'] != null) {
      return LlmResult(msg['content'].toString(), promptTokens: pTok, completionTokens: cTok);
    }
  }
  throw LlmException('返回里没有正文内容。原始返回：${_short(jsonEncode(data))}');
}

Future<LlmResult> _callAnthropic(Settings settings, List<Map<String, String>> messages) async {
  final base = settings.baseUrl.trim().replaceAll(RegExp(r'/+$'), '');
  final uri = Uri.parse('$base/messages');

  final system = messages
      .where((m) => m['role'] == 'system')
      .map((m) => m['content'] ?? '')
      .join('\n\n');
  final rest = messages.where((m) => m['role'] != 'system').toList();

  final body = <String, dynamic>{
    'model': settings.model.trim(),
    'max_tokens': (settings.maxOutputK.clamp(1, 128)) * 1024,
    'temperature': settings.temperature.clamp(0.0, 1.0),
    if (system.trim().isNotEmpty) 'system': system,
    'messages': rest,
  };

  http.Response resp;
  try {
    resp = await _post(
      uri,
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': settings.apiKey.trim(),
        'anthropic-version': '2023-06-01',
      },
      body: body,
    );
  } on TimeoutException {
    throw LlmException('等了 5 分钟还没返回，网络卡住了。点重试。');
  } catch (_) {
    throw LlmException('连不上接口地址：$base\nAnthropic 的地址一般填 https://api.anthropic.com/v1');
  }

  _checkStatus(resp, base);

  Map<String, dynamic> data;
  try {
    data = jsonDecode(utf8.decode(resp.bodyBytes)) as Map<String, dynamic>;
  } catch (_) {
    throw LlmException('返回的不是标准 JSON。返回内容开头：${_short(resp.body)}');
  }

  final usage = data['usage'];
  final pTok = usage is Map ? (usage['input_tokens'] as num?)?.toInt() ?? 0 : 0;
  final cTok = usage is Map ? (usage['output_tokens'] as num?)?.toInt() ?? 0 : 0;

  final content = data['content'];
  if (content is List) {
    final buf = StringBuffer();
    for (final block in content) {
      if (block is Map && block['type'] == 'text' && block['text'] != null) {
        buf.write(block['text'].toString());
      }
    }
    if (buf.isNotEmpty) {
      return LlmResult(buf.toString(), promptTokens: pTok, completionTokens: cTok);
    }
  }
  throw LlmException('返回里没有正文内容。原始返回：${_short(jsonEncode(data))}');
}

/// 拉取模型列表（仅 OpenAI 兼容接口支持）
Future<List<String>> fetchModelIds(Settings settings) async {
  if (settings.format == 'anthropic') {
    throw LlmException('Anthropic 不提供模型列表接口，请手动填模型名（例如 claude-sonnet-4-5）。');
  }
  final base = settings.baseUrl.trim().replaceAll(RegExp(r'/+$'), '');
  final uri = Uri.parse('$base/models');

  http.Response resp;
  try {
    resp = await http.get(
      uri,
      headers: {'Authorization': 'Bearer ${settings.apiKey.trim()}'},
    ).timeout(const Duration(seconds: 30));
  } on TimeoutException {
    throw LlmException('拉列表超时，检查网络。');
  } catch (_) {
    throw LlmException('连不上 $base/models，检查接口地址和网络。');
  }

  if (resp.statusCode != 200) {
    throw LlmException('拉模型列表失败（HTTP ${resp.statusCode}）：${_short(resp.body)}\n'
        '有些供应商不开放这个接口，直接手动填模型名即可。');
  }

  try {
    final data = jsonDecode(utf8.decode(resp.bodyBytes)) as Map<String, dynamic>;
    final list = (data['data'] as List<dynamic>? ?? []);
    final ids = list
        .whereType<Map<String, dynamic>>()
        .map((e) => (e['id'] ?? '').toString())
        .where((e) => e.isNotEmpty)
        .toList();
    ids.sort();
    return ids;
  } catch (_) {
    throw LlmException('列表格式看不懂，可能是别家的接口。手动填模型名吧。');
  }
}

void _checkStatus(http.Response resp, String base) {
  if (resp.statusCode == 401 || resp.statusCode == 403) {
    throw LlmException('API Key 不对或没权限（HTTP ${resp.statusCode}）。重新粘贴 Key，注意别带空格。');
  }
  if (resp.statusCode == 404) {
    throw LlmException('接口地址找不到（404）。检查地址是不是填到了 /v1 这一层，别多写 /chat/completions。');
  }
  if (resp.statusCode == 429) {
    throw LlmException('请求太频繁或余额不足（429）。等一分钟，或去供应商后台看余额。');
  }
  if (resp.statusCode != 200) {
    throw LlmException('接口报错（HTTP ${resp.statusCode}）：${_short(resp.body)}');
  }
}

Future<http.Response> _post(
    Uri uri, {
      required Map<String, String> headers,
      required Map<String, dynamic> body,
    }) {
  return http
      .post(uri, headers: headers, body: jsonEncode(body))
      .timeout(const Duration(minutes: 5));
}

String _short(String s) {
  final t = s.replaceAll('\n', ' ').trim();
  return t.length <= 200 ? t : '${t.substring(0, 200)}…';
}


/// 带工具的流式请求。解析 OpenAI 兼容协议的 delta.tool_calls。
/// Anthropic 协议暂不支持，直接抛 ToolUnsupportedException 让上层退回普通模式。
Future<LlmResult> streamModelWithTools({
  required Settings settings,
  required List<Map<String, dynamic>> messages,
  required List<Map<String, dynamic>> tools,
  required void Function(String content, String reasoning) onDelta,
  CancelToken? cancel,
}) async {
  if (settings.format == 'anthropic') {
    throw ToolUnsupportedException('当前是 Anthropic 协议，工具调用暂只支持 OpenAI 兼容接口。');
  }

  final base = settings.baseUrl.trim().replaceAll(RegExp(r'/+$'), '');
  final uri = Uri.parse('$base/chat/completions');
  final headers = {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer ${settings.apiKey.trim()}',
    'Accept': 'text/event-stream',
  };

  Map<String, dynamic> buildBody({required bool withUsage}) => {
        'model': settings.model.trim(),
        'messages': messages,
        'temperature': settings.temperature,
        'stream': true,
        'tools': tools,
        'tool_choice': 'auto',
        if (withUsage) 'stream_options': {'include_usage': true},
      };

  http.StreamedResponse resp;
  try {
    final req = http.Request('POST', uri)
      ..headers.addAll(headers)
      ..body = jsonEncode(buildBody(withUsage: true));
    resp = await req.send().timeout(const Duration(minutes: 5));
    if (resp.statusCode == 400) {
      // 先去掉 stream_options 再试，仍然是 400 就认定不支持 tools
      final req2 = http.Request('POST', uri)
        ..headers.addAll(headers)
        ..body = jsonEncode(buildBody(withUsage: false));
      resp = await req2.send().timeout(const Duration(minutes: 5));
      if (resp.statusCode == 400) {
        await resp.stream.drain<void>();
        throw ToolUnsupportedException('这个模型不认 tools 参数，已退回普通模式。');
      }
    }
  } on ToolUnsupportedException {
    rethrow;
  } on TimeoutException {
    throw LlmException('连接超时，检查网络再试。');
  } catch (_) {
    throw LlmException('连不上接口地址：$base\n检查网络和「接口地址」有没有写错。');
  }

  if (resp.statusCode != 200) {
    final body = await resp.stream.bytesToString();
    if (resp.statusCode == 401 || resp.statusCode == 403) {
      throw LlmException('API Key 不对或没权限（HTTP ${resp.statusCode}）。重新粘贴 Key。');
    }
    throw LlmException('接口报错（HTTP ${resp.statusCode}）：${_short(body)}');
  }

  var content = '';
  var reasoning = '';
  var pTok = 0;
  var cTok = 0;
  final calls = <int, Map<String, String>>{};

  final lines = resp.stream.transform(utf8.decoder).transform(const LineSplitter());
  await for (final line in lines) {
    if (cancel?.cancelled == true) break;
    final t = line.trim();
    if (!t.startsWith('data:')) continue;
    final payload = t.substring(5).trim();
    if (payload.isEmpty || payload == '[DONE]') continue;
    try {
      final obj = jsonDecode(payload) as Map<String, dynamic>;
      final usage = obj['usage'];
      if (usage is Map) {
        pTok = (usage['prompt_tokens'] as num?)?.toInt() ?? pTok;
        cTok = (usage['completion_tokens'] as num?)?.toInt() ?? cTok;
      }
      final choices = obj['choices'];
      if (choices is! List || choices.isEmpty) continue;
      final delta = choices.first['delta'];
      if (delta is! Map) continue;

      final c = delta['content'];
      final r = delta['reasoning_content'] ?? delta['reasoning'];
      var changed = false;
      if (c != null && c.toString().isNotEmpty) {
        content += c.toString();
        changed = true;
      }
      if (r != null && r.toString().isNotEmpty) {
        reasoning += r.toString();
        changed = true;
      }
      if (changed) onDelta(content, reasoning);

      final tcs = delta['tool_calls'];
      if (tcs is List) {
        for (final raw in tcs) {
          if (raw is! Map) continue;
          final idx = (raw['index'] as num?)?.toInt() ?? 0;
          final cur = calls.putIfAbsent(idx, () => {'id': '', 'name': '', 'args': ''});
          final id = raw['id'];
          if (id != null && id.toString().isNotEmpty) cur['id'] = id.toString();
          final fn = raw['function'];
          if (fn is Map) {
            final n = fn['name'];
            final a = fn['arguments'];
            if (n != null && n.toString().isNotEmpty) cur['name'] = n.toString();
            if (a != null) cur['args'] = '${cur['args']}${a.toString()}';
          }
        }
      }
    } catch (_) {
      // 分片坏了就跳过
    }
  }

  final toolCalls = <ToolCall>[];
  final keys = calls.keys.toList()..sort();
  for (final k in keys) {
    final c = calls[k]!;
    final name = c['name'] ?? '';
    if (name.isEmpty) continue;
    toolCalls.add(ToolCall(
      (c['id'] ?? '').isEmpty ? 'call_$k' : c['id']!,
      name,
      c['args'] ?? '{}',
    ));
  }

  return LlmResult(
    content,
    promptTokens: pTok,
    completionTokens: cTok,
    reasoning: reasoning,
    toolCalls: toolCalls,
  );
}


/// 把内部消息（OpenAI 风格，含 tool_calls / role=tool）转成 Anthropic messages。
List<Map<String, dynamic>> anthropicMessages(List<Map<String, dynamic>> msgs) {
  final out = <Map<String, dynamic>>[];

  Object? decodeArgs(Object? raw) {
    if (raw is Map) return raw;
    final text = (raw ?? '').toString().trim();
    if (text.isEmpty) return <String, dynamic>{};
    try {
      final v = jsonDecode(text);
      return v is Map ? v : <String, dynamic>{};
    } catch (_) {
      return <String, dynamic>{};
    }
  }

  for (final m in msgs) {
    final role = m['role'];

    if (role == 'tool') {
      final block = <String, dynamic>{
        'type': 'tool_result',
        'tool_use_id': m['tool_call_id'] ?? '',
        'content': (m['content'] ?? '').toString(),
      };
      final last = out.isEmpty ? null : out.last;
      if (last != null && last['role'] == 'user' && last['_tr'] == true) {
        (last['content'] as List).add(block);
      } else {
        out.add({'role': 'user', 'content': [block], '_tr': true});
      }
      continue;
    }

    if (role == 'assistant') {
      final blocks = <Map<String, dynamic>>[];
      final text = (m['content'] ?? '').toString();
      if (text.trim().isNotEmpty) blocks.add({'type': 'text', 'text': text});
      final tcs = m['tool_calls'];
      if (tcs is List) {
        for (final raw in tcs) {
          if (raw is! Map) continue;
          final fn = raw['function'];
          final fnn = fn is Map ? fn : const <String, dynamic>{};
          blocks.add({
            'type': 'tool_use',
            'id': (raw['id'] ?? '').toString(),
            'name': (fnn['name'] ?? '').toString(),
            'input': decodeArgs(fnn['arguments']),
          });
        }
      }
      if (blocks.isEmpty) blocks.add({'type': 'text', 'text': '（继续）'});
      out.add({'role': 'assistant', 'content': blocks});
      continue;
    }

    // user
    final text = (m['content'] ?? '').toString();
    final last = out.isEmpty ? null : out.last;
    if (last != null && last['role'] == 'user' && last['_tr'] != true) {
      last['content'] = '${last['content']}\n\n$text';
    } else {
      out.add({'role': 'user', 'content': text});
    }
  }

  for (final m in out) {
    m.remove('_tr');
  }
  return out;
}

/// Anthropic 协议的工具调用（流式）
Future<LlmResult> streamModelWithToolsAnthropic({
  required Settings settings,
  required List<Map<String, dynamic>> messages,
  required List<Map<String, dynamic>> tools,
  required void Function(String content, String reasoning) onDelta,
  CancelToken? cancel,
}) async {
  final base = settings.baseUrl.trim().replaceAll(RegExp(r'/+$'), '');
  final uri = Uri.parse('$base/messages');

  final system = messages
      .where((m) => m['role'] == 'system')
      .map((m) => (m['content'] ?? '').toString())
      .where((s) => s.trim().isNotEmpty)
      .join('\n\n');
  final converted = anthropicMessages(
    messages.where((m) => m['role'] != 'system').toList(),
  );
  final anthropicTools = <Map<String, dynamic>>[];
  for (final t in tools) {
    final fn = t['function'];
    if (fn is! Map) continue;
    anthropicTools.add({
      'name': fn['name'] ?? '',
      'description': fn['description'] ?? '',
      'input_schema': fn['parameters'] ?? {'type': 'object', 'properties': {}},
    });
  }

  final body = <String, dynamic>{
    'model': settings.model.trim(),
    'max_tokens': (settings.maxOutputK.clamp(1, 128)) * 1024,
    'temperature': settings.temperature.clamp(0.0, 1.0),
    'stream': true,
    if (system.isNotEmpty) 'system': system,
    'messages': converted,
    'tools': anthropicTools,
  };

  http.StreamedResponse resp;
  try {
    final req = http.Request('POST', uri)
      ..headers.addAll({
        'Content-Type': 'application/json',
        'x-api-key': settings.apiKey.trim(),
        'anthropic-version': '2023-06-01',
        'Accept': 'text/event-stream',
      })
      ..body = jsonEncode(body);
    resp = await req.send().timeout(const Duration(minutes: 5));
  } on TimeoutException {
    throw LlmException('连接超时，检查网络再试。');
  } catch (_) {
    throw LlmException('连不上接口地址：$base\nAnthropic 的地址一般填 https://api.anthropic.com/v1。');
  }

  if (resp.statusCode != 200) {
    final raw = await resp.stream.bytesToString();
    if (resp.statusCode == 401 || resp.statusCode == 403) {
      throw LlmException('API Key 不对或没权限（HTTP ${resp.statusCode}）。');
    }
    if (resp.statusCode == 400 && raw.toLowerCase().contains('tool')) {
      throw ToolUnsupportedException('这个模型不认 tools 参数，已退回普通模式。');
    }
    throw LlmException('接口报错（HTTP ${resp.statusCode}）：${_short(raw)}');
  }

  var text = '';
  var pTok = 0;
  var cTok = 0;
  final byIndex = <int, Map<String, String>>{};

  final lines = resp.stream.transform(utf8.decoder).transform(const LineSplitter());
  await for (final line in lines) {
    if (cancel?.cancelled == true) break;
    final t = line.trim();
    if (!t.startsWith('data:')) continue;
    final payload = t.substring(5).trim();
    if (payload.isEmpty || payload == '[DONE]') continue;
    try {
      final obj = jsonDecode(payload) as Map<String, dynamic>;
      final type = obj['type'];

      if (type == 'message_start') {
        final msg = obj['message'];
        if (msg is Map && msg['usage'] is Map) {
          final u = msg['usage'] as Map;
          pTok = (u['input_tokens'] as num?)?.toInt() ?? pTok;
        }
      } else if (type == 'content_block_start') {
        final idx = (obj['index'] as num?)?.toInt() ?? 0;
        final block = obj['content_block'];
        if (block is Map) {
          if (block['type'] == 'tool_use') {
            byIndex[idx] = {
              'id': (block['id'] ?? '').toString(),
              'name': (block['name'] ?? '').toString(),
              'args': '',
            };
          } else if (block['type'] == 'text' && block['text'] != null) {
            text += block['text'].toString();
            onDelta(text, '');
          }
        }
      } else if (type == 'content_block_delta') {
        final idx = (obj['index'] as num?)?.toInt() ?? 0;
        final delta = obj['delta'];
        if (delta is Map) {
          if (delta['type'] == 'text_delta') {
            text += (delta['text'] ?? '').toString();
            onDelta(text, '');
          } else if (delta['type'] == 'input_json_delta') {
            final cur = byIndex.putIfAbsent(idx, () => {'id': '', 'name': '', 'args': ''});
            cur['args'] = '${cur['args']}${delta['partial_json'] ?? ''}';
          }
        }
      } else if (type == 'message_delta') {
        final u = obj['usage'];
        if (u is Map) {
          cTok = (u['output_tokens'] as num?)?.toInt() ?? cTok;
        }
      }
    } catch (_) {
      // 坏分片跳过
    }
  }

  final calls = <ToolCall>[];
  final keys = byIndex.keys.toList()..sort();
  for (final k in keys) {
    final c = byIndex[k]!;
    if ((c['name'] ?? '').isEmpty) continue;
    calls.add(ToolCall(
      (c['id'] ?? '').isEmpty ? 'tool_$k' : c['id']!,
      c['name']!,
      (c['args'] ?? '').isEmpty ? '{}' : c['args']!,
    ));
  }

  return LlmResult(
    text,
    promptTokens: pTok,
    completionTokens: cTok,
    toolCalls: calls,
  );
}
