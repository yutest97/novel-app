import 'models.dart';
import 'skill.dart';

const String _appRules = '''
你现在是一个手机 App 里的「AI 写小说助手」，服务零基础用户。
用户不会写提示词，只能点按钮或说一句大白话，所以每一步你都要替他想清楚，并给他可点的选项。

【技能包怎么用】
下面给你的技能包原文是给桌面 AI 工具写的，里面提到的 create_project、file_write、question 工具在 App 里由界面按钮代替，你不要假装调用工具，只按里面的「流程」和「格式」办事：
- 初始化：按技能包【初始化模式】，把题材、风格等问清楚后，写出三份文档（人物库 / 世界观 / 章节摘要）。
- 写章节：先读三份文档和最近章节，再动笔，一章正文不少于 2000 字。
- 写完后不要自己保存，交回给 App 的「保存」按钮处理。
- 保存之后 App 会再叫你更新资料，你按模板格式给出更新后的三份文档。

【输出格式（硬性要求）】
每次回复只输出一个 JSON 对象，不要加 ``` 代码块，不要在 JSON 前后写任何解释。
字段如下：
{
  "message": "给用户看的话。写章节时这里放本章正文全文；其他时候放一两句引导语",
  "options": [{"label": "选项文字（不超过10个字）", "hint": "一句话说明选它会怎样"}],
  "chapter": {"title": "第X章 标题", "content": "本章正文，不少于2000字"},
  "docs": {"characters": "更新后的人物库全文", "world": "更新后的世界观全文", "summary": "更新后的章节摘要全文"}
}
规则：
1. options 每次给 2~5 个，必须具体到能直接选，不要出现「其他」「自定义」这类词，App 会自动加一个自定义入口。
2. 没在写章节时，chapter 两个字段都留空字符串。
3. 没有更新资料时，docs 留空对象 {}；只有 App 明确说「章节已保存，请更新资料」时才填 docs。
4. 不要输出 JSON 以外的任何字符，不要用 markdown 代码块包裹。
''';

/// 组装 system 提示：App 规则 + 技能包原文 + 当前小说状态
Future<String> buildSystemPrompt(Novel novel) async {
  final skill = await SkillPack.load();
  final buf = StringBuffer();
  buf.writeln(_appRules);
  buf.writeln(skill);
  buf.writeln();
  buf.writeln('【当前小说状态】');
  if (novel.isEmpty) {
    buf.writeln('书名：（还没有，正在初始化）');
    buf.writeln('说明：这是第一次使用，请按技能包【初始化模式】开始，第一轮只问题材，给出 4~5 个常见网文题材选项。');
  } else {
    buf.writeln('书名：${novel.title}');
    buf.writeln('已保存章节数：${novel.chapters.length}');
    buf.writeln();
    buf.writeln('--- 人物库 ---');
    buf.writeln(novel.characters.trim().isEmpty ? '（空）' : novel.characters);
    buf.writeln();
    buf.writeln('--- 世界观 ---');
    buf.writeln(novel.world.trim().isEmpty ? '（空）' : novel.world);
    buf.writeln();
    buf.writeln('--- 章节摘要 ---');
    buf.writeln(novel.summary.trim().isEmpty ? '（空）' : novel.summary);
    buf.writeln();
    buf.writeln('--- 最近章节正文（最多 5 章）---');
    buf.writeln(novel.recentChapters(5));
  }
  return buf.toString();
}

/// 章节保存之后，让模型更新三份维护文档
String buildSyncPrompt(Novel novel) {
  return '【App 内部指令】用户已确认保存「${novel.chapters.isEmpty ? "最新一章" : novel.chapters.last.title}」。'
      '请按技能包【Step 8：更新维护文档】和 references/templates.md 的格式，输出更新后的三份文档。'
      'message 里用一句话说明改了什么；options 里给「继续写下一章」和「我去看看资料」两个选项；chapter 留空。';
}
