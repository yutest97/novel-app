import 'package:flutter/material.dart';

import '../models.dart';
import '../store.dart';

/// 小说资料页：人物库 / 世界观 / 章节摘要 / 章节正文，四栏可切
class KnowledgeScreen extends StatelessWidget {
  const KnowledgeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final st = AppState.I;
    return AnimatedBuilder(
      animation: st,
      builder: (context, _) {
        return DefaultTabController(
          length: 4,
          child: Scaffold(
            appBar: AppBar(
              title: Text(st.novel.title.trim().isEmpty ? '小说资料' : st.novel.title),
              bottom: const TabBar(
                isScrollable: true,
                tabs: [
                  Tab(text: '人物库'),
                  Tab(text: '世界观'),
                  Tab(text: '章节摘要'),
                  Tab(text: '章节正文'),
                ],
              ),
            ),
            body: Column(
              children: [
                Container(
                  width: double.infinity,
                  color: const Color(0xFFEEF0FB),
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  child: const Text(
                    '这些资料由 AI 按技能包自动生成并同步；第一版只读。',
                    style: TextStyle(fontSize: 11, color: Color(0xFF3D4785)),
                  ),
                ),
                Expanded(
                  child: TabBarView(
                    children: [
                      _DocView(text: st.novel.characters, empty: '还没有人物库。写完第一章并点「同步资料」后，这里会自动出现。'),
                      _DocView(text: st.novel.world, empty: '还没有世界观设定。等 AI 问完金手指和力量体系，这里会自动填上。'),
                      _DocView(text: st.novel.summary, empty: '还没有章节摘要。每存一章，摘要会追加一条。'),
                      _ChaptersView(chapters: st.novel.chapters),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _DocView extends StatelessWidget {
  const _DocView({required this.text, required this.empty});

  final String text;
  final String empty;

  @override
  Widget build(BuildContext context) {
    if (text.trim().isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Text(
            empty,
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 13, height: 1.7, color: Colors.grey.shade600),
          ),
        ),
      );
    }
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 30),
      child: SelectableText(
        text,
        style: const TextStyle(fontSize: 14, height: 1.8),
      ),
    );
  }
}

class _ChaptersView extends StatelessWidget {
  const _ChaptersView({required this.chapters});

  final List<Chapter> chapters;

  /// 列表里显示的前 28 个字
  static String _preview(String s) {
    final one = s.replaceAll(RegExp(r'\s+'), ' ').trim();
    return one.length <= 28 ? one : '${one.substring(0, 28)}…';
  }

  @override
  Widget build(BuildContext context) {
    if (chapters.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Text(
            '还没有保存过章节。\n回到「对话」页，写完一章点「保存这一章」，就会出现在这里。',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 13, height: 1.7, color: Colors.grey.shade600),
          ),
        ),
      );
    }
    return ListView.separated(
      padding: const EdgeInsets.symmetric(vertical: 8),
      itemCount: chapters.length,
      separatorBuilder: (_, __) => const Divider(height: 1, indent: 16, endIndent: 16),
      itemBuilder: (context, i) {
        final c = chapters[i];
        return ListTile(
          leading: CircleAvatar(
            radius: 15,
            backgroundColor: const Color(0xFFEEF0FB),
            child: Text('${i + 1}', style: const TextStyle(fontSize: 12, color: Color(0xFF3D4785))),
          ),
          title: Text(c.title, style: const TextStyle(fontSize: 14)),
          subtitle: Text(
            _preview(c.content),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
          ),
          trailing: Text('${c.content.replaceAll(RegExp(r'\s'), '').length} 字',
              style: TextStyle(fontSize: 11, color: Colors.grey.shade500)),
          onTap: () => Navigator.of(context).push(
            MaterialPageRoute(builder: (_) => ChapterDetailPage(chapter: c)),
          ),
        );
      },
    );
  }
}

class ChapterDetailPage extends StatelessWidget {
  const ChapterDetailPage({super.key, required this.chapter});

  final Chapter chapter;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(chapter.title)),
      body: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(18, 16, 18, 40),
        child: SelectableText(
          chapter.content,
          style: const TextStyle(fontSize: 15, height: 1.9),
        ),
      ),
    );
  }
}
