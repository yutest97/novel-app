import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:novel_app/models.dart';
import 'package:novel_app/prompt.dart';
import 'package:novel_app/skill.dart';
import 'package:novel_app/store.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('两条内置技能按原样打进去（内容以用户给的包为准）', () async {
    final text = await SkillPack.load();
    expect(text, contains('小说写作助手'));
    expect(text, contains('初始化模式'));
    expect(text, contains('Step 8'));
    expect(text, contains('2000'));

    final creator = await SkillPack.load('builtin:skill-creator');
    expect(creator, contains('技能创建助手'));
    expect(creator, contains('SKILL.md'));
  });

  test('内置技能的附件都在，主文件排在附件前', () async {
    final writer = await SkillPack.load();
    expect(writer, contains('===== 附件：templates.md ====='));
    expect(writer.indexOf('# 小说写作助手'), lessThan(writer.indexOf('===== 附件')));

    final creator = await SkillPack.load('builtin:skill-creator');
    expect(creator, contains('===== 附件：templates.md ====='));
    expect(creator.indexOf('# 技能创建助手'), lessThan(creator.indexOf('===== 附件')));
  });

  test('提示词里有 App 环境说明，抵消技能里的文件和工具步骤', () async {
    SharedPreferences.setMockInitialValues(<String, Object>{});
    await AppState.I.init();

    final prompt = await buildSystemPrompt(Novel(title: '长夜将至'));
    expect(prompt, contains('【App 环境说明】'));
    expect(prompt, contains('一律跳过'));
    expect(prompt, contains('[人物库]'));
    expect(prompt, contains('没有文件'));
    // 技能原文不做删改，适配放在 App 这一侧
    expect(prompt, contains('skill_lookup'));
    expect(prompt, contains('以这段说明为准'));

    // 你给的技能原文确实在提示里，且排在说明之前（说明在后，模型更容易听后者）
    expect(prompt, contains('使用 `create_project` 工具创建项目'));
    expect(prompt, contains('禁止直接用file_write工具保存文件'));
    expect(prompt, contains('# 人物库'));
    final skillAt = prompt.indexOf('小说写作助手');
    final noteAt = prompt.indexOf('【App 环境说明】');
    expect(skillAt, greaterThanOrEqualTo(0));
    expect(noteAt, greaterThan(skillAt));
  });
}
