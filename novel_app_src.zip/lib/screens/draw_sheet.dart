import 'package:flutter/material.dart';

import '../store.dart';
import '../theme.dart';

/// 抽卡面板：3 份候选并排，选一份留用，其余收进候选
class DrawSheet extends StatelessWidget {
  const DrawSheet({super.key});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: AppState.I,
      builder: (context, _) {
        final st = AppState.I;
        final list = <int>[];
        for (var i = 0; i < st.draws.length; i++) {
          if (!st.draws[i].discarded) list.add(i);
        }
        if (list.isEmpty) {
          // 全丢完了，直接关
          WidgetsBinding.instance.addPostFrameCallback((_) {
            if (Navigator.of(context).canPop()) Navigator.of(context).pop();
          });
        }

        return Container(
          decoration: const BoxDecoration(
            color: C.surface,
            borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
          ),
          child: SafeArea(
            top: false,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 38,
                  height: 4,
                  margin: const EdgeInsets.symmetric(vertical: 10),
                  decoration: BoxDecoration(
                    color: Colors.white24,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(18, 2, 12, 8),
                  child: Row(
                    children: [
                      const Icon(Icons.casino_outlined, size: 18, color: C.purpleSoft),
                      const SizedBox(width: 8),
                      const Text('抽卡模式',
                          style: TextStyle(fontSize: 14.5, fontWeight: FontWeight.w600)),
                      const Spacer(),
                      Text(
                        st.drawing ? '生成中…' : '已完成',
                        style: TextStyle(
                          fontSize: 11,
                          color: st.drawing ? C.purpleSoft : C.dim,
                        ),
                      ),
                    ],
                  ),
                ),
                const Padding(
                  padding: EdgeInsets.fromLTRB(18, 0, 18, 8),
                  child: Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      '同时生成 3 份，选一份留用，其余会存成「其他候选」，随时能换回来。',
                      style: TextStyle(fontSize: 11, height: 1.6, color: C.dim),
                    ),
                  ),
                ),
                Flexible(
                  child: ListView(
                    shrinkWrap: true,
                    padding: const EdgeInsets.fromLTRB(14, 2, 14, 8),
                    children: [
                      for (final i in list) _card(context, st, i),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(14, 0, 14, 10),
                  child: Row(
                    children: [
                      Expanded(
                        child: SizedBox(
                          height: 38,
                          child: OutlinedButton(
                            onPressed: () {
                              st.closeDraw();
                              Navigator.of(context).pop();
                            },
                            style: OutlinedButton.styleFrom(
                              side: const BorderSide(color: C.border),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10),
                              ),
                            ),
                            child: Text(
                              st.drawing ? '取消抽卡' : '都不要',
                              style: const TextStyle(fontSize: 12.5, color: C.dim),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _card(BuildContext context, AppState st, int i) {
    final c = st.draws[i];
    final chars = c.text.replaceAll(RegExp(r'\s'), '').length;
    final ready = c.done && c.text.trim().isNotEmpty;

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
      decoration: BoxDecoration(
        color: C.card,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: ready ? const Color(0xFF3B2F6B) : C.border,
          width: 0.8,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 20,
                height: 20,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: const Color(0x337B5CFF),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Text('${i + 1}',
                    style: const TextStyle(fontSize: 10.5, color: C.purpleSoft)),
              ),
              const SizedBox(width: 8),
              Text(
                c.error != null
                    ? '失败'
                    : (c.done ? '已完成' : '正在写…'),
                style: TextStyle(
                  fontSize: 11.5,
                  color: c.error != null
                      ? const Color(0xFFE8A9A4)
                      : (c.done ? C.green : C.dim),
                ),
              ),
              const Spacer(),
              if (chars > 0)
                Text('$chars 字', style: const TextStyle(fontSize: 10.5, color: C.faint)),
            ],
          ),
          const SizedBox(height: 8),
          if (c.error != null)
            Text(c.error!, style: const TextStyle(fontSize: 11, height: 1.6, color: C.dim))
          else
            Text(
              c.text.trim().isEmpty ? '……' : c.text.trim(),
              maxLines: ready ? 5 : 3,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 12, height: 1.7, color: Color(0xFFD6D6E4)),
            ),
          const SizedBox(height: 10),
          Row(
            children: [
              TextButton(
                onPressed: () => st.discardDraw(i),
                child: const Text('丢弃', style: TextStyle(fontSize: 12, color: C.dim)),
              ),
              const Spacer(),
              SizedBox(
                height: 32,
                child: ElevatedButton(
                  onPressed: ready
                      ? () async {
                          final nav = Navigator.of(context);
                          await st.pickDraw(i);
                          if (nav.canPop()) nav.pop();
                        }
                      : null,
                  style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all<Color>(
                      ready ? C.purple : C.cardHi,
                    ),
                    foregroundColor: MaterialStateProperty.all<Color>(Colors.white),
                    shape: MaterialStateProperty.all(
                      RoundedRectangleBorder(borderRadius: BorderRadius.circular(9)),
                    ),
                  ),
                  child: const Text('用这个', style: TextStyle(fontSize: 12.5)),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
