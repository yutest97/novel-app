import 'package:flutter/material.dart';

import 'screens/app_drawer.dart';
import 'screens/book_shelf_screen.dart';
import 'screens/chat_screen.dart';
import 'screens/settings_screen.dart';
import 'store.dart';
import 'theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await AppState.I.init(); // 先把本地存档读出来，再画界面
  runApp(const NovelApp());
}

class NovelApp extends StatelessWidget {
  const NovelApp({super.key});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: AppState.I,
      builder: (context, _) => MaterialApp(
        title: 'AI 写小说',
        debugShowCheckedModeBanner: false,
        theme: buildDarkTheme(),
        darkTheme: buildDarkTheme(),
        themeMode: AppState.I.settings.themeMode == 'dark'
            ? ThemeMode.dark
            : ThemeMode.system,
        home: const HomeShell(),
      ),
    );
  }
}

/// 全局钥匙：对话页的汉堡按钮靠它打开最外层侧边栏
final GlobalKey<ScaffoldState> homeScaffoldKey = GlobalKey<ScaffoldState>();

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  @override
  Widget build(BuildContext context) {
    // 自己监听状态：否则 goTab() 改了 tabIndex 也不会重画
    return AnimatedBuilder(
      animation: AppState.I,
      builder: (context, _) {
        final st = AppState.I;
        return Scaffold(
          key: homeScaffoldKey,
          drawer: const AppDrawer(),
          body: IndexedStack(
            index: st.tabIndex,
            children: const [
              ChatScreen(),
              BookShelfScreen(),
              SettingsScreen(),
            ],
          ),
          bottomNavigationBar: NavigationBar(
            height: 62,
            selectedIndex: st.tabIndex,
            onDestinationSelected: st.goTab,
            destinations: const [
          NavigationDestination(
            icon: Icon(Icons.chat_bubble_outline, size: 21),
            selectedIcon: Icon(Icons.chat_bubble, size: 21, color: C.purpleSoft),
            label: '对话',
          ),
          NavigationDestination(
            icon: Icon(Icons.menu_book_outlined, size: 21),
            selectedIcon: Icon(Icons.menu_book, size: 21, color: C.purpleSoft),
            label: '小说',
          ),
          NavigationDestination(
            icon: Icon(Icons.settings_outlined, size: 21),
            selectedIcon: Icon(Icons.settings, size: 21, color: C.purpleSoft),
                label: '设置',
              ),
            ],
          ),
        );
      },
    );
  }
}
