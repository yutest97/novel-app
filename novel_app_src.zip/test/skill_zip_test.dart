import 'dart:convert';

import 'package:archive/archive.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:novel_app/skill_import.dart';

List<int> _zip(Map<String, String> files) {
  final a = Archive();
  files.forEach((name, content) {
    final bytes = utf8.encode(content);
    a.addFile(ArchiveFile(name, bytes.length, bytes));
  });
  return ZipEncoder().encode(a)!;
}

void main() {
  test('zip 里找 SKILL.md，连同 references 一起读进来', () {
    final bytes = _zip({
      'novel-writer/SKILL.md': '# 小说写作\n按步骤来。',
      'novel-writer/references/templates.md': '# 模板\n三幕式结构。',
      'novel-writer/README.md': '仓库说明',
    });
    final p = readSkillZip('novel-writer.zip', '/tmp/novel-writer.zip', bytes);

    expect(p.name, 'novel-writer');
    expect(p.content, contains('按步骤来'));
    expect(p.content, contains('三幕式结构'));
    // SKILL.md 排在最前
    expect(p.content.indexOf('SKILL.md'), lessThan(p.content.indexOf('references/templates.md')));
  });

  test('没有 SKILL.md 时用里面的 md，名字取 zip 名', () {
    final bytes = _zip({'我的技能.md': '只有正文'});
    final p = readSkillZip('我的技能.zip', '', bytes);
    expect(p.name, '我的技能');
    expect(p.content, contains('只有正文'));
  });

  test('zip 里没有 md/txt 就报错', () {
    final bytes = _zip({'data.json': '{}'});
    expect(
      () => readSkillZip('x.zip', '', bytes),
      throwsA(isA<SkillPickException>()),
    );
  });

  test('打不开的 zip 给出可读提示', () {
    expect(
      () => readSkillZip('bad.zip', '', utf8.encode('这不是压缩包')),
      throwsA(isA<SkillPickException>()),
    );
  });

  test('包太大时截断并注明', () {
    final bytes = _zip({'huge/SKILL.md': '字' * (kSkillPackMaxChars + 1000)});
    final p = readSkillZip('huge.zip', '', bytes);
    expect(p.content, contains('技能包太大'));
  });

  test('多个文件时带路径分隔标记，方便模型分清附件', () {
    final bytes = _zip({
      'a/SKILL.md': '主文件',
      'a/references/x.md': '参考文件',
    });
    final p = readSkillZip('a.zip', '', bytes);
    expect(p.content, contains('===== a/SKILL.md 原文开始 ====='));
    expect(p.content, contains('===== a/references/x.md 原文结束 ====='));
  });
}
