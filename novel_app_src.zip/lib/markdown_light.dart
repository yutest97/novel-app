import 'package:flutter/material.dart';

import 'theme.dart';

/// 极简 Markdown 显示：标题、粗体、行内代码、列表、引用、分隔线、代码块。
/// 只做「看得舒服」，不做完整语法（表格、图片等按原文显示）。
class MarkdownText extends StatelessWidget {
  const MarkdownText(
    this.text, {
    super.key,
    this.style,
    this.selectable = true,
  });

  final String text;
  final TextStyle? style;
  final bool selectable;

  @override
  Widget build(BuildContext context) {
    final base = style ??
        const TextStyle(fontSize: 14, height: 1.68, color: Color(0xFFE3E3EE));
    final span = TextSpan(style: base, children: buildMarkdownSpans(text, base));
    if (!selectable) return RichText(text: span);
    return SelectableText.rich(span);
  }
}

/// 把 Markdown 拆成带样式的 TextSpan，供气泡使用
List<InlineSpan> buildMarkdownSpans(String text, TextStyle base) {
  final out = <InlineSpan>[];
  final lines = text.replaceAll('\r\n', '\n').replaceAll('\r', '\n').split('\n');
  var inCode = false;

  for (var i = 0; i < lines.length; i++) {
    final raw = lines[i];
    final line = raw.trimRight();
    final trimmed = line.trimLeft();

    if (trimmed.startsWith('```')) {
      inCode = !inCode;
      continue;
    }
    if (inCode) {
      out.add(TextSpan(
        text: '$line\n',
        style: base.copyWith(
          fontFamily: 'monospace',
          fontSize: (base.fontSize ?? 14) - 0.5,
          height: 1.55,
          color: C.purpleSoft,
        ),
      ));
      continue;
    }

    // 空行
    if (trimmed.isEmpty) {
      out.add(TextSpan(text: '\n', style: base));
      continue;
    }

    // 分隔线
    if (RegExp(r'^([-*_])\1{2,}$').hasMatch(trimmed)) {
      out.add(TextSpan(
        text: '──────────\n',
        style: base.copyWith(color: C.faint, fontSize: 11),
      ));
      continue;
    }

    // 标题
    final h = RegExp(r'^(#{1,6})\s+(.*)$').firstMatch(trimmed);
    if (h != null) {
      final level = h.group(1)!.length;
      final size = switch (level) {
        1 => 19.0,
        2 => 17.0,
        3 => 15.6,
        _ => 14.6,
      };
      if (out.isNotEmpty) out.add(TextSpan(text: '\n', style: base));
      out.addAll(_inline(
        h.group(2)!.trim(),
        base.copyWith(fontSize: size, fontWeight: FontWeight.w700, height: 1.45,
            color: const Color(0xFFF2F2F8)),
      ));
      out.add(TextSpan(text: '\n', style: base));
      continue;
    }

    // 引用
    if (trimmed.startsWith('>')) {
      final body = trimmed.replaceFirst(RegExp(r'^>\s?'), '');
      out.add(TextSpan(text: '│ ', style: base.copyWith(color: C.faint)));
      out.addAll(_inline(body, base.copyWith(color: C.dim, height: 1.6)));
      out.add(TextSpan(text: '\n', style: base));
      continue;
    }

    // 无序列表
    final bullet = RegExp(r'^[-*•·]\s+(.*)$').firstMatch(trimmed);
    if (bullet != null) {
      out.add(TextSpan(text: '  • ', style: base.copyWith(color: C.purpleSoft)));
      out.addAll(_inline(bullet.group(1)!, base));
      out.add(TextSpan(text: '\n', style: base));
      continue;
    }

    // 有序列表
    final num = RegExp(r'^(\d{1,2}[.、)）])\s+(.*)$').firstMatch(trimmed);
    if (num != null) {
      out.add(TextSpan(text: '  ${num.group(1)} ', style: base.copyWith(color: C.dim)));
      out.addAll(_inline(num.group(2)!, base));
      out.add(TextSpan(text: '\n', style: base));
      continue;
    }

    out.addAll(_inline(trimmed, base));
    out.add(TextSpan(text: '\n', style: base));
  }

  // 去掉末尾多余的换行
  if (out.isNotEmpty && out.last is TextSpan && (out.last as TextSpan).text == '\n') {
    out.removeLast();
  }
  return out;
}

/// 行内样式：**粗体**、`代码`、*斜体*
List<InlineSpan> _inline(String text, TextStyle base) {
  final out = <InlineSpan>[];
  final re = RegExp(r'(\*\*[^*]+\*\*|`[^`]+`|\*[^*\n]+\*)');
  var last = 0;
  for (final m in re.allMatches(text)) {
    if (m.start > last) out.add(TextSpan(text: text.substring(last, m.start), style: base));
    final token = m.group(0)!;
    if (token.startsWith('**')) {
      out.add(TextSpan(
        text: token.substring(2, token.length - 2),
        style: base.copyWith(fontWeight: FontWeight.w700, color: const Color(0xFFF2F2F8)),
      ));
    } else if (token.startsWith('`')) {
      out.add(TextSpan(
        text: token.substring(1, token.length - 1),
        style: base.copyWith(
          fontFamily: 'monospace',
          fontSize: (base.fontSize ?? 14) - 0.5,
          color: C.purpleSoft,
        ),
      ));
    } else {
      out.add(TextSpan(
        text: token.substring(1, token.length - 1),
        style: base.copyWith(fontStyle: FontStyle.italic, color: C.dim),
      ));
    }
    last = m.end;
  }
  if (last < text.length) out.add(TextSpan(text: text.substring(last), style: base));
  return out;
}
