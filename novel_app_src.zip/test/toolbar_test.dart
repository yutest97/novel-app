import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:novel_app/main.dart';
import 'package:novel_app/models.dart';
import 'package:novel_app/screens/blurb_sheet.dart';
import 'package:novel_app/screens/deconstruct_sheet.dart';
import 'package:novel_app/screens/distill_sheet.dart';
import 'package:novel_app/screens/idea_sheet.dart';
import 'package:novel_app/screens/naming_sheet.dart';
import 'package:novel_app/screens/notes_page.dart';
import 'package:novel_app/screens/scan_sheet.dart';
import 'package:novel_app/store.dart';
import 'package:novel_app/theme.dart';

Future<void> _loadFonts() async {
  final cjk = File('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc').readAsBytesSync();
  for (final f in ['CJK', 'monospace', 'Roboto']) {
    await (FontLoader(f)..addFont(Future.value(ByteData.view(cjk.buffer)))).load();
  }
  final icon = File('/opt/f3/flutter/bin/cache/artifacts/material_fonts/MaterialIcons-Regular.otf').readAsBytesSync();
  await (FontLoader('MaterialIcons')..addFont(Future.value(ByteData.view(icon.buffer)))).load();
}

Widget _wrap(Widget home, {double scale = 1.0}) {
  final t = buildDarkTheme();
  return MaterialApp(
    debugShowCheckedModeBanner: false,
    theme: t.copyWith(
      textTheme: t.textTheme.apply(fontFamily: 'CJK'),
      primaryTextTheme: t.primaryTextTheme.apply(fontFamily: 'CJK'),
      appBarTheme: t.appBarTheme.copyWith(
        titleTextStyle: (t.appBarTheme.titleTextStyle ?? const TextStyle())
            .copyWith(fontFamily: 'CJK', color: const Color(0xFFEDEDF5)),
      ),
    ),
    builder: (context, child) => MediaQuery(
      data: MediaQuery.of(context).copyWith(textScaler: TextScaler.linear(scale)),
      child: child!,
    ),
    home: home,
  );
}

Future<void> _setup(WidgetTester tester, {String model = 'deepseek-flash'}) async {
  SharedPreferences.setMockInitialValues(<String, Object>{});
  await AppState.I.init();
  final b = Novel(title: '灰烬纪元');
  AppState.I.books = [b];
  AppState.I.currentId = b.id;
  AppState.I.settings.model = model;
  AppState.I.goTab(0);
}

void _size(WidgetTester tester, Size size) {
  tester.view.physicalSize = size;
  tester.view.devicePixelRatio = 3.0;
  addTearDown(tester.view.resetPhysicalSize);
  addTearDown(tester.view.resetDevicePixelRatio);
}

void main() {
  setUp(() async => _loadFonts());

  testWidgets('顶部每个按钮都能点开', (tester) async {
    _size(tester, const Size(1080, 2280));
    await _setup(tester);
    await tester.pumpWidget(_wrap(const HomeShell()));
    await tester.pumpAndSettle();

    Future<void> openAndClose(String label, Finder expected) async {
      final chip = find.text(label);
      expect(chip, findsWidgets, reason: '找不到按钮：$label');
      await tester.ensureVisible(chip.first);
      await tester.pumpAndSettle();
      await tester.tap(chip.first);
      await tester.pumpAndSettle();
      expect(expected, findsWidgets, reason: '$label 点了没打开');
      // 关掉：全屏页返回，面板点关闭/下滑
      if (find.byType(NotesPage).evaluate().isNotEmpty) {
        final ctx = tester.element(find.byType(NotesPage));
        Navigator.of(ctx).pop();
      } else {
        final ctx = tester.element(find.byType(Scaffold).first);
        Navigator.of(ctx).pop();
      }
      await tester.pumpAndSettle();
    }

    await openAndClose('备忘录', find.byType(NotesPage));
    await openAndClose('起名', find.byType(NamingSheet));
    await openAndClose('扫榜', find.byType(ScanSheet));
    await openAndClose('脑洞', find.byType(IdeaSheet));
    await openAndClose('简介', find.byType(BlurbSheet));
    await openAndClose('蒸馏', find.byType(DistillSheet));
    await openAndClose('拆解', find.byType(DeconstructSheet));
  });

  testWidgets('窄屏 + 长模型名不溢出', (tester) async {
    _size(tester, const Size(960, 2280));
    await _setup(tester, model: 'qwen-max-longcontext-preview');
    await tester.pumpWidget(_wrap(const HomeShell()));
    await tester.pumpAndSettle();
    // 溢出在测试里会直接抛异常，能跑到这里说明没溢出
    expect(find.byType(HomeShell), findsOneWidget);
  });

  testWidgets('大字号也不溢出', (tester) async {
    _size(tester, const Size(1080, 2280));
    await _setup(tester);
    await tester.pumpWidget(_wrap(const HomeShell(), scale: 1.25));
    await tester.pumpAndSettle();
    expect(find.byType(HomeShell), findsOneWidget);
  });
}
