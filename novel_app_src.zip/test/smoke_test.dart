import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:novel_app/main.dart';
import 'package:novel_app/skill.dart';
import 'package:novel_app/store.dart';

void main() {
  testWidgets('打开 App 能看到三个页签和开场引导', (tester) async {
    SharedPreferences.setMockInitialValues(<String, Object>{});
    await AppState.I.init();
    await tester.pumpWidget(const NovelApp());
    await tester.pumpAndSettle();

    expect(find.text('对话'), findsWidgets);
    expect(find.text('小说资料'), findsWidgets);
    expect(find.text('设置'), findsWidgets);
    expect(find.text('开始新建一本'), findsOneWidget);
  });

  test('技能包能被读到', () async {
    final text = await SkillPack.load();
    expect(text.contains('小说写作助手'), isTrue);
    expect(text.contains('人物库'), isTrue);
  });
}
