import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import 'package:novel_app/lan_sync.dart';
import 'package:novel_app/models.dart';
import 'package:novel_app/store.dart';
import 'package:novel_app/webdav.dart';

const String _base = 'http://127.0.0.1:8777';

WebDavConfig _cfg({String path = '/dav/OpenWrite/'}) =>
    WebDavConfig(url: _base, user: 'u', pass: 'p', path: path);

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  setUpAll(() => HttpOverrides.global = null);

  group('备份与恢复', () {
    setUp(() async {
      SharedPreferences.setMockInitialValues(<String, Object>{});
      await AppState.I.init();
      AppState.I.books.clear();
      AppState.I.currentId = '';
    });

    test('导出再导入，书、章节、备忘录都回来', () async {
      final st = AppState.I;
      final a = Novel(title: '灰烬纪元')
        ..characters = '叶烬'
        ..chapters = [Chapter(title: '第1章 雨夜', content: '雨停了。')]
        ..notes = [Note(text: '伏笔：妹妹的名字', category: '大纲')];
      final b = Novel(title: '夜班守则')
        ..chapters = [Chapter(title: '第1章 交接', content: '凌晨两点。')];
      st.books = [a, b];
      st.currentId = b.id;

      final json = st.exportBackupJson();
      expect(json.contains('灰烬纪元'), isTrue);
      expect(json.contains('妹妹的名字'), isTrue);

      // 清空后恢复
      st.books.clear();
      st.currentId = '';
      final msg = await st.importBackupJson(json);

      expect(st.books.length, 2);
      expect(msg.contains('2 本书'), isTrue);
      expect(st.books.first.title, '灰烬纪元');
      expect(st.books.first.chapters.first.content, '雨停了。');
      expect(st.books.first.notes.length, 1);
      expect(st.currentId, st.books.firstWhere((x) => x.title == '夜班守则').id);
    });

    test('坏备份给出明确错误，不动现有数据', () async {
      final st = AppState.I;
      st.books = [Novel(title: '保留我')];
      st.currentId = st.books.first.id;

      expect(
        () => st.importBackupJson('not json'),
        throwsA(isA<FormatException>()),
      );
      expect(
        () => st.importBackupJson('{"books": "oops"}'),
        throwsA(isA<FormatException>()),
      );
      expect(st.books.length, 1);
      expect(st.books.first.title, '保留我');
    });

    test('重置保留作品与 Key，清掉聊天和自定义参数', () async {
      final st = AppState.I;
      final a = Novel(title: '灰烬纪元')
        ..chats = [ChatBubble(role: 'user', text: '你好')]
        ..notes = [Note(text: '留着')];
      st.books = [a];
      st.currentId = a.id;
      st.settings
        ..apiKey = 'sk-test'
        ..customPrompt = '自定义'
        ..importedSkills.add(SkillDoc(id: 'x', name: 'x', content: 'x'));

      await st.resetUserData();

      expect(st.books.length, 1);
      expect(st.books.first.chats, isEmpty);
      expect(st.books.first.notes.length, 1);
      expect(st.settings.apiKey, 'sk-test');
      expect(st.settings.customPrompt, '');
      expect(st.settings.importedSkills, isEmpty);
    });
  });

  group('WebDAV', () {
    test('目录不存在会自动创建，上传后能下载', () async {
      final cfg = _cfg();
      await ensureWebDavDir(cfg);

      const payload = '{"app":"novel_app","books":[]}';
      await uploadWebDavBackup(cfg, payload);

      final back = await downloadWebDavBackup(cfg);
      expect(back, payload);
    });

    test('云端没备份时给出可操作的提示', () async {
      final cfg = _cfg(path: '/dav/Empty/');
      expect(
        () => downloadWebDavBackup(cfg),
        throwsA(predicate((e) => e.toString().contains('云端还没有备份'))),
      );
    });
  });

  test('局域网：开启后能通过 HTTP 下载到备份', () async {
    SharedPreferences.setMockInitialValues(<String, Object>{});
    await AppState.I.init();
    AppState.I.books = [Novel(title: '局域网之书')];

    final urls = await LanSyncServer.start(() => AppState.I.exportBackupJson());
    expect(urls, isNotEmpty);
    final uri = Uri.parse('http://127.0.0.1:${LanSyncServer.port}/backup.json');
    final resp = await http.get(uri);
    expect(resp.statusCode, 200);
    expect(resp.body.contains('局域网之书'), isTrue);

    await LanSyncServer.stop();
    expect(LanSyncServer.running, isFalse);
  });
}
