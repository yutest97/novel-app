import 'package:flutter/material.dart';

import '../models.dart';
import '../store.dart';
import '../theme.dart';
import '../web_search.dart';

/// 联网搜索设置面板：通道、Key、条数、测试
class SearchSheet extends StatefulWidget {
  const SearchSheet({super.key});

  @override
  State<SearchSheet> createState() => _SearchSheetState();
}

class _SearchSheetState extends State<SearchSheet> {
  late String _provider;
  late int _count;
  late final TextEditingController _key;
  final TextEditingController _test = TextEditingController();

  bool _busy = false;
  String? _error;
  List<WebSource> _preview = const [];

  @override
  void initState() {
    super.initState();
    final s = AppState.I.settings;
    _provider = s.searchProvider;
    _count = s.searchCount;
    _key = TextEditingController(text: s.searchKey);
  }

  @override
  void dispose() {
    _key.dispose();
    _test.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    await AppState.I.saveSearchConfig(
      provider: _provider,
      key: _key.text,
      count: _count,
    );
  }

  Future<void> _runTest() async {
    final q = _test.text.trim();
    if (q.isEmpty) {
      setState(() => _error = '先写一个测试搜索词');
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
      _preview = const [];
    });
    await _save();
    try {
      final list = await AppState.I.runSearchOnce(q);
      if (!mounted) return;
      setState(() => _preview = list.take(3).toList());
    } on WebSearchException catch (e) {
      if (!mounted) return;
      setState(() => _error = e.message);
    } catch (e) {
      if (!mounted) return;
      setState(() => _error = '搜索出错了：$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final st = AppState.I;
    final enabled = st.settings.searchEnabled;
    final isBocha = _provider == 'bocha';

    return Container(
      decoration: const BoxDecoration(
        color: C.surface,
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: SafeArea(
        top: false,
        child: Padding(
          padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: Container(
                    width: 38,
                    height: 4,
                    margin: const EdgeInsets.symmetric(vertical: 10),
                    decoration: BoxDecoration(
                      color: Colors.white24,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(18, 0, 18, 10),
                  child: Row(
                    children: [
                      const Icon(Icons.language, size: 17, color: C.purpleSoft),
                      const SizedBox(width: 8),
                      const Text('联网搜索',
                          style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
                      const Spacer(),
                      Switch(
                        value: enabled,
                        activeColor: Colors.white,
                        activeTrackColor: C.purple,
                        inactiveThumbColor: const Color(0xFFBFC2D4),
                        inactiveTrackColor: C.cardHi,
                        onChanged: (v) async {
                          await st.setSearchEnabled(v);
                          if (mounted) setState(() {});
                        },
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(18, 0, 18, 12),
                  child: Text(
                    enabled
                        ? '开：Agent 模式下模型会自己决定什么时候搜；普通模式下每轮先搜一次再回答。'
                        : '关：完全按自己的知识回答，不联网。',
                    style: const TextStyle(fontSize: 10.5, height: 1.6, color: C.dim),
                  ),
                ),
                const Padding(
                  padding: EdgeInsets.fromLTRB(18, 0, 18, 6),
                  child: Text('通道', style: TextStyle(fontSize: 11.5, color: C.faint)),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 18),
                  child: Row(
                    children: [
                      _providerChip(
                        '必应（免 Key）',
                        _provider == 'bing',
                        () => setState(() => _provider = 'bing'),
                      ),
                      const SizedBox(width: 8),
                      _providerChip(
                        '博查（需 Key）',
                        _provider == 'bocha',
                        () => setState(() => _provider = 'bocha'),
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(18, 8, 18, 0),
                  child: Text(
                    isBocha
                        ? '博查是国内可直连的搜索 API，按次计费，新用户有免费额度。'
                            '去 open.bochaai.com 注册，拿 sk- 开头的 Key。'
                        : '抓必应的结果页，不需要 Key。被要求验证或结构变了会失败，'
                            '失败时不会假装搜到，会明确提示你换通道。',
                    style: const TextStyle(fontSize: 10, height: 1.6, color: C.faint),
                  ),
                ),
                if (isBocha) ...[
                  const SizedBox(height: 10),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 18),
                    child: TextField(
                      controller: _key,
                      obscureText: true,
                      style: const TextStyle(fontSize: 12.5, color: C.text),
                      decoration: _inputDeco('博查 Key，sk- 开头'),
                    ),
                  ),
                ],
                const SizedBox(height: 14),
                Padding(
                  padding: const EdgeInsets.fromLTRB(18, 0, 18, 6),
                  child: Row(
                    children: [
                      const Text('每次取几条', style: TextStyle(fontSize: 11.5, color: C.faint)),
                      const Spacer(),
                      Text('$_count 条', style: const TextStyle(fontSize: 11.5, color: C.purpleSoft)),
                    ],
                  ),
                ),
                Slider(
                  value: _count.toDouble(),
                  min: 3,
                  max: 10,
                  divisions: 7,
                  activeColor: C.purple,
                  onChanged: (v) => setState(() => _count = v.round()),
                ),
                const Divider(height: 22, color: C.border),
                const Padding(
                  padding: EdgeInsets.fromLTRB(18, 0, 18, 6),
                  child: Text('测试一下', style: TextStyle(fontSize: 11.5, color: C.faint)),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 18),
                  child: Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: _test,
                          style: const TextStyle(fontSize: 12.5, color: C.text),
                          decoration: _inputDeco('例如：2026 年 10 月 都市小说 畅销榜'),
                        ),
                      ),
                      const SizedBox(width: 8),
                      SizedBox(
                        height: 42,
                        child: ElevatedButton(
                          onPressed: _busy ? null : _runTest,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: C.purple,
                            elevation: 0,
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(9)),
                          ),
                          child: Text(
                            _busy ? '搜索中…' : '测试',
                            style: const TextStyle(fontSize: 12, color: Colors.white),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                if (_error != null)
                  Padding(
                    padding: const EdgeInsets.fromLTRB(18, 10, 18, 0),
                    child: Text(
                      _error!,
                      style: const TextStyle(fontSize: 11, height: 1.6, color: Color(0xFFE0736E)),
                    ),
                  ),
                if (_preview.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.fromLTRB(18, 10, 18, 0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('搜到 ${_preview.length} 条（预览）',
                            style: const TextStyle(fontSize: 10.5, color: C.green)),
                        const SizedBox(height: 6),
                        for (var i = 0; i < _preview.length; i++)
                          Padding(
                            padding: const EdgeInsets.only(bottom: 8),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  '[${i + 1}] ${_preview[i].title}',
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                      fontSize: 11.5, height: 1.4, color: C.text),
                                ),
                                Text(
                                  _preview[i].site,
                                  style: const TextStyle(fontSize: 9.5, color: C.faint),
                                ),
                              ],
                            ),
                          ),
                      ],
                    ),
                  ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(18, 14, 18, 10),
                  child: SizedBox(
                    height: 44,
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () async {
                        await _save();
                        if (mounted) Navigator.of(context).pop();
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: C.purple,
                        elevation: 0,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                      ),
                      child: const Text('保存',
                          style: TextStyle(fontSize: 13, color: Colors.white)),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  InputDecoration _inputDeco(String hint) => InputDecoration(
        hintText: hint,
        hintStyle: const TextStyle(fontSize: 11.5, color: C.faint),
        filled: true,
        fillColor: C.card,
        isDense: true,
        contentPadding: const EdgeInsets.symmetric(horizontal: 11, vertical: 12),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: const BorderSide(color: C.border, width: 0.7),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: const BorderSide(color: C.border, width: 0.7),
        ),
      );

  Widget _providerChip(String label, bool on, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(8),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: on ? C.purple : C.card,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: on ? C.purple : C.border, width: 0.6),
        ),
        child: Text(
          label,
          style: TextStyle(fontSize: 11.5, color: on ? Colors.white : C.dim),
        ),
      ),
    );
  }
}
