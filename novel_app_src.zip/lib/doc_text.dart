import 'dart:convert';

import 'package:archive/archive.dart';

/// 从上传的文件里取出纯文本：支持 txt / md / docx
String extractText(String fileName, List<int> bytes) {
  final lower = fileName.toLowerCase();
  if (lower.endsWith('.docx')) {
    return _docxToText(bytes);
  }
  // txt / md 按 UTF-8 解，解不开就按 GBK 的宽松方式当二进制忽略
  return utf8.decode(bytes, allowMalformed: true);
}

/// docx 就是 zip，正文在 word/document.xml 里
String _docxToText(List<int> bytes) {
  try {
    final archive = ZipDecoder().decodeBytes(bytes);
    for (final f in archive) {
      if (f.name == 'word/document.xml') {
        final xml = utf8.decode(f.content as List<int>, allowMalformed: true);
        // 段落标签换行，其余标签去掉
        var text = xml
            .replaceAll(RegExp(r'</w:p>'), '\n')
            .replaceAll(RegExp(r'<w:br[^>]*/>'), '\n')
            .replaceAll(RegExp(r'<[^>]+>'), '');
        text = text
            .replaceAll('&amp;', '&')
            .replaceAll('&lt;', '<')
            .replaceAll('&gt;', '>')
            .replaceAll('&quot;', '"')
            .replaceAll('&apos;', "'");
        return text.replaceAll(RegExp(r'\n{3,}'), '\n\n').trim();
      }
    }
  } catch (_) {
    // 坏文件走下面返回空
  }
  return '';
}
