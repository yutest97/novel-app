import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';

import 'package:fast_gbk/fast_gbk.dart';
import 'package:html/dom.dart' as dom;
import 'package:html/parser.dart' as html_parser;
import 'package:http/http.dart' as http;

/// 抓取失败时抛这个，界面上直接显示 message
class NovelFetchException implements Exception {
  final String message;
  NovelFetchException(this.message);
  @override
  String toString() => message;
}

class SourceBook {
  final String title;
  final String url;
  final int score;
  const SourceBook(this.title, this.url, this.score);
}

class SourceChapter {
  final String title;
  final String url;
  const SourceChapter(this.title, this.url);
}

const String _ua =
    'Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36';

/// 把用户填的域名补成 https://xxx
String normalizeBase(String raw) {
  var s = raw.trim();
  if (s.isEmpty) return '';
  if (!s.startsWith('http://') && !s.startsWith('https://')) {
    s = 'https://$s';
  }
  while (s.endsWith('/')) {
    s = s.substring(0, s.length - 1);
  }
  return s;
}

/// 按页面 meta charset 解码，兼容 GBK 站
String _decode(Uint8List bytes) {
  final head = latin1.decode(
    bytes.length > 2048 ? bytes.sublist(0, 2048) : bytes,
    allowInvalid: true,
  ).toLowerCase();
  final m = RegExp(r"""charset\s*=\s*["']?([a-z0-9\-]+)""").firstMatch(head);
  final cs = m?.group(1) ?? 'utf-8';
  if (cs.contains('gbk') || cs.contains('gb2312') || cs.contains('gb18030')) {
    try {
      return gbk.decode(bytes);
    } catch (_) {
      return utf8.decode(bytes, allowMalformed: true);
    }
  }
  return utf8.decode(bytes, allowMalformed: true);
}

Future<String> _get(String url) async {
  final uri = Uri.tryParse(url);
  if (uri == null || !uri.hasScheme) {
    throw NovelFetchException('链接不对：$url');
  }
  http.Response resp;
  try {
    resp = await http.get(uri, headers: {
      'User-Agent': _ua,
      'Accept': 'text/html,application/xhtml+xml,*/*;q=0.8',
      'Accept-Language': 'zh-CN,zh;q=0.9',
    }).timeout(const Duration(seconds: 15));
  } on TimeoutException {
    throw NovelFetchException('请求超时了。站点可能很慢，或者被你的网络挡了。');
  } catch (e) {
    throw NovelFetchException('连不上这个站点：$e');
  }
  if (resp.statusCode != 200) {
    throw NovelFetchException('站点返回 ${resp.statusCode}，可能被拦截了（反爬）。');
  }
  return _decode(resp.bodyBytes);
}

/// 搜书：依次试几种常见搜索路径，返回第一个有结果的
Future<List<SourceBook>> searchBooks(String base, String keyword) async {
  final b = normalizeBase(base);
  if (b.isEmpty) throw NovelFetchException('先在设置里填一个书源域名。');
  final kw = keyword.trim();
  if (kw.isEmpty) throw NovelFetchException('请输入书名。');

  final q = Uri.encodeComponent(kw);
  final paths = [
    '/search?q=$q',
    '/search?keyword=$q',
    '/search.php?keyword=$q',
    '/s?q=$q',
    '/search/?q=$q',
    '/search/$q',
  ];

  final errors = <String>[];
  for (final p in paths) {
    try {
      final text = await _get('$b$p');
      final books = _parseSearch(text, '$b$p', kw);
      if (books.isNotEmpty) return books;
    } on NovelFetchException catch (e) {
      errors.add(e.message);
    }
  }
  if (errors.isNotEmpty) {
    throw NovelFetchException('这个站点搜不出来。\n${errors.first}');
  }
  throw NovelFetchException('搜不到「$kw」。可能路径不对，或者站点靠 JS 渲染内容。');
}

List<SourceBook> _parseSearch(String htmlText, String pageUrl, String keyword) {
  final doc = html_parser.parse(htmlText);
  final baseUri = Uri.parse(pageUrl);
  final key = keyword.length >= 2 ? keyword.substring(0, 2) : keyword;
  final out = <SourceBook>[];
  final seen = <String>{};

  for (final a in doc.querySelectorAll('a')) {
    final href = a.attributes['href'];
    final text = a.text.trim().replaceAll(RegExp(r'\s+'), ' ');
    if (href == null || text.isEmpty) continue;
    if (text.length < 2 || text.length > 40) continue;
    if (!text.contains(key)) continue;

    final u = baseUri.resolve(href).toString();
    if (!u.startsWith('http') || seen.contains(u)) continue;
    seen.add(u);

    final score = text == keyword
        ? 100
        : (text.contains(keyword) ? 85 : 60);
    out.add(SourceBook(text, u, score));
    if (out.length >= 60) break;
  }
  out.sort((a, b) => b.score.compareTo(a.score));
  return out;
}

/// 拉目录：找所有「第X章」链接
Future<List<SourceChapter>> fetchChapters(String bookUrl) async {
  final text = await _get(bookUrl);
  final doc = html_parser.parse(text);
  final baseUri = Uri.parse(bookUrl);
  final re = RegExp(r'第\s*[0-9０-９一二三四五六七八九十百千零两]+\s*[章节回]');
  final out = <SourceChapter>[];
  final seen = <String>{};

  for (final a in doc.querySelectorAll('a')) {
    final t = a.text.trim().replaceAll(RegExp(r'\s+'), ' ');
    if (t.isEmpty || t.length > 40 || !re.hasMatch(t)) continue;
    final href = a.attributes['href'];
    if (href == null) continue;
    final u = baseUri.resolve(href).toString();
    if (!u.startsWith('http') || seen.contains(u)) continue;
    seen.add(u);
    out.add(SourceChapter(t, u));
  }

  if (out.isEmpty) {
    throw NovelFetchException('这个页面没找到章节链接。可能目录在另一个页面，或者要 JS 加载。');
  }
  return out;
}

/// 抓一章正文：先找常见容器，找不到就取全页文字最多的 div
Future<String> fetchChapterContent(String chapterUrl) async {
  final text = await _get(chapterUrl);
  final doc = html_parser.parse(text);
  for (final bad in doc.querySelectorAll('script,style,nav,header,footer,iframe')) {
    bad.remove();
  }

  dom.Element? best;
  var bestLen = 0;

  const prefer = [
    '#content',
    '#chaptercontent',
    '#booktxt',
    '.content',
    '.chapter-content',
    '.read-content',
    '.txt',
  ];
  for (final sel in prefer) {
    for (final el in doc.querySelectorAll(sel)) {
      final n = el.text.replaceAll(RegExp(r'\s'), '').length;
      if (n > bestLen) {
        best = el;
        bestLen = n;
      }
    }
  }
  if (bestLen < 200) {
    for (final el in doc.querySelectorAll('div')) {
      final n = el.text.replaceAll(RegExp(r'\s'), '').length;
      if (n > bestLen) {
        best = el;
        bestLen = n;
      }
    }
  }

  if (best == null || bestLen < 100) {
    throw NovelFetchException('这页没抓到正文，可能内容由 JS 动态加载。');
  }

  var body = best.text;
  body = body.replaceAll('\r\n', '\n').replaceAll('\r', '\n');
  body = body.replaceAll(RegExp(r'[ \t\u00a0]+'), ' ');
  body = body.replaceAll(RegExp(r'\n{3,}'), '\n\n');
  return body.trim();
}

/// 把若干章拼成一段给模型看的文本，超长自动截断
String joinChapters(List<SourceChapter> picked, List<String> contents, {int max = 15000}) {
  final buf = StringBuffer();
  var used = 0;
  for (var i = 0; i < picked.length && i < contents.length; i++) {
    final chunk = '${picked[i].title}\n${contents[i]}\n\n';
    if (used + chunk.length > max) break;
    buf.write(chunk);
    used += chunk.length;
  }
  return buf.toString();
}

/// 榜单里的一本书
class RankBook {
  final String title;
  final String extra; // 作者 / 题材等补充信息，可能为空
  final String url;
  const RankBook(this.title, this.extra, this.url);
}

/// 抓榜单页：按文档顺序抽出书名链接，最多 50 条
Future<List<RankBook>> fetchRanking(String pageUrl) async {
  final text = await _get(pageUrl);
  final doc = html_parser.parse(text);
  for (final bad in doc.querySelectorAll('script,style,nav,header,footer,iframe')) {
    bad.remove();
  }
  final baseUri = Uri.parse(pageUrl);

  const skip = {
    '首页', '排行', '排行榜', '榜单', '全部', '更多', '上一页', '下一页', '登录', '注册',
    '目录', '书架', '完本', '连载', '免费', '充值', '客户端', '下载', '我的', '搜索',
    '分类', '全部作品', '查看全部', '展开', '收起', '加入书架', '开始阅读', '投票',
  };

  final out = <RankBook>[];
  final seenTitle = <String>{};

  bool looksLikeBook(String href) {
    final h = href.toLowerCase();
    return h.contains('/book/') ||
        h.contains('/info/') ||
        h.contains('/novel/') ||
        h.contains('/b/') ||
        h.contains('bookid=') ||
        RegExp(r'/\d{3,}/?$').hasMatch(h);
  }

  for (final a in doc.querySelectorAll('a')) {
    final href = a.attributes['href'];
    var title = a.text.trim().replaceAll(RegExp(r'\s+'), ' ');
    // 去掉书名号 / 方括号
    title = title.replaceAll(RegExp(r'^[《【\[]+|[》】\]]+$'), '').trim();
    if (href == null || title.isEmpty) continue;
    if (title.length < 2 || title.length > 30) continue;
    if (skip.contains(title)) continue;
    if (RegExp(r'第\s*[0-9一二三四五六七八九十百千零两]+\s*[章节回]').hasMatch(title)) continue;
    if (!looksLikeBook(href)) continue;

    final u = baseUri.resolve(href).toString();
    if (!u.startsWith('http') || seenTitle.contains(title)) continue;
    seenTitle.add(title);

    // 从最近的 li / 卡片容器里取作者等补充信息
    var extra = '';
    var p = a.parent;
    for (var depth = 0; depth < 4 && p != null; depth++) {
      if (p.localName == 'li' || p.localName == 'div' || p.localName == 'tr') {
        final t = p.text.replaceAll(RegExp(r'\s+'), ' ').trim();
        var rest = t.replaceFirst(title, '').trim();
        rest = rest.replaceAll(RegExp(r'^[《》【】\[\]\s]+'), '');
        if (rest.isNotEmpty && rest.length <= 50) {
          extra = rest;
          break;
        }
      }
      p = p.parent;
    }

    out.add(RankBook(title, extra, u));
    if (out.length >= 50) break;
  }

  if (out.length < 3) {
    throw NovelFetchException('这个页面没解析出榜单。可能榜单要 JS 加载，或者链接不是书籍页。');
  }
  return out;
}

/// 抓一本书的简介（书籍详情页）
Future<String> fetchBookIntro(String bookUrl) async {
  final text = await _get(bookUrl);
  final doc = html_parser.parse(text);
  for (final bad in doc.querySelectorAll('script,style,nav,header,footer,iframe')) {
    bad.remove();
  }

  // 先看容器，容器通常比 meta 更完整
  const sels = [
    '#intro',
    '.intro',
    '.book-intro',
    '#bookIntro',
    '.book-dec',
    '.book-desc',
    '.desc',
    '.introduct',
    '#bookinfo',
  ];
  var best = '';
  for (final sel in sels) {
    for (final el in doc.querySelectorAll(sel)) {
      final t = el.text.replaceAll(RegExp(r'\s+'), ' ').trim();
      if (t.length > best.length) best = t;
    }
  }

  if (best.length < 30) {
    final meta = doc.querySelector('meta[name="description"]')?.attributes['content'] ??
        doc.querySelector('meta[property="og:description"]')?.attributes['content'] ??
        '';
    if (meta.trim().length > best.length) best = meta.trim();
  }

  if (best.length < 30) {
    throw NovelFetchException('这页没抓到简介，可能简介由 JS 加载。');
  }
  return best.length > 1200 ? '${best.substring(0, 1200)}…' : best;
}

/// 探测一个书源是否活着：能打开首页就算通过
Future<bool> isSourceAlive(String base) async {
  final b = normalizeBase(base);
  if (b.isEmpty) return false;
  try {
    final uri = Uri.parse('$b/');
    final resp = await http.get(uri, headers: {
      'User-Agent': _ua,
      'Accept': 'text/html,application/xhtml+xml,*/*;q=0.8',
    }).timeout(const Duration(seconds: 6));
    return resp.statusCode >= 200 && resp.statusCode < 400;
  } catch (_) {
    return false;
  }
}
