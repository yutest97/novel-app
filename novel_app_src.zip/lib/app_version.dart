/// 版本号唯一来源：改这里就等于改全 App 的版本显示。
/// 有测试会校验它和 pubspec.yaml 里的 version 一致，忘了改会报错。
const String kAppVersion = '1.28.0';
