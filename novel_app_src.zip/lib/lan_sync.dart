import 'dart:async';
import 'dart:convert';
import 'dart:io';

/// 局域网传输：手机开一个临时 HTTP 服务，电脑浏览器打开就能下载备份。
/// 只在 App 运行期间有效，退出即关闭。
class LanSyncServer {
  static HttpServer? _server;
  static int port = 0;

  static bool get running => _server != null;

  static Future<List<String>> start(String Function() buildBackup) async {
    if (_server != null) return addresses();

    for (var p = 8080; p <= 8084; p++) {
      try {
        _server = await HttpServer.bind(InternetAddress.anyIPv4, p);
        port = p;
        break;
      } on SocketException {
        // 这个端口被占了，试下一个
      }
    }
    if (_server == null) {
      throw Exception('8080~8084 都被占用了，先关掉占用端口的程序再试。');
    }

    _server!.listen((HttpRequest req) async {
      try {
        if (req.uri.path == '/' ||
            req.uri.path == '/backup.json' ||
            req.uri.path == '/index.html') {
          final body = utf8.encode(buildBackup());
          req.response.headers.contentType =
              ContentType('application', 'json', charset: 'utf-8');
          req.response.headers.set(
            'Content-Disposition',
            'attachment; filename="novel_app_backup.json"',
          );
          req.response.add(body);
        } else {
          req.response.statusCode = 404;
          req.response.write('Not found. 打开根路径即可下载备份。');
        }
      } catch (e) {
        req.response.statusCode = 500;
        req.response.write('生成备份失败：$e');
      }
      await req.response.close();
    });

    return addresses();
  }

  static Future<List<String>> addresses() async {
    if (_server == null) return const [];
    final out = <String>[];
    try {
      final list = await NetworkInterface.list(
        type: InternetAddressType.IPv4,
        includeLoopback: false,
      );
      for (final ni in list) {
        for (final a in ni.addresses) {
          out.add('http://${a.address}:$port');
        }
      }
    } catch (_) {}
    return out;
  }

  static Future<void> stop() async {
    await _server?.close(force: true);
    _server = null;
    port = 0;
  }
}
