import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'models.dart';

/// 书稿存储的抽象：应用内（SharedPreferences）或外部目录（SAF）
abstract class BookStorage {
  String get label;

  /// 是否为外部目录
  bool get external;

  Future<List<Novel>> loadAll();

  Future<void> saveAll(List<Novel> books);

  /// 读回一本用于校验（迁移时用）
  Future<Novel?> readOne(String id);
}

String _safe(String id) => id.replaceAll(RegExp(r'[^A-Za-z0-9_\-]'), '_');

String _fileName(String id) => 'book_${_safe(id)}.json';

// ---------------- 应用内 ----------------

class PrefsBookStorage implements BookStorage {
  PrefsBookStorage(this.prefs);

  final SharedPreferences prefs;
  static const String key = 'books_v1';

  @override
  String get label => '应用内存储';

  @override
  bool get external => false;

  @override
  Future<List<Novel>> loadAll() async {
    final raw = prefs.getString(key);
    if (raw == null || raw.isEmpty) return const [];
    try {
      final list = jsonDecode(raw) as List<dynamic>;
      return list
          .map((e) => Novel.fromJson(e as Map<String, dynamic>))
          .toList();
    } catch (_) {
      return const [];
    }
  }

  @override
  Future<void> saveAll(List<Novel> books) async {
    await prefs.setString(
      key,
      jsonEncode(books.map((b) => b.toJson()).toList()),
    );
  }

  @override
  Future<Novel?> readOne(String id) async {
    final all = await loadAll();
    for (final b in all) {
      if (b.id == id) return b;
    }
    return null;
  }
}

// ---------------- 外部目录（SAF） ----------------

class SafDirectory {
  final String uri;
  final String name;
  const SafDirectory(this.uri, this.name);
}

/// 原生桥：MainActivity 里用 DocumentsContract 实现
class SafStorage {
  static const MethodChannel _channel = MethodChannel('novel_app/storage');

  static Future<SafDirectory?> pickDirectory() async {
    final res = await _channel.invokeMethod<Map<dynamic, dynamic>>('pickDirectory');
    if (res == null) return null;
    return SafDirectory(
      (res['uri'] ?? '').toString(),
      (res['name'] ?? '外部目录').toString(),
    );
  }

  static Future<bool> check(String uri) async {
    final ok = await _channel.invokeMethod<bool>('check', {'uri': uri});
    return ok ?? false;
  }

  static Future<List<Map<String, dynamic>>> list(String uri) async {
    final res = await _channel.invokeMethod<List<dynamic>>('list', {'uri': uri});
    return (res ?? [])
        .whereType<Map>()
        .map((e) => e.cast<String, dynamic>())
        .toList();
  }

  static Future<String> read(String uri, String name) async {
    final res = await _channel
        .invokeMethod<String>('read', {'uri': uri, 'name': name});
    return res ?? '';
  }

  static Future<void> write(String uri, String name, String content) async {
    await _channel.invokeMethod('write', {
      'uri': uri,
      'name': name,
      'bytes': Uint8List.fromList(utf8.encode(content)),
    });
  }

  static Future<void> delete(String uri, String name) async {
    await _channel.invokeMethod('delete', {'uri': uri, 'name': name});
  }
}

class SafBookStorage implements BookStorage {
  SafBookStorage(this.directory);

  final SafDirectory directory;
  final Map<String, String> _lastWritten = <String, String>{};

  @override
  String get label => '外部目录 · ${directory.name}';

  @override
  bool get external => true;

  @override
  Future<List<Novel>> loadAll() async {
    final files = await SafStorage.list(directory.uri);
    final byId = <String, Novel>{};
    final order = <String>[];

    for (final f in files) {
      final name = (f['name'] ?? '').toString();
      if (!name.endsWith('.json')) continue;
      if (name == 'index.json') {
        try {
          final data = jsonDecode(
              await SafStorage.read(directory.uri, name));
          if (data is Map && data['order'] is List) {
            order.addAll((data['order'] as List).map((e) => e.toString()));
          }
        } catch (_) {}
        continue;
      }
      if (!name.startsWith('book_')) continue;
      try {
        final text = await SafStorage.read(directory.uri, name);
        final data = jsonDecode(text);
        if (data is! Map) continue;
        final n = Novel.fromJson(data.cast<String, dynamic>());
        var id = n.id;
        if (id.isEmpty) {
          id = name.substring(5, name.length - 5);
          n.id = id;
        }
        byId[id] = n;
        _lastWritten[id] = text;
      } catch (_) {
        // 单个文件坏了就跳过
      }
    }

    final out = <Novel>[];
    for (final id in order) {
      final n = byId.remove(id);
      if (n != null) out.add(n);
    }
    out.addAll(byId.values);
    return out;
  }

  @override
  Future<void> saveAll(List<Novel> books) async {
    final ids = <String>{};
    for (final b in books) {
      ids.add(b.id);
      final name = _fileName(b.id);
      final json = jsonEncode(b.toJson());
      if (_lastWritten[b.id] == json) continue;
      await SafStorage.write(directory.uri, name, json);
      _lastWritten[b.id] = json;
    }

    // 删掉已经不存在的书
    for (final f in await SafStorage.list(directory.uri)) {
      final name = (f['name'] ?? '').toString();
      if (!name.startsWith('book_') || !name.endsWith('.json')) continue;
      final rawId = name.substring(5, name.length - 5);
      if (!ids.any((x) => _safe(x) == rawId)) {
        try {
          await SafStorage.delete(directory.uri, name);
        } catch (_) {}
      }
    }

    final indexJson = jsonEncode({'order': books.map((b) => b.id).toList()});
    if (_lastWritten['__index__'] != indexJson) {
      await SafStorage.write(directory.uri, 'index.json', indexJson);
      _lastWritten['__index__'] = indexJson;
    }
  }

  @override
  Future<Novel?> readOne(String id) async {
    try {
      final text = await SafStorage.read(directory.uri, _fileName(id));
      if (text.isEmpty) return null;
      final data = jsonDecode(text);
      if (data is! Map) return null;
      return Novel.fromJson(data.cast<String, dynamic>());
    } catch (_) {
      return null;
    }
  }
}
