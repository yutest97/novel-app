import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:novel_app/main.dart';
import 'package:novel_app/models.dart';
import 'package:novel_app/store.dart';
import 'package:novel_app/theme.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  testWidgets('保存章节那条的主按钮文字是白的，不能紫底紫字', (tester) async {
    tester.view.physicalSize = const Size(1080, 2400);
    tester.view.devicePixelRatio = 3.0;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);

    SharedPreferences.setMockInitialValues(<String, Object>{});
    await AppState.I.init();

    final book = Novel(title: '别在三中讲鬼故事')
      ..chapters = [Chapter(title: '第一章', content: '正文')]
      ..chats = [ChatBubble(role: 'assistant', text: '写完了。')];
    AppState.I.books = [book];
    AppState.I.currentId = book.id;
    AppState.I.settings
      ..baseUrl = 'http://127.0.0.1:9/v1'
      ..apiKey = ''
      ..model = 'm';
    AppState.I.pending = Pending.saveChapter;
    AppState.I.pendingTitle = '第1章 十三级台阶';
    AppState.I.pendingContent = '正文';
    AppState.I.goTab(0);

    await tester.pumpWidget(MaterialApp(theme: buildDarkTheme(), home: const HomeShell()));
    await tester.pumpAndSettle();

    final btn = tester.widget<ElevatedButton>(
      find.widgetWithText(ElevatedButton, '保存这一章'),
    );
    expect(btn.style?.foregroundColor?.resolve(<MaterialState>{}), Colors.white);
    expect(btn.style?.backgroundColor?.resolve(<MaterialState>{}), C.purple);
  });
}
