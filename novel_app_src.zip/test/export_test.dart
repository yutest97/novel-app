import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:novel_app/backup_util.dart';
import 'package:novel_app/models.dart';
import 'package:novel_app/screens/simple_pages.dart';
import 'package:novel_app/store.dart';
import 'package:novel_app/theme.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('备份文件名带日期，且同一天同一分钟不会重名', () {
    expect(
      backupFileName(DateTime(2026, 10, 23, 14, 5)),
      'novel_app_backup_20261023_1405.json',
    );
    expect(
      backupFileName(DateTime(2026, 1, 2, 3, 4)),
      'novel_app_backup_20260102_0304.json',
    );
  });

  testWidgets('导出走系统保存面板，取消时明确提示', (tester) async {
    SharedPreferences.setMockInitialValues(<String, Object>{});
    await AppState.I.init();
    AppState.I.books = [
      Novel(title: '灰烬纪元')
        ..chapters = [Chapter(title: '第1章', content: '正文')],
    ];
    AppState.I.currentId = AppState.I.books.first.id;

    await tester.pumpWidget(MaterialApp(
      theme: buildDarkTheme(),
      home: const DataPage(),
    ));
    await tester.pumpAndSettle();

    await tester.ensureVisible(find.text('保存为文件'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('保存为文件'));
    await tester.pumpAndSettle();

    // 宿主环境没有文件选择器插件：可能是取消（返回 null），也可能直接报插件缺失
    final cancelled = find.text('已取消，没有保存').evaluate().isNotEmpty;
    final blocked = find.textContaining('打不开保存面板').evaluate().isNotEmpty ||
        find.textContaining('保存失败').evaluate().isNotEmpty;
    expect(cancelled || blocked, isTrue);

    // 恢复入口要能从文件选
    await tester.ensureVisible(find.text('从备份恢复'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('从备份恢复'));
    await tester.pumpAndSettle();
    expect(find.text('选择备份文件'), findsOneWidget);
  });
}
