import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:novel_app/main.dart';
import 'package:novel_app/models.dart';
import 'package:novel_app/store.dart';
import 'package:novel_app/theme.dart';

const String _base = 'http://127.0.0.1:8777';

Future<Novel> _book() async {
  SharedPreferences.setMockInitialValues(<String, Object>{});
  await AppState.I.init();
  final b = Novel(title: '灰烬纪元');
  AppState.I.books = [b];
  AppState.I.currentId = b.id;
  AppState.I.settings
    ..baseUrl = '$_base/v1'
    ..apiKey = 'k'
    ..model = 'm'
    ..format = 'openai'
    ..agentEnabled = false
    ..searchEnabled = false
    ..requestCount = 0;
  AppState.I.pendingFiles.clear();
  return b;
}

Future<void> _loadFonts() async {
  final cjk = File('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc').readAsBytesSync();
  for (final f in ['CJK', 'monospace', 'Roboto']) {
    await (FontLoader(f)..addFont(Future.value(ByteData.view(cjk.buffer)))).load();
  }
  final icon = File('/opt/f3/flutter/bin/cache/artifacts/material_fonts/MaterialIcons-Regular.otf').readAsBytesSync();
  await (FontLoader('MaterialIcons')..addFont(Future.value(ByteData.view(icon.buffer)))).load();
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  setUpAll(() => HttpOverrides.global = null);

  test('空文件、超量都拒绝，并给出能看懂的原因', () async {
    await _book();

    expect(
      () => AppState.I.addPendingFile('空.txt', '   '),
      throwsA(isA<FormatException>().having(
          (e) => e.message, 'message', contains('没解析出文字'))),
    );

    for (var i = 0; i < AppState.kMaxFiles; i++) {
      AppState.I.addPendingFile('第$i章.txt', '正文' * 100);
    }
    expect(AppState.I.pendingFiles.length, AppState.kMaxFiles);
    expect(
      () => AppState.I.addPendingFile('多出来的.txt', '正文'),
      throwsA(isA<FormatException>().having(
          (e) => e.message, 'message', contains('最多带 5 个'))),
    );
  });

  test('超长文件截断到 6 万字', () async {
    await _book();
    AppState.I.addPendingFile('超长.txt', '字' * 90000);
    expect(AppState.I.pendingFiles.first.text.length, AppState.kMaxFileChars);
  });

  test('只发附件也能发出去，正文拼进消息给模型', () async {
    await _book();
    AppState.I.addPendingFile('设定.txt', '主角叶烬，24 岁，殡仪馆火化工。');

    await AppState.I.send('');

    final last = AppState.I.novel.chats.last;
    expect(last.role, 'assistant');
    expect(last.text.contains('已收到附件'), isTrue);

    final user = AppState.I.novel.chats[AppState.I.novel.chats.length - 2];
    expect(user.attachments, ['设定.txt']);
    expect(user.attachmentText.contains('殡仪馆火化工'), isTrue);
    expect(AppState.I.pendingFiles, isEmpty);
  });

  test('附件正文随消息持久化，重启后还在', () async {
    await _book();
    AppState.I.addPendingFile('大纲.md', '# 第一章\n雨夜捡到芯片。');
    await AppState.I.send('按这个大纲写第一章');

    final json = AppState.I.novel.toJson();
    final back = Novel.fromJson(jsonDecode(jsonEncode(json)) as Map<String, dynamic>);
    final user = back.chats.firstWhere((c) => c.role == 'user');
    expect(user.attachments, ['大纲.md']);
    expect(user.attachmentText.contains('雨夜捡到芯片'), isTrue);
  });

  testWidgets('输入框上方出现附件卡，点 × 能删掉', (tester) async {
    tester.view.physicalSize = const Size(1080, 2280);
    tester.view.devicePixelRatio = 3.0;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    await _loadFonts();

    await _book();
    AppState.I.books = [Novel(title: '灰烬纪元')];
    AppState.I.currentId = AppState.I.books.first.id;
    AppState.I.goTab(0);
    AppState.I.addPendingFile('设定.txt', '主角叶烬，24 岁，殡仪馆火化工。');

    final t = buildDarkTheme();
    await tester.pumpWidget(MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: t.copyWith(
        textTheme: t.textTheme.apply(fontFamily: 'CJK'),
        primaryTextTheme: t.primaryTextTheme.apply(fontFamily: 'CJK'),
      ),
      home: const HomeShell(),
    ));
    await tester.pumpAndSettle();

    expect(find.text('设定.txt'), findsWidgets);
    expect(find.textContaining('字'), findsWidgets);

    await tester.tap(find.byIcon(Icons.close).first);
    await tester.pumpAndSettle();
    expect(AppState.I.pendingFiles, isEmpty);
    expect(find.text('设定.txt'), findsNothing);
  });
}
