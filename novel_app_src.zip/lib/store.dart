import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'llm.dart';
import 'agent_tools.dart';
import 'app_version.dart';
import 'book_storage.dart';
import 'book_text.dart';
import 'book_sources.dart';
import 'novel_source.dart';
import 'web_search.dart';
import 'builtin_skills.dart';
import 'models.dart';
import 'prompt.dart';
import 'skill.dart';

/// 当前这一轮要用户确认什么
enum Pending { none, saveChapter, syncDocs }

/// 模型给的资料怎么处理了
enum DocsOutcome { none, applied, pending }

/// 全局状态：书架、设置、聊天记录，全部落在手机本地
/// 抽卡的一个候选
class DrawCandidate {
  String text = '';
  int tokens = 0;
  bool done = false;
  bool discarded = false;
  String? error;
}

/// 把输入里的 `#世界观.md` 换成该文件真实内容，只影响发给模型的消息，气泡里仍显示短tag
String _expandRefsFor(Novel b, String text) {
  var out = text;
  final refs = <String, String>{
    '#世界观.md': b.world,
    '#人物库.md': b.characters,
    '#章节摘要.md': b.summary,
  };
  refs.forEach((tag, content) {
    if (out.contains(tag) && content.trim().isNotEmpty) {
      out = out.replaceFirst(tag, '【引用 ${tag.substring(1)}】\n$content\n');
    }
  });
  return out;
}

String _snip(String text, [int max = 240]) {
  final t = text.trim();
  if (t.isEmpty) return '（空）';
  return t.length <= max ? t : '${t.substring(0, max)}…';
}

class AppState extends ChangeNotifier {
  static final AppState I = AppState._();
  AppState._();

  static const _kCurrent = 'current_v1';
  static const _kSettings = 'settings_v1';
  // 老版本的单书存储，用来迁移
  static const _kOldNovel = 'novel_v1';
  static const _kOldChat = 'chat_v1';

  SharedPreferences? _prefs;

  List<Novel> books = <Novel>[];
  late BookStorage _storage;
  String storageNote = '';
  String currentId = '';
  Settings settings = Settings();

  bool ready = false;
  bool busy = false;
  CancelToken? _cancel;

  // 扫榜缓存（只在内存里，App 重启就没了，避免过期数据误导）
  List<WebSource> _roundSources = <WebSource>[];

  /// 已选好、还没发出去的附件
  List<ChatFile> pendingFiles = <ChatFile>[];
  static const int kMaxFileChars = 60000; // 单个附件最多带 6 万字
  static const int kMaxFiles = 5;

  List<RankBook> lastRank = <RankBook>[];
  String lastRankUrl = '';
  String lastRankAt = '';

  // 抽卡
  List<DrawCandidate> draws = <DrawCandidate>[];
  bool drawing = false;
  bool get drawVisible => draws.isNotEmpty;
  int tabIndex = 0; // 0 对话 / 1 小说 / 2 设置

  void goTab(int i) {
    tabIndex = i;
    notifyListeners();
  }

  String? errorText;
  /// 上一次失败的动作，供「重试」原样重放（普通对话 / 风格蒸馏都支持）
  Future<void> Function()? _retryAction;
  ChatBubble? _failedBubble;

  /// 「重试」按钮是否可用
  bool get canRetry => _retryAction != null && !busy;

  // 新建小说向导
  bool wizardOpen = false;
  int wizardStep = 0;
  List<String> wizardAnswers = ['', '', ''];

  Pending pending = Pending.none;
  String pendingTitle = '';
  String pendingContent = '';
  Map<String, String> pendingDocs = const {};

  /// 当前这本书（回收站里的书不算）
  Novel get novel {
    final cur = books.where((b) => b.id == currentId && !b.deleted).toList();
    if (cur.isNotEmpty) return cur.first;
    final alive = books.where((b) => !b.deleted).toList();
    if (alive.isNotEmpty) {
      currentId = alive.first.id;
      return alive.first;
    }
    final fresh = Novel();
    books.add(fresh);
    currentId = fresh.id;
    return fresh;
  }

  List<ChatBubble> get bubbles => novel.chats;

  /// 书架上真正要显示的：有内容的书。一启动自动占位的空书不算，回收站里的不算。
  List<Novel> get visibleBooks =>
      books.where((b) => !b.deleted && (!b.isEmpty || b.chats.isNotEmpty)).toList();

  /// 回收站：最近删的排前面
  List<Novel> get trashedBooks {
    final list = books.where((b) => b.deleted).toList()
      ..sort((a, b) => b.deletedAt.compareTo(a.deletedAt));
    return list;
  }

  // ---------- 启动 ----------

  Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
    books = <Novel>[];
    currentId = '';
    storageNote = '';

    // 先读设置，决定这次用哪个存储
    final rawSettings = _prefs!.getString(_kSettings);
    if (rawSettings != null && rawSettings.isNotEmpty) {
      try {
        settings = Settings.fromJson(jsonDecode(rawSettings) as Map<String, dynamic>);
      } catch (_) {}
    }

    BookStorage? chosen;
    if (settings.storageMode == 'saf' && settings.safUri.isNotEmpty) {
      try {
        if (await SafStorage.check(settings.safUri)) {
          final saf = SafBookStorage(
            SafDirectory(settings.safUri, settings.safName),
          );
          final loaded = await saf.loadAll();
          chosen = saf;
          books = loaded;
          if (loaded.isEmpty) {
            final inApp = await PrefsBookStorage(_prefs!).loadAll();
            if (inApp.isNotEmpty) {
              books = inApp;
              chosen = PrefsBookStorage(_prefs!);
              storageNote = '外部目录里没有书，已临时显示应用内数据。';
            }
          }
        } else {
          storageNote = '外部目录的授权已失效，这次先使用应用内存储。';
        }
      } catch (e) {
        storageNote = '外部目录读不了，已回到应用内存储：$e';
      }
    }

    _storage = chosen ?? PrefsBookStorage(_prefs!);

    if (!_storage.external) {
      final loaded = await _storage.loadAll();
      if (loaded.isNotEmpty) books = loaded;
    }

    if (books.isEmpty) {
      // 从单书版本迁移
      Novel? old;
      final n = _prefs!.getString(_kOldNovel);
      if (n != null && n.isNotEmpty) {
        try {
          old = Novel.fromJson(jsonDecode(n) as Map<String, dynamic>);
        } catch (_) {}
      }
      final oldChat = _prefs!.getString(_kOldChat);
      if (old != null && oldChat != null && oldChat.isNotEmpty) {
        try {
          final list = jsonDecode(oldChat) as List<dynamic>;
          old.chats = list.map((e) => ChatBubble.fromJson(e as Map<String, dynamic>)).toList();
        } catch (_) {}
      }
      books = [old ?? Novel()];
    }

    currentId = _prefs!.getString(_kCurrent) ?? books.first.id;

    // 回收站只留 30 天，过期自动清掉（启动时顺手做，不用后台任务）
    final stale = books.where((b) => b.deleted && _expired(b.deletedAt)).toList();
    if (stale.isNotEmpty) {
      books.removeWhere((b) => b.deleted && _expired(b.deletedAt));
      if (books.isEmpty) books.add(Novel());
      if (!books.any((b) => b.id == currentId)) {
        currentId = books.firstWhere((b) => !b.deleted, orElse: () => books.first).id;
      }
      await _persist();
    }

    ready = true;
    notifyListeners();
  }

  /// 回收站保留天数
  static const int trashKeepDays = 30;

  bool _expired(int deletedAtMs) {
    final cutoff = DateTime.now()
        .subtract(const Duration(days: trashKeepDays))
        .millisecondsSinceEpoch;
    return deletedAtMs < cutoff;
  }

  /// 当前存储位置的名字，给界面显示
  String get storageLabel => _storage.label;

  bool get storageExternal => _storage.external;

  /// 测试用：直接换一个存储实现
  void useStorageForTest(BookStorage s) {
    _storage = s;
  }

  Future<void> _persistSettingsOnly() async {
    final p = _prefs;
    if (p == null) return;
    await p.setString(_kCurrent, currentId);
    await p.setString(_kSettings, jsonEncode(settings.toJson()));
  }

  /// 迁移到任意存储：写完后读回校验，成功才切换。原来的存储保留一份。
  Future<void> migrateToStorage(
    BookStorage target, {
    required String mode,
    String uri = '',
    String name = '',
  }) async {
    final snapshot = List<Novel>.from(books);
    await target.saveAll(snapshot);
    final back = await target.loadAll();
    if (back.length != snapshot.length) {
      throw Exception('校验失败：写入 ${snapshot.length} 本，读回 ${back.length} 本');
    }
    final previous = _storage;
    _storage = target;
    settings.storageMode = mode;
    if (mode == 'saf') {
      settings.safUri = uri;
      settings.safName = name;
    } else {
      settings.safUri = '';
      settings.safName = '';
    }
    if (previous is PrefsBookStorage) {
      try {
        await previous.saveAll(snapshot);
      } catch (_) {}
    }
    await _persistSettingsOnly();
    storageNote = name.isEmpty
        ? '已切换存储位置。'
        : '已迁移到「$name」，应用内保留了一份备份。';
    notifyListeners();
  }

  Future<void> migrateToExternal(SafDirectory dir) => migrateToStorage(
        SafBookStorage(dir),
        mode: 'saf',
        uri: dir.uri,
        name: dir.name,
      );

  /// 改回应用内存储（外部文件不删）
  Future<void> migrateToInternal() async {
    final target = PrefsBookStorage(_prefs!);
    await target.saveAll(books);
    _storage = target;
    settings.storageMode = 'app';
    settings.safUri = '';
    settings.safName = '';
    await _persistSettingsOnly();
    storageNote = '已改回应用内存储，外部目录里的文件没有删。';
    notifyListeners();
  }

  // ---------- 保存到本地 ----------

  Future<void> _persist() async {
    final p = _prefs;
    if (p == null) return;

    try {
      await _storage.saveAll(books);
    } catch (e) {
      // 外部目录写失败：先写一份到应用内，避免丢数据，并在界面上提示
      try {
        await PrefsBookStorage(p).saveAll(books);
      } catch (_) {}
      storageNote = '写入外部目录失败，已临时存到应用内：$e';
      notifyListeners();
    }

    await p.setString(_kCurrent, currentId);
    await p.setString(_kSettings, jsonEncode(settings.toJson()));
  }

  // ---------- 书架 ----------

  Future<Novel> createBook({String title = ''}) async {
    final book = Novel(title: title);
    books.insert(0, book);
    currentId = book.id;
    pending = Pending.none;
    await _persist();
    notifyListeners();
    return book;
  }

  Future<void> switchBook(String id) async {
    if (id == currentId) return;
    currentId = id;
    pending = Pending.none;
    pendingDocs = const {};
    errorText = null;
    await _persist();
    notifyListeners();
  }

  // ---------- 备忘录 ----------

  Future<Note> addNote(String text, String category) async {
    final n = Note(text: text, category: category);
    novel.notes.insert(0, n);
    novel.touch();
    await _persist();
    notifyListeners();
    return n;
  }

  Future<void> updateNote(String id, String text, String category) async {
    for (final n in novel.notes) {
      if (n.id == id) {
        n.text = text;
        n.category = category;
      }
    }
    novel.touch();
    await _persist();
    notifyListeners();
  }

  Future<void> deleteNote(String id) async {
    novel.notes.removeWhere((n) => n.id == id);
    novel.touch();
    await _persist();
    notifyListeners();
  }

  /// 手动修改某份资料（world / characters / summary）
  Future<void> updateDoc(String kind, String text) async {
    final b = novel;
    if (kind == 'world') {
      b.world = text;
    } else if (kind == 'characters') {
      b.characters = text;
    } else {
      b.summary = text;
    }
    b.touch();
    await _persist();
    notifyListeners();
  }

  /// 导出整本书的纯文本（资料在前，章节在后）
  String exportBookText(String id) {
    final b = books.firstWhere((x) => x.id == id, orElse: () => novel);
    final buf = StringBuffer();
    buf.writeln(b.title.trim().isEmpty ? '未命名' : b.title);
    buf.writeln();
    if (b.world.trim().isNotEmpty) {
      buf
        ..writeln('【世界观】')
        ..writeln(b.world)
        ..writeln();
    }
    if (b.characters.trim().isNotEmpty) {
      buf
        ..writeln('【人物库】')
        ..writeln(b.characters)
        ..writeln();
    }
    if (b.summary.trim().isNotEmpty) {
      buf
        ..writeln('【章节摘要】')
        ..writeln(b.summary)
        ..writeln();
    }
    for (final c in b.chapters) {
      buf
        ..writeln(c.title)
        ..writeln()
        ..writeln(c.content)
        ..writeln();
    }
    return buf.toString();
  }

  Future<void> renameBook(String id, String title) async {
    final i = books.indexWhere((b) => b.id == id);
    if (i < 0) return;
    books[i].title = title.trim();
    books[i].touch();
    await _persist();
    notifyListeners();
  }

  /// 删除 = 放进回收站，30 天内可以恢复
  Future<void> deleteBook(String id) async {
    final i = books.indexWhere((b) => b.id == id);
    if (i < 0) return;
    books[i].deletedAt = DateTime.now().millisecondsSinceEpoch;
    if (currentId == id) {
      final alive = books.where((b) => !b.deleted).toList();
      if (alive.isNotEmpty) {
        currentId = alive.first.id;
      } else {
        final fresh = Novel();
        books.add(fresh);
        currentId = fresh.id;
      }
    }
    pending = Pending.none;
    await _persist();
    notifyListeners();
  }

  /// 从回收站恢复，并切到这本书
  Future<void> restoreBook(String id) async {
    final i = books.indexWhere((b) => b.id == id);
    if (i < 0) return;
    books[i].deletedAt = 0;
    books[i].touch();
    currentId = id;
    pending = Pending.none;
    await _persist();
    notifyListeners();
  }

  /// 彻底删掉（不进回收站）
  Future<void> purgeBook(String id) async {
    books.removeWhere((b) => b.id == id);
    if (books.isEmpty) books.add(Novel());
    if (currentId == id) {
      currentId = books.firstWhere((b) => !b.deleted, orElse: () => books.first).id;
    }
    await _persist();
    notifyListeners();
  }

  /// 清空回收站
  Future<int> emptyTrash() async {
    final n = books.where((b) => b.deleted).length;
    if (n == 0) return 0;
    books.removeWhere((b) => b.deleted);
    if (books.isEmpty) books.add(Novel());
    await _persist();
    notifyListeners();
    return n;
  }

  /// 导入一本书：按「第X章」切成章节；没有章节标记就整体当一章
  Future<Novel> importBook({required String title, required String raw}) async {
    final book = Novel(title: title.trim());
    final parts = splitChapters(raw);
    book.chapters = parts;
    book.touch();
    books.insert(0, book);
    currentId = book.id;
    pending = Pending.none;
    await _persist();
    notifyListeners();
    return book;
  }

  /// 清空当前这本书的内容（保留书名）
  Future<void> resetNovel() async {
    final old = novel;
    old
      ..characters = ''
      ..world = ''
      ..summary = ''
      ..chapters = []
      ..chats = [];
    old.touch();
    pending = Pending.none;
    pendingDocs = const {};
    await _persist();
    notifyListeners();
  }

  // ---------- 发消息 ----------

  Future<void> send(String text) async {
    final t = text.trim();
    if (busy) return;
    if (t.isEmpty && pendingFiles.isEmpty) return;
    errorText = null;

    final files = List<ChatFile>.of(pendingFiles);
    pendingFiles.clear();
    final attachText = files.isEmpty
        ? ''
        : files.map((f) => '【附件：${f.name}】\n${f.text}').join('\n\n');
    final display = t.isEmpty
        ? (files.length == 1 ? '看一下这个附件' : '看一下这几个附件')
        : t;

    novel.chats.add(ChatBubble(
      role: 'user',
      text: display,
      attachments: files.map((f) => f.name).toList(),
      attachmentText: attachText,
    ));
    novel.touch();
    notifyListeners();
    await _call();
  }

  /// 加一个附件；解析失败 / 超量时抛 FormatException，message 可直接展示
  void addPendingFile(String name, String text) {
    final t = text.trim();
    if (t.isEmpty) {
      throw const FormatException(
        '这个文件里没解析出文字。扫描版 PDF、图片、加密的 docx 都读不出内容。',
      );
    }
    if (pendingFiles.length >= kMaxFiles) {
      throw const FormatException('一次最多带 5 个文件，先删掉一个再加。');
    }
    pendingFiles.add(ChatFile(name, t.length > kMaxFileChars ? t.substring(0, kMaxFileChars) : t));
    notifyListeners();
  }

  void removePendingFile(int index) {
    if (index < 0 || index >= pendingFiles.length) return;
    pendingFiles.removeAt(index);
    notifyListeners();
  }

  /// 用户点「重试」：历史里已有上一条用户消息，直接重发
  Future<void> retry() async {
    if (busy) return;
    final action = _retryAction;
    if (action == null) return;

    // 把上次失败留下那条空气泡删掉，避免重试后出现两条「（出错了）」
    final bad = _failedBubble;
    if (bad != null && novel.chats.contains(bad)) {
      novel.chats.remove(bad);
    }
    _failedBubble = null;
    _retryAction = null;
    errorText = null;
    notifyListeners();

    await action();
  }

  Future<void> _call() async {
    if (!settings.isReady) {
      errorText = '还没填 API Key。请到「设置 → AI 提供商」填好，再回来继续。';
      notifyListeners();
      return;
    }

    busy = true;
    errorText = null;
    final started = DateTime.now();

    // 先放一个空气泡，边收边往上写
    final bubble = ChatBubble(role: 'assistant', text: '');
    novel.chats.add(bubble);
    notifyListeners();

    final token = CancelToken();
    _cancel = token;
    final useAgent = settings.agentEnabled;
    _roundSources = <WebSource>[];

    try {
      // 联网搜索：普通模式先搜再塞进上下文；Agent 模式把搜索做成工具，由模型自己决定
      var searchBlock = '';
      if (settings.searchEnabled && !useAgent) {
        final q = _lastUserText(bubble);
        if (q.isNotEmpty) {
          bubble.text = '正在联网搜索…';
          notifyListeners();
          try {
            final list = await _searchWeb(q);
            _roundSources = list;
            bubble.sources = list;
            bubble.tools = <ToolStep>[
              ToolStep(
                '联网搜索',
                settings.searchProvider == 'bocha' ? '博查' : '必应',
                formatSources(list),
              ),
            ];
            searchBlock = '${kSearchRules}\n\n【搜索结果】\n${formatSources(list)}';
          } on WebSearchException catch (e) {
            bubble.tools = <ToolStep>[
              ToolStep(
                '联网搜索',
                settings.searchProvider == 'bocha' ? '博查' : '必应',
                '搜索词：$q\n失败：${e.message}',
              ),
            ];
            errorText = '联网搜索失败：${e.message}（这一轮按不联网回答）';
          } finally {
            bubble.text = '';
            notifyListeners();
          }
        }
      }

      final system = await buildSystemPrompt(
        novel,
        skillText: activeSkillText,
        skillId: settings.activeSkillId,
        skillName: activeSkillName,
        styleName: styleSkill?.name,
        styleText: styleSkill?.content,
        thinkingLevel: settings.thinkingLevel,
        agentMode: useAgent,
        webSearch: settings.searchEnabled,
        customPrompt: settings.customPrompt,
      );
      final chats = novel.chats;
      final picked = <ChatBubble>[];
      var skipped = 0;

      if (settings.autoCompact) {
        // 按 token 预算从最近往前挑；超了就折叠更早的
        final windowK = settings.contextWindowK.clamp(4, 2000);
        final reserveK = settings.outputReserveK.clamp(0, windowK - 1);
        final budget = (windowK - reserveK) * 1024;
        var used = _estimateTokens(system);
        final history = chats.where((b) =>
            !identical(b, bubble) &&
            !(b.role == 'assistant' && b.text.trim().isEmpty)).toList();
        for (var i = history.length - 1; i >= 0; i--) {
          final b = history[i];
          final text = b.role == 'user' ? _expandRefs(b.text) : b.text;
          final cost = _estimateTokens(text) + 8;
          if (used + cost > budget) break;
          used += cost;
          picked.insert(0, b);
        }
        skipped = history.length - picked.length;
      } else {
        // 关掉自动压缩：固定带最近 12 条（先过滤掉空气泡，再截断）
        final history = chats.where((b) =>
            !identical(b, bubble) &&
            !(b.role == 'assistant' && b.text.trim().isEmpty)).toList();
        final start = history.length > 12 ? history.length - 12 : 0;
        picked.addAll(history.sublist(start));
      }

      var systemWithNote = (settings.autoCompact && skipped > 0)
          ? '$system\n\n【上下文提示】更早的 $skipped 条对话已折叠，'
              '涉及前文时优先以章节摘要、人物库和工具读取的正文为准。'
          : system;
      if (searchBlock.isNotEmpty) {
        systemWithNote = '$systemWithNote\n\n$searchBlock';
      }

      final msgs = <Map<String, dynamic>>[
        {'role': 'system', 'content': systemWithNote},
      ];
      ChatBubble? lastUser;
      for (final b in picked) {
        if (b.role == 'user') lastUser = b;
      }
      for (final b in picked) {
        var content = b.role == 'user' ? _expandRefs(b.text) : b.text;
        if (b.role == 'user' && b.attachmentText.isNotEmpty) {
          content = identical(b, lastUser)
              ? '$content\n\n${b.attachmentText}'
              : '$content\n\n【附件 ${b.attachments.join("、")} 的正文已省略；'
                  '需要时让用户重新发一次，或用工具读章节】';
        }
        msgs.add({'role': b.role, 'content': content});
      }

      LlmResult? res;
      if (useAgent) {
        try {
          res = await _agentLoop(bubble, msgs, token);
        } on ToolUnsupportedException {
          bubble.text = '';
          res = await _plainCall(
            bubble,
            msgs,
            token,
            prefix: const [
              ToolStep('提示', '模型不支持工具调用', '已自动退回普通模式，这一轮仍然正常回答。'),
            ],
          );
        }
      } else {
        res = await _plainCall(bubble, msgs, token);
      }

      final reply = AiReply.parse(res.text);
      bubble
        ..text = reply.message.trim().isNotEmpty ? reply.message : reply.chapterContent
        ..options = reply.options
        ..tokens = res.totalTokens
        ..ms = DateTime.now().difference(started).inMilliseconds
        ..raw = res.text
        ..reasoning = res.reasoning;

      // 用户定了书名：趁书还没名字，写进去（已命名的书不覆盖）
      if (reply.hasBookTitle && absorbBookTitle(reply.bookTitle)) {
        final t = novel.title;
        bubble.tools.add(ToolStep('设置书名', '《$t》', '书架和对话标题都会跟着改'));
        if (bubble.text.trim().isEmpty) bubble.text = '书名定了：《$t》';
      }

      // 新书第一次给设定：直接写进「小说资料」；已有资料时走确认，避免覆盖用户改过的东西。
      // 同一轮里带章节的话先存章节，资料等保存后按 Step 8 重新同步。
      var docsPending = false;
      if (reply.hasDocs && !reply.hasChapter) {
        final outcome = absorbDocs(reply.docs);
        if (outcome == DocsOutcome.applied) {
          bubble.tools.add(ToolStep(
            '写入资料',
            _docLabel(reply.docs),
            '已存进「小说资料」，在书详情里能看到',
          ));
          if (bubble.text.trim().isEmpty) {
            bubble.text = '设定已经写进「小说资料」，点开这本书就能看到。';
          }
        } else if (outcome == DocsOutcome.pending) {
          docsPending = true;
          if (bubble.text.trim().isEmpty) {
            bubble.text = '资料整理好了，点下面的「同步资料」写入。';
          }
        }
      }

      if (token.cancelled) {
        if (bubble.text.trim().isEmpty) bubble.text = '（已停止）';
      } else if (reply.hasChapter) {
        pendingTitle = reply.chapterTitle.trim().isEmpty
            ? '第${novel.chapters.length + 1}章'
            : reply.chapterTitle.trim();
        pendingContent = reply.chapterContent.trim();
        pending = Pending.saveChapter;
      } else {
        pending = docsPending ? Pending.syncDocs : Pending.none;
      }

      novel.touch();
      await _persist();
      _retryAction = null;
      _failedBubble = null;
    } on LlmException catch (e) {
      bubble.text = bubble.text.trim().isEmpty ? '（出错了）' : bubble.text;
      errorText = e.message;
      _retryAction = _call;
      _failedBubble = bubble;
    } catch (e) {
      bubble.text = bubble.text.trim().isEmpty ? '（出错了）' : bubble.text;
      errorText = '出了点意外：$e';
      _retryAction = _call;
      _failedBubble = bubble;
    } finally {
      busy = false;
      _cancel = null;
      notifyListeners();
    }
  }

  /// Agent 循环：模型调工具 → 拿到结果 → 继续，最多 5 轮
  Future<LlmResult> _agentLoop(
    ChatBubble bubble,
    List<Map<String, dynamic>> msgs,
    CancelToken token,
  ) async {
    final steps = <ToolStep>[];
    var lastPaint = DateTime.now();

    for (var round = 0; round < 5; round++) {
      if (token.cancelled) break;

      void onDelta(String content, String reasoning) {
        bubble.text = content;
        bubble.reasoning = reasoning;
        final now = DateTime.now();
        if (now.difference(lastPaint).inMilliseconds > 80) {
          lastPaint = now;
          notifyListeners();
        }
      }

      final res = settings.format == 'anthropic'
          ? await streamModelWithToolsAnthropic(
              settings: settings,
              messages: msgs,
              tools: agentToolSpecs(webSearch: settings.searchEnabled),
              cancel: token,
              onDelta: onDelta,
            )
          : await streamModelWithTools(
              settings: settings,
              messages: msgs,
              tools: agentToolSpecs(webSearch: settings.searchEnabled),
              cancel: token,
              onDelta: onDelta,
            );

      settings.totalTokens += res.totalTokens;
      settings.requestCount += 1;

      if (res.toolCalls.isEmpty) {
        bubble.tools = List<ToolStep>.of(steps);
        bubble.sources = List<WebSource>.of(_roundSources);
        return res;
      }

      // 把助手这一轮的 tool_calls 回填，模型才知道自己调了什么
      msgs.add({
        'role': 'assistant',
        'content': res.text,
        'tool_calls': [
          for (final c in res.toolCalls)
            {
              'id': c.id,
              'type': 'function',
              'function': {'name': c.name, 'arguments': c.arguments},
            },
        ],
      });

      bubble.text = '';
      for (final c in res.toolCalls) {
        if (token.cancelled) break;
        bubble.text = '正在调用 ${c.name}…';
        notifyListeners();

        final out = await _runTool(c);
        steps.add(ToolStep('调用', _toolStepLabel(c), '参数：${c.arguments}\n\n$out'));
        bubble.tools = List<ToolStep>.of(steps);
        bubble.text = '';

        msgs.add({
          'role': 'tool',
          'tool_call_id': c.id,
          'name': c.name,
          'content': out,
        });
        notifyListeners();
      }
    }

    if (token.cancelled) return LlmResult('');
    throw LlmException('工具调用超过 5 轮，先停下来了。可以让我接着做，或者把任务拆小一点。');
  }

  /// 普通模式：一次性请求，不做工具调用
  Future<LlmResult> _plainCall(
    ChatBubble bubble,
    List<Map<String, dynamic>> msgs,
    CancelToken token, {
    List<ToolStep> prefix = const <ToolStep>[],
  }) async {
    // 这一轮真正塞进上下文的东西，界面上显示成卡片
    final recentCount = novel.chapters.length < 5 ? novel.chapters.length : 5;
    bubble.tools = <ToolStep>[
      ...bubble.tools,
      ...prefix,
      ToolStep('加载技能', activeSkillName),
      ToolStep('读取', '人物库.md', _snip(novel.characters)),
      ToolStep('读取', '世界观.md', _snip(novel.world)),
      ToolStep('读取', '章节摘要.md', _snip(novel.summary)),
      if (recentCount > 0)
        ToolStep(
          '读取',
          '最近 $recentCount 章正文',
          _snip(novel.chapters.skip(novel.chapters.length - recentCount)
              .map((c) => '${c.title}\n${c.content}')
              .join('\n\n')),
        ),
    ];

    final plain = msgs
        .map((m) => m.map((k, v) => MapEntry(k, v is String ? v : jsonEncode(v))))
        .toList();

    var lastPaint = DateTime.now();
    final res = await streamModel(
      settings: settings,
      messages: plain,
      cancel: token,
      onDelta: (content, reasoning) {
        bubble.text = content;
        bubble.reasoning = reasoning;
        final now = DateTime.now();
        if (now.difference(lastPaint).inMilliseconds > 80) {
          lastPaint = now;
          notifyListeners();
        }
      },
    );

    settings.totalTokens += res.totalTokens;
    settings.requestCount += 1;
    return res;
  }

  /// 工具步骤显示成中文，例如「读资料 · 人物库」
  String _toolStepLabel(ToolCall c) {
    const names = <String, String>{
      'read_doc': '读资料',
      'list_chapters': '列章节',
      'read_chapter': '读章节',
      'search_book': '搜书',
      'read_notes': '读备忘录',
      'web_search': '联网搜索',
    };
    final base = names[c.name] ?? c.name;
    try {
      final a = jsonDecode(c.arguments.trim().isEmpty ? '{}' : c.arguments);
      if (a is Map) {
        if (c.name == 'read_doc' && a['name'] != null) return '$base · ${a['name']}';
        if (c.name == 'read_chapter' && a['index'] != null) return '$base · 第${a['index']}章';
        if (c.name == 'search_book' && a['title'] != null) return '$base · ${a['title']}';
      }
    } catch (_) {}
    return base;
  }

  /// 执行一个工具调用，返回给模型看的文本
  Future<String> _runTool(ToolCall call) async {
    Map<String, dynamic> args = <String, dynamic>{};
    final raw = call.arguments.trim();
    if (raw.isNotEmpty) {
      try {
        final decoded = jsonDecode(raw);
        if (decoded is Map) args = decoded.cast<String, dynamic>();
      } catch (_) {
        // 参数解析失败就按空参数跑，下面会返回明确错误
      }
    }

    try {
      switch (call.name) {
        case 'read_doc':
          final name = (args['name'] ?? '').toString();
          final docs = <String, String>{
            '世界观': novel.world,
            '人物库': novel.characters,
            '章节摘要': novel.summary,
          };
          if (!docs.containsKey(name)) {
            return '没有这份资料：$name。可选：世界观 / 人物库 / 章节摘要。';
          }
          final text = docs[name]!.trim();
          if (text.isEmpty) return '$name 目前是空的。';
          return _snip(text, 6000);

        case 'list_chapters':
          if (novel.chapters.isEmpty) return '还没有保存任何章节。';
          final buf = StringBuffer('共 ${novel.chapters.length} 章：\n');
          for (var i = 0; i < novel.chapters.length && i < 100; i++) {
            final c = novel.chapters[i];
            final words = c.content.replaceAll(RegExp(r'\s'), '').length;
            buf.writeln('${i + 1}. ${c.title}（$words 字）');
          }
          return buf.toString();

        case 'read_chapter':
          if (novel.chapters.isEmpty) return '还没有保存任何章节。';
          var index = 0;
          final rawIdx = args['index'];
          if (rawIdx is num) index = rawIdx.toInt();
          if (index <= 0) {
            final key = (args['title'] ?? '').toString().trim();
            if (key.isEmpty) return '需要 index 或 title。';
            index = novel.chapters.indexWhere((c) => c.title.contains(key)) + 1;
          }
          if (index <= 0 || index > novel.chapters.length) {
            return '没有第 $index 章。当前共 ${novel.chapters.length} 章。';
          }
          final c = novel.chapters[index - 1];
          return '${c.title}\n\n${_snip(c.content, 6000)}';

        case 'search_book':
          final title = (args['title'] ?? '').toString().trim();
          if (title.isEmpty) return '参数 title 是空的。';
          final base = await ensureSource();
          if (base.isEmpty) return '没有可用书源，搜索失败。';
          final list = await searchBooks(base, title);
          if (list.isEmpty) return '在 $base 没有搜到「$title」。';
          final host = Uri.tryParse(base)?.host ?? base;
          final buf = StringBuffer('在 $host 搜到 ${list.length} 条：\n');
          for (final b in list.take(5)) {
            buf.writeln('- ${b.title}：${b.url}');
          }
          return buf.toString();

        case 'web_search':
          final q = (args['query'] ?? '').toString().trim();
          if (q.isEmpty) return '参数 query 是空的。';
          try {
            final list = await _searchWeb(q);
            final seen = _roundSources.map((s) => s.url).toSet();
            for (final s in list) {
              if (seen.add(s.url)) _roundSources.add(s);
            }
            return '搜索「$q」得到 ${list.length} 条：\n\n${formatSources(list)}';
          } on WebSearchException catch (e) {
            return '搜索失败：${e.message}';
          }

        case 'read_notes':
          if (novel.notes.isEmpty) return '还没有备忘录。';
          final buf = StringBuffer('共 ${novel.notes.length} 条：\n');
          for (final n in novel.notes.take(20)) {
            buf.writeln('【${n.category}】${_snip(n.text, 200)}');
          }
          return buf.toString();

        default:
          return '没有这个工具：${call.name}。';
      }
    } catch (e) {
      return '工具执行失败：$e';
    }
  }

  /// 重新生成最后一条回复：把最后一条用户消息之后的助手气泡都删掉再重发
  Future<void> regenerateLast() async {
    if (busy) return;
    final chats = novel.chats;
    var lastUser = -1;
    for (var i = chats.length - 1; i >= 0; i--) {
      if (chats[i].role == 'user') {
        lastUser = i;
        break;
      }
    }
    if (lastUser < 0) return;
    if (lastUser + 1 < chats.length) {
      chats.removeRange(lastUser + 1, chats.length);
    }
    errorText = null;
    _retryAction = null;
    _failedBubble = null;
    notifyListeners();
    await _call();
  }

  /// 删除一条消息
  Future<void> deleteBubble(int index) async {
    if (index < 0 || index >= novel.chats.length) return;
    novel.chats.removeAt(index);
    novel.touch();
    await _persist();
    notifyListeners();
  }

  // ---------- 抽卡 ----------

  /// 同一份上下文生成 3 份候选，等用户挑
  Future<void> drawCards(String userText) async {
    if (busy || drawing) return;
    if (!settings.isReady) {
      errorText = '还没填 API Key。请到「设置 → AI 提供商」填好，再回来继续。';
      notifyListeners();
      return;
    }

    final text = userText.trim();
    if (text.isNotEmpty) {
      novel.chats.add(ChatBubble(role: 'user', text: text));
      novel.touch();
    }

    drawing = true;
    errorText = null;
    draws = [DrawCandidate(), DrawCandidate(), DrawCandidate()];
    notifyListeners();

    try {
      final system = await buildSystemPrompt(
        novel,
        skillText: activeSkillText,
        skillId: settings.activeSkillId,
        skillName: activeSkillName,
        styleName: styleSkill?.name,
        styleText: styleSkill?.content,
        thinkingLevel: settings.thinkingLevel,
      );
      final msgs = <Map<String, String>>[
        {'role': 'system', 'content': system},
      ];
      final chats = novel.chats;
      final recent = chats.length > 12 ? chats.sublist(chats.length - 12) : chats;
      for (final b in recent) {
        if (b.role == 'assistant' && b.text.trim().isEmpty) continue;
        msgs.add({
          'role': b.role,
          'content': b.role == 'user' ? _expandRefs(b.text) : b.text,
        });
      }

      var lastPaint = DateTime.now();
      await Future.wait(List.generate(3, (i) async {
        try {
          final res = await streamModel(
            settings: settings,
            messages: msgs,
            onDelta: (content, reasoning) {
              draws[i].text = content;
              final now = DateTime.now();
              if (now.difference(lastPaint).inMilliseconds > 120) {
                lastPaint = now;
                notifyListeners();
              }
            },
          );
          draws[i]
            ..text = res.text
            ..tokens = res.totalTokens
            ..done = true;
          settings.totalTokens += res.totalTokens;
          settings.requestCount += 1;
        } on LlmException catch (e) {
          draws[i]
            ..error = e.message
            ..done = true;
        } catch (e) {
          draws[i]
            ..error = '出了点意外：$e'
            ..done = true;
        }
      }));

      await _persist();
    } finally {
      drawing = false;
      notifyListeners();
    }
  }

  /// 选定一份：其余未丢弃的收进这条消息的「其他候选」
  Future<void> pickDraw(int index) async {
    if (index < 0 || index >= draws.length) return;
    final picked = draws[index];
    if (!picked.done || picked.text.trim().isEmpty) return;

    final others = <String>[];
    for (var i = 0; i < draws.length; i++) {
      if (i != index && !draws[i].discarded && draws[i].text.trim().isNotEmpty) {
        others.add(draws[i].text);
      }
    }

    final reply = AiReply.parse(picked.text);
    final bubble = ChatBubble(
      role: 'assistant',
      text: reply.message.trim().isNotEmpty ? reply.message : reply.chapterContent,
      options: reply.options,
      tokens: picked.tokens,
      raw: picked.text,
      alts: others,
    );
    novel.chats.add(bubble);
    draws = <DrawCandidate>[];

    if (reply.hasChapter) {
      pendingTitle = reply.chapterTitle.trim().isEmpty
          ? '第${novel.chapters.length + 1}章'
          : reply.chapterTitle.trim();
      pendingContent = reply.chapterContent.trim();
      pending = Pending.saveChapter;
    }
    novel.touch();
    await _persist();
    notifyListeners();
  }

  void discardDraw(int index) {
    if (index < 0 || index >= draws.length) return;
    draws[index].discarded = true;
    notifyListeners();
  }

  void closeDraw() {
    draws = <DrawCandidate>[];
    notifyListeners();
  }

  /// 把某条「其他候选」换成正文，原来的正文退回候选
  Future<void> useAlt(int bubbleIndex, int altIndex) async {
    if (bubbleIndex < 0 || bubbleIndex >= novel.chats.length) return;
    final b = novel.chats[bubbleIndex];
    if (altIndex < 0 || altIndex >= b.alts.length) return;
    final cur = b.text;
    b.text = b.alts[altIndex];
    b.alts[altIndex] = cur;
    await _persist();
    notifyListeners();
  }

  Future<void> removeAlt(int bubbleIndex, int altIndex) async {
    if (bubbleIndex < 0 || bubbleIndex >= novel.chats.length) return;
    final b = novel.chats[bubbleIndex];
    if (altIndex < 0 || altIndex >= b.alts.length) return;
    b.alts.removeAt(altIndex);
    await _persist();
    notifyListeners();
  }

  /// 停止生成
  void cancelGeneration() {
    _cancel?.cancel();
    notifyListeners();
  }

  // ---------- 保存章节 ----------

  void confirmSaveChapter() {
    if (pending != Pending.saveChapter) return;
    novel.chapters.add(Chapter(title: pendingTitle, content: pendingContent));
    novel.touch();
    pending = Pending.none;
    pendingTitle = '';
    pendingContent = '';
    notifyListeners();
    _persist();
  }

  void cancelSaveChapter() {
    pending = Pending.none;
    pendingTitle = '';
    pendingContent = '';
    notifyListeners();
  }

  /// 模型给了书名：只有书还没名字时才写进去，返回是否改了
  bool absorbBookTitle(String raw) {
    final t = raw.trim();
    if (t.isEmpty) return false;
    if (novel.title.trim().isNotEmpty) return false;
    novel.title = t;
    novel.touch();
    return true;
  }

  /// 模型给了资料：新书第一次直接落库，已有资料时挂起等用户点「同步资料」
  DocsOutcome absorbDocs(Map<String, String> docs) {
    if (docs.isEmpty) return DocsOutcome.none;
    if (!novel.needsSetup) {
      pendingDocs = docs;
      return DocsOutcome.pending;
    }
    writeDocs(docs);
    return DocsOutcome.applied;
  }

  /// 把模型给的三份资料写进这本书（只改内存，保存和通知由调用方负责）
  void writeDocs(Map<String, String> docs) {
    if (docs.containsKey('characters')) novel.characters = docs['characters']!;
    if (docs.containsKey('world')) novel.world = docs['world']!;
    if (docs.containsKey('summary')) novel.summary = docs['summary']!;
    novel.touch();
  }

  static String _docLabel(Map<String, String> docs) {
    const names = {'characters': '人物库', 'world': '世界观', 'summary': '章节摘要'};
    return docs.keys.map((k) => names[k] ?? k).join(' · ');
  }

  // ---------- 章节存完后，问是否同步资料 ----------

  Future<void> requestDocsUpdate() async {
    if (busy) return;
    busy = true;
    errorText = null;
    notifyListeners();
    try {
      final system = await buildSystemPrompt(
        novel,
        skillText: activeSkillText,
        skillId: settings.activeSkillId,
        skillName: activeSkillName,
        styleName: styleSkill?.name,
        styleText: styleSkill?.content,
        thinkingLevel: settings.thinkingLevel,
      );
      final msgs = <Map<String, String>>[
        {'role': 'system', 'content': system},
        {'role': 'user', 'content': buildSyncPrompt(novel)},
      ];
      final res = await callModel(settings: settings, messages: msgs);
      settings.totalTokens += res.totalTokens;
      settings.requestCount += 1;
      final reply = AiReply.parse(res.text);
      if (reply.hasDocs) {
        pendingDocs = reply.docs;
        pending = Pending.syncDocs;
      } else {
        errorText = '模型这次没给出资料更新，可以先跳过，下一章再同步。';
      }
      await _persist();
    } on LlmException catch (e) {
      errorText = e.message;
    } catch (e) {
      errorText = '出了点意外：$e';
    } finally {
      busy = false;
      notifyListeners();
    }
  }

  void confirmSyncDocs() {
    if (pending != Pending.syncDocs) return;
    writeDocs(pendingDocs);
    pendingDocs = const {};
    pending = Pending.none;
    notifyListeners();
    _persist();
  }

  void cancelSyncDocs() {
    pendingDocs = const {};
    pending = Pending.none;
    notifyListeners();
  }

  // ---------- 技能 ----------

  SkillDoc? get activeImportedSkill {
    for (final s in settings.importedSkills) {
      if (s.id == settings.activeSkillId) return s;
    }
    return null;
  }

  String get activeSkillName {
    final imported = activeImportedSkill;
    if (imported != null) return imported.name;
    return builtinSkillById(settings.activeSkillId)?.name ?? '小说写作';
  }

  /// 当前风格技能（附加约束，不改主流程）
  SkillDoc? get styleSkill {
    for (final s in settings.importedSkills) {
      if (s.id == settings.styleSkillId) return s;
    }
    return null;
  }

  Future<void> setStyleSkill(String id) async {
    settings.styleSkillId = settings.styleSkillId == id ? '' : id;
    await _persist();
    notifyListeners();
  }

  /// 风格蒸馏：上传的样本文本 → 生成风格技能并设为风格
  Future<String?> distillStyle({required String name, required String sample}) async {
    if (busy) return null;
    busy = true;
    errorText = null;
    final bubble = ChatBubble(role: 'assistant', text: '');
    novel.chats.add(ChatBubble(
      role: 'user',
      text: '【风格蒸馏】$name · 样本 ${sample.length} 字',
    ));
    novel.chats.add(bubble);
    novel.touch();
    notifyListeners();

    final token = CancelToken();
    _cancel = token;

    try {
      final skillText = await SkillPack.load('builtin:skill-creator');
      final system = await buildSystemPrompt(
        novel,
        skillText: skillText,
        skillId: 'builtin:skill-creator',
        skillName: '技能创作',
      );
      final clipped = sample.length > 20000 ? sample.substring(0, 20000) : sample;
      final msgs = <Map<String, String>>[
        {
          'role': 'system',
          'content': '$system\n\n【本次任务·风格蒸馏】'
              '用户上传了一份小说样本，要把它蒸馏成一个可复用的「写作风格技能」。'
              '不要反问、不要征求确认，直接输出最终的 SKILL.md 全文：'
              '开头是 --- name/description --- frontmatter，正文写清用词偏好、句长、节奏、'
              '常见桥段、对话处理、禁忌与反例。用中文写。'
        },
        {
          'role': 'user',
          'content': '风格名称：$name\n\n样本正文（可能已截断）：\n$clipped'
        },
      ];

      bubble.tools = <ToolStep>[
        const ToolStep('加载技能', '技能创作'),
        ToolStep('读取', name, '样本 ${sample.length} 字，实际送入 ${clipped.length} 字'),
      ];

      var lastPaint = DateTime.now();
      final res = await streamModel(
        settings: settings,
        messages: msgs,
        cancel: token,
        onDelta: (content, reasoning) {
          bubble.text = content;
          bubble.reasoning = reasoning;
          final now = DateTime.now();
          if (now.difference(lastPaint).inMilliseconds > 80) {
            lastPaint = now;
            notifyListeners();
          }
        },
      );

      settings.totalTokens += res.totalTokens;
      settings.requestCount += 1;

      final body = res.text.trim();
      if (body.isEmpty) {
        bubble.text = '（蒸馏失败：模型没返回内容）';
        return null;
      }

      final doc = await saveSkillFromText(name, body);
      settings.styleSkillId = doc.id;
      bubble
        ..text = '已生成风格技能「$name」，并设为写作风格。\n'
            '以后写小说会自动套用它的用词与节奏；想改就进「设置 → Skill 管理」点开这份技能。'
        ..tokens = res.totalTokens
        ..ms = 0
        ..raw = body;
      await _persist();
      _retryAction = null;
      _failedBubble = null;
      return name;
    } on LlmException catch (e) {
      bubble.text = bubble.text.trim().isEmpty ? '（出错了）' : bubble.text;
      errorText = e.message;
      _retryAction = () => distillStyle(name: name, sample: sample);
      _failedBubble = bubble;
      return null;
    } catch (e) {
      bubble.text = '（出错了）';
      errorText = '出了点意外：$e';
      _retryAction = () => distillStyle(name: name, sample: sample);
      _failedBubble = bubble;
      return null;
    } finally {
      busy = false;
      _cancel = null;
      notifyListeners();
    }
  }

  /// 把对话里生成的技能内容直接存成技能
  Future<SkillDoc> saveSkillFromText(String name, String content) async {
    final id = 'imported-${DateTime.now().microsecondsSinceEpoch}';
    final doc = SkillDoc(id: id, name: name.trim(), content: content, path: '来自对话');
    settings.importedSkills.add(doc);
    await _persist();
    notifyListeners();
    return doc;
  }

  /// 当前内置技能 id（导入技能时返回 null）
  String? get activeBuiltinId => builtinSkillById(settings.activeSkillId)?.id;

  /// 当前技能原文（内置则返回 null，让提示词去读 assets）
  String? get activeSkillText => activeImportedSkill?.content;

  Future<void> importSkill(String name, String path, String content) async {
    final id = 'imported-${DateTime.now().microsecondsSinceEpoch}';
    settings.importedSkills.add(SkillDoc(
      id: id,
      name: name,
      content: content,
      path: path,
    ));
    if (!settings.allowedDirs.contains(path)) {
      // 记一份来源，方便以后做「始终允许」判断
    }
    settings.activeSkillId = id;
    await _persist();
    notifyListeners();
  }

  Future<void> removeSkill(String id) async {
    settings.importedSkills.removeWhere((s) => s.id == id);
    if (settings.activeSkillId == id) settings.activeSkillId = 'builtin';
    await _persist();
    notifyListeners();
  }

  bool isSkillEnabled(String id) => !settings.disabledSkills.contains(id);

  int get totalSkillCount => kBuiltinSkills.length + settings.importedSkills.length;

  int get enabledSkillCount {
    var n = 0;
    for (final b in kBuiltinSkills) {
      if (isSkillEnabled(b.id)) n++;
    }
    for (final s in settings.importedSkills) {
      if (isSkillEnabled(s.id)) n++;
    }
    return n;
  }

  String? _firstEnabledSkill({String? exclude}) {
    for (final b in kBuiltinSkills) {
      if (b.id != exclude && isSkillEnabled(b.id)) return b.id;
    }
    for (final s in settings.importedSkills) {
      if (s.id != exclude && isSkillEnabled(s.id)) return s.id;
    }
    return null;
  }

  /// 开关技能。全部关掉会拒绝，至少留一个。
  Future<bool> setSkillEnabled(String id, bool on) async {
    if (on) {
      settings.disabledSkills.remove(id);
    } else {
      final remain = _firstEnabledSkill(exclude: id);
      if (remain == null) return false;
      if (!settings.disabledSkills.contains(id)) settings.disabledSkills.add(id);
      if (settings.activeSkillId == id) settings.activeSkillId = remain;
      if (settings.styleSkillId == id) settings.styleSkillId = '';
    }
    await _persist();
    notifyListeners();
    return true;
  }

  /// 广场添加：已存在则不重复加
  Future<bool> addMarketSkill({
    required String id,
    required String name,
    required String content,
  }) async {
    final skillId = 'market:$id';
    if (settings.importedSkills.any((s) => s.id == skillId)) return false;
    settings.importedSkills.add(SkillDoc(
      id: skillId,
      name: name,
      content: content,
      path: 'Skill 广场',
    ));
    settings.disabledSkills.remove(skillId);
    await _persist();
    notifyListeners();
    return true;
  }

  bool hasMarketSkill(String id) =>
      settings.importedSkills.any((s) => s.id == 'market:$id');

  /// 导出：当前技能原文（可直接存成 .md 分享）
  Future<String> exportActiveSkillText() async {
    final imported = activeImportedSkill;
    if (imported != null) return imported.content;
    return SkillPack.load(settings.activeSkillId);
  }

  /// 导出：全部技能打包成 JSON
  Future<String> exportAllSkillsJson() async {
    final list = <Map<String, dynamic>>[];
    for (final b in kBuiltinSkills) {
      list.add({
        'id': b.id,
        'name': b.name,
        'desc': b.desc,
        'content': await SkillPack.load(b.id),
      });
    }
    for (final s in settings.importedSkills) {
      list.add({'id': s.id, 'name': s.name, 'content': s.content});
    }
    return const JsonEncoder.withIndent('  ').convert({
      'app': 'novel_app',
      'version': 1,
      'skills': list,
    });
  }

  Future<void> setActiveSkill(String id) async {
    settings.activeSkillId = id;
    await _persist();
    notifyListeners();
  }

  Future<void> rememberDir(String dir) async {
    if (dir.trim().isEmpty) return;
    if (!settings.allowedDirs.contains(dir)) {
      settings.allowedDirs.add(dir);
      await _persist();
      notifyListeners();
    }
  }

  // ---------- 新建小说向导 ----------

  void startWizard() {
    wizardOpen = true;
    wizardStep = 0;
    wizardAnswers = ['', '', ''];
    notifyListeners();
  }

  void wizardPick(String value) {
    if (!wizardOpen) return;
    wizardAnswers[wizardStep] = value;
    notifyListeners();
  }

  void wizardPrev() {
    if (wizardStep > 0) {
      wizardStep -= 1;
      notifyListeners();
    }
  }

  void wizardNext() {
    if (wizardAnswers[wizardStep].trim().isEmpty) return;
    if (wizardStep < kNewBookWizard.length - 1) {
      wizardStep += 1;
      notifyListeners();
    }
  }

  void wizardCancel() {
    wizardOpen = false;
    notifyListeners();
  }

  /// 向导走完：把三步答案整理成一段话，交给界面放进输入框（不自动发）
  String wizardPromptText() {
    final q = StringBuffer('【新书设定】');
    for (var i = 0; i < kNewBookWizard.length; i++) {
      q.write('${kNewBookWizard[i].title}：${wizardAnswers[i]}');
      if (i < kNewBookWizard.length - 1) q.write('；');
    }
    q.write('。\n请按技能包初始化这本小说：先问我要书名（给几个候选，我也能自己填），'
        '我选定后再写人物库、世界观和章节摘要（三份都要写全）。');
    q.write('\n书名确定前不要自己起名、不要写资料；初始化完成后不要直接写正文，'
        '先用 [选项] 给我两条路：直接写第一章 / 先调整设定。');
    return q.toString();
  }

  void wizardClose() {
    wizardOpen = false;
    notifyListeners();
  }

  // ---------- 模型切换 ----------

  /// 从清单里选一个模型：地址、模型名、对应的 Key 一起换
  Future<void> switchModel(ModelOption m) async {
    settings.baseUrl = m.baseUrl;
    settings.model = m.model;
    settings.provider = m.provider;
    settings.apiKey = settings.keys[m.provider] ?? '';
    await _persist();
    notifyListeners();
  }

  /// 自定义模型 ID（清单里没有的）
  Future<void> switchCustomModel(
      {required String provider, required String baseUrl, required String model}) async {
    settings.provider = provider;
    settings.baseUrl = baseUrl;
    settings.model = model;
    settings.apiKey = settings.keys[provider] ?? '';
    await _persist();
    notifyListeners();
  }

  /// 记住某个供应商的 Key
  Future<void> setKey(String provider, String key) async {
    settings.keys[provider] = key.trim();
    if (settings.provider == provider) settings.apiKey = key.trim();
    await _persist();
    notifyListeners();
  }

  // ---------- 设置 ----------

  Future<void> saveSettings(Settings s) async {
    final old = settings;
    settings = s;
    // 换了 Key / 地址后，之前那条 401 已不成立。但不直接清掉——
    // 留着错误条，用户才知道可以点「重试」接着跑，不用重新导入文件。
    if (errorText != null &&
        s.isReady &&
        (old.apiKey != s.apiKey || old.baseUrl != s.baseUrl || old.model != s.model)) {
      errorText = 'Key 已更新，点「重试」可以接着跑刚才那一步';
    }
    await _persist();
    notifyListeners();
  }

  String _expandRefs(String text) => _expandRefsFor(novel, text);

  /// 自动选源：先试上次能用的，再依次试内置书源
  Future<String> ensureSource({
    List<String>? candidates,
    void Function(String message)? onProgress,
    bool forceReprobe = false,
  }) async {
    final saved = settings.sourceBase.trim();
    final raw = candidates ?? [if (!forceReprobe && saved.isNotEmpty) saved, ...kBookSources];
    final ordered = <String>[];
    final seen = <String>{};
    for (final c in raw) {
      final n = normalizeBase(c);
      if (n.isEmpty || !seen.add(n)) continue;
      ordered.add(n);
    }
    for (var i = 0; i < ordered.length; i++) {
      final base = ordered[i];
      final host = Uri.tryParse(base)?.host ?? base;
      onProgress?.call('正在找可用书源 ${i + 1}/${ordered.length}：$host');
      if (await isSourceAlive(base)) {
        settings.sourceBase = base;
        await _persist();
        notifyListeners();
        return base;
      }
    }
    return '';
  }

  bool get hasRank => lastRank.isNotEmpty;

  void cacheRank(List<RankBook> list, String url) {
    lastRank = list;
    lastRankUrl = url;
    final now = DateTime.now();
    lastRankAt = '${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}';
    notifyListeners();
  }

  // ---------- 备份 / 恢复 ----------

  /// 全量备份：书（含章节、对话、备忘录、生成历史）+ 设置
  String exportBackupJson() {
    return jsonEncode({
      'app': 'novel_app',
      'version': kAppVersion,
      'exportedAt': DateTime.now().millisecondsSinceEpoch,
      'currentId': currentId,
      'books': books.map((b) => b.toJson()).toList(),
      'settings': settings.toJson(),
    });
  }

  /// 导入备份，替换当前全部数据。失败抛 FormatException，message 可直接展示。
  Future<String> importBackupJson(String raw) async {
    dynamic data;
    try {
      data = jsonDecode(raw);
    } catch (_) {
      throw const FormatException('备份内容不是合法 JSON。');
    }
    if (data is! Map) throw const FormatException('备份格式不对：最外层应该是对象。');
    final list = data['books'];
    if (list is! List) throw const FormatException('备份里没有 books 列表，可能不是这个 App 导出的。');

    final restored = <Novel>[];
    for (final e in list) {
      if (e is Map) restored.add(Novel.fromJson(e.cast<String, dynamic>()));
    }
    if (restored.isEmpty) throw const FormatException('备份里一本书都没有。');

    books = restored;
    final cid = (data['currentId'] ?? '').toString();
    currentId = books.any((b) => b.id == cid) ? cid : books.first.id;
    final s = data['settings'];
    if (s is Map) settings = Settings.fromJson(s.cast<String, dynamic>());

    await _persist();
    notifyListeners();
    return '已恢复 ${books.length} 本书，共 ${books.fold<int>(0, (n, b) => n + b.chapters.length)} 章';
  }

  /// 占用体积（按 JSON 字节粗算）
  int get storageBytes =>
      utf8.encode(jsonEncode(books.map((b) => b.toJson()).toList())).length +
      utf8.encode(jsonEncode(settings.toJson())).length;

  /// 重置：清聊天记录、导入的技能、自定义参数；保留作品、备忘录和 API Key
  Future<void> resetUserData() async {
    for (final b in books) {
      b.chats.clear();
      b.gens.clear();
      b.touch();
    }
    settings.importedSkills.clear();
    settings.disabledSkills.clear();
    settings.styleSkillId = '';
    settings.activeSkillId = 'builtin:novel-writer';
    settings.customPrompt = '';
    settings.temperature = 0.9;
    settings.thinkingLevel = 'default';
    settings.chatFontSize = 14;
    settings.editorFontSize = 14;
    settings.webdavUrl = '';
    settings.webdavUser = '';
    settings.webdavPass = '';
    settings.webdavPath = '/OpenWrite/';
    await _persist();
    notifyListeners();
  }

  Future<void> saveWebdav({
    required String url,
    required String user,
    required String pass,
    required String path,
  }) async {
    settings.webdavUrl = url.trim();
    settings.webdavUser = user.trim();
    settings.webdavPass = pass;
    settings.webdavPath = path.trim();
    await _persist();
    notifyListeners();
  }

  /// 粗估 token：中文约 1.6 字/token，够用来做预算裁剪
  int _estimateTokens(String text) =>
      (text.replaceAll(RegExp(r'\s'), '').length / 1.6).ceil();

  Future<void> saveParams({
    required bool autoCompact,
    required int contextWindowK,
    required int maxOutputK,
    required int outputReserveK,
  }) async {
    settings.autoCompact = autoCompact;
    settings.contextWindowK = contextWindowK;
    settings.maxOutputK = maxOutputK;
    settings.outputReserveK = outputReserveK;
    await _persist();
    notifyListeners();
  }

  Future<void> setCustomPrompt(String v) async {
    settings.customPrompt = v.trim();
    await _persist();
    notifyListeners();
  }

  Future<void> setChatFontSize(double v) async {
    settings.chatFontSize = v;
    await _persist();
    notifyListeners();
  }

  Future<void> setEditorFontSize(double v) async {
    settings.editorFontSize = v;
    await _persist();
    notifyListeners();
  }

  Future<void> setSoundEnabled(bool v) async {
    settings.soundEnabled = v;
    await _persist();
    notifyListeners();
  }

  Future<void> setThemeMode(String v) async {
    settings.themeMode = v;
    await _persist();
    notifyListeners();
  }

  Future<void> setAgentEnabled(bool v) async {
    settings.agentEnabled = v;
    await _persist();
    notifyListeners();
  }

  Future<void> setSearchEnabled(bool v) async {
    settings.searchEnabled = v;
    await _persist();
    notifyListeners();
  }

  Future<void> saveSearchConfig({
    required String provider,
    required String key,
    required int count,
  }) async {
    settings.searchProvider = provider;
    settings.searchKey = key.trim();
    settings.searchCount = count.clamp(1, 10);
    await _persist();
    notifyListeners();
  }

  /// 界面上的「测试搜索」按钮直接用这个
  Future<List<WebSource>> runSearchOnce(String query) => _searchWeb(query);

  Future<List<WebSource>> _searchWeb(String query) => searchWeb(
        provider: settings.searchProvider,
        key: settings.searchKey,
        query: query,
        count: settings.searchCount,
      );

  /// 取气泡之前最近一条用户消息，作为搜索词
  String _lastUserText(ChatBubble before) {
    final list = novel.chats;
    final i = list.indexOf(before);
    for (var k = (i < 0 ? list.length : i) - 1; k >= 0; k--) {
      final b = list[k];
      if (b.role == 'user' && b.text.trim().isNotEmpty) {
        return b.text.replaceAll(RegExp(r'#[^\s]+'), '').trim();
      }
    }
    return '';
  }

  Future<void> setMarketFeedUrl(String v) async {
    settings.marketFeedUrl = v.trim();
    await _persist();
    notifyListeners();
  }

  Future<void> setScanEnabled(bool v) async {
    settings.scanEnabled = v;
    await _persist();
    notifyListeners();
  }

  // ---------- 脑洞 / 简介历史 ----------

  List<GenRecord> gensOf(String kind) =>
      novel.gens.where((g) => g.kind == kind).toList();

  Future<void> addGen(GenRecord r) async {
    novel.gens.insert(0, r);
    novel.touch();
    await _persist();
    notifyListeners();
  }

  Future<void> removeGen(String id) async {
    novel.gens.removeWhere((g) => g.id == id);
    novel.touch();
    await _persist();
    notifyListeners();
  }

  Future<void> setSourceBase(String v) async {
    settings.sourceBase = v.trim();
    await _persist();
  }

  Future<void> setThinkingLevel(String level) async {
    settings.thinkingLevel = level;
    await _persist();
    notifyListeners();
  }

  Future<void> setTemperature(double v) async {
    settings.temperature = v;
    await _persist();
    notifyListeners();
  }

  Future<void> setFollowSystemTheme(bool v) async {
    settings.followSystemTheme = v;
    await _persist();
    notifyListeners();
  }
}
