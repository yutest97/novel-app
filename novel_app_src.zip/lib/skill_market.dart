import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;

/// 广场里的一个技能
class MarketSkill {
  final String id;
  final String name;
  final String desc;
  final String category;
  final String author;
  final int downloads; // 订阅源提供；内置为 0
  final String content;

  const MarketSkill({
    required this.id,
    required this.name,
    required this.desc,
    required this.category,
    required this.author,
    required this.content,
    this.downloads = 0,
  });
}

class SkillFeedException implements Exception {
  final String message;
  SkillFeedException(this.message);
  @override
  String toString() => message;
}

const List<String> kMarketCategories = ['全部', '润色', '技法', '大纲', '脑洞', '流程'];

/// 随 App 内置的精选技能（离线可用）
const List<MarketSkill> kMarketSkills = [
  MarketSkill(
    id: 'deai-polish',
    name: '去 AI 味润色',
    desc: '删掉排比、升华和空泛比喻，把文字改回人写的',
    category: '润色',
    author: '内置精选',
    content: r'''# 去 AI 味润色

## 目标
把一段读起来像 AI 写的文字，改成有人味的小说正文。剧情和事实不许改。

## 必须删掉的
- 排比三连、每段都「不是……而是……」
- 空泛比喻：「仿佛整个世界都安静了」「像是被命运扼住了喉咙」
- 情绪解释句：直接写「他很愤怒」「她感到绝望」
- 段落结尾的升华和总结：“这一刻，他终于明白……”
- 形容词堆叠：用动作、声音、气味、数字替代

## 怎么改
1. 先删掉所有解释情绪的句子，只留动作、对话、感官细节
2. 把三句合并成一句，或把一句拆成三个短句，让句长不齐
3. 每 200 字至少放一处具体名词：牌子、型号、气味、时间、金额
4. 对话允许不完整句、打断、答非所问；不要每句都带「说道」

## 输出
先给改后的全文，再用三行说明改了哪几类问题。不要讲理论。''',
  ),
  MarketSkill(
    id: 'opening-hooks',
    name: '开篇三章钩子',
    desc: '前三章各留一个必须追问的悬念，避免开局劝退',
    category: '技法',
    author: '内置精选',
    content: r'''# 开篇三章钩子

## 目标
让读者看完第一章前 300 字，心里冒出一个必须回答的问题。

## 三章结构
- 第 1 章「异常日常」：熟悉场景里出现一件不该发生的事，结尾留具体物证、一句话或一个来电。
- 第 2 章「代价显现」：主角去处理，越处理越糟，暴露短板和他真正在乎的人。
- 第 3 章「被迫入场」：规则或反派第一次正面施压，主角做出不可逆的选择。

## 硬要求
- 第一章不解释世界观，只给感官细节
- 主角第一次出场必须有一个具体动作，不要从外貌写起
- 每章结尾都留一个「下一章要解释的事」
- 三章内至少一次「意料之外、情理之中」的小反转

## 输出
每章给 3 个钩子方案（各一句话），再推荐一套组合，最后用 [选项] 让我挑。''',
  ),
  MarketSkill(
    id: 'character-arc',
    name: '人物弧光设计',
    desc: '把主角从「设定」变成「会变的人」，附三段式弧光模板',
    category: '技法',
    author: '内置精选',
    content: r'''# 人物弧光设计

## 先问三个问题
1. 他一开始坚信什么（一句能被现实打脸的话）？
2. 什么事能逼他放弃这个信念？
3. 放弃之后他换成了什么（新的行为准则，不是新口号）？

## 三段式
- 建立：用一个具体选择证明他的旧信念，让读者看见代价。
- 撕裂：让旧信念救不了他在乎的人，且是他自己的选择导致的。
- 重建：他做出和开头相反的选择，但保留一个旧习惯作为痕迹。

## 配角规则
- 每个重要配角都要有一件「和主角冲突但在理」的事
- 反派的目标要具体到可以被拒绝，不要「统治世界」
- 配角不许只负责夸主角

## 输出
给主角一份 200 字弧光卡：旧信念 / 触发事件 / 新准则 / 保留的旧习惯。再给两个配角各一句冲突点。''',
  ),
  MarketSkill(
    id: 'dialogue-subtext',
    name: '对话潜台词打磨',
    desc: '让角色说一半、藏一半，对话不再像信息播报',
    category: '技法',
    author: '内置精选',
    content: r'''# 对话潜台词打磨

## 原则
人物说出口的话，和他真正想要的东西，必须不一样。

## 四个手法
1. 答非所问：问「你去哪了」，答「你吃饭了吗」。
2. 转移焦点：不接情绪，只纠一个细节（「几点」「哪把钥匙」）。
3. 动作打断：话说一半，去做一件小事（点烟、关窗、擦桌子）。
4. 重复对方的话：把一句关键话原样重复，语气变冷。

## 禁止
- 两个人互相解释设定
- 每句都「他说道」「她问道」
- 一段对话里出现三个以上人名

## 输出
重写给出的对话，保留信息点但改成有潜台词；末尾用两行说明每个人真正想要什么。''',
  ),
  MarketSkill(
    id: 'payoff-pacing',
    name: '爽点节奏表',
    desc: '按字数排出压抑、反转、兑现的位置，避免一直平',
    category: '技法',
    author: '内置精选',
    content: r'''# 爽点节奏表

## 节奏单位
以 3000 字为一节，一节内必须有一次情绪起伏。

## 四拍循环
1. 压：主角被看轻、被限制，给出具体羞辱或损失（不超过 800 字）。
2. 转：主角发现一个别人不知道的信息或规则漏洞。
3. 兑：当众兑现，让施压者付出代价，写出旁观者反应。
4. 钩：兑现后暴露更大的麻烦，或引来更强的对手。

## 检查表
- 连续两节都在「压」＝读者会跑，中间必须插一次小兑现
- 兑现要落在具体物件或数字上（合同、排名、金额），不要只写「众人震惊」
- 每 5 节安排一次关系变化（结盟、背叛、身份暴露）

## 输出
针对当前大纲，标出每节的四拍位置，指出哪几节缺兑现，给修改建议。''',
  ),
  MarketSkill(
    id: 'outline-30',
    name: '三十章大纲流水线',
    desc: '从一句梗概推到 30 章，每章带目标、冲突、钩子',
    category: '大纲',
    author: '内置精选',
    content: r'''# 三十章大纲流水线

## 输入
一句话梗概 + 主角金手指 + 目标读者（男频/女频）。

## 三段推进
- 1~10 章：立人设、亮金手指、拿到第一个小胜，结尾进入更大的局。
- 11~20 章：换地图或换对手，旧方法失效，主角被迫升级规则理解。
- 21~30 章：旧对手回归，主角用前 20 章埋的伏笔翻盘，留一个续作口子。

## 每章必须写清
1. 本章目标（角色想得到什么）
2. 阻力（谁或什么规则挡着）
3. 结果（得到/失去/换目标）
4. 结尾钩子（一句话）

## 禁止
- 连续三章同一场景
- 靠新角色解决主角的问题
- 「修炼了三个月，实力大涨」这种跳时间

## 输出
用表格给 30 行，每行四列。最后标出 3 个必须提前埋的伏笔及回收章节。''',
  ),
  MarketSkill(
    id: 'urban-idea',
    name: '都市脑洞引擎',
    desc: '从「一个规则 + 一个代价」出发，批量产出能写的都市设定',
    category: '脑洞',
    author: '内置精选',
    content: r'''# 都市脑洞引擎

## 公式
一个日常职业 + 一条超自然规则 + 一个必须支付的代价 = 一个脑洞。

## 生成步骤
1. 先选职业：殡仪馆、外卖、房产中介、夜班保安、宠物医院、拆迁办。
2. 给这个职业一个「只有从业者知道的秘密」。
3. 规则必须能一句话说清，且有边界（例如：只能在凌晨三点后用，只能用三次）。
4. 代价必须影响人际关系，不只是掉血。

## 好脑洞的检验
- 能不能用一句话让朋友听懂并追问「然后呢」
- 前 10 章有没有天然的冲突来源（同行、监管、客户）
- 主角能不能靠脑子而不是靠升级解决问题

## 输出
给 5 个脑洞，每个包含：书名、一句话梗概、规则与代价、前 10 章冲突源。用 [选项] 让我挑一个展开。''',
  ),
  MarketSkill(
    id: 'fanqie-short',
    name: '短篇快节奏改写',
    desc: '按短篇平台习惯压节奏：开头 300 字见冲突，每章一个钩子',
    category: '流程',
    author: '内置精选',
    content: r'''# 短篇快节奏改写

## 平台习惯
读者在信息流里滑到你的第一章，只给你三句话。

## 三条硬指标
1. 前 300 字必须出现具体冲突（被退婚、被辞退、被冒领功劳）。
2. 每章 1500~2500 字，结尾必须有一句让人想点下一章的话。
3. 一章只解决一件事，不要在一章里换两个场景。

## 改写顺序
- 先砍掉所有背景介绍，挪到对话或动作里
- 把最刺激的一幕提到开头，再用一两句补前因
- 每段不超过四行，手机屏上一屏能读完
- 章末钩子用「新信息」或「新威胁」，不要用感慨

## 输出
按上面规则重排当前章节：给出新开头 300 字、删减说明、新的章末钩子。''',
  ),
  MarketSkill(
    id: 'consistency-check',
    name: '设定一致性检查',
    desc: '对照人物库与世界观，找出前后矛盾的设定和称呼',
    category: '流程',
    author: '内置精选',
    content: r'''# 设定一致性检查

## 检查范围
- 人名、称呼、亲属关系是否前后一致
- 能力规则有没有被临时加强（尤其是「突然能打赢」）
- 地点距离与时间线是否对得上（一夜之间跨城）
- 物品是否凭空出现或消失
- 人物知道的信息是否超出了他应该知道的

## 方法
1. 先列出本章出现的所有专有名词。
2. 逐个对照人物库/世界观/章节摘要。
3. 标出冲突：原文引用 + 冲突点 + 建议改法（改哪一边都行，但要给理由）。

## 输出
分三组：确定矛盾 / 可能矛盾 / 建议补设定。每条不超过两行，方便我直接改。''',
  ),
  MarketSkill(
    id: 'blurb-polish',
    name: '简介打磨',
    desc: '把简介改成三句话抓住人：处境、转折、代价',
    category: '润色',
    author: '内置精选',
    content: r'''# 简介打磨

## 结构
第一句写处境（具体到身份和处境，不写「一个平凡少年」）。
第二句写转折（发生了一件打破日常的事，带具体细节）。
第三句写代价或悬念（他必须付出什么，或读者会追问什么）。

## 禁忌
- 「且看……」 「从此走上人生巅峰」
- 罗列设定名词超过三个
- 用「神秘」「未知」「惊天秘密」这种空词

## 三版要求
1. 悬念版：藏住金手指，只给异常。
2. 爽点版：亮出规则和代价，让读者预期兑现。
3. 人物版：写他和谁的关系被改变。

## 输出
给三版，每版 80~120 字，各附一句「适合的读者」。''',
  ),
];

/// 解析订阅源 JSON：支持数组，或 {"skills":[...]}
List<MarketSkill> parseMarketFeed(String raw) {
  dynamic data;
  try {
    data = jsonDecode(raw);
  } catch (_) {
    throw SkillFeedException('订阅源不是合法 JSON。');
  }

  List<dynamic>? list;
  if (data is List) {
    list = data;
  } else if (data is Map && data['skills'] is List) {
    list = data['skills'] as List;
  }
  if (list == null) {
    throw SkillFeedException('订阅源格式不对：要 JSON 数组，或 {"skills": [...]}。');
  }

  final out = <MarketSkill>[];
  for (final e in list) {
    if (e is! Map) continue;
    final name = (e['name'] ?? '').toString().trim();
    final content = (e['content'] ?? '').toString();
    if (name.isEmpty || content.trim().isEmpty) continue;
    out.add(MarketSkill(
      id: (e['id'] ?? name).toString(),
      name: name,
      desc: (e['desc'] ?? '').toString(),
      category: (e['category'] ?? '其他').toString(),
      author: (e['author'] ?? '未署名').toString(),
      downloads: e['downloads'] is num ? (e['downloads'] as num).toInt() : 0,
      content: content,
    ));
  }
  if (out.isEmpty) {
    throw SkillFeedException('订阅源里没有有效技能（每条要有 name 和 content）。');
  }
  return out;
}

/// 拉订阅源
Future<List<MarketSkill>> fetchMarketFeed(String url) async {
  final uri = Uri.tryParse(url.trim());
  if (uri == null || !uri.hasScheme) {
    throw SkillFeedException('订阅地址不对，要以 http:// 或 https:// 开头。');
  }
  http.Response resp;
  try {
    resp = await http.get(uri, headers: {
      'Accept': 'application/json,text/plain,*/*',
    }).timeout(const Duration(seconds: 12));
  } on TimeoutException {
    throw SkillFeedException('订阅源请求超时。');
  } catch (e) {
    throw SkillFeedException('连不上订阅源：$e');
  }
  if (resp.statusCode != 200) {
    throw SkillFeedException('订阅源返回 ${resp.statusCode}。');
  }
  return parseMarketFeed(utf8.decode(resp.bodyBytes, allowMalformed: true));
}
