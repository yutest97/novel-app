import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:novel_app/agent_tools.dart';
import 'package:novel_app/llm.dart';
import 'package:novel_app/models.dart';
import 'package:novel_app/prompt.dart';
import 'package:novel_app/store.dart';

const String _base = 'http://127.0.0.1:8777';

Settings _settings({String base = '$_base/v1'}) => Settings(
      baseUrl: base,
      apiKey: 'test-key',
      model: 'test-model',
      format: 'openai',
      agentEnabled: true,
    );

Future<Novel> _book() async {
  SharedPreferences.setMockInitialValues(<String, Object>{});
  await AppState.I.init();
  final b = Novel(title: '灰烬纪元')
    ..characters = '# 人物库\n叶烬，24 岁，殡仪馆火化工。'
    ..world = '# 世界观\n近未来江城，异能者被登记管理。'
    ..summary = '第1章 雨夜：捡到一枚芯片'
    ..chapters = [Chapter(title: '第1章 雨夜', content: '雨在凌晨三点停了。叶烬把最后一具遗体推进三号炉。')]
    ..notes = [Note(text: '伏笔：妹妹的名字要留到第 10 章', category: '大纲')];
  AppState.I.books = [b];
  AppState.I.currentId = b.id;
  AppState.I.settings
    ..baseUrl = '$_base/v1'
    ..apiKey = 'test-key'
    ..model = 'test-model'
    ..format = 'openai'
    ..agentEnabled = true
    ..sourceBase = _base
    ..requestCount = 0;
  return b;
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  setUpAll(() => HttpOverrides.global = null);

  test('流式解析 tool_calls', () async {
    final res = await streamModelWithTools(
      settings: _settings(),
      messages: [
        {'role': 'user', 'content': '读人物库'},
      ],
      tools: kAgentToolSpecs,
      onDelta: (_, __) {},
    );
    expect(res.toolCalls.length, 1);
    expect(res.toolCalls.first.name, 'read_doc');
    expect(res.toolCalls.first.arguments.contains('人物库'), isTrue);
    expect(res.promptTokens, 80);
  });

  test('Agent 循环：执行工具、回填结果、再回答', () async {
    final book = await _book();

    await AppState.I.send('读一下人物库');

    final last = AppState.I.novel.chats.last;
    expect(last.role, 'assistant');
    expect(last.tools.length, 1);
    expect(last.tools.first.action, '调用');
    expect(last.tools.first.name, '读资料 · 人物库');
    // 工具真的读到了书里的内容，不是摆设
    expect(last.tools.first.detail.contains('叶烬'), isTrue);
    expect(last.text.contains('叶烬'), isTrue);
    // 两轮对话：调工具一轮 + 最终回答一轮
    expect(book.chats.where((c) => c.role == 'user').length, 1);
    expect(AppState.I.settings.requestCount, 2);
  });

  test('Agent 循环：search_book 走真实爬虫', () async {
    await _book();

    await AppState.I.send('帮我搜一下斗破苍穹');

    final last = AppState.I.novel.chats.last;
    expect(last.tools.first.name, '搜书 · 斗破苍穹');
    expect(last.tools.first.detail.contains('斗破苍穹'), isTrue);
    expect(last.tools.first.detail.contains('/book/'), isTrue);
  });

  test('模型不认 tools：自动退回普通模式并说明', () async {
    final book = await _book();
    AppState.I.settings.baseUrl = '$_base/v1/bad';

    await AppState.I.send('读人物库');

    final last = AppState.I.novel.chats.last;
    expect(last.tools.first.action, '提示');
    expect(last.tools.first.name, '模型不支持工具调用');
    expect(last.text.contains('普通模式回答'), isTrue);
    // 普通模式仍然会把资料塞进上下文
    expect(last.tools.any((t) => t.name == '人物库.md'), isTrue);
    expect(book.chapters.length, 1);
  });

  test('Anthropic 消息转换：tool_calls 变 tool_use，工具结果合并成一条 user', () {
    final out = anthropicMessages([
      {'role': 'user', 'content': '读人物库'},
      {
        'role': 'assistant',
        'content': '',
        'tool_calls': [
          {
            'id': 't1',
            'type': 'function',
            'function': {'name': 'read_doc', 'arguments': '{"name":"人物库"}'},
          },
        ],
      },
      {'role': 'tool', 'tool_call_id': 't1', 'name': 'read_doc', 'content': '叶烬'},
      {'role': 'tool', 'tool_call_id': 't2', 'name': 'read_doc', 'content': '世界观'},
    ]);
    expect(out.length, 3);
    expect(out[0]['role'], 'user');
    final blocks = out[1]['content'] as List;
    expect(blocks.length, 1);
    expect(blocks.first['type'], 'tool_use');
    expect(blocks.first['input'], {'name': '人物库'});
    expect(out[2]['role'], 'user');
    expect((out[2]['content'] as List).length, 2);
    expect((out[2]['content'] as List).first['type'], 'tool_result');
  });

  test('Anthropic 协议：工具调用跑通并拿到结果', () async {
    await _book();
    AppState.I.settings
      ..format = 'anthropic'
      ..baseUrl = '$_base/v1';

    await AppState.I.send('读人物库');

    final last = AppState.I.novel.chats.last;
    expect(last.tools.first.action, '调用');
    expect(last.tools.first.name, '读资料 · 人物库');
    expect(last.tools.first.detail.contains('叶烬'), isTrue);
    expect(last.text.contains('Anthropic'), isTrue);
    expect(AppState.I.settings.requestCount, 2);
  });

  test('自定义提示词替换默认人设，但保留输出格式', () async {
    final prompt = await buildSystemPrompt(
      Novel(title: '测试书'),
      customPrompt: '你是一个只写悬疑的写手，从不解释设定。',
    );
    expect(prompt.contains('你是一个只写悬疑的写手'), isTrue);
    expect(prompt.contains('[选项]'), isTrue);
    expect(prompt.contains('AI 写小说助手'), isFalse);
  });

  test('上下文预算：窗口调小后历史被裁掉大部分', () async {
    final book = await _book();
    for (var i = 0; i < 30; i++) {
      book.chats.add(ChatBubble(role: 'user', text: '第 $i 条：${'测' * 300}'));
      book.chats.add(ChatBubble(role: 'assistant', text: '回复 $i：${'答' * 300}'));
    }
    AppState.I.settings
      ..agentEnabled = false
      ..autoCompact = true
      ..contextWindowK = 8
      ..outputReserveK = 1;

    await AppState.I.send('统计消息');
    final last = AppState.I.novel.chats.last;
    final m = RegExp(r'消息数：(\d+)').firstMatch(last.text);
    expect(m, isNotNull);
    final n = int.parse(m!.group(1)!);
    // 原本 61 条，裁完只留很少一部分
    expect(n, lessThan(40));
  });

  test('关闭自动压缩：固定带最近 12 条', () async {
    final book = await _book();
    for (var i = 0; i < 30; i++) {
      book.chats.add(ChatBubble(role: 'user', text: '第 $i 条：${'测' * 300}'));
      book.chats.add(ChatBubble(role: 'assistant', text: '回复 $i：${'答' * 300}'));
    }
    AppState.I.settings
      ..agentEnabled = false
      ..autoCompact = false
      ..contextWindowK = 8;

    await AppState.I.send('统计消息');
    final m = RegExp(r'消息数：(\d+)')
        .firstMatch(AppState.I.novel.chats.last.text);
    expect(m, isNotNull);
    expect(int.parse(m!.group(1)!), 13); // 1 system + 12 条
  });
}
