import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:novel_app/main.dart';
import 'package:novel_app/models.dart';
import 'package:novel_app/store.dart';
import 'package:novel_app/theme.dart';

Future<void> _loadFonts() async {
  final cjk = File('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc').readAsBytesSync();
  for (final f in ['CJK', 'monospace', 'Roboto']) {
    await (FontLoader(f)..addFont(Future.value(ByteData.view(cjk.buffer)))).load();
  }
  final icon = File('/opt/f3/flutter/bin/cache/artifacts/material_fonts/MaterialIcons-Regular.otf').readAsBytesSync();
  await (FontLoader('MaterialIcons')..addFont(Future.value(ByteData.view(icon.buffer)))).load();
}

Widget _wrap(Widget home) {
  final t = buildDarkTheme();
  return MaterialApp(
    debugShowCheckedModeBanner: false,
    theme: t.copyWith(
      textTheme: t.textTheme.apply(fontFamily: 'CJK'),
      primaryTextTheme: t.primaryTextTheme.apply(fontFamily: 'CJK'),
      appBarTheme: t.appBarTheme.copyWith(
        titleTextStyle: (t.appBarTheme.titleTextStyle ?? const TextStyle())
            .copyWith(fontFamily: 'CJK', color: const Color(0xFFEDEDF5)),
      ),
    ),
    home: home,
  );
}

Future<void> _setup(WidgetTester tester, {bool twoRounds = false}) async {
  tester.view.physicalSize = const Size(1080, 2400);
  tester.view.devicePixelRatio = 3.0;
  addTearDown(tester.view.resetPhysicalSize);
  addTearDown(tester.view.resetDevicePixelRatio);

  SharedPreferences.setMockInitialValues(<String, Object>{});
  await AppState.I.init();
  final b = Novel(title: '新对话')
    ..chats = [
      ChatBubble(role: 'user', text: '给我几个题材'),
      ChatBubble(
        role: 'assistant',
        text: '先选题材。',
        options: const [
          Choice('都市异能', '现代都市里觉醒特殊能力'),
          Choice('玄幻修真', '修炼升级、宗门争锋'),
        ],
      ),
      if (twoRounds) ...[
        ChatBubble(role: 'user', text: '都市异能'),
        ChatBubble(
          role: 'assistant',
          text: '好，那主角的困境是什么？',
          options: const [
            Choice('被公司裁员', '现实主义开局'),
            Choice('亲人病重', '需要钱'),
          ],
        ),
      ],
    ];
  AppState.I.books = [b];
  AppState.I.currentId = b.id;
  AppState.I.settings
    ..baseUrl = 'http://127.0.0.1:9/v1'
    ..apiKey = ''
    ..model = 'm';
  AppState.I.goTab(0);
  await tester.pumpWidget(_wrap(const HomeShell()));
  await tester.pumpAndSettle();
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  setUp(() async => _loadFonts());

  testWidgets('选项渲染成小胶囊，不是大卡片', (tester) async {
    await _setup(tester);
    expect(find.text('都市异能'), findsOneWidget);
    expect(find.text('玄幻修真'), findsOneWidget);
    // 说明文字不再占一整块卡片，只作为长按提示存在
    expect(find.text('现代都市里觉醒特殊能力'), findsNothing);
    expect(find.textContaining('选一个，或者直接说你的想法'), findsOneWidget);
  });

  testWidgets('最后一条才有内联输入框', (tester) async {
    await _setup(tester);
    expect(find.text('输入自定义答案…'), findsOneWidget);
    expect(find.text('发送'), findsOneWidget);
  });

  testWidgets('历史里的旧选项没有输入框', (tester) async {
    await _setup(tester, twoRounds: true);
    // 两轮选项，但只有最后一轮带输入框
    expect(find.text('输入自定义答案…'), findsOneWidget);
    expect(find.text('都市异能'), findsOneWidget);
    expect(find.text('被公司裁员'), findsOneWidget);
  });

  testWidgets('点胶囊把选项文字发出去', (tester) async {
    await _setup(tester);
    await tester.tap(find.text('玄幻修真'));
    await tester.pump();

    final last = AppState.I.novel.chats.last;
    expect(last.role, 'user');
    expect(last.text, '玄幻修真');
  });

  testWidgets('内联输入框写自定义答案并发送', (tester) async {
    await _setup(tester);
    await tester.enterText(find.widgetWithText(TextField, '输入自定义答案…'), '我想写殡葬师');
    await tester.pump();
    await tester.tap(find.text('发送'));
    await tester.pump();

    final last = AppState.I.novel.chats.last;
    expect(last.role, 'user');
    expect(last.text, '我想写殡葬师');
  });
}
