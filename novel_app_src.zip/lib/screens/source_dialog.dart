import 'package:flutter/material.dart';

import '../novel_source.dart';
import '../store.dart';
import '../theme.dart';

/// 全部内置书源都连不上时，让用户手动填一次
Future<String?> askSourceManually(BuildContext context, {String message = ''}) async {
  final ctrl = TextEditingController();
  final result = await showDialog<String>(
    context: context,
    builder: (ctx) => AlertDialog(
      backgroundColor: C.surface,
      title: const Text('手动填一个书源', style: TextStyle(fontSize: 15)),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (message.isNotEmpty)
            Text(
              message,
              style: const TextStyle(fontSize: 11.5, height: 1.6, color: C.dim),
            ),
          const SizedBox(height: 10),
          TextField(
            controller: ctrl,
            autofocus: true,
            style: const TextStyle(fontSize: 13, color: C.text),
            decoration: InputDecoration(
              hintText: '例如 www.example.com',
              hintStyle: const TextStyle(fontSize: 12, color: C.faint),
              filled: true,
              fillColor: C.card,
              isDense: true,
              contentPadding: const EdgeInsets.symmetric(vertical: 11, horizontal: 10),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(9),
                borderSide: const BorderSide(color: C.border, width: 0.7),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(9),
                borderSide: const BorderSide(color: C.border, width: 0.7),
              ),
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            '只需要填这一次，之后会记住。',
            style: TextStyle(fontSize: 10, color: C.faint),
          ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(ctx),
          child: const Text('取消', style: TextStyle(fontSize: 12.5, color: C.dim)),
        ),
        TextButton(
          onPressed: () => Navigator.pop(ctx, ctrl.text.trim()),
          child: const Text('使用', style: TextStyle(fontSize: 12.5, color: C.purpleSoft)),
        ),
      ],
    ),
  );
  ctrl.dispose();
  if (result == null || result.trim().isEmpty) return null;
  return normalizeBase(result);
}

/// 自动选源；全部失败时弹一次手动填写。返回可用地址，取消则返回空串。
Future<String> ensureSourceWithManual(
  BuildContext context, {
  bool forceReprobe = false,
  void Function(String message)? onProgress,
}) async {
  final navContext = Navigator.of(context).context;
  var base = await AppState.I.ensureSource(
    forceReprobe: forceReprobe,
    onProgress: onProgress,
  );
  if (base.isNotEmpty) return base;
  // 面板还开着才可能走到这里；用 navContext 是为了避开原 context 的 lint 误报
  // ignore: use_build_context_synchronously
  final manual = await askSourceManually(
    navContext,
    message: '内置书源这次都没连上（可能是网络或站点换了域名）。'
        '你可以填一个自己打得开的书站，只需要这一次。',
  );
  if (manual == null) return '';
  await AppState.I.setSourceBase(manual);
  return manual;
}
