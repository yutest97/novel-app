import 'dart:convert';

/// 一个章节
class Chapter {
  String title;
  String content;

  Chapter({required this.title, required this.content});

  Map<String, dynamic> toJson() => {'title': title, 'content': content};

  factory Chapter.fromJson(Map<String, dynamic> j) =>
      Chapter(title: j['title'] as String? ?? '未命名', content: j['content'] as String? ?? '');
}

/// 一本书：书名 + 三份维护文档 + 章节列表
class Novel {
  String title;
  String characters; // 人物库
  String world; // 世界观
  String summary; // 章节摘要
  List<Chapter> chapters;

  Novel({
    this.title = '',
    this.characters = '',
    this.world = '',
    this.summary = '',
    List<Chapter>? chapters,
  }) : chapters = chapters ?? <Chapter>[];

  bool get isEmpty =>
      title.trim().isEmpty &&
      characters.trim().isEmpty &&
      world.trim().isEmpty &&
      chapters.isEmpty;

  Map<String, dynamic> toJson() => {
        'title': title,
        'characters': characters,
        'world': world,
        'summary': summary,
        'chapters': chapters.map((c) => c.toJson()).toList(),
      };

  factory Novel.fromJson(Map<String, dynamic> j) => Novel(
        title: j['title'] as String? ?? '',
        characters: j['characters'] as String? ?? '',
        world: j['world'] as String? ?? '',
        summary: j['summary'] as String? ?? '',
        chapters: (j['chapters'] as List<dynamic>? ?? [])
            .map((e) => Chapter.fromJson(e as Map<String, dynamic>))
            .toList(),
      );

  /// 最近 n 章的正文，拼成给模型看的上下文
  String recentChapters(int n) {
    if (chapters.isEmpty) return '（暂无已保存章节）';
    final start = chapters.length - n < 0 ? 0 : chapters.length - n;
    final buf = StringBuffer();
    for (var i = start; i < chapters.length; i++) {
      buf.writeln('### ${chapters[i].title}');
      buf.writeln(_clip(chapters[i].content, 1200));
      buf.writeln();
    }
    return buf.toString();
  }

  static String _clip(String s, int max) =>
      s.length <= max ? s : '${s.substring(0, max)}……（后略）';
}

/// 一个可点的选项
class Choice {
  final String label;
  final String hint;

  Choice(this.label, this.hint);

  factory Choice.fromJson(Map<String, dynamic> j) => Choice(
        (j['label'] ?? j['text'] ?? '继续').toString(),
        (j['hint'] ?? j['description'] ?? '').toString(),
      );

  Map<String, dynamic> toJson() => {'label': label, 'hint': hint};
}

/// 一条聊天气泡
class ChatBubble {
  final String role; // 'user' | 'assistant'
  String text;
  List<Choice> options;

  ChatBubble({required this.role, required this.text, List<Choice>? options})
      : options = options ?? <Choice>[];

  Map<String, dynamic> toJson() => {
        'role': role,
        'text': text,
        'options': options.map((o) => o.toJson()).toList(),
      };

  factory ChatBubble.fromJson(Map<String, dynamic> j) => ChatBubble(
        role: j['role'] as String? ?? 'assistant',
        text: j['text'] as String? ?? '',
        options: (j['options'] as List<dynamic>? ?? [])
            .map((e) => Choice.fromJson(e as Map<String, dynamic>))
            .toList(),
      );
}

/// 模型一次回复解析后的结果
class AiReply {
  final String message;
  final List<Choice> options;
  final String chapterTitle;
  final String chapterContent;
  final Map<String, String> docs;

  AiReply({
    required this.message,
    this.options = const [],
    this.chapterTitle = '',
    this.chapterContent = '',
    this.docs = const {},
  });

  bool get hasChapter => chapterContent.trim().isNotEmpty;
  bool get hasDocs => docs.values.any((v) => v.trim().isNotEmpty);

  /// 把模型原始输出解析成结构化结果；解析失败就整段当普通文本，不崩。
  static AiReply parse(String raw) {
    final text = raw.trim();
    final start = text.indexOf('{');
    final end = text.lastIndexOf('}');
    if (start >= 0 && end > start) {
      try {
        final map = jsonDecode(text.substring(start, end + 1)) as Map<String, dynamic>;
        final opts = (map['options'] as List<dynamic>? ?? [])
            .whereType<Map<String, dynamic>>()
            .map(Choice.fromJson)
            .toList();
        final chap = map['chapter'];
        var cTitle = '';
        var cContent = '';
        if (chap is Map<String, dynamic>) {
          cTitle = (chap['title'] ?? '').toString();
          cContent = (chap['content'] ?? '').toString();
        }
        final docsRaw = map['docs'];
        final docs = <String, String>{};
        if (docsRaw is Map<String, dynamic>) {
          for (final k in ['characters', 'world', 'summary']) {
            final v = docsRaw[k];
            if (v != null) docs[k] = v.toString();
          }
        }
        final msg = (map['message'] ?? map['reply'] ?? '').toString();
        if (msg.isEmpty && cContent.isEmpty && opts.isEmpty) {
          return AiReply(message: text);
        }
        return AiReply(
          message: msg.isEmpty ? '（模型只返回了章节内容）' : msg,
          options: opts,
          chapterTitle: cTitle,
          chapterContent: cContent,
          docs: docs,
        );
      } catch (_) {
        // 落到下面，按纯文本处理
      }
    }
    return AiReply(message: text);
  }
}

/// 设置：走 OpenAI 兼容接口，任何家都能用
class Settings {
  String baseUrl;
  String apiKey;
  String model;

  Settings({
    this.baseUrl = 'https://api.deepseek.com/v1',
    this.apiKey = '',
    this.model = 'deepseek-chat',
  });

  bool get isReady => apiKey.trim().isNotEmpty && baseUrl.trim().isNotEmpty && model.trim().isNotEmpty;

  Map<String, dynamic> toJson() => {'baseUrl': baseUrl, 'apiKey': apiKey, 'model': model};

  factory Settings.fromJson(Map<String, dynamic> j) => Settings(
        baseUrl: j['baseUrl'] as String? ?? 'https://api.deepseek.com/v1',
        apiKey: j['apiKey'] as String? ?? '',
        model: j['model'] as String? ?? 'deepseek-chat',
      );
}
