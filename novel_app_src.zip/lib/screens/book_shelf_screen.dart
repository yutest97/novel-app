import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../book_text.dart';
import '../models.dart';
import '../skill_import.dart';
import '../store.dart';
import '../theme.dart';
import '../webdav.dart';
import 'book_home_page.dart';
import 'sync_page.dart';
import 'trash_page.dart';

/// 书架：所有小说
class BookShelfScreen extends StatelessWidget {
  const BookShelfScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final st = AppState.I;
    return AnimatedBuilder(
      animation: st,
      builder: (context, _) {
        final books = st.visibleBooks;
        return Scaffold(
          appBar: AppBar(
            title: Row(
              children: const [
                Icon(Icons.menu_book, size: 18, color: C.purpleSoft),
                SizedBox(width: 7),
                Text('我的小说'),
              ],
            ),
            actions: [
              _roundBtn(Icons.sync, '同步', () => _openSync(context)),
              _roundBtn(Icons.add, '新建', () => _newBook(context)),
              _moreMenu(context),
              const SizedBox(width: 6),
            ],
          ),
          body: books.isEmpty
              ? const Center(
                  child: Text('还没有小说，点右上角新建', style: TextStyle(color: C.dim, fontSize: 13)),
                )
              : ListView.builder(
                  padding: const EdgeInsets.fromLTRB(14, 8, 14, 24),
                  itemCount: books.length,
                  itemBuilder: (context, i) => _bookCard(context, books[i]),
                ),
        );
      },
    );
  }

  // ---------- 右上角三个按钮 ----------

  Widget _roundBtn(IconData icon, String tip, VoidCallback onTap) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 3),
      child: Tooltip(
        message: tip,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(20),
          child: Container(
            width: 34,
            height: 34,
            decoration: const BoxDecoration(color: C.card, shape: BoxShape.circle),
            child: Icon(icon, size: 17, color: C.dim),
          ),
        ),
      ),
    );
  }

  Widget _moreMenu(BuildContext context) {
    return PopupMenuButton<String>(
      tooltip: '更多',
      color: C.cardHi,
      offset: const Offset(0, 6),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      padding: EdgeInsets.zero,
      icon: Container(
        width: 34,
        height: 34,
        decoration: const BoxDecoration(color: C.card, shape: BoxShape.circle),
        child: const Icon(Icons.more_vert, size: 17, color: C.dim),
      ),
      onSelected: (v) {
        if (v == 'import') _importBook(context);
        if (v == 'export') _exportBook(context, AppState.I.novel);
        if (v == 'trash') {
          Navigator.of(context).push(MaterialPageRoute(builder: (_) => const TrashPage()));
        }
      },
      itemBuilder: (_) => [
        _menuItem('import', Icons.file_download_outlined, '导入'),
        _menuItem('export', Icons.file_upload_outlined, '导出'),
        _menuItem('trash', Icons.delete_outline, '回收站'),
      ],
    );
  }

  PopupMenuItem<String> _menuItem(
    String value,
    IconData icon,
    String label, {
    Color color = C.text,
    Color iconColor = C.purpleSoft,
  }) {
    return PopupMenuItem<String>(
      value: value,
      height: 42,
      child: Row(
        children: [
          Icon(icon, size: 16, color: iconColor),
          const SizedBox(width: 10),
          Text(label, style: TextStyle(fontSize: 13.5, color: color)),
        ],
      ),
    );
  }

  // ---------- 同步 ----------

  void _openSync(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => const _SyncSheet(),
    );
  }

  // ---------- 新建 ----------

  Future<void> _newBook(BuildContext context) async {
    final st = AppState.I;
    final name = await showDialog<String>(
      context: context,
      builder: (_) => _NewBookDialog(place: _whereItGoes),
    );
    if (name == null || name.trim().isEmpty) return;
    await st.createBook(title: name.trim());
    st.goTab(0);
    // 配好了模型就直接开聊，按技能包的初始化流程问题材；没配就等用户自己开口
    if (st.settings.isReady) {
      unawaited(st.send('开写这本新书吧'));
    }
  }

  /// 新建后会落到哪儿：外部目录就显示目录名，否则写「应用内存储」
  String _whereItGoes(String name) {
    final s = AppState.I.settings;
    if (s.storageMode == 'saf' && s.safName.trim().isNotEmpty) {
      return '${s.safName.trim()}/$name/';
    }
    return '应用内存储/$name/';
  }

  // ---------- 导入 / 导出 ----------

  Future<void> _importBook(BuildContext context) async {
    final messenger = ScaffoldMessenger.of(context);
    final st = AppState.I;
    try {
      final f = await pickTextFile();
      if (f == null) return;
      if (f.content.trim().isEmpty) {
        messenger.showSnackBar(const SnackBar(content: Text('这个文件里没有文字')));
        return;
      }
      final name = f.name.replaceAll(RegExp(r'\.[^.]+$'), '').trim();
      final book = await st.importBook(
        title: name.isEmpty ? '未命名作品' : name,
        raw: f.content,
      );
      messenger.showSnackBar(
        SnackBar(
          content: Text('已导入《${book.title}》 · ${book.chapters.length} 章 / ${book.chapterWords} 字'),
        ),
      );
      if (!context.mounted) return;
      Navigator.of(context)
          .push(MaterialPageRoute(builder: (_) => BookHomePage(bookId: book.id)));
    } on SkillPickException catch (e) {
      messenger.showSnackBar(SnackBar(content: Text(e.message)));
    } catch (e) {
      messenger.showSnackBar(SnackBar(content: Text('导入失败：$e')));
    }
  }

  Future<void> _exportBook(BuildContext context, Novel book) async {
    final messenger = ScaffoldMessenger.of(context);
    if (book.chapters.isEmpty) {
      messenger.showSnackBar(const SnackBar(content: Text('这本书还没有章节，先写点内容再导出')));
      return;
    }
    final raw = book.title.trim().isEmpty ? '未命名作品' : book.title.trim();
    final safe = raw.replaceAll(RegExp(r'[\\/:*?"<>|]'), '_');
    final text = exportBookText(book);
    try {
      final path = await saveTextFile('$safe.txt', text, title: '导出书稿');
      if (path == null) {
        messenger.showSnackBar(const SnackBar(content: Text('已取消，没有保存')));
        return;
      }
      messenger.showSnackBar(
        SnackBar(
          content: Text('已导出《$raw》 · ${book.chapters.length} 章 / ${book.chapterWords} 字'),
          duration: const Duration(seconds: 5),
        ),
      );
    } on SkillPickException catch (e) {
      messenger.showSnackBar(
        SnackBar(
          content: Text(e.message),
          duration: const Duration(seconds: 6),
          action: SnackBarAction(
            label: '复制正文',
            onPressed: () => Clipboard.setData(ClipboardData(text: text)),
          ),
        ),
      );
    }
  }

  Future<void> _renameBook(BuildContext context, Novel book) async {
    final messenger = ScaffoldMessenger.of(context);
    final st = AppState.I;
    final ctrl = TextEditingController(text: book.title);
    final name = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: C.card,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('重命名', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
        content: TextField(
          controller: ctrl,
          autofocus: true,
          style: const TextStyle(fontSize: 14),
          decoration: InputDecoration(
            hintText: '书名',
            hintStyle: const TextStyle(fontSize: 13.5, color: C.faint),
            filled: true,
            fillColor: C.bg,
            contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 13),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: const BorderSide(color: C.border, width: 0.8),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: const BorderSide(color: C.border, width: 0.8),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: const BorderSide(color: C.purple, width: 1),
            ),
          ),
        ),
        actionsPadding: const EdgeInsets.fromLTRB(16, 0, 12, 10),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('取消', style: TextStyle(color: C.dim)),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, ctrl.text),
            child: const Text('保存'),
          ),
        ],
      ),
    );
    if (name == null) return;
    if (name.trim().isEmpty) {
      messenger.showSnackBar(const SnackBar(content: Text('书名不能为空')));
      return;
    }
    await st.renameBook(book.id, name);
  }

  Future<void> _trashBook(BuildContext context, Novel book) async {
    final st = AppState.I;
    final title = book.title.trim().isEmpty ? '未命名作品' : book.title.trim();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: C.card,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('移入回收站？', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
        content: Text(
          '《$title》会从书架移走，${AppState.trashKeepDays} 天内可以在回收站里恢复。',
          style: const TextStyle(fontSize: 12.5, height: 1.6),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('取消', style: TextStyle(color: C.dim)),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: ButtonStyle(
              backgroundColor: MaterialStateProperty.all<Color>(const Color(0xFFD9534F)),
            ),
            child: const Text('移入回收站'),
          ),
        ],
      ),
    );
    if (ok == true) await st.deleteBook(book.id);
  }

  // ---------- 书的卡片 ----------

  Widget _bookCard(BuildContext context, Novel book) {
    final st = AppState.I;
    final isCurrent = book.id == st.currentId;
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: () async {
          final nav = Navigator.of(context);
          await st.switchBook(book.id);
          nav.push(MaterialPageRoute(builder: (_) => BookHomePage(bookId: book.id)));
        },
        child: Container(
          padding: const EdgeInsets.fromLTRB(12, 12, 6, 12),
          decoration: BoxDecoration(
            color: isCurrent ? const Color(0xFF201B3A) : C.card,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: isCurrent ? const Color(0xFF3B2F6B) : C.border,
              width: 0.8,
            ),
          ),
          child: Row(
            children: [
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFF9B7BFF), Color(0xFF5B3FE0)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(11),
                ),
                child: const Icon(Icons.book, color: Colors.white, size: 19),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      book.title.trim().isEmpty ? '未命名作品' : book.title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontSize: 14.5, fontWeight: FontWeight.w600),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '${book.chapters.isEmpty ? "设定 ${book.settingWords} 字" : "正文 ${book.chapterWords} 字"} · 更新于 ${_ago(book.updatedAt)}',
                      style: const TextStyle(fontSize: 11, color: C.dim),
                    ),
                  ],
                ),
              ),
              if (isCurrent)
                Container(
                  margin: const EdgeInsets.only(right: 2),
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    color: const Color(0x337B5CFF),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: const Text('当前', style: TextStyle(fontSize: 10.5, color: C.purpleSoft)),
                ),
              PopupMenuButton<String>(
                tooltip: '这本书的更多操作',
                icon: const Icon(Icons.more_vert, size: 18, color: C.dim),
                color: C.cardHi,
                offset: const Offset(0, 6),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                onSelected: (v) {
                  if (v == 'rename') _renameBook(context, book);
                  if (v == 'export') _exportBook(context, book);
                  if (v == 'trash') _trashBook(context, book);
                },
                itemBuilder: (_) => [
                  _menuItem('rename', Icons.edit_outlined, '重命名'),
                  _menuItem('export', Icons.file_upload_outlined, '导出'),
                  _menuItem('trash', Icons.delete_outline, '移至回收站',
                      color: const Color(0xFFE86A63), iconColor: const Color(0xFFE86A63)),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  static String _ago(int ms) {
    final diff = DateTime.now().difference(DateTime.fromMillisecondsSinceEpoch(ms));
    if (diff.inMinutes < 1) return '刚刚';
    if (diff.inMinutes < 60) return '${diff.inMinutes} 分钟前';
    if (diff.inHours < 24) return '${diff.inHours} 小时前';
    return '${diff.inDays} 天前';
  }
}

/// 新建小说：起个名字，顺手告诉用户文件会落在哪儿
class _NewBookDialog extends StatefulWidget {
  const _NewBookDialog({required this.place});

  /// 把书名映射成「将创建：…」里的路径
  final String Function(String name) place;

  @override
  State<_NewBookDialog> createState() => _NewBookDialogState();
}

class _NewBookDialogState extends State<_NewBookDialog> {
  final TextEditingController _ctrl = TextEditingController();
  String _text = '';

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  void _submit() {
    if (_text.isEmpty) return;
    Navigator.pop(context, _text);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: C.card,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      title: const Text('新建小说', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          TextField(
            controller: _ctrl,
            autofocus: true,
            onChanged: (v) => setState(() => _text = v.trim()),
            onSubmitted: (_) => _submit(),
            style: const TextStyle(fontSize: 14),
            decoration: InputDecoration(
              hintText: '输入小说名称',
              hintStyle: const TextStyle(fontSize: 13.5, color: C.faint),
              filled: true,
              fillColor: C.bg,
              contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 13),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
                borderSide: const BorderSide(color: C.border, width: 0.8),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
                borderSide: const BorderSide(color: C.border, width: 0.8),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(10),
                borderSide: const BorderSide(color: C.purple, width: 1),
              ),
            ),
          ),
          const SizedBox(height: 10),
          Text(
            '将创建：${widget.place(_text.isEmpty ? '小说名称' : _text)}',
            style: const TextStyle(fontSize: 11, color: C.faint),
          ),
        ],
      ),
      actionsPadding: const EdgeInsets.fromLTRB(16, 0, 12, 10),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('取消', style: TextStyle(color: C.dim)),
        ),
        ElevatedButton(
          onPressed: _text.isEmpty ? null : _submit,
          child: const Text('创建'),
        ),
      ],
    );
  }
}

/// 同步浮层：看一眼状态，或者直接备份到云端
class _SyncSheet extends StatefulWidget {
  const _SyncSheet();

  @override
  State<_SyncSheet> createState() => _SyncSheetState();
}

class _SyncSheetState extends State<_SyncSheet> {
  bool _busy = false;

  bool get _configured => AppState.I.settings.webdavUrl.trim().isNotEmpty;

  String get _host {
    final u = AppState.I.settings.webdavUrl.trim();
    try {
      return Uri.parse(u).host;
    } catch (_) {
      return u;
    }
  }

  void _openSettings() {
    final nav = Navigator.of(context);
    nav.pop();
    nav.push(MaterialPageRoute(builder: (_) => const SyncPage()));
  }

  Future<void> _backup() async {
    final messenger = ScaffoldMessenger.of(context);
    final st = AppState.I;
    final s = st.settings;
    setState(() => _busy = true);
    try {
      await uploadWebDavBackup(
        WebDavConfig(url: s.webdavUrl, user: s.webdavUser, pass: s.webdavPass, path: s.webdavPath),
        st.exportBackupJson(),
      );
      messenger.showSnackBar(const SnackBar(content: Text('已备份到云端')));
    } catch (e) {
      messenger.showSnackBar(SnackBar(content: Text('备份失败：$e')));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: C.surface,
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      padding: const EdgeInsets.fromLTRB(18, 10, 18, 26),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Center(
            child: Container(
              width: 36,
              height: 4,
              margin: const EdgeInsets.only(bottom: 18),
              decoration: BoxDecoration(
                color: C.border,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
          ),
          Row(
            children: [
              const Icon(Icons.sync, size: 20, color: C.purpleSoft),
              const SizedBox(width: 10),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: const [
                  Text('同步', style: TextStyle(fontSize: 15.5, fontWeight: FontWeight.w600)),
                  SizedBox(height: 2),
                  Text('通过 WebDAV 云端互传', style: TextStyle(fontSize: 11.5, color: C.dim)),
                ],
              ),
            ],
          ),
          const SizedBox(height: 16),
          InkWell(
            onTap: _openSettings,
            borderRadius: BorderRadius.circular(10),
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 10),
              child: Row(
                children: [
                  Icon(
                    _configured ? Icons.check_circle_outline : Icons.warning_amber_rounded,
                    size: 18,
                    color: _configured ? C.green : const Color(0xFFE2B33C),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      _configured ? '已配置：$_host' : '未配置同步，点此前往设置',
                      style: const TextStyle(fontSize: 12.5, color: C.text),
                    ),
                  ),
                  const Icon(Icons.chevron_right, size: 16, color: C.faint),
                ],
              ),
            ),
          ),
          if (_configured) ...[
            const Divider(height: 18),
            InkWell(
              onTap: _busy ? null : _backup,
              borderRadius: BorderRadius.circular(10),
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 12),
                child: Row(
                  children: [
                    _busy
                        ? const SizedBox(
                            width: 16,
                            height: 16,
                            child: CircularProgressIndicator(strokeWidth: 1.6, color: C.purpleSoft),
                          )
                        : const Icon(Icons.cloud_upload_outlined, size: 18, color: C.purpleSoft),
                    const SizedBox(width: 10),
                    Text(
                      _busy ? '正在上传备份…' : '立即备份到云端',
                      style: const TextStyle(fontSize: 13, color: C.text),
                    ),
                  ],
                ),
              ),
            ),
          ],
          const Divider(height: 18),
          InkWell(
            onTap: _openSettings,
            borderRadius: BorderRadius.circular(10),
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 12),
              child: Row(
                children: const [
                  Icon(Icons.settings_outlined, size: 18, color: C.dim),
                  SizedBox(width: 10),
                  Text('同步设置...', style: TextStyle(fontSize: 13, color: C.text)),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
