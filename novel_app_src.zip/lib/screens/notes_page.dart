import 'package:flutter/material.dart';

import '../models.dart';
import '../store.dart';
import '../theme.dart';

const List<String> kNoteCategories = ['默认', '灵感', '大纲'];

/// 备忘录：按当前书存放，可按分类筛选
class NotesPage extends StatefulWidget {
  const NotesPage({super.key});

  @override
  State<NotesPage> createState() => _NotesPageState();
}

class _NotesPageState extends State<NotesPage> {
  String _cat = '全部';

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: AppState.I,
      builder: (context, _) {
        final st = AppState.I;
        final notes = _cat == '全部'
            ? st.novel.notes
            : st.novel.notes.where((n) => n.category == _cat).toList();

        return Scaffold(
          appBar: AppBar(
            title: const Text('备忘录'),
            actions: [
              TextButton.icon(
                onPressed: () => _openEditor(context, null),
                icon: const Icon(Icons.add, size: 16, color: C.purpleSoft),
                label: const Text('新建',
                    style: TextStyle(fontSize: 13, color: C.purpleSoft)),
              ),
              IconButton(
                icon: const Icon(Icons.close, size: 20),
                onPressed: () => Navigator.of(context).maybePop(),
              ),
            ],
          ),
          body: Column(
            children: [
              // 按书筛选
              Padding(
                padding: const EdgeInsets.fromLTRB(14, 4, 14, 0),
                child: Row(
                  children: [
                    const Icon(Icons.filter_alt_outlined, size: 14, color: C.dim),
                    const SizedBox(width: 6),
                    const Text('筛选', style: TextStyle(fontSize: 12, color: C.dim)),
                    const SizedBox(width: 10),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                      decoration: BoxDecoration(
                        color: const Color(0x337B5CFF),
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: const Color(0xFF3B2F6B), width: 0.7),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(Icons.menu_book, size: 12, color: C.purpleSoft),
                          const SizedBox(width: 5),
                          Text(
                            st.novel.title.trim().isEmpty ? '未命名' : st.novel.title,
                            style: const TextStyle(fontSize: 11.5, color: C.purpleSoft),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              // 分类
              SizedBox(
                height: 46,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                  children: [
                    for (final c in ['全部', ...kNoteCategories])
                      Padding(
                        padding: const EdgeInsets.only(right: 8),
                        child: GestureDetector(
                          onTap: () => setState(() => _cat = c),
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                            decoration: BoxDecoration(
                              color: _cat == c ? const Color(0xFF2A2154) : C.card,
                              borderRadius: BorderRadius.circular(9),
                              border: Border.all(
                                color: _cat == c ? C.purple : C.border,
                                width: 0.8,
                              ),
                            ),
                            child: Center(
                              child: Text(
                                c,
                                style: TextStyle(
                                  fontSize: 12,
                                  color: _cat == c ? C.purpleSoft : C.dim,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                  ],
                ),
              ),
              Expanded(
                child: notes.isEmpty
                    ? Center(
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.note_add_outlined,
                                size: 46, color: C.faint.withOpacity(0.6)),
                            const SizedBox(height: 14),
                            const Text('该分类下暂无备忘录',
                                style: TextStyle(fontSize: 13, color: C.dim)),
                            const SizedBox(height: 6),
                            const Text('点击右上角「新建」按钮创建',
                                style: TextStyle(fontSize: 11.5, color: C.faint)),
                          ],
                        ),
                      )
                    : ListView.separated(
                        padding: const EdgeInsets.fromLTRB(14, 4, 14, 30),
                        itemCount: notes.length,
                        separatorBuilder: (_, __) => const SizedBox(height: 10),
                        itemBuilder: (context, i) => _noteCard(context, notes[i]),
                      ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _noteCard(BuildContext context, Note n) {
    return Material(
      color: C.card,
      borderRadius: BorderRadius.circular(12),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: () => _openEditor(context, n),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(13, 11, 13, 11),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                n.text.trim().isEmpty ? '（空白备忘录）' : n.text.trim(),
                maxLines: 4,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 13, height: 1.7, color: Color(0xFFDCDCE8)),
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                    decoration: BoxDecoration(
                      color: const Color(0x337B5CFF),
                      borderRadius: BorderRadius.circular(5),
                    ),
                    child: Text(n.category,
                        style: const TextStyle(fontSize: 10, color: C.purpleSoft)),
                  ),
                  const Spacer(),
                  Text(
                    _ago(n.createdAt),
                    style: const TextStyle(fontSize: 10, color: C.faint),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  static String _ago(int ms) {
    final diff = DateTime.now().difference(DateTime.fromMillisecondsSinceEpoch(ms));
    if (diff.inMinutes < 1) return '刚刚';
    if (diff.inMinutes < 60) return '${diff.inMinutes} 分钟前';
    if (diff.inHours < 24) return '${diff.inHours} 小时前';
    return '${diff.inDays} 天前';
  }

  Future<void> _openEditor(BuildContext context, Note? note) async {
    await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => NoteEditorPage(note: note),
        fullscreenDialog: true,
      ),
    );
  }
}

/// 新建 / 编辑一条备忘录
class NoteEditorPage extends StatefulWidget {
  const NoteEditorPage({super.key, this.note});

  final Note? note;

  @override
  State<NoteEditorPage> createState() => _NoteEditorPageState();
}

class _NoteEditorPageState extends State<NoteEditorPage> {
  late final TextEditingController _ctrl;
  late String _cat;

  bool get _isNew => widget.note == null;

  @override
  void initState() {
    super.initState();
    _ctrl = TextEditingController(text: widget.note?.text ?? '');
    _cat = widget.note?.category ?? '默认';
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    final text = _ctrl.text.trim();
    if (text.isEmpty) {
      Navigator.of(context).pop();
      return;
    }
    if (_isNew) {
      await AppState.I.addNote(text, _cat);
    } else {
      await AppState.I.updateNote(widget.note!.id, text, _cat);
    }
    if (!mounted) return;
    Navigator.of(context).pop();
  }

  Future<void> _delete() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: C.card,
        title: const Text('删除这条备忘录？', style: TextStyle(fontSize: 15)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('取消')),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: ButtonStyle(
              backgroundColor: MaterialStateProperty.all<Color>(const Color(0xFFD9534F)),
              foregroundColor: MaterialStateProperty.all<Color>(Colors.white),
            ),
            child: const Text('删除'),
          ),
        ],
      ),
    );
    if (ok != true) return;
    await AppState.I.deleteNote(widget.note!.id);
    if (!mounted) return;
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_isNew ? '新建备忘录' : '编辑备忘录'),
        actions: [
          if (!_isNew)
            IconButton(
              icon: const Icon(Icons.delete_outline, size: 20),
              onPressed: _delete,
            ),
          TextButton(
            onPressed: _save,
            child: const Text('保存', style: TextStyle(fontSize: 13.5, color: C.purpleSoft)),
          ),
        ],
      ),
      body: Column(
        children: [
          SizedBox(
            height: 44,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
              children: [
                for (final c in kNoteCategories)
                  Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: GestureDetector(
                      onTap: () => setState(() => _cat = c),
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
                        decoration: BoxDecoration(
                          color: _cat == c ? const Color(0xFF2A2154) : C.card,
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(
                            color: _cat == c ? C.purple : C.border,
                            width: 0.8,
                          ),
                        ),
                        child: Center(
                          child: Text(c,
                              style: TextStyle(
                                fontSize: 12,
                                color: _cat == c ? C.purpleSoft : C.dim,
                              )),
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(14, 4, 14, 14),
              child: TextField(
                controller: _ctrl,
                autofocus: _isNew,
                maxLines: null,
                expands: true,
                textAlignVertical: TextAlignVertical.top,
                style: const TextStyle(fontSize: 14, height: 1.8, color: Color(0xFFE3E3EE)),
                decoration: const InputDecoration(
                  hintText: '记点什么…灵感、伏笔、人名、待办都行',
                  hintStyle: TextStyle(fontSize: 13, color: C.faint),
                  border: OutlineInputBorder(borderSide: BorderSide.none),
                  filled: true,
                  fillColor: Color(0xFF14141E),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
