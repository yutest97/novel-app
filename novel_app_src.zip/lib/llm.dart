import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;

import 'models.dart';

/// 调用模型时的错误，带大白话提示
class LlmException implements Exception {
  final String message;
  LlmException(this.message);
  @override
  String toString() => message;
}

/// 走 OpenAI 兼容的 /chat/completions 接口，DeepSeek、通义、智谱、自建代理都适用
Future<String> callModel({
  required Settings settings,
  required List<Map<String, String>> messages,
}) async {
  final base = settings.baseUrl.trim().replaceAll(RegExp(r'/+$'), '');
  final uri = Uri.parse('$base/chat/completions');

  http.Response resp;
  try {
    resp = await http
        .post(
          uri,
          headers: {
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ${settings.apiKey.trim()}',
          },
          body: jsonEncode({
            'model': settings.model.trim(),
            'messages': messages,
            'temperature': 0.9,
            'stream': false,
          }),
        )
        .timeout(const Duration(minutes: 5));
  } on TimeoutException {
    throw LlmException('等了 5 分钟还没返回。可能是网络卡住，或者这次要写的字太多。点重试，或把这一章拆短一点。');
  } catch (e) {
    throw LlmException('连不上接口地址：$base\n检查两件事：手机上有没有网、设置页的「接口地址」有没有写错（要带 https://）。');
  }

  if (resp.statusCode == 401 || resp.statusCode == 403) {
    throw LlmException('API Key 不对或没权限（HTTP ${resp.statusCode}）。去设置页重新粘贴 Key，注意别带空格。');
  }
  if (resp.statusCode == 404) {
    throw LlmException('接口地址找不到（HTTP 404）。检查「接口地址」末尾应该是 /v1 这种形式，别多写 /chat/completions。');
  }
  if (resp.statusCode == 429) {
    throw LlmException('请求太频繁或余额不足（HTTP 429）。等一分钟再试，或者去供应商后台看余额。');
  }
  if (resp.statusCode != 200) {
    throw LlmException('接口报错（HTTP ${resp.statusCode}）：${_short(resp.body)}');
  }

  Map<String, dynamic> data;
  try {
    data = jsonDecode(utf8.decode(resp.bodyBytes)) as Map<String, dynamic>;
  } catch (_) {
    throw LlmException('返回的不是标准 JSON，可能是接口地址填成了网页地址。返回内容开头：${_short(resp.body)}');
  }

  final choices = data['choices'];
  if (choices is List && choices.isNotEmpty) {
    final msg = choices.first['message'];
    if (msg is Map && msg['content'] != null) {
      return msg['content'].toString();
    }
  }
  throw LlmException('返回里没有正文内容。原始返回：${_short(jsonEncode(data))}');
}

String _short(String s) {
  final t = s.replaceAll('\n', ' ').trim();
  return t.length <= 200 ? t : '${t.substring(0, 200)}…';
}
