import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../models.dart';
import '../novel_source.dart';
import '../skill_import.dart';
import '../store.dart';
import '../theme.dart';
import 'source_dialog.dart';

class _Mat {
  final String label;
  final String text;
  const _Mat(this.label, this.text);
}

/// 简介生成器：吃书籍资料（md / 备忘录），可选抓真实热门简介仿写
class BlurbSheet extends StatefulWidget {
  const BlurbSheet({super.key});

  @override
  State<BlurbSheet> createState() => _BlurbSheetState();
}

class _BlurbSheetState extends State<BlurbSheet> {
  static const List<String> _channels = ['自动', '男频', '女频'];
  static const int _cap = 8000;

  int _tab = 0;
  int _channel = 0;
  bool _mimic = false;
  bool _busy = false;
  String _progress = '';

  final List<_Mat> _mats = <_Mat>[];
  final TextEditingController _extra = TextEditingController();

  int get _chars => _mats.fold<int>(0, (s, m) => s + m.text.length);

  @override
  void dispose() {
    _extra.dispose();
    super.dispose();
  }

  Future<void> _pickFile() async {
    final messenger = ScaffoldMessenger.of(context);
    try {
      final f = await pickTextFile();
      if (f == null) return;
      if (!mounted) return;
      setState(() => _mats.add(_Mat(f.name, f.content)));
    } on SkillPickException catch (e) {
      messenger.showSnackBar(SnackBar(content: Text(e.message)));
    } catch (e) {
      messenger.showSnackBar(SnackBar(content: Text('读取失败：$e')));
    }
  }

  Future<void> _pickNote() async {
    final st = AppState.I;
    final notes = st.novel.notes;
    if (notes.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('还没有备忘录。先去「备忘录」写几条设定或梗。')),
      );
      return;
    }
    final picked = await showModalBottomSheet<Note>(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => Container(
        decoration: const BoxDecoration(
          color: C.surface,
          borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
        ),
        child: SafeArea(
          top: false,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 38,
                height: 4,
                margin: const EdgeInsets.symmetric(vertical: 10),
                decoration: BoxDecoration(
                  color: Colors.white24,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              const Padding(
                padding: EdgeInsets.fromLTRB(18, 2, 18, 8),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Text('选择备忘录',
                      style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
                ),
              ),
              Flexible(
                child: ListView.builder(
                  shrinkWrap: true,
                  padding: const EdgeInsets.fromLTRB(14, 0, 14, 10),
                  itemCount: notes.length,
                  itemBuilder: (context, i) {
                    final n = notes[i];
                    return InkWell(
                      onTap: () => Navigator.pop(context, n),
                      borderRadius: BorderRadius.circular(9),
                      child: Container(
                        margin: const EdgeInsets.only(bottom: 8),
                        padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
                        decoration: BoxDecoration(
                          color: C.card,
                          borderRadius: BorderRadius.circular(9),
                          border: Border.all(color: C.border, width: 0.6),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(n.category,
                                style: const TextStyle(fontSize: 10, color: C.purpleSoft)),
                            const SizedBox(height: 4),
                            Text(
                              n.text.replaceAll(RegExp(r'\s+'), ' '),
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(fontSize: 11.5, color: C.text),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
    if (picked == null || !mounted) return;
    setState(() => _mats.add(_Mat('备忘录·${picked.category}', picked.text)));
  }

  Future<void> _generate() async {
    final messenger = ScaffoldMessenger.of(context);
    final st = AppState.I;
    final extra = _extra.text.trim();

    if (!st.settings.isReady) {
      messenger.showSnackBar(const SnackBar(
        content: Text('还没填 API Key。请到「设置 → AI 提供商」填好，再回来。'),
      ));
      return;
    }
    if (_mats.isEmpty && extra.isEmpty) {
      messenger.showSnackBar(
        const SnackBar(content: Text('先加一点书籍资料，或者写两句补充要求。')),
      );
      return;
    }

    // 仿写：抓同站热门书的真实简介
    final refs = <String>[];
    if (_mimic) {
      setState(() {
        _busy = true;
        _progress = '抓参考简介…';
      });
      try {
        var rank = st.lastRank;
        if (rank.isEmpty) {
          setState(() => _progress = '先找书源…');
          final base = await ensureSourceWithManual(
            context,
            onProgress: (m) {
              if (mounted) setState(() => _progress = m);
            },
          );
          if (base.isEmpty) {
            throw NovelFetchException('没找到可用书源。可以先把「简介仿写」关掉再生成。');
          }
          if (!mounted) return;
          setState(() => _progress = '先抓榜单…');
          rank = await fetchRanking('$base/rank/hotsales/');
          st.cacheRank(rank, '$base/rank/hotsales/');
        }
        for (var i = 0; i < rank.length && refs.length < 2; i++) {
          if (!mounted) return;
          setState(() => _progress = '抓简介 ${refs.length + 1}/2…');
          try {
            final intro = await fetchBookIntro(rank[i].url);
            refs.add('《${rank[i].title}》：$intro');
          } on NovelFetchException {
            // 这本抓不到就换下一本
          }
        }
        if (refs.isEmpty) {
          throw NovelFetchException('热门书的简介都没抓到（站点可能用 JS 渲染）。先把「简介仿写」关掉再生成。');
        }
      } on NovelFetchException catch (e) {
        messenger.showSnackBar(
          SnackBar(content: Text(e.message), duration: const Duration(seconds: 6)),
        );
        if (mounted) {
          setState(() {
            _busy = false;
            _progress = '';
          });
        }
        return;
      } finally {
        if (mounted && _busy) {
          setState(() {
            _busy = false;
            _progress = '';
          });
        }
      }
    }

    if (!mounted) return;
    final channel = _channels[_channel];
    final buf = StringBuffer('【简介】频道：$channel。\n');

    if (_mats.isNotEmpty) {
      buf.writeln('\n【书籍资料】');
      var used = 0;
      for (final m in _mats) {
        final left = _cap - used;
        if (left <= 0) break;
        final body = m.text.length > left ? m.text.substring(0, left) : m.text;
        used += body.length;
        buf.writeln('— ${m.label} —\n$body\n');
      }
    }

    if (refs.isNotEmpty) {
      buf.writeln('【参考：同站真实热门简介（抓取，仅供模仿节奏和结构，不要抄句子）】');
      for (final r in refs) {
        buf.writeln('· $r');
      }
      buf.writeln();
    }

    if (extra.isNotEmpty) buf.writeln('【补充要求】$extra\n');

    buf
      ..writeln('请写 3 版作品简介，每版 150~250 字：')
      ..writeln('第 1 版：突出设定与悬念；')
      ..writeln('第 2 版：突出爽点与金手指；')
      ..writeln('第 3 版：偏人物与情绪。')
      ..writeln('每版后面标一句「适合的读者」。不要剧透结局，不要用「本文讲述了」这种开头。')
      ..writeln()
      ..writeln('最后用 [选项] 让我挑一版继续打磨。');

    final prompt = buf.toString();
    final title = '$channel · ${st.novel.title.isEmpty ? '未命名' : st.novel.title}';
    final nav = Navigator.of(context);
    nav.pop();
    await st.send(prompt);

    final chats = st.novel.chats;
    if (chats.isNotEmpty && chats.last.role == 'assistant') {
      final out = chats.last.text.trim();
      if (out.isNotEmpty) {
        await st.addGen(GenRecord(
          kind: 'blurb',
          title: title,
          input: extra,
          output: out,
        ));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final st = AppState.I;
    final history = st.gensOf('blurb');
    return Container(
      constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * 0.86),
      decoration: const BoxDecoration(
        color: C.surface,
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: SafeArea(
        top: false,
        child: Padding(
          padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 38,
                height: 4,
                margin: const EdgeInsets.symmetric(vertical: 10),
                decoration: BoxDecoration(
                  color: Colors.white24,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(18, 2, 10, 4),
                child: Row(
                  children: [
                    Container(
                      width: 26,
                      height: 26,
                      decoration: BoxDecoration(
                        color: const Color(0x337B5CFF),
                        borderRadius: BorderRadius.circular(7),
                      ),
                      child: const Icon(Icons.description_outlined,
                          size: 14, color: C.purpleSoft),
                    ),
                    const SizedBox(width: 9),
                    const Text('简介生成器',
                        style: TextStyle(fontSize: 14.5, fontWeight: FontWeight.w600)),
                    const Spacer(),
                    IconButton(
                      icon: const Icon(Icons.close, size: 19, color: C.dim),
                      onPressed: () => Navigator.of(context).pop(),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(18, 0, 18, 0),
                child: Row(
                  children: [
                    _tabPill('生成', _tab == 0, () => setState(() => _tab = 0)),
                    const SizedBox(width: 8),
                    _tabPill('历史 (${history.length})', _tab == 1,
                        () => setState(() => _tab = 1)),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              Flexible(
                child: _tab == 0
                    ? SingleChildScrollView(
                        padding: const EdgeInsets.fromLTRB(18, 0, 18, 4),
                        child: _form(st),
                      )
                    : _historyList(history),
              ),
              if (_tab == 0)
                Padding(
                  padding: const EdgeInsets.fromLTRB(18, 8, 18, 12),
                  child: SizedBox(
                    height: 46,
                    width: double.infinity,
                    child: ElevatedButton.icon(
                      onPressed: _busy ? null : _generate,
                      icon: _busy
                          ? const SizedBox(
                              width: 14,
                              height: 14,
                              child: CircularProgressIndicator(
                                  strokeWidth: 1.6, color: Colors.white),
                            )
                          : const Icon(Icons.auto_awesome, size: 17, color: Colors.white),
                      label: Text(_busy && _progress.isNotEmpty ? _progress : '生成简介',
                          style: const TextStyle(fontSize: 13.5, color: Colors.white)),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: C.purple,
                        shape:
                            RoundedRectangleBorder(borderRadius: BorderRadius.circular(11)),
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _form(AppState st) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('频道', style: TextStyle(fontSize: 11, color: C.dim)),
        const SizedBox(height: 7),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            for (var i = 0; i < _channels.length; i++)
              _chip(_channels[i], _channel == i, () => setState(() => _channel = i)),
          ],
        ),
        const SizedBox(height: 14),
        Container(
          padding: const EdgeInsets.fromLTRB(12, 11, 12, 11),
          decoration: BoxDecoration(
            color: C.card,
            borderRadius: BorderRadius.circular(11),
            border: Border.all(color: C.border, width: 0.6),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const Icon(Icons.folder_open, size: 16, color: C.purpleSoft),
                  const SizedBox(width: 8),
                  const Expanded(
                    child: Text('书籍资料（md 文件 / 备忘录，供 AI 理解书籍）',
                        style: TextStyle(fontSize: 11.5, color: C.text)),
                  ),
                  Text('$_chars / $_cap 字',
                      style: const TextStyle(fontSize: 10, color: C.faint)),
                ],
              ),
              if (_mats.isNotEmpty) ...[
                const SizedBox(height: 8),
                for (var i = 0; i < _mats.length; i++)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 4),
                    child: Row(
                      children: [
                        const Icon(Icons.insert_drive_file_outlined,
                            size: 13, color: C.faint),
                        const SizedBox(width: 6),
                        Expanded(
                          child: Text(
                            '${_mats[i].label} · ${_mats[i].text.length} 字',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontSize: 10.5, color: C.dim),
                          ),
                        ),
                        InkWell(
                          onTap: () => setState(() => _mats.removeAt(i)),
                          child: const Padding(
                            padding: EdgeInsets.all(2),
                            child: Icon(Icons.close, size: 13, color: C.faint),
                          ),
                        ),
                      ],
                    ),
                  ),
              ],
              const SizedBox(height: 9),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: _pickFile,
                      icon: const Icon(Icons.upload_file, size: 15, color: C.text),
                      label: const Text('书籍文件',
                          style: TextStyle(fontSize: 11.5, color: C.text)),
                      style: OutlinedButton.styleFrom(
                        side: const BorderSide(color: C.border),
                        minimumSize: const Size(0, 36),
                        shape:
                            RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: _pickNote,
                      icon: const Icon(Icons.sticky_note_2_outlined,
                          size: 15, color: C.text),
                      label: const Text('备忘录',
                          style: TextStyle(fontSize: 11.5, color: C.text)),
                      style: OutlinedButton.styleFrom(
                        side: const BorderSide(color: C.border),
                        minimumSize: const Size(0, 36),
                        shape:
                            RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 10),
        Container(
          padding: const EdgeInsets.fromLTRB(12, 8, 8, 8),
          decoration: BoxDecoration(
            color: C.card,
            borderRadius: BorderRadius.circular(11),
            border: Border.all(color: C.border, width: 0.6),
          ),
          child: Row(
            children: [
              const Icon(Icons.track_changes, size: 17, color: C.purpleSoft),
              const SizedBox(width: 9),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('简介仿写（搜索全网真实热门简介作参考）',
                        style: TextStyle(fontSize: 12)),
                    const SizedBox(height: 2),
                    Text(
                      st.hasRank
                          ? '用已抓榜单，取前 2 本的真实简介'
                          : '会先抓一次榜单，再取前 2 本的真实简介',
                      style: const TextStyle(fontSize: 10, color: C.faint),
                    ),
                  ],
                ),
              ),
              Switch(
                value: _mimic,
                activeColor: Colors.white,
                activeTrackColor: C.purple,
                inactiveThumbColor: const Color(0xFFBFC2D4),
                inactiveTrackColor: C.cardHi,
                onChanged: (v) => setState(() => _mimic = v),
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        const Text('补充要求（书名 / 风格 / 想强调的点，自由填写）',
            style: TextStyle(fontSize: 11, color: C.dim)),
        const SizedBox(height: 7),
        TextField(
          controller: _extra,
          minLines: 3,
          maxLines: 5,
          style: const TextStyle(fontSize: 12.5, color: C.text),
          decoration: InputDecoration(
            hintText: '例如：书名《签到都市》、轻松搞笑风、突出金手指的特殊规则…',
            hintStyle: const TextStyle(fontSize: 11.5, color: C.faint),
            filled: true,
            fillColor: C.card,
            contentPadding: const EdgeInsets.all(12),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: const BorderSide(color: C.border, width: 0.7),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: const BorderSide(color: C.border, width: 0.7),
            ),
          ),
        ),
      ],
    );
  }

  Widget _historyList(List<GenRecord> list) {
    if (list.isEmpty) {
      return const Padding(
        padding: EdgeInsets.symmetric(vertical: 40),
        child: Text('还没有生成记录', style: TextStyle(fontSize: 12, color: C.dim)),
      );
    }
    return ListView.builder(
      shrinkWrap: true,
      padding: const EdgeInsets.fromLTRB(18, 0, 18, 8),
      itemCount: list.length,
      itemBuilder: (context, i) {
        final r = list[i];
        return Padding(
          padding: const EdgeInsets.only(bottom: 8),
          child: InkWell(
            onTap: () => _openRecord(r),
            borderRadius: BorderRadius.circular(10),
            child: Container(
              padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
              decoration: BoxDecoration(
                color: C.card,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: C.border, width: 0.6),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(r.title,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style:
                                const TextStyle(fontSize: 12, color: C.purpleSoft)),
                      ),
                      const SizedBox(width: 8),
                      Text(_time(r.createdAt),
                          style: const TextStyle(fontSize: 9.5, color: C.faint)),
                    ],
                  ),
                  const SizedBox(height: 5),
                  Text(
                    r.output.replaceAll(RegExp(r'\s+'), ' '),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 11.5, height: 1.6, color: C.dim),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Future<void> _openRecord(GenRecord r) async {
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: C.surface,
        title: Text(r.title, style: const TextStyle(fontSize: 15)),
        content: SizedBox(
          width: double.maxFinite,
          child: SingleChildScrollView(
            child: SelectableText(
              r.output,
              style: const TextStyle(fontSize: 12.5, height: 1.7, color: C.text),
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () async {
              final nav = Navigator.of(ctx);
              await Clipboard.setData(ClipboardData(text: r.output));
              nav.pop();
              if (mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('已复制')),
                );
              }
            },
            child: const Text('复制', style: TextStyle(fontSize: 12.5, color: C.purpleSoft)),
          ),
          TextButton(
            onPressed: () async {
              final nav = Navigator.of(ctx);
              await AppState.I.removeGen(r.id);
              nav.pop();
              if (mounted) setState(() {});
            },
            child: const Text('删除', style: TextStyle(fontSize: 12.5, color: C.faint)),
          ),
        ],
      ),
    );
  }

  String _time(int ms) {
    final d = DateTime.fromMillisecondsSinceEpoch(ms);
    final now = DateTime.now();
    final sameDay = d.year == now.year && d.month == now.month && d.day == now.day;
    final hm =
        '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';
    return sameDay ? hm : '${d.month}/${d.day} $hm';
  }

  Widget _tabPill(String label, bool on, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(7),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: on ? const Color(0x337B5CFF) : Colors.transparent,
          borderRadius: BorderRadius.circular(7),
        ),
        child: Text(
          label,
          style: TextStyle(fontSize: 12, color: on ? C.purpleSoft : C.dim),
        ),
      ),
    );
  }

  Widget _chip(String label, bool on, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(8),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: on ? C.purple : C.card,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: on ? C.purple : C.border, width: 0.6),
        ),
        child: Text(
          label,
          style: TextStyle(fontSize: 12, color: on ? Colors.white : C.text),
        ),
      ),
    );
  }
}
