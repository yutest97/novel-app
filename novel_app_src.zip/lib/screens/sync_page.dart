import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../lan_sync.dart';
import '../store.dart';
import '../theme.dart';
import '../webdav.dart';

/// 同步：WebDAV 云备份 + 局域网临时传输
class SyncPage extends StatefulWidget {
  const SyncPage({super.key});

  @override
  State<SyncPage> createState() => _SyncPageState();
}

class _SyncPageState extends State<SyncPage> {
  int _tab = 0;
  bool _busy = false;
  String _status = '';

  late final TextEditingController _url;
  late final TextEditingController _user;
  late final TextEditingController _pass;
  late final TextEditingController _path;

  bool _lanRunning = false;
  List<String> _lanUrls = const [];

  @override
  void initState() {
    super.initState();
    final s = AppState.I.settings;
    _url = TextEditingController(text: s.webdavUrl);
    _user = TextEditingController(text: s.webdavUser);
    _pass = TextEditingController(text: s.webdavPass);
    _path = TextEditingController(text: s.webdavPath);
    _lanRunning = LanSyncServer.running;
    if (_lanRunning) {
      LanSyncServer.addresses().then((v) {
        if (mounted) setState(() => _lanUrls = v);
      });
    }
  }

  @override
  void dispose() {
    _url.dispose();
    _user.dispose();
    _pass.dispose();
    _path.dispose();
    super.dispose();
  }

  WebDavConfig get _cfg => WebDavConfig(
        url: _url.text.trim(),
        user: _user.text.trim(),
        pass: _pass.text,
        path: _path.text.trim(),
      );

  Future<void> _test() async {
    final messenger = ScaffoldMessenger.of(context);
    if (_cfg.url.isEmpty) {
      messenger.showSnackBar(const SnackBar(content: Text('先填 WebDAV 地址。')));
      return;
    }
    setState(() {
      _busy = true;
      _status = '正在测试连接…';
    });
    try {
      await ensureWebDavDir(_cfg);
      if (!mounted) return;
      setState(() => _status = '连接成功，目录可用。');
      messenger.showSnackBar(const SnackBar(content: Text('连接成功')));
    } catch (e) {
      if (!mounted) return;
      setState(() => _status = '$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _save() async {
    final messenger = ScaffoldMessenger.of(context);
    if (_url.text.trim().isEmpty) {
      messenger.showSnackBar(const SnackBar(content: Text('WebDAV 地址不能为空。')));
      return;
    }
    await AppState.I.saveWebdav(
      url: _url.text,
      user: _user.text,
      pass: _pass.text,
      path: _path.text.isEmpty ? '/' : _path.text,
    );
    if (!mounted) return;
    setState(() => _status = '配置已保存。');
    messenger.showSnackBar(const SnackBar(content: Text('配置已保存')));
  }

  Future<void> _backup() async {
    final messenger = ScaffoldMessenger.of(context);
    final st = AppState.I;
    if (st.settings.webdavUrl.trim().isEmpty) {
      messenger.showSnackBar(const SnackBar(content: Text('先保存 WebDAV 配置。')));
      return;
    }
    setState(() {
      _busy = true;
      _status = '正在上传备份…';
    });
    try {
      final cfg = WebDavConfig(
        url: st.settings.webdavUrl,
        user: st.settings.webdavUser,
        pass: st.settings.webdavPass,
        path: st.settings.webdavPath,
      );
      final json = st.exportBackupJson();
      await uploadWebDavBackup(cfg, json);
      final now = DateTime.now();
      final hm =
          '${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}';
      if (!mounted) return;
      setState(() => _status = '已备份 $hm · ${_size(json.length)}');
      messenger.showSnackBar(const SnackBar(content: Text('已备份到云端')));
    } catch (e) {
      if (mounted) setState(() => _status = '$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _restore() async {
    final messenger = ScaffoldMessenger.of(context);
    final st = AppState.I;
    if (st.settings.webdavUrl.trim().isEmpty) {
      messenger.showSnackBar(const SnackBar(content: Text('先保存 WebDAV 配置。')));
      return;
    }
    setState(() {
      _busy = true;
      _status = '正在下载备份…';
    });
    try {
      final cfg = WebDavConfig(
        url: st.settings.webdavUrl,
        user: st.settings.webdavUser,
        pass: st.settings.webdavPass,
        path: st.settings.webdavPath,
      );
      final json = await downloadWebDavBackup(cfg);
      if (!mounted) return;
      setState(() {
        _busy = false;
        _status = '';
      });
      final ok = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          backgroundColor: C.surface,
          title: const Text('用云端备份覆盖本机？'),
          content: Text(
            '本机现在有 ${st.books.length} 本书。恢复后会被云端那份替换，'
            '当前的数据不会保留（建议先导出一份到本地）。',
            style: const TextStyle(fontSize: 12, height: 1.7),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('取消', style: TextStyle(color: C.dim)),
            ),
            ElevatedButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('覆盖'),
            ),
          ],
        ),
      );
      if (ok != true) return;
      final msg = await st.importBackupJson(json);
      if (!mounted) return;
      setState(() => _status = msg);
      messenger.showSnackBar(SnackBar(content: Text(msg)));
    } catch (e) {
      if (mounted) {
        setState(() {
          _busy = false;
          _status = '$e';
        });
      }
    } finally {
      if (mounted && _busy) setState(() => _busy = false);
    }
  }

  Future<void> _toggleLan() async {
    final messenger = ScaffoldMessenger.of(context);
    if (_lanRunning) {
      await LanSyncServer.stop();
      if (!mounted) return;
      setState(() {
        _lanRunning = false;
        _lanUrls = const [];
      });
      return;
    }
    try {
      final urls = await LanSyncServer.start(() => AppState.I.exportBackupJson());
      if (!mounted) return;
      setState(() {
        _lanRunning = true;
        _lanUrls = urls;
      });
      if (urls.isEmpty) {
        messenger.showSnackBar(
          const SnackBar(content: Text('已开启，但没拿到局域网 IP。确认手机连着 Wi-Fi。')),
        );
      }
    } catch (e) {
      messenger.showSnackBar(SnackBar(content: Text('$e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('同步')),
      body: Column(
        children: [
          _tabs(),
          const Divider(height: 1, color: C.border),
          Expanded(child: _tab == 0 ? _cloud() : _lan()),
        ],
      ),
    );
  }

  Widget _tabs() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 10, 12, 10),
      child: Row(
        children: [
          _tabChip('云同步', Icons.cloud_outlined, _tab == 0, () => setState(() => _tab = 0)),
          const SizedBox(width: 8),
          _tabChip('局域网同步', Icons.devices_other, _tab == 1, () => setState(() => _tab = 1)),
          const Spacer(),
          TextButton.icon(
            onPressed: _tutorial,
            icon: const Icon(Icons.menu_book_outlined, size: 14, color: C.purpleSoft),
            label: const Text('使用教程',
                style: TextStyle(fontSize: 11, color: C.purpleSoft)),
          ),
        ],
      ),
    );
  }

  Widget _tabChip(String label, IconData icon, bool on, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(20),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
        decoration: BoxDecoration(
          color: on ? C.purple : C.card,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: on ? C.purple : C.border, width: 0.6),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 14, color: on ? Colors.white : C.dim),
            const SizedBox(width: 5),
            Text(label,
                style: TextStyle(fontSize: 11.5, color: on ? Colors.white : C.dim)),
          ],
        ),
      ),
    );
  }

  Widget _cloud() {
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 28),
      children: [
        Container(
          padding: const EdgeInsets.fromLTRB(14, 13, 14, 14),
          decoration: BoxDecoration(
            color: C.card,
            borderRadius: BorderRadius.circular(13),
            border: Border.all(color: C.border, width: 0.6),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    width: 34,
                    height: 34,
                    decoration: BoxDecoration(
                      color: const Color(0x337B5CFF),
                      borderRadius: BorderRadius.circular(9),
                    ),
                    child: const Icon(Icons.cloud_sync_outlined,
                        size: 17, color: C.purpleSoft),
                  ),
                  const SizedBox(width: 10),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: const [
                      Text('云同步配置',
                          style: TextStyle(fontSize: 13, fontWeight: FontWeight.w500)),
                      SizedBox(height: 2),
                      Text('配置 WebDAV 服务（坚果云 / 群晖 / Nextcloud）',
                          style: TextStyle(fontSize: 10, color: C.faint)),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 14),
              _label('WebDAV 地址'),
              _field(_url, 'https://dav.example.com/dav/', false),
              const SizedBox(height: 10),
              _field(_user, '用户名 / 邮箱', false),
              const SizedBox(height: 10),
              _field(_pass, '密码 / 应用密码', true),
              const SizedBox(height: 10),
              _label('远程路径'),
              _field(_path, '/OpenWrite/', false),
              const SizedBox(height: 14),
              Row(
                children: [
                  Expanded(
                    child: SizedBox(
                      height: 40,
                      child: OutlinedButton.icon(
                        onPressed: _busy ? null : _test,
                        icon: const Icon(Icons.link, size: 15, color: C.purpleSoft),
                        label: const Text('测试连接',
                            style: TextStyle(fontSize: 12, color: C.purpleSoft)),
                        style: OutlinedButton.styleFrom(
                          side: const BorderSide(color: C.purple, width: 0.7),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(9)),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: SizedBox(
                      height: 40,
                      child: ElevatedButton.icon(
                        onPressed: _busy ? null : _save,
                        icon: const Icon(Icons.save_outlined,
                            size: 15, color: Colors.white),
                        label: const Text('保存配置',
                            style: TextStyle(fontSize: 12, color: Colors.white)),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: C.purple,
                          elevation: 0,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(9)),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              if (_busy)
                const Padding(
                  padding: EdgeInsets.only(top: 10),
                  child: LinearProgressIndicator(minHeight: 2, color: C.purple),
                ),
              if (_status.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(top: 9),
                  child: Text(_status,
                      style: const TextStyle(fontSize: 10.5, height: 1.5, color: C.dim)),
                ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        Container(
          padding: const EdgeInsets.fromLTRB(14, 12, 14, 14),
          decoration: BoxDecoration(
            color: C.card,
            borderRadius: BorderRadius.circular(13),
            border: Border.all(color: C.border, width: 0.6),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('备份与恢复',
                  style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w500)),
              const SizedBox(height: 4),
              const Text(
                '上传到上面那个目录里的 novel_app_backup.json。'
                '备份包含书稿、章节、对话、备忘录、生成历史和全部设置（含 API Key），别公开分享。',
                style: TextStyle(fontSize: 10, height: 1.6, color: C.dim),
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(
                    child: SizedBox(
                      height: 40,
                      child: OutlinedButton.icon(
                        onPressed: _busy ? null : _backup,
                        icon: const Icon(Icons.cloud_upload_outlined,
                            size: 15, color: C.text),
                        label: const Text('备份到云端',
                            style: TextStyle(fontSize: 12, color: C.text)),
                        style: OutlinedButton.styleFrom(
                          side: const BorderSide(color: C.border),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(9)),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: SizedBox(
                      height: 40,
                      child: OutlinedButton.icon(
                        onPressed: _busy ? null : _restore,
                        icon: const Icon(Icons.cloud_download_outlined,
                            size: 15, color: C.text),
                        label: const Text('从云端恢复',
                            style: TextStyle(fontSize: 12, color: C.text)),
                        style: OutlinedButton.styleFrom(
                          side: const BorderSide(color: C.border),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(9)),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _lan() {
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 28),
      children: [
        Container(
          padding: const EdgeInsets.fromLTRB(14, 14, 14, 15),
          decoration: BoxDecoration(
            color: C.card,
            borderRadius: BorderRadius.circular(13),
            border: Border.all(color: C.border, width: 0.6),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    width: 34,
                    height: 34,
                    decoration: BoxDecoration(
                      color: const Color(0x337B5CFF),
                      borderRadius: BorderRadius.circular(9),
                    ),
                    child: const Icon(Icons.lan_outlined, size: 17, color: C.purpleSoft),
                  ),
                  const SizedBox(width: 10),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(_lanRunning ? '局域网传输已开启' : '局域网传输未开启',
                          style: const TextStyle(
                              fontSize: 13, fontWeight: FontWeight.w500)),
                      const SizedBox(height: 2),
                      Text(
                        _lanRunning ? '电脑连同一个 Wi-Fi，用浏览器打开下面地址' : '不用装电脑端，手机开个临时网页',
                        style: const TextStyle(fontSize: 10, color: C.faint),
                      ),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 12),
              const Text(
                '开启后，手机在 8080~8084 里找一个空闲端口起一个临时网页，'
                '电脑浏览器打开就能下载当前全部数据的备份 JSON。'
                '关闭 App 或点停止就断开，数据只在局域网内传输，不经过任何服务器。',
                style: TextStyle(fontSize: 10.5, height: 1.7, color: C.dim),
              ),
              if (_lanRunning) ...[
                const SizedBox(height: 12),
                for (final u in _lanUrls)
                  Container(
                    margin: const EdgeInsets.only(bottom: 8),
                    padding: const EdgeInsets.fromLTRB(11, 9, 8, 9),
                    decoration: BoxDecoration(
                      color: C.surface,
                      borderRadius: BorderRadius.circular(9),
                      border: Border.all(color: C.border, width: 0.6),
                    ),
                    child: Row(
                      children: [
                        Expanded(
                          child: SelectableText(
                            u,
                            style: const TextStyle(
                                fontSize: 12, color: C.text, fontFamily: 'monospace'),
                          ),
                        ),
                        IconButton(
                          onPressed: () async {
                            await Clipboard.setData(ClipboardData(text: u));
                            if (!mounted) return;
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(content: Text('地址已复制')),
                            );
                          },
                          icon: const Icon(Icons.copy, size: 15, color: C.dim),
                          constraints:
                              const BoxConstraints(minWidth: 30, minHeight: 30),
                          padding: EdgeInsets.zero,
                        ),
                      ],
                    ),
                  ),
                if (_lanUrls.isEmpty)
                  const Text('还没拿到局域网 IP，确认手机连着 Wi-Fi 后重开一次。',
                      style: TextStyle(fontSize: 10.5, color: Color(0xFFE0A05C))),
              ],
              const SizedBox(height: 12),
              SizedBox(
                height: 42,
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: _toggleLan,
                  icon: Icon(_lanRunning ? Icons.stop_circle_outlined : Icons.play_circle_outline,
                      size: 16, color: Colors.white),
                  label: Text(_lanRunning ? '停止传输' : '开启局域网传输',
                      style: const TextStyle(fontSize: 13, color: Colors.white)),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _lanRunning ? C.cardHi : C.purple,
                    elevation: 0,
                    shape:
                        RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        Container(
          padding: const EdgeInsets.all(13),
          decoration: BoxDecoration(
            color: C.card,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: C.border, width: 0.6),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: const [
              Text('为什么不是「扫码配对电脑」',
                  style: TextStyle(fontSize: 12, fontWeight: FontWeight.w500)),
              SizedBox(height: 6),
              Text(
                '参考软件有一个 Windows 客户端，手机扫码就能连上，它靠的是桌面端在跑服务。'
                '我们没有桌面端，做扫码只能做个假配对。所以反过来：让手机当服务端，'
                '电脑用浏览器下载——同样是一根网线之内传数据，不需要装任何东西。',
                style: TextStyle(fontSize: 10.5, height: 1.7, color: C.dim),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _label(String text) => Padding(
        padding: const EdgeInsets.only(bottom: 5),
        child: Text(text, style: const TextStyle(fontSize: 10.5, color: C.dim)),
      );

  Widget _field(TextEditingController c, String hint, bool obscure) {
    return SizedBox(
      height: 42,
      child: TextField(
        controller: c,
        obscureText: obscure,
        style: const TextStyle(fontSize: 12.5, color: C.text),
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: const TextStyle(fontSize: 11.5, color: C.faint),
          filled: true,
          fillColor: C.surface,
          isDense: true,
          contentPadding: const EdgeInsets.symmetric(horizontal: 11, vertical: 10),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(9),
            borderSide: const BorderSide(color: C.border, width: 0.7),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(9),
            borderSide: const BorderSide(color: C.border, width: 0.7),
          ),
        ),
      ),
    );
  }

  void _tutorial() {
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: C.surface,
        title: const Text('同步怎么用', style: TextStyle(fontSize: 15)),
        content: const SingleChildScrollView(
          child: Text(
            '云同步（WebDAV）\n'
            '1. 以坚果云为例：网页端「账户信息 → 安全选项 → 添加应用」，'
            '拿到一串应用密码。\n'
            '2. 地址填 https://dav.jianguoyun.com/dav/，用户名填邮箱，密码填应用密码。\n'
            '3. 远程路径填 /OpenWrite/，点测试连接，成功再保存。\n'
            '4. 之后点「备份到云端」，换手机时点「从云端恢复」。\n\n'
            '局域网传输\n'
            '1. 手机和电脑连同一个 Wi-Fi。\n'
            '2. 点开启，把显示的地址输入电脑浏览器，会直接下载备份。\n'
            '3. 关闭 App 或点停止即断开。',
            style: TextStyle(fontSize: 12, height: 1.75),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('知道了', style: TextStyle(color: C.purpleSoft)),
          ),
        ],
      ),
    );
  }

  String _size(int bytes) {
    if (bytes < 1024) return '$bytes B';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB';
    return '${(bytes / 1024 / 1024).toStringAsFixed(1)} MB';
  }
}
