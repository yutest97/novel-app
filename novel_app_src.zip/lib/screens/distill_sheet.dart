import 'package:flutter/material.dart';

import '../skill_import.dart';
import '../store.dart';
import '../theme.dart';

/// 弹出「风格蒸馏」面板
Future<void> showDistillSheet(BuildContext context) {
  return showModalBottomSheet<void>(
    context: context,
    backgroundColor: Colors.transparent,
    isScrollControlled: true,
    builder: (_) => const DistillSheet(),
  );
}

class DistillSheet extends StatefulWidget {
  const DistillSheet({super.key});

  @override
  State<DistillSheet> createState() => _DistillSheetState();
}

class _DistillSheetState extends State<DistillSheet> {
  final TextEditingController _name = TextEditingController();
  String _fileName = '';
  String _sample = '';
  bool _picking = false;

  static const int _maxChars = 100000;

  @override
  void dispose() {
    _name.dispose();
    super.dispose();
  }

  int get _len => _sample.replaceAll(RegExp(r'\s'), '').length;

  Future<void> _pick() async {
    final messenger = ScaffoldMessenger.of(context);
    setState(() => _picking = true);
    try {
      final picked = await pickTextFile();
      if (picked == null) return;
      final text = picked.content.trim();
      if (text.isEmpty) {
        messenger.showSnackBar(
          const SnackBar(content: Text('这个文件读不出文字（docx 可能加密或损坏）')),
        );
        return;
      }
      if (!mounted) return;
      setState(() {
        _fileName = picked.name;
        _sample = text.length > _maxChars ? text.substring(0, _maxChars) : text;
        if (_name.text.trim().isEmpty) {
          _name.text = picked.name.replaceAll(RegExp(r'\.(txt|md|markdown|docx)$', caseSensitive: false), '');
        }
      });
    } on SkillPickException catch (e) {
      messenger.showSnackBar(
        SnackBar(content: Text(e.message), duration: const Duration(seconds: 6)),
      );
    } catch (e) {
      messenger.showSnackBar(
        SnackBar(content: Text('选择文件失败：$e'), duration: const Duration(seconds: 6)),
      );
    } finally {
      if (mounted) setState(() => _picking = false);
    }
  }

  Future<void> _start() async {
    final name = _name.text.trim();
    if (name.isEmpty || _sample.isEmpty) return;
    final navigator = Navigator.of(context);
    final messenger = ScaffoldMessenger.of(context);
    navigator.pop();
    messenger.showSnackBar(
      SnackBar(content: Text('开始蒸馏「$name」，大约 1~2 分钟，过程中可以停止')),
    );
    await AppState.I.distillStyle(name: name, sample: _sample);
  }

  @override
  Widget build(BuildContext context) {
    final canStart = _name.text.trim().isNotEmpty && _sample.isNotEmpty;
    return Container(
      decoration: const BoxDecoration(
        color: C.surface,
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
      child: SafeArea(
        top: false,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 38,
                height: 4,
                margin: const EdgeInsets.only(bottom: 12),
                decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(2)),
              ),
            ),
            Row(
              children: [
                Container(
                  width: 26,
                  height: 26,
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(colors: [Color(0xFF9B7BFF), Color(0xFF5B3FE0)]),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Icon(Icons.auto_fix_high, size: 14, color: Colors.white),
                ),
                const SizedBox(width: 9),
                const Text('风格蒸馏', style: TextStyle(fontSize: 15.5, fontWeight: FontWeight.w600)),
                const Spacer(),
                IconButton(
                  onPressed: () => Navigator.pop(context),
                  icon: const Icon(Icons.close, size: 18, color: C.dim),
                  constraints: const BoxConstraints(minWidth: 32, minHeight: 32),
                  padding: EdgeInsets.zero,
                ),
              ],
            ),
            const SizedBox(height: 6),
            const Text(
              '上传小说文本，AI 将分析其写作风格并创建一个可复用的风格 Skill。可蒸馏自己或他人的写作风格。',
              style: TextStyle(fontSize: 12, height: 1.7, color: C.dim),
            ),
            const SizedBox(height: 14),

            // 风格名称
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 2),
              decoration: BoxDecoration(
                color: const Color(0xFF12121B),
                borderRadius: BorderRadius.circular(11),
                border: Border.all(color: C.border, width: 0.8),
              ),
              child: Row(
                children: [
                  const Icon(Icons.edit_outlined, size: 15, color: C.dim),
                  const SizedBox(width: 8),
                  Expanded(
                    child: TextField(
                      controller: _name,
                      onChanged: (_) => setState(() {}),
                      style: const TextStyle(fontSize: 13.5, color: C.text),
                      decoration: const InputDecoration(
                        hintText: '风格名称',
                        hintStyle: TextStyle(fontSize: 13, color: C.faint),
                        contentPadding: EdgeInsets.symmetric(vertical: 13),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 10),

            // 上传区
            GestureDetector(
              onTap: _picking ? null : _pick,
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(vertical: 22),
                decoration: BoxDecoration(
                  color: const Color(0xFF12121B),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: _fileName.isEmpty ? C.border : const Color(0xFF3B2F6B),
                    width: _fileName.isEmpty ? 0.8 : 1,
                  ),
                ),
                child: Column(
                  children: [
                    Icon(
                      _fileName.isEmpty ? Icons.upload_file : Icons.description,
                      size: 26,
                      color: _fileName.isEmpty ? C.dim : C.purpleSoft,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      _fileName.isEmpty
                          ? (_picking ? '读取中…' : '点击选择或拖入文件（支持 txt、md、docx）')
                          : _fileName,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 12.5,
                        color: _fileName.isEmpty ? C.dim : C.purpleSoft,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      _fileName.isEmpty ? '最大支持 10 万字' : '$_len 字 · 再点一次可换文件',
                      style: const TextStyle(fontSize: 10.5, color: C.faint),
                    ),
                  ],
                ),
              ),
            ),

            if (_sample.length >= 20000)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Text(
                  '样本较长，蒸馏时只会把前 2 万字发给模型（足够抓风格，省费用）',
                  style: TextStyle(fontSize: 10.5, color: Colors.orange.shade200),
                ),
              ),

            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('取消', style: TextStyle(fontSize: 13, color: C.dim)),
                ),
                const SizedBox(width: 8),
                SizedBox(
                  height: 42,
                  child: ElevatedButton.icon(
                    onPressed: canStart ? _start : null,
                    icon: const Icon(Icons.auto_fix_high, size: 16),
                    label: const Text('开始蒸馏', style: TextStyle(fontSize: 13.5)),
                    style: ButtonStyle(
                      backgroundColor: MaterialStateProperty.all<Color>(
                        canStart ? C.purple : C.cardHi,
                      ),
                      foregroundColor: MaterialStateProperty.all<Color>(
                        canStart ? Colors.white : C.faint,
                      ),
                      shape: MaterialStateProperty.all(
                        RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
                      ),
                      padding: MaterialStateProperty.all(
                        const EdgeInsets.symmetric(horizontal: 18),
                      ),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
          ],
        ),
      ),
    );
  }
}
